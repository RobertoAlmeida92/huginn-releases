@echo off
title HUGINN - Servidor Local
chcp 65001 > nul
cls
echo ===================================================================
echo     HUGINN - Plataforma de Inteligência & Análise Telemática
echo     Digital Investigation & Police Intelligence System
echo ===================================================================
echo.
echo [*] Iniciando o servidor local do Huginn...
echo [*] Abrindo a Janela Própria de Aplicativo em instantes...
echo.

cd /d "%~dp0"
python run.py

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [*] Tentando inicializar via 'py run.py'...
    py run.py
)

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERRO] Nao foi possivel iniciar o servidor. Verifique se o Python esta instalado.
    pause
)

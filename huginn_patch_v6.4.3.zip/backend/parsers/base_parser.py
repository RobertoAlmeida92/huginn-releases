from abc import ABC, abstractmethod
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Optional

class BaseParser(ABC):
    """
    Classe abstrata base para parsers de dados de quebras judiciais da Meta (Instagram / WhatsApp).
    """

    @abstractmethod
    def parse_file(
        self,
        file_path: str,
        operation_id: int,
        phase_id: int,
        target_id: int,
        phase_target_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Lê e extrai os dados do arquivo/diretório e persiste vinculado à Operação, Fase e Alvo.
        """
        pass

    @staticmethod
    def utc_to_brt(utc_str: Optional[str]) -> Optional[str]:
        """
        Converte string timestamp em UTC ('YYYY-MM-DD HH:MM:SS UTC' ou ISO) para Horário de Brasília (UTC-3).
        """
        if not utc_str:
            return None
        
        utc_clean = utc_str.replace(" UTC", "").strip()
        formats = [
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%d/%m/%Y %H:%M:%S",
            "%d/%m/%Y %H:%M"
        ]
        
        dt = None
        for fmt in formats:
            try:
                dt = datetime.strptime(utc_clean, fmt)
                break
            except ValueError:
                continue
                
        if dt is None:
            return utc_str
            
        brt_dt = dt - timedelta(hours=3)
        return brt_dt.strftime("%d/%m/%Y %H:%M:%S (BRT)")

    @staticmethod
    def format_phone(phone_str: Optional[str]) -> Optional[str]:
        """
        Formata números de telefone para padrão legível nacional/internacional.
        """
        if not phone_str:
            return None
        clean = "".join([c for c in phone_str if c.isdigit()])
        if clean.startswith("55") and len(clean) in [12, 13]:
            ddd = clean[2:4]
            rest = clean[4:]
            if len(rest) == 9:
                return f"+55 ({ddd}) {rest[:5]}-{rest[5:]}"
            elif len(rest) == 8:
                return f"+55 ({ddd}) {rest[:4]}-{rest[4:]}"
        return phone_str

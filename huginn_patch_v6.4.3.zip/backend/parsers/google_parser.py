import os
import re
import csv
import io
import json
import mailbox
import email
from email.header import decode_header
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional, Tuple
from bs4 import BeautifulSoup

# Fuso horário Brasília (UTC-3)
BRT_TZ = timezone(timedelta(hours=-3))

def decode_rfc2047(header_val: Optional[str]) -> str:
    if not header_val:
        return ""
    try:
        decoded_parts = decode_header(header_val)
        result = []
        for part, enc in decoded_parts:
            if isinstance(part, bytes):
                encoding = enc or 'utf-8'
                try:
                    result.append(part.decode(encoding, errors='replace'))
                except Exception:
                    result.append(part.decode('latin1', errors='replace'))
            else:
                result.append(str(part))
        return " ".join(result).strip()
    except Exception:
        return str(header_val)

def parse_utc_to_brt(date_str: Optional[str]) -> Tuple[str, str]:
    """
    Converte datas do Google (formatos variados) para UTC e BRT padronizados.
    Formatos comuns:
    '2022-10-01 22:44:57 Z', '2025-06-18 00:20:50 UTC', '2025-07-07T21:22:29.811896Z'
    """
    if not date_str:
        return "", ""
    
    clean = date_str.strip().replace(" UTC", "Z").replace(" GMT", "Z").replace("\u202f", " ")
    
    dt = None
    formats = [
        "%Y-%m-%d %H:%M:%S%z",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%d %H:%M:%SZ",
        "%a, %d %b %Y %H:%M:%S %z",
        "%d %b %Y %H:%M:%S %z",
        "%b %d, %Y, %I:%M:%S %p %Z",
        "%B %d, %Y, %I:%M:%S %p %Z"
    ]

    # Normalizar Z para +00:00 se necessário
    if clean.endswith('Z'):
        iso_clean = clean[:-1] + "+00:00"
        try:
            dt = datetime.fromisoformat(iso_clean)
        except Exception:
            pass

    if not dt:
        for fmt in formats:
            try:
                dt = datetime.strptime(clean.replace("Z", ""), fmt)
                if not dt.tzinfo:
                    dt = dt.replace(tzinfo=timezone.utc)
                break
            except Exception:
                continue

    if dt:
        dt_utc = dt.astimezone(timezone.utc)
        dt_brt = dt.astimezone(BRT_TZ)
        return dt_utc.strftime("%Y-%m-%d %H:%M:%S UTC"), dt_brt.strftime("%d/%m/%Y %H:%M:%S (BRT)")
    
    return str(date_str), str(date_str)


class GoogleParser:
    """
    Analisador de pacotes periciais do Google LERS (Law Enforcement Request System).
    """

    @staticmethod
    def parse_subscriber_info(html_content: str) -> Dict[str, Any]:
        """
        Extrai os dados cadastrais completos e a tabela de logins do SubscriberInfo.html.
        """
        soup = BeautifulSoup(html_content, 'html.parser')
        data = {
            "google_account_id": "",
            "full_name": "",
            "given_name": "",
            "family_name": "",
            "email": "",
            "created_at_utc": "",
            "created_at_brt": "",
            "terms_ip": "",
            "terms_language": "",
            "terms_country": "",
            "provider": "",
            "birthday": "",
            "services_list": "",
            "status": "",
            "last_updated_utc": "",
            "last_updated_brt": "",
            "last_logins": "",
            "contact_email": "",
            "recovery_email": "",
            "recovery_sms": "",
            "login_history": []
        }

        # Extrair itens da lista cadastral
        for li in soup.find_all('li'):
            text = li.get_text(separator=' ', strip=True)
            if ':' not in text:
                continue
            key, val = text.split(':', 1)
            key = key.strip().lower()
            val = val.strip()

            if "google account id" in key:
                data["google_account_id"] = val
            elif key == "name":
                data["full_name"] = val
            elif "given name" in key:
                data["given_name"] = val
            elif "family name" in key:
                data["family_name"] = val
            elif key == "e-mail":
                data["email"] = val.lower()
            elif "created on" in key:
                u, b = parse_utc_to_brt(val)
                data["created_at_utc"] = u
                data["created_at_brt"] = b
            elif "terms of service ip" in key:
                data["terms_ip"] = val
            elif "terms of service language" in key:
                data["terms_language"] = val
            elif "terms of service country" in key:
                data["terms_country"] = val
            elif "provider for consumer services" in key:
                data["provider"] = val
            elif "birthday" in key:
                data["birthday"] = val
            elif "services" in key:
                data["services_list"] = val
            elif key == "status":
                data["status"] = val
            elif "last updated date" in key:
                u, b = parse_utc_to_brt(val)
                data["last_updated_utc"] = u
                data["last_updated_brt"] = b
            elif "last logins" in key:
                data["last_logins"] = val
            elif "contact e-mail" in key:
                data["contact_email"] = val.lower()
            elif "recovery e-mail" in key:
                data["recovery_email"] = val.lower()
            elif "recovery sms" in key:
                data["recovery_sms"] = val

        # Se full_name estiver vazio, unir given + family
        if not data["full_name"] and (data["given_name"] or data["family_name"]):
            data["full_name"] = f"{data['given_name']} {data['family_name']}".strip()

        # Extrair histórico de logins e acessos da tabela
        tables = soup.find_all('table')
        for t in tables:
            headers = [th.get_text(strip=True).lower() for th in t.find_all('th')]
            if any('ip address' in h for h in headers) or any('timestamp' in h for h in headers):
                rows = t.find_all('tr')
                for row in rows[1:]:
                    tds = [td.get_text(strip=True) for td in row.find_all('td')]
                    if len(tds) >= 2:
                        raw_time = tds[0] if len(tds) > 0 else ""
                        ip = tds[1] if len(tds) > 1 else ""
                        act_type = tds[2] if len(tds) > 2 else "Login"
                        android_id = tds[3] if len(tds) > 3 else ""
                        user_agent = tds[5] if len(tds) > 5 else (tds[4] if len(tds) > 4 else "")
                        
                        u, b = parse_utc_to_brt(raw_time)
                        data["login_history"].append({
                            "timestamp_utc": u,
                            "timestamp_brt": b,
                            "ip_address": ip,
                            "event_type": act_type or "Login",
                            "android_id": android_id,
                            "user_agent": user_agent
                        })

        return data

    @staticmethod
    def parse_device_profile(html_content: str, fallback_android_id: str = "") -> List[Dict[str, Any]]:
        """
        Extrai informações de hardware, aparelhos celulares e versões do Android de DeviceAndUserProfile.html.
        """
        soup = BeautifulSoup(html_content, 'html.parser')
        devices = []

        # Tabela 3: Conexões de Build / Hardware
        tables = soup.find_all('table')
        for t in tables:
            headers = [th.get_text(strip=True).lower() for th in t.find_all('th')]
            if 'build fingerprint' in headers or 'brand' in headers:
                col_map = {h: i for i, h in enumerate(headers)}
                for row in t.find_all('tr')[1:]:
                    tds = [td.get_text(strip=True) for td in row.find_all('td')]
                    if not tds:
                        continue
                    
                    conn_time = tds[col_map['connection time']] if 'connection time' in col_map and len(tds) > col_map['connection time'] else ""
                    build = tds[col_map['build fingerprint']] if 'build fingerprint' in col_map and len(tds) > col_map['build fingerprint'] else ""
                    product = tds[col_map['product']] if 'product' in col_map and len(tds) > col_map['product'] else ""
                    brand = tds[col_map['brand']] if 'brand' in col_map and len(tds) > col_map['brand'] else ""
                    radio = tds[col_map['radio firmware version']] if 'radio firmware version' in col_map and len(tds) > col_map['radio firmware version'] else ""
                    bootloader = tds[col_map['bootloader firmware version']] if 'bootloader firmware version' in col_map and len(tds) > col_map['bootloader firmware version'] else ""
                    play_ver = tds[col_map['google play services version']] if 'google play services version' in col_map and len(tds) > col_map['google play services version'] else ""

                    u, b = parse_utc_to_brt(conn_time)
                    
                    # Identificar modelo comercial legível a partir do build fingerprint
                    # Ex: samsung/a06ub/a06:14/UP1A.231005.007/... -> Samsung Galaxy A06
                    model_display = product or brand
                    if brand and brand.lower() == 'samsung' and '/' in build:
                        parts = build.split('/')
                        if len(parts) > 2:
                            model_display = f"Samsung Galaxy {parts[2].upper()}"

                    devices.append({
                        "android_id": fallback_android_id,
                        "brand": (brand or "Android").capitalize(),
                        "model": model_display,
                        "product": product,
                        "build_fingerprint": build,
                        "radio_firmware": radio,
                        "bootloader_firmware": bootloader,
                        "play_services_version": play_ver,
                        "roaming_state": "",
                        "connection_time_utc": u,
                        "connection_time_brt": b,
                        "http_response_code": "200"
                    })

        # Se não achou tabela com fingerprint, criar um registro básico com o fallback_android_id
        if not devices and fallback_android_id:
            devices.append({
                "android_id": fallback_android_id,
                "brand": "Android",
                "model": f"Dispositivo Android ({fallback_android_id})",
                "product": "",
                "build_fingerprint": "",
                "radio_firmware": "",
                "bootloader_firmware": "",
                "play_services_version": "",
                "roaming_state": "",
                "connection_time_utc": "",
                "connection_time_brt": "",
                "http_response_code": ""
            })

        return devices

    @staticmethod
    def parse_maps_places(json_content: str) -> List[Dict[str, Any]]:
        """
        Extrai lugares salvos/rotulados pelo alvo no Google Maps (Home, Work, etc.).
        """
        places = []
        try:
            data = json.loads(json_content)
            features = data.get("features", [])
            for feat in features:
                props = feat.get("properties", {})
                geom = feat.get("geometry", {})
                coords = geom.get("coordinates", [])
                
                if len(coords) >= 2:
                    lon = float(coords[0])
                    lat = float(coords[1])
                    name = props.get("name", "Local Salvo")
                    addr = props.get("address", "")
                    
                    loc_type = "Labeled"
                    if "home" in name.lower():
                        loc_type = "Home"
                    elif "work" in name.lower():
                        loc_type = "Work"

                    places.append({
                        "source": "maps",
                        "location_type": loc_type,
                        "name": name,
                        "address": addr,
                        "latitude": lat,
                        "longitude": lon,
                        "raw_json": json.dumps(feat)
                    })
        except Exception as e:
            print(f"[GoogleParser] Erro ao parsear Maps Places: {e}")

        return places

    @staticmethod
    def parse_waze(activity_csv: Optional[str] = None, account_csv: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Extrai locais favoritos e trajetos salvos no Waze com coordenadas GPS.
        """
        locations = []
        if not activity_csv:
            return locations

        lines = activity_csv.splitlines()
        in_favorites = False
        fav_headers = []

        coord_regex = re.compile(r'\(([-0-9.]+)\s+([-0-9.]+)\)')

        for line in lines:
            line_str = line.strip()
            if not line_str:
                continue

            if "Favorites" in line_str:
                in_favorites = True
                continue

            if in_favorites:
                if not fav_headers and "Place" in line_str:
                    fav_headers = [h.strip().lower() for h in line_str.split(',')]
                    continue

                if fav_headers:
                    # Linha de dados: Place, Name, Type
                    parts = [p.strip() for p in line_str.split(',')]
                    if len(parts) >= 2:
                        place_str = parts[0]
                        name = parts[1] if len(parts) > 1 else "Favorito Waze"
                        ltype = parts[2] if len(parts) > 2 else "Favorite"

                        # Extrair coordenadas do padrão: Brasil BA Salvador ... (-38.469348 -13.010799)
                        m = coord_regex.search(place_str)
                        if m:
                            c1 = float(m.group(1))
                            c2 = float(m.group(2))
                            # Identificar qual é lat e qual é lon (no Brasil, lat fica entre -35 e +6, lon entre -75 e -34)
                            if -35.0 <= c2 <= 6.0:
                                lat, lon = c2, c1
                            else:
                                lat, lon = c1, c2

                            clean_address = coord_regex.sub('', place_str).strip()

                            locations.append({
                                "source": "waze",
                                "location_type": ltype,
                                "name": name,
                                "address": clean_address,
                                "latitude": lat,
                                "longitude": lon,
                                "raw_json": json.dumps({"place": place_str, "name": name, "type": ltype})
                            })

        return locations

    @staticmethod
    def parse_mbox(mbox_file_path: str, default_folder: str = "INBOX", metadata_map: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Extrai e-mails completos de um arquivo .mbox usando a biblioteca nativa mailbox.
        """
        emails = []
        if not os.path.exists(mbox_file_path):
            return emails

        metadata_map = metadata_map or {}

        try:
            mb = mailbox.mbox(mbox_file_path)
            for key, msg in mb.items():
                try:
                    subject = decode_rfc2047(msg.get('Subject', 'Sem Assunto'))
                    from_addr = decode_rfc2047(msg.get('From', ''))
                    to_addr = decode_rfc2047(msg.get('To', ''))
                    cc_addr = decode_rfc2047(msg.get('Cc', ''))
                    bcc_addr = decode_rfc2047(msg.get('Bcc', ''))
                    date_raw = msg.get('Date', '')
                    msg_id = msg.get('Message-ID', f"msg_{key}")

                    u_date, b_date = parse_utc_to_brt(date_raw)

                    body_text = ""
                    body_html = ""
                    attachments = []

                    if msg.is_multipart():
                        for part in msg.walk():
                            content_type = part.get_content_type()
                            disposition = str(part.get('Content-Disposition', ''))
                            fn = part.get_filename()

                            if fn:
                                fn_decoded = decode_rfc2047(fn)
                                payload = part.get_payload(decode=True) or b""
                                attachments.append({
                                    "filename": fn_decoded,
                                    "content_type": content_type,
                                    "size_bytes": len(payload)
                                })
                            elif content_type == 'text/plain' and 'attachment' not in disposition:
                                payload = part.get_payload(decode=True)
                                if payload:
                                    body_text += payload.decode('utf-8', errors='replace')
                            elif content_type == 'text/html' and 'attachment' not in disposition:
                                payload = part.get_payload(decode=True)
                                if payload:
                                    body_html += payload.decode('utf-8', errors='replace')
                    else:
                        payload = msg.get_payload(decode=True)
                        if payload:
                            text_str = payload.decode('utf-8', errors='replace')
                            if msg.get_content_type() == 'text/html':
                                body_html = text_str
                            else:
                                body_text = text_str

                    # Snippet para a listagem rápida
                    clean_snippet = body_text.strip() if body_text else BeautifulSoup(body_html, 'html.parser').get_text()
                    snippet = re.sub(r'\s+', ' ', clean_snippet)[:160]

                    # Cruzar com metadados do Gmail (MessageInformation) se disponíveis
                    meta = metadata_map.get(str(msg_id)) or metadata_map.get(str(key)) or {}
                    is_trash = 1 if ('trash' in default_folder.lower() or meta.get('is_trash')) else 0
                    is_deleted = 1 if ('deleted' in default_folder.lower() or meta.get('is_deleted')) else 0
                    is_spam = 1 if ('spam' in default_folder.lower() or meta.get('is_spam')) else 0

                    folder = default_folder
                    if is_trash:
                        folder = "Lixeira"
                    elif is_deleted:
                        folder = "Excluídos"
                    elif is_spam:
                        folder = "Spam"
                    elif "sent" in default_folder.lower():
                        folder = "Enviados"
                    else:
                        folder = "Caixa de Entrada"

                    emails.append({
                        "message_id": msg_id,
                        "thread_id": meta.get("thread_id", ""),
                        "server_id": meta.get("server_id", ""),
                        "folder": folder,
                        "date_utc": u_date,
                        "date_brt": b_date,
                        "from_address": from_addr,
                        "to_address": to_addr,
                        "cc_address": cc_addr,
                        "bcc_address": bcc_addr,
                        "subject": subject,
                        "snippet": snippet,
                        "body_text": body_text,
                        "body_html": body_html,
                        "has_attachments": 1 if len(attachments) > 0 else 0,
                        "attachments_json": json.dumps(attachments),
                        "is_read": 1 if meta.get("is_opened") else 0,
                        "is_starred": 0,
                        "is_trash": is_trash,
                        "is_spam": is_spam,
                        "is_deleted": is_deleted,
                        "status_action_date": meta.get("status_date", ""),
                        "size_bytes": len(str(msg))
                    })
                except Exception as ex:
                    print(f"[GoogleParser] Erro ao parsear mensagem {key}: {ex}")
                    continue

        except Exception as e:
            print(f"[GoogleParser] Erro ao abrir MBOX {mbox_file_path}: {e}")

        return emails

    @staticmethod
    def parse_access_log_devices(csv_content: str) -> List[Dict[str, Any]]:
        """
        Extrai dispositivos e aparelhos (iOS, Android, Windows, etc.) a partir
        do arquivo CSV de atividades do Google (AccessLogActivity).
        """
        devices = []
        if not csv_content:
            return devices

        try:
            reader = csv.DictReader(io.StringIO(csv_content))
            for row in reader:
                ua = (row.get("User Agent String") or "").strip()
                aid = (row.get("Android ID") or "").strip()
                if aid == "0":
                    aid = ""
                ts = (row.get("Activity Timestamp") or "").strip()
                product = (row.get("Product Name") or "").strip()

                if not ua and not aid:
                    continue

                u, b = parse_utc_to_brt(ts)

                brand = "Dispositivo"
                model = "Aparelho Desconhecido"
                os_type = "Outro"

                # 1. Detecção de Apple iOS (iPhone / iPad)
                if "IOS_OS" in ua or "iPhone" in ua or "iPad" in ua:
                    brand = "Apple"
                    os_type = "iOS"
                    m_ios = re.search(r'Os Version\s*:\s*([\d\.]+)', ua)
                    if not m_ios:
                        m_ios = re.search(r'OS ([\d_]+)', ua)
                    ver = m_ios.group(1).replace('_', '.') if m_ios else ""
                    model = f"Apple iPhone (iOS {ver})" if ver else "Apple iPhone"
                    if "iPad" in ua:
                        model = f"Apple iPad (iOS {ver})" if ver else "Apple iPad"

                # 2. Detecção de Android
                elif "Android" in ua or aid:
                    brand = "Android"
                    os_type = "Android"
                    model = "Dispositivo Android"
                    
                    m_sm = re.search(r';\s*([A-Z0-9\-_]+(?:[A-Z0-9\-_]+)?)\s*Build', ua, re.IGNORECASE)
                    if m_sm:
                        mod_code = m_sm.group(1).strip()
                        if mod_code.startswith("SM-"):
                            brand = "Samsung"
                            model = f"Samsung {mod_code}"
                        elif "moto" in mod_code.lower():
                            brand = "Motorola"
                            model = f"Motorola {mod_code}"
                        else:
                            model = f"Android ({mod_code})"
                    elif "Samsung" in ua:
                        brand = "Samsung"
                        model = "Samsung Galaxy"
                    elif "Motorola" in ua:
                        brand = "Motorola"
                        model = "Motorola"

                # 3. Detecção de Desktop (Windows, Mac, Linux)
                elif "Windows" in ua:
                    brand = "Microsoft"
                    os_type = "Windows"
                    model = "Computador Windows"
                elif "Macintosh" in ua or "Mac OS" in ua:
                    brand = "Apple"
                    os_type = "macOS"
                    model = "Computador Mac OS X"
                elif "Linux" in ua:
                    brand = "Linux"
                    os_type = "Linux"
                    model = "Computador Linux"

                devices.append({
                    "android_id": aid,
                    "brand": brand,
                    "model": model,
                    "product": product or os_type,
                    "build_fingerprint": ua,
                    "radio_firmware": "",
                    "bootloader_firmware": "",
                    "play_services_version": "",
                    "roaming_state": "",
                    "connection_time_utc": u,
                    "connection_time_brt": b,
                    "http_response_code": "200"
                })
        except Exception as ex:
            print(f"[GoogleParser] Erro ao parsear AccessLogActivity: {ex}")

        return devices

    @staticmethod
    def parse_google_photo_metadata(json_content: str, filename: str) -> Dict[str, Any]:
        """
        Extrai metadados periciais (título, timestamp, coordenadas GPS e EXIF hash)
        do arquivo de metadados JSON do Google Photos.
        """
        data = {
            "title": filename,
            "capture_time_utc": "",
            "capture_time_brt": "",
            "latitude": None,
            "longitude": None,
            "exif_hash": "",
            "description": "",
            "is_deleted": 0
        }

        if not json_content:
            return data

        try:
            # Sanitizar JSON quebrado gerado pelo exportador do Google
            clean = re.sub(r'{\s*,', '{', json_content)
            clean = re.sub(r',\s*}', '}', clean)
            js = json.loads(clean)

            # Título
            t = js.get("photoTextFields", {}).get("photo", {}).get("header", {}).get("title")
            if t:
                data["title"] = t

            # Descrição
            d = js.get("photoTextFields", {}).get("photo", {}).get("header", {}).get("description")
            if d:
                data["description"] = d

            # Hash EXIF
            exif_hash = js.get("photoExif", {}).get("photo", {}).get("body", {}).get("exifOriginHash")
            if exif_hash:
                data["exif_hash"] = exif_hash

            # Timestamp de captura / criação
            ts_dict = js.get("photoTimestamps", {}).get("photo", {}).get("header", {})
            raw_ts = ts_dict.get("creationTime") or ts_dict.get("timeStamp") or ts_dict.get("asyncCreateCompleteTimeMs")
            if raw_ts:
                try:
                    val = int(raw_ts)
                    if val > 10000000000:
                        val = val / 1000.0
                    dt_utc = datetime.fromtimestamp(val, tz=timezone.utc)
                    dt_brt = dt_utc.astimezone(BRT_TZ)
                    data["capture_time_utc"] = dt_utc.strftime("%Y-%m-%d %H:%M:%S UTC")
                    data["capture_time_brt"] = dt_brt.strftime("%d/%m/%Y %H:%M:%S (BRT)")
                except Exception:
                    data["capture_time_utc"] = str(raw_ts)
                    data["capture_time_brt"] = str(raw_ts)

            # Geolocalização (GPS)
            loc_body = js.get("photoLocationInformation", {}).get("photo", {}).get("header", {}).get("geoinfo", {})
            lat = loc_body.get("latitude")
            lon = loc_body.get("longitude")

            if not lat or not lon:
                exif_loc = js.get("photoLocationInformation", {}).get("exifLocation", {}).get("geoLocation", {})
                lat = exif_loc.get("latitudeDegrees")
                lon = exif_loc.get("longitudeDegrees")

            if lat is not None and lon is not None:
                flat, flon = float(lat), float(lon)
                if flat != 0.0 or flon != 0.0:
                    data["latitude"] = flat
                    data["longitude"] = flon

            # Excluído
            del_info = js.get("deletedPhotos", {}).get("photo", {})
            if del_info and isinstance(del_info, dict) and len(del_info) > 0:
                data["is_deleted"] = 1

        except Exception as ex:
            print(f"[GoogleParser] Erro ao extrair metadados de foto {filename}: {ex}")

        return data

    @staticmethod
    def parse_chrome_history(json_content: str) -> List[Dict[str, Any]]:
        """
        Extrai URLs, títulos e timestamps do arquivo History.json do Chrome.
        """
        results = []
        if not json_content:
            return results

        try:
            data = json.loads(json_content)
            raw_list = data.get("Browser History", [])
            for item in raw_list:
                url = (item.get("url") or "").strip()
                if not url:
                    continue
                title = (item.get("title") or url).strip()
                time_usec = item.get("time_usec", 0)
                u_str, b_str = "", ""
                if time_usec:
                    ts_sec = time_usec / 1_000_000.0
                    try:
                        dt_u = datetime.fromtimestamp(ts_sec, tz=timezone.utc)
                        u_str = dt_u.strftime("%Y-%m-%d %H:%M:%S UTC")
                        b_str = dt_u.astimezone(BRT_TZ).strftime("%d/%m/%Y %H:%M:%S (BRT)")
                    except Exception:
                        pass

                results.append({
                    "url": url,
                    "title": title,
                    "visit_time_utc": u_str,
                    "visit_time_brt": b_str,
                    "transition": item.get("page_transition", ""),
                    "raw_json": json.dumps(item)
                })
        except Exception as ex:
            print(f"[GoogleParser] Erro ao parsear Chrome History: {ex}")

        return results

    @staticmethod
    def parse_chrome_bookmarks(json_content: str) -> List[Dict[str, Any]]:
        """
        Extrai os favoritos salvos do arquivo Bookmarks.json do Chrome.
        """
        results = []
        if not json_content:
            return results

        try:
            data = json.loads(json_content)
            roots = data.get("roots", {})

            def _traverse(node, folder_name="Favoritos"):
                if isinstance(node, dict):
                    node_type = node.get("type", "")
                    if node_type == "url":
                        url = node.get("url", "")
                        name = node.get("name", "") or url
                        raw_date = node.get("date_added", "0")
                        u_str, b_str = "", ""
                        try:
                            # Windows/WebKit epoch (micros since 1601-01-01) ou UNIX micros
                            val = int(raw_date)
                            if val > 11644473600000000:
                                val = (val - 11644473600000000) / 1_000_000.0
                            elif val > 1000000000000:
                                val = val / 1_000_000.0
                            dt_u = datetime.fromtimestamp(val, tz=timezone.utc)
                            u_str = dt_u.strftime("%Y-%m-%d %H:%M:%S UTC")
                            b_str = dt_u.astimezone(BRT_TZ).strftime("%d/%m/%Y %H:%M:%S (BRT)")
                        except Exception:
                            pass

                        results.append({
                            "title": name,
                            "url": url,
                            "folder": folder_name,
                            "date_added_utc": u_str,
                            "date_added_brt": b_str
                        })
                    elif node_type == "folder" or "children" in node:
                        curr_folder = node.get("name", folder_name)
                        for child in node.get("children", []):
                            _traverse(child, curr_folder)

            for root_key in ["bookmark_bar", "other", "synced"]:
                if root_key in roots:
                    _traverse(roots[root_key], roots[root_key].get("name", "Favoritos"))

        except Exception as ex:
            print(f"[GoogleParser] Erro ao parsear Chrome Bookmarks: {ex}")

        return results

    @staticmethod
    def parse_my_activity_html(html_content: str, default_product: str = "Search") -> List[Dict[str, Any]]:
        """
        Extrai pesquisas, termos buscados, URLs e gravações de áudio .mp3 do MyActivity.html.
        """
        results = []
        if not html_content:
            return results

        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            date_pattern = re.compile(r'([A-Za-z]{3,9}\s+\d{1,2},\s+\d{4},\s+\d{1,2}:\d{2}:\d{2}\s+(?:AM|PM)(?:\s+[A-Za-z]{1,4})?)')

            for cell in soup.find_all('div', class_='outer-cell'):
                header_el = cell.find('div', class_='header-cell')
                product = header_el.get_text(strip=True) if header_el else default_product

                content_cells = cell.find_all('div', class_='content-cell')
                if not content_cells:
                    continue

                main_cell = content_cells[0]

                # Áudio de voz se existir
                audio_src = ""
                source_el = cell.find('source')
                if source_el and source_el.get('src'):
                    audio_src = source_el.get('src').strip()
                else:
                    audio_el = cell.find('audio')
                    if audio_el and audio_el.get('src'):
                        audio_src = audio_el.get('src').strip()

                # URL associada
                link_el = main_cell.find('a')
                target_url = link_el.get('href') if link_el else ""

                # Texto da ação e extração da data
                text_lines = [line.strip() for line in main_cell.stripped_strings if line.strip()]
                action_parts = []
                raw_time = ""

                for t in text_lines:
                    m = date_pattern.search(t.replace('\u202f', ' '))
                    if m:
                        raw_time = m.group(1)
                    else:
                        action_parts.append(t)

                action_text = " ".join(action_parts).strip()
                if not action_text:
                    continue

                u_time, b_time = parse_utc_to_brt(raw_time)

                results.append({
                    "product": product,
                    "action_text": action_text,
                    "target_url": target_url,
                    "timestamp_utc": u_time,
                    "timestamp_brt": b_time,
                    "audio_file": audio_src,
                    "has_audio": 1 if audio_src else 0,
                    "details": ""
                })

        except Exception as ex:
            print(f"[GoogleParser] Erro ao parsear MyActivity: {ex}")

        return results

    @staticmethod
    def parse_drive_info_json(json_content: str, default_filename: str = "") -> Dict[str, Any]:
        """
        Extrai metadados forenses do arquivo -info.json do Google Drive:
        - Título original
        - ID único do arquivo
        - MIME type
        - Datas de criação e modificação (UTC e BRT)
        - IP de upload (creation_upload_ip_address)
        - Proprietário (nome, e-mail, GAIA ID)
        - Se está na lixeira (is_trashed)
        - Resumo das ações (upload, edit, move, acl_change)
        """
        result = {
            "file_id": "",
            "title": default_filename,
            "mime_type": "",
            "creation_date_utc": "",
            "creation_date_brt": "",
            "modified_date_utc": "",
            "modified_date_brt": "",
            "upload_ip": "",
            "owner_email": "",
            "owner_name": "",
            "is_trashed": 0,
            "actions_summary": "",
            "raw_metadata": json_content
        }
        if not json_content:
            return result

        try:
            d = json.loads(json_content)
            lis = d.get("lis", {})
            meta = d.get("lis_metadata", {})

            # Título
            title = lis.get("title") or d.get("title") or default_filename
            result["title"] = title

            # Datas
            c_raw = lis.get("creation_date") or ""
            m_raw = lis.get("modified") or ""
            c_u, c_b = parse_utc_to_brt(c_raw)
            m_u, m_b = parse_utc_to_brt(m_raw)
            result["creation_date_utc"] = c_u
            result["creation_date_brt"] = c_b
            result["modified_date_utc"] = m_u
            result["modified_date_brt"] = m_b

            # IP de Upload
            ips = meta.get("creation_upload_ip_address", [])
            if isinstance(ips, list):
                result["upload_ip"] = ", ".join([str(ip).strip() for ip in ips if ip])
            elif ips:
                result["upload_ip"] = str(ips).strip()

            # Dono
            owners = lis.get("owners", {}).get("user_info", [])
            if owners and isinstance(owners, list):
                u = owners[0].get("user", {})
                result["owner_email"] = u.get("email_address", "")
                result["owner_name"] = u.get("display_name", "")

            # Lixeira
            if lis.get("trashed") or lis.get("is_explicitly_trashed"):
                result["is_trashed"] = 1

            # Activity records: extrair file_id, mime_type e histórico de ações
            act_records = meta.get("activity_records", {}).get("activity_event_records", [])
            actions = []
            for act in act_records:
                target = act.get("target", {})
                if not result["file_id"] and target.get("item_id", {}).get("id"):
                    result["file_id"] = target["item_id"]["id"]
                if not result["mime_type"] and target.get("item", {}).get("mime_type"):
                    result["mime_type"] = target["item"]["mime_type"]
                if not result["owner_email"] and target.get("owner", {}).get("user", {}):
                    ou = target["owner"]["user"]
                    result["owner_email"] = ou.get("email_address", "")
                for a in act.get("actions", []):
                    for k in a.keys():
                        if k not in actions:
                            actions.append(k)

            # Se ainda não encontrou file_id, buscar nos deltas
            if not result["file_id"]:
                deltas = meta.get("delta_log_records", {}).get("item_deltas", [])
                for delta in deltas:
                    din = delta.get("drive_item_name", "")
                    if din.startswith("items/"):
                        result["file_id"] = din.replace("items/", "")
                        break

            # Mapear ações em português forense amigável
            act_map = {
                "upload": "Upload",
                "create": "Criação",
                "edit": "Edição",
                "move": "Movimentação",
                "rename": "Renomeação",
                "acl_change": "Alteração de Permissões",
                "view": "Visualização",
                "indexable_content_change": "Indexação de Conteúdo"
            }
            res_actions = [act_map.get(a, a.capitalize()) for a in actions]
            result["actions_summary"] = ", ".join(res_actions)

        except Exception as ex:
            print(f"[GoogleParser] Erro ao parsear Drive info JSON: {ex}")

        return result

    @staticmethod
    def parse_timeline_settings(json_content: str) -> List[Dict[str, Any]]:
        """
        Extrai as configurações de rastreamento de aparelhos de Timeline/Settings.json.
        """
        devices = []
        if not json_content:
            return devices

        try:
            d = json.loads(json_content)
            gaia_id = str(d.get("gaiaId", ""))
            raw_devs = d.get("deviceSettings", [])

            for dev in raw_devs:
                tag = str(dev.get("deviceTag", ""))
                pretty_name = dev.get("devicePrettyName", "Dispositivo Android")
                platform = dev.get("platformType", "ANDROID")
                enabled = 1 if dev.get("reportingEnabled") else 0

                # Criação do aparelho
                c_raw = dev.get("deviceCreationTime", "")
                c_u, c_b = parse_utc_to_brt(c_raw)

                # Última alteração de configuração de rastreamento
                chg = dev.get("latestLocationReportingSettingChange", {})
                chg_src = chg.get("settingsChangeSource", "")
                chg_raw = chg.get("reportingEnabledModificationTime", "")
                chg_u, chg_b = parse_utc_to_brt(chg_raw)

                devices.append({
                    "gaia_id": gaia_id,
                    "device_tag": tag,
                    "device_pretty_name": pretty_name,
                    "platform_type": platform,
                    "reporting_enabled": enabled,
                    "device_creation_time_utc": c_u,
                    "device_creation_time_brt": c_b,
                    "setting_change_source": chg_src,
                    "setting_change_time_utc": chg_u,
                    "setting_change_time_brt": chg_b,
                    "raw_json": json.dumps(dev)
                })

        except Exception as ex:
            print(f"[GoogleParser] Erro ao parsear Timeline Settings: {ex}")

        return devices

    @staticmethod
    def parse_timeline_semantic_or_records(json_content: str) -> List[Dict[str, Any]]:
        """
        Parseia arquivos de histórico semântico (Semantic Location History) ou Records.json da Timeline.
        """
        locations = []
        if not json_content:
            return locations

        try:
            data = json.loads(json_content)

            # Formato 1: Semantic Location History (timelineObjects com placeVisit ou activitySegment)
            if "timelineObjects" in data:
                for obj in data.get("timelineObjects", []):
                    if "placeVisit" in obj:
                        pv = obj["placeVisit"]
                        loc = pv.get("location", {})
                        lat_e7 = loc.get("latitudeE7")
                        lng_e7 = loc.get("longitudeE7")
                        if lat_e7 is not None and lng_e7 is not None:
                            lat = lat_e7 / 1e7
                            lon = lng_e7 / 1e7
                            name = loc.get("name") or loc.get("semanticType", "Visita")
                            addr = loc.get("address", "")
                            dur = pv.get("duration", {})
                            s_raw = dur.get("startTimestamp", "")
                            s_u, s_b = parse_utc_to_brt(s_raw)
                            locations.append({
                                "source": "timeline",
                                "location_type": loc.get("semanticType", "Visita / Parada"),
                                "name": name,
                                "address": addr,
                                "latitude": lat,
                                "longitude": lon,
                                "timestamp_utc": s_u,
                                "timestamp_brt": s_b,
                                "raw_json": json.dumps(pv)
                            })
                    elif "activitySegment" in obj:
                        act = obj["activitySegment"]
                        s_loc = act.get("startLocation", {})
                        lat_e7 = s_loc.get("latitudeE7")
                        lng_e7 = s_loc.get("longitudeE7")
                        if lat_e7 is not None and lng_e7 is not None:
                            lat = lat_e7 / 1e7
                            lon = lng_e7 / 1e7
                            act_type = act.get("activityType", "Deslocamento")
                            dur = act.get("duration", {})
                            s_raw = dur.get("startTimestamp", "")
                            s_u, s_b = parse_utc_to_brt(s_raw)
                            locations.append({
                                "source": "timeline",
                                "location_type": f"Trajeto ({act_type})",
                                "name": f"Deslocamento: {act_type}",
                                "address": "",
                                "latitude": lat,
                                "longitude": lon,
                                "timestamp_utc": s_u,
                                "timestamp_brt": s_b,
                                "raw_json": json.dumps(act)
                            })

            # Formato 2: Records.json (locations com latitudeE7, longitudeE7, timestamp, accuracy)
            elif "locations" in data:
                for item in data.get("locations", []):
                    lat_e7 = item.get("latitudeE7")
                    lng_e7 = item.get("longitudeE7")
                    if lat_e7 is not None and lng_e7 is not None:
                        lat = lat_e7 / 1e7
                        lon = lng_e7 / 1e7
                        ts = item.get("timestamp", "")
                        u_str, b_str = parse_utc_to_brt(ts)
                        acc = item.get("accuracy", "")
                        locations.append({
                            "source": "timeline",
                            "location_type": f"Registro GPS (Precisão: {acc}m)" if acc else "Registro GPS",
                            "name": "Coordenada Timeline",
                            "address": "",
                            "latitude": lat,
                            "longitude": lon,
                            "timestamp_utc": u_str,
                            "timestamp_brt": b_str,
                            "raw_json": json.dumps(item)
                        })

        except Exception as ex:
            print(f"[GoogleParser] Erro ao parsear Timeline Semantic/Records: {ex}")

        return locations


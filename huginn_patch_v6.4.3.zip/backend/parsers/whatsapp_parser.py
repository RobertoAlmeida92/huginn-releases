import os
import re
import zipfile
import json
import bs4
import shutil
import pandas as pd
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone, timedelta
from backend.parsers.base_parser import BaseParser
from backend.database import get_db_connection
from backend.config import MEDIA_BASE_DIR

class WhatsAppParser(BaseParser):
    """
    Parser forense especializado para relatórios judiciais do WhatsApp / Meta (LERS).
    Suporta extrações de dados telemáticos, agendas de contatos, grupos, aparelhos,
    sessões web e históricos diários de conexões de IP.
    """

    def parse_file(
        self,
        file_path: str,
        operation_id: int,
        phase_id: int,
        target_id: int,
        phase_target_id: Optional[int] = None
    ) -> Dict[str, Any]:
        extracted_data = {
            "target_info": {},
            "devices": [],
            "groups": [],
            "contacts": [],
            "connections": [],
            "media_files": []
        }

        # Diretório pericial de mídias do alvo
        target_media_dir = os.path.join(MEDIA_BASE_DIR, "whatsapp", str(operation_id), str(target_id))
        os.makedirs(target_media_dir, exist_ok=True)

        if zipfile.is_zipfile(file_path):
            with zipfile.ZipFile(file_path, "r") as z:
                # Extrair mídias vinculadas
                for name in z.namelist():
                    if name.startswith("linked_media/") and not name.endswith("/"):
                        out_path = os.path.join(target_media_dir, os.path.basename(name))
                        with open(out_path, "wb") as f_out:
                            f_out.write(z.read(name))
                        extracted_data["media_files"].append(out_path)

                # Priorizar records.html ou preservation-1.html
                if "records.html" in z.namelist():
                    self._parse_html_report(z.read("records.html").decode("utf-8", errors="ignore"), extracted_data, target_media_dir)
                elif "preservation-1.html" in z.namelist():
                    self._parse_html_report(z.read("preservation-1.html").decode("utf-8", errors="ignore"), extracted_data, target_media_dir)
                else:
                    for name in z.namelist():
                        if name.endswith(".html"):
                            self._parse_html_report(z.read(name).decode("utf-8", errors="ignore"), extracted_data, target_media_dir)
                        elif name.endswith((".xlsx", ".xls", ".csv")):
                            self._parse_spreadsheet(z.open(name), name, extracted_data)
                        elif name.endswith(".json"):
                            try:
                                json_data = json.loads(z.read(name).decode("utf-8", errors="ignore"))
                                self._parse_json_data(json_data, extracted_data)
                            except Exception:
                                pass
        elif file_path.endswith(".html"):
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                self._parse_html_report(f.read(), extracted_data, target_media_dir)
        elif file_path.endswith((".xlsx", ".xls", ".csv")):
            self._parse_spreadsheet(file_path, os.path.basename(file_path), extracted_data)
        elif file_path.endswith(".json"):
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                self._parse_json_data(json.load(f), extracted_data)

        # Salvar e persistir no banco de dados SQLite
        wa_target_id = self._save_to_database(extracted_data, operation_id, phase_id, target_id, phase_target_id, target_media_dir)
        extracted_data["wa_target_id"] = wa_target_id
        return extracted_data

    def _parse_html_report(self, html_str: str, data: Dict[str, Any], media_dir: str):
        """
        Parser forense linear/regex de altíssima performance para relatórios do WhatsApp / Meta LERS.
        Processa arquivos de dezenas de megabytes (70.000+ conexões IP) em menos de 0.5 segundo,
        eliminando estouro de memória do BeautifulSoup e mantendo precisão cirúrgica.
        """
        import html as html_lib

        def clean_val(v: str) -> str:
            if not v:
                return ""
            t = re.sub(r'<br\s*/?>', ' ', v, flags=re.IGNORECASE)
            t = re.sub(r'<[^>]+>', ' ', t)
            t = html_lib.unescape(t)
            return re.sub(r'\s+', ' ', t).strip()

        # 1. Mapear seções principais por <div id="property-([^"]+)"
        panes = list(re.finditer(r'<div\s+id=[\'"]property-([^\'"]+)[\'"][^>]*>', html_str, re.IGNORECASE))
        sections = {}
        for i, match in enumerate(panes):
            prop_name = match.group(1).lower().strip()
            start_idx = match.end()
            end_idx = panes[i+1].start() if i+1 < len(panes) else len(html_str)
            sections[prop_name] = html_str[start_idx:end_idx]

        # ----------------------------------------------------
        # 1. Parâmetros da Requisição Judicial (property-request_parameters)
        # ----------------------------------------------------
        if "request_parameters" in sections:
            sec = sections["request_parameters"]
            pairs = re.findall(r'<div\s+class=[\'"]t i[\'"]>(.*?)<div\s+class=[\'"]m[\'"]><div>(.*?)<div\s+class=[\'"]p[\'"]>', sec, re.DOTALL)
            for lbl, val in pairs:
                c_lbl = clean_val(lbl).lower()
                c_val = clean_val(val)
                if c_lbl == "service":
                    data["target_info"]["service"] = c_val
                elif "internal ticket number" in c_lbl:
                    data["target_info"]["internal_ticket"] = c_val
                elif c_lbl == "target":
                    data["target_info"]["phone_number"] = c_val
                elif "logical id" in c_lbl:
                    data["target_info"]["logical_id"] = c_val
                elif "account identifier" in c_lbl:
                    if not data["target_info"].get("phone_number"):
                        data["target_info"]["phone_number"] = c_val
                    data["target_info"]["account_identifier"] = c_val
                elif "account type" in c_lbl:
                    data["target_info"]["account_type"] = c_val
                elif "generated" in c_lbl:
                    data["target_info"]["generated_utc"] = c_val
                elif "date range" in c_lbl:
                    data["target_info"]["date_range"] = c_val

        # ----------------------------------------------------
        # 2. E-mails Registrados (property-emails)
        # ----------------------------------------------------
        if "emails" in sections:
            sec = sections["emails"]
            m_em = re.search(r'Registered Email Addresses<div class="m"><div>(.*?)<div class="p">', sec, re.DOTALL)
            if m_em:
                c_em = clean_val(m_em.group(1))
                if c_em and "no responsive" not in c_em.lower():
                    data["target_info"]["email"] = c_em

        # ----------------------------------------------------
        # 3. Foto de Perfil (property-profile_picture)
        # ----------------------------------------------------
        if "profile_picture" in sections:
            sec = sections["profile_picture"]
            m_pic = re.search(r'linked_media/(profile_picture_[^\'\"<>\s]+)', sec, re.IGNORECASE)
            if m_pic:
                data["target_info"]["profile_pic_filename"] = m_pic.group(1).strip()

        # ----------------------------------------------------
        # 4. Dados Comerciais (property-small_medium_business)
        # ----------------------------------------------------
        if "small_medium_business" in sections:
            sec = sections["small_medium_business"]
            for field, key in [
                ("Name", "business_name"),
                ("Email", "business_email"),
                ("Address", "business_address"),
                ("Websites", "business_website")
            ]:
                m_f = re.search(rf'{field}<div class="m"><div>(.*?)<div class="p">', sec, re.DOTALL)
                if m_f:
                    cv = clean_val(m_f.group(1))
                    if cv and not any(w in cv.lower() for w in ["definition", "no responsive", "account holder"]):
                        data["target_info"][key] = cv

        # ----------------------------------------------------
        # 5. Notas do Usuário / Status (property-user_notes_info)
        # ----------------------------------------------------
        if "user_notes_info" in sections:
            sec = sections["user_notes_info"]
            m_note = re.search(r'Note Text<div class="m"><div>(.*?)<div class="p">', sec, re.DOTALL)
            if m_note:
                cv = clean_val(m_note.group(1))
                if cv and "no responsive" not in cv.lower():
                    data["target_info"]["status_text"] = cv

        # ----------------------------------------------------
        # 6. Informações de Conexão e Dispositivos (property-connection_info)
        # ----------------------------------------------------
        if "connection_info" in sections:
            sec = sections["connection_info"]
            m_push = re.search(r'Push Name<div class="m"><div>(.*?)<div class="p">', sec, re.DOTALL)
            if m_push:
                c_push = clean_val(m_push.group(1))
                if c_push and "no responsive" not in c_push.lower():
                    data["target_info"]["push_name"] = c_push

            m_start = re.search(r'Service start<div class="m"><div>(.*?)<div class="p">', sec, re.DOTALL)
            if m_start:
                data["target_info"]["service_start_utc"] = clean_val(m_start.group(1))

            m_conn_ip = re.search(r'Connected from<div class="m"><div>(.*?)<div class="p">', sec, re.DOTALL)
            if m_conn_ip:
                data["target_info"]["last_ip"] = clean_val(m_conn_ip.group(1))

        # ----------------------------------------------------
        # 7. Detalhes de Hardware (property-device_info)
        # ----------------------------------------------------
        if "device_info" in sections:
            sec = sections["device_info"]
            dev_match = re.search(
                r'Device Id<div class="m"><div>(.*?)<div class="p">.*?App Version<div class="m"><div>(.*?)<div class="p">.*?OS Version<div class="m"><div>(.*?)<div class="p">.*?Device Manufacturer<div class="m"><div>(.*?)<div class="p">.*?Device Model<div class="m"><div>(.*?)<div class="p">',
                sec, re.DOTALL
            )
            if dev_match:
                data["devices"].append({
                    "device_id": clean_val(dev_match.group(1)),
                    "app_version": clean_val(dev_match.group(2)),
                    "os_version": clean_val(dev_match.group(3)),
                    "device_manufacturer": clean_val(dev_match.group(4)),
                    "device_model": clean_val(dev_match.group(5)),
                    "service_start_utc": data["target_info"].get("service_start_utc"),
                    "last_ip": data["target_info"].get("last_ip"),
                    "status": "INACTIVE"
                })

        # ----------------------------------------------------
        # 8. Grupos de WhatsApp (property-groups_info)
        # ----------------------------------------------------
        if "groups_info" in sections:
            sec = sections["groups_info"]
            g_matches = list(re.finditer(r'<div class="t i">ID<div class="m"><div>(\d+)<', sec))
            for idx, gm in enumerate(g_matches):
                g_id = gm.group(1)
                g_start = gm.start()
                g_end = g_matches[idx+1].start() if idx+1 < len(g_matches) else len(sec)
                g_block = sec[g_start:g_end]

                c_match = re.search(r'Creation<div class="m"><div>(.*?)<div class="p">', g_block, re.DOTALL)
                s_match = re.search(r'Size<div class="m"><div>(\d+)<div class="p">', g_block, re.DOTALL)
                p_match = re.search(r'linked_media/(profile_picture_[^\'\"<>\s]+)', g_block, re.IGNORECASE)
                sub_match = re.search(r'Subject<div class="m"><div>(.*?)<div class="p">', g_block, re.DOTALL)
                desc_match = re.search(r'Description<div class="m"><div>(.*?)<div class="p">', g_block, re.DOTALL)

                data["groups"].append({
                    "group_jid": f"{g_id}@g.us",
                    "created_at_utc": clean_val(c_match.group(1)) if c_match else None,
                    "total_participants": int(s_match.group(1)) if s_match else 0,
                    "profile_pic_path": p_match.group(1) if p_match else None,
                    "subject": clean_val(sub_match.group(1)) if sub_match else "Sem Assunto",
                    "description": clean_val(desc_match.group(1)) if desc_match else None,
                    "role": "participating"
                })

        # ----------------------------------------------------
        # 9. Agenda de Contatos Sincronizada (property-address_book_info)
        # Separação Rigorosa de Contatos Simétricos e Assimétricos
        # ----------------------------------------------------
        if "address_book_info" in sections:
            sec = sections["address_book_info"]
            tgt_ph = (data["target_info"].get("phone_number") or "").replace("+", "").strip()

            # Extração de Contatos Simétricos (Mútuos)
            sym_match = re.search(r'Symmetric contacts<div class="m"><div>\s*\d+\s*Total(.*?)(?=Asymmetric contacts<div class="m"><div>|$)', sec, re.DOTALL)
            if sym_match:
                sym_phones = re.findall(r'\b(55\d{10,11}|\d{10,13})\b', sym_match.group(1))
                seen_sym = set()
                for p in sym_phones:
                    if p not in seen_sym and p != tgt_ph:
                        seen_sym.add(p)
                        data["contacts"].append({
                            "phone_number": f"+{p}",
                            "display_name": None,
                            "is_symmetric": True
                        })

            # Extração de Contatos Assimétricos (Unilaterais)
            asym_match = re.search(r'Asymmetric contacts<div class="m"><div>\s*\d+\s*Total(.*?)(?=<div\s+id=[\'"]property-|$)', sec, re.DOTALL)
            if asym_match:
                asym_phones = re.findall(r'\b(55\d{10,11}|\d{10,13})\b', asym_match.group(1))
                seen_asym = set()
                for p in asym_phones:
                    if p not in seen_asym and p != tgt_ph:
                        seen_asym.add(p)
                        data["contacts"].append({
                            "phone_number": f"+{p}",
                            "display_name": None,
                            "is_symmetric": False
                        })

        # ----------------------------------------------------
        # 10. Histórico Massivo de Conexões de IP (property-ip_addresses)
        # ----------------------------------------------------
        if "ip_addresses" in sections:
            sec = sections["ip_addresses"]
            # Limpar quebras de página intermediárias da Meta que interrompem pares
            clean_sec = re.sub(r'<div[^>]*class=[\'"]pageBreak[\'"][^>]*>.*?</div>', '', sec, flags=re.IGNORECASE)
            ip_matches = re.findall(
                r'Time<div\s+class=[\'"]m[\'"]><div>([^<]+)<.*?IP Address<div\s+class=[\'"]m[\'"]><div>([^<]+)<',
                clean_sec,
                re.DOTALL
            )
            for t_raw, ip_raw in ip_matches:
                t_val = t_raw.strip()
                ip_val = ip_raw.strip()
                if ip_val and t_val and ip_val.lower() != "no responsive":
                    data["connections"].append({
                        "timestamp_utc": t_val,
                        "timestamp_brt": self.utc_to_brt(t_val),
                        "source_ip": ip_val,
                        "source_port": None,
                        "event_type": "connection"
                    })

    def _parse_spreadsheet(self, file_or_buffer, filename: str, data: Dict[str, Any]):
        try:
            if filename.endswith(".csv"):
                df = pd.read_csv(file_or_buffer)
            else:
                df = pd.read_excel(file_or_buffer)

            cols = {c: str(c).strip().lower() for c in df.columns}
            df.rename(columns=cols, inplace=True)

            ip_col = next((c for c in df.columns if "ip" in c and "dest" not in c), None)
            time_col = next((c for c in df.columns if any(t in c for t in ["time", "data", "date", "hora"])), None)
            port_col = next((c for c in df.columns if "port" in c or "porta" in c), None)

            if ip_col and time_col:
                for _, row in df.iterrows():
                    ip_val = str(row[ip_col]).strip()
                    time_val = str(row[time_col]).strip()
                    port_val = row[port_col] if port_col and pd.notna(row[port_col]) else None
                    if ip_val and time_val and ip_val != "nan":
                        data["connections"].append({
                            "timestamp_utc": time_val,
                            "timestamp_brt": self.utc_to_brt(time_val),
                            "source_ip": ip_val,
                            "source_port": int(port_val) if port_val and str(port_val).isdigit() else None,
                            "event_type": "connection"
                        })
        except Exception as e:
            print(f"[WhatsAppParser] Erro ao ler planilha {filename}: {e}")

    def _parse_json_data(self, json_obj: Any, data: Dict[str, Any]):
        if isinstance(json_obj, dict):
            if "phone" in json_obj:
                data["target_info"]["phone_number"] = json_obj["phone"]
            if "push_name" in json_obj:
                data["target_info"]["push_name"] = json_obj["push_name"]
            if "connections" in json_obj and isinstance(json_obj["connections"], list):
                for c in json_obj["connections"]:
                    c["timestamp_brt"] = self.utc_to_brt(c.get("timestamp_utc"))
                    data["connections"].append(c)
            if "groups" in json_obj and isinstance(json_obj["groups"], list):
                data["groups"].extend(json_obj["groups"])
            if "contacts" in json_obj and isinstance(json_obj["contacts"], list):
                data["contacts"].extend(json_obj["contacts"])

    def _save_to_database(
        self,
        data: Dict[str, Any],
        operation_id: int,
        phase_id: int,
        target_id: int,
        phase_target_id: Optional[int],
        media_dir: str
    ) -> int:
        conn = get_db_connection()
        cursor = conn.cursor()

        t_info = data.get("target_info", {})
        phone = t_info.get("phone_number")
        logical_id = t_info.get("logical_id")
        email = t_info.get("email")
        business_name = t_info.get("business_name")
        push_name = t_info.get("push_name") or business_name
        ticket = t_info.get("internal_ticket")
        date_range = t_info.get("date_range")
        generated_utc = t_info.get("generated_utc")
        profile_pic = t_info.get("profile_pic_filename")
        status_text = t_info.get("status_text")

        # Buscar primeiro e último registro de conexão/ativação
        first_service_utc = None
        first_service_brt = None
        last_ip = None
        for d in data.get("devices", []):
            if d.get("service_start_utc") and not first_service_utc:
                first_service_utc = d["service_start_utc"]
                first_service_brt = self.utc_to_brt(first_service_utc)
            if d.get("last_ip") and not last_ip:
                last_ip = d["last_ip"]

        if not last_ip and data.get("connections"):
            last_ip = data["connections"][0]["source_ip"]

        # Atualizar dados do Alvo na tabela Targets master
        cursor.execute("""
            UPDATE targets SET
                main_identifier = CASE 
                    WHEN main_identifier IS NULL OR main_identifier = '' OR main_identifier = '@alvo' OR main_identifier LIKE 'Alvo_%' THEN COALESCE(?, main_identifier)
                    ELSE main_identifier
                END,
                name_or_alias = CASE 
                    WHEN name_or_alias IS NULL OR name_or_alias = '' OR name_or_alias = 'Alvo_Meta' OR name_or_alias LIKE 'Alvo_%' OR name_or_alias LIKE 'Investigado%' THEN COALESCE(?, ?, main_identifier)
                    ELSE name_or_alias
                END,
                email = COALESCE(email, ?),
                phone = COALESCE(phone, ?),
                registration_ip = COALESCE(registration_ip, ?),
                registration_date = COALESCE(registration_date, ?)
            WHERE id = ?
        """, (
            phone,
            business_name,
            phone,
            email,
            phone,
            last_ip,
            first_service_brt or first_service_utc,
            target_id
        ))

        # Inserir ou Atualizar Dossiê Cadastral do WhatsApp
        cursor.execute("""
            SELECT id FROM whatsapp_targets WHERE target_id = ? AND phase_id = ?
        """, (target_id, phase_id))
        existing_wa = cursor.fetchone()

        if existing_wa:
            wa_target_id = existing_wa["id"]
            cursor.execute("""
                UPDATE whatsapp_targets SET
                    phone_number = COALESCE(?, phone_number),
                    push_name = COALESCE(?, push_name),
                    email = COALESCE(?, email),
                    logical_id = COALESCE(?, logical_id),
                    account_type = COALESCE(?, account_type),
                    internal_ticket = COALESCE(?, internal_ticket),
                    date_range = COALESCE(?, date_range),
                    report_generated_utc = COALESCE(?, report_generated_utc),
                    profile_pic_path = COALESCE(?, profile_pic_path),
                    business_name = COALESCE(?, business_name),
                    business_email = COALESCE(?, business_email),
                    business_address = COALESCE(?, business_address),
                    business_website = COALESCE(?, business_website),
                    status_text = COALESCE(?, status_text),
                    account_created_utc = COALESCE(?, account_created_utc),
                    account_created_brt = COALESCE(?, account_created_brt),
                    registration_ip = COALESCE(?, registration_ip),
                    raw_metadata = ?
                WHERE id = ?
            """, (
                phone, push_name, email, logical_id, t_info.get("account_type"), ticket, date_range,
                generated_utc, profile_pic, business_name, t_info.get("business_email"),
                t_info.get("business_address"), t_info.get("business_website"), status_text,
                first_service_utc, first_service_brt, last_ip, json.dumps(t_info, ensure_ascii=False),
                wa_target_id
            ))
        else:
            cursor.execute("""
                INSERT INTO whatsapp_targets (
                    phase_target_id, phase_id, target_id, phone_number, push_name, email,
                    logical_id, account_type, internal_ticket, date_range, report_generated_utc,
                    profile_pic_path, business_name, business_email, business_address,
                    business_website, status_text, account_created_utc, account_created_brt,
                    registration_ip, raw_metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                phase_target_id, phase_id, target_id, phone or "N/A", push_name, email,
                logical_id, t_info.get("account_type"), ticket, date_range, generated_utc,
                profile_pic, business_name, t_info.get("business_email"), t_info.get("business_address"),
                t_info.get("business_website"), status_text, first_service_utc, first_service_brt,
                last_ip, json.dumps(t_info, ensure_ascii=False)
            ))
            wa_target_id = cursor.lastrowid

        # Inserir Dispositivos
        for d in data.get("devices", []):
            start_utc = d.get("service_start_utc")
            start_brt = self.utc_to_brt(start_utc)
            seen_utc = d.get("last_seen_utc")
            seen_brt = self.utc_to_brt(seen_utc)

            cursor.execute("""
                INSERT OR REPLACE INTO whatsapp_devices (
                    target_id, phase_id, device_id, device_type, app_version, os_version,
                    device_manufacturer, device_model, service_start_utc, service_start_brt,
                    last_seen_utc, last_seen_brt, last_ip, status, is_active
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                target_id, phase_id, d.get("device_id"), d.get("device_type"), d.get("app_version"),
                d.get("os_version"), d.get("device_manufacturer"), d.get("device_model"),
                start_utc, start_brt, seen_utc, seen_brt, d.get("last_ip"),
                d.get("status"), 1 if d.get("status") == "ONLINE" else 0
            ))

        # Inserir Grupos
        for g in data.get("groups", []):
            c_utc = g.get("created_at_utc")
            c_brt = self.utc_to_brt(c_utc)
            cursor.execute("""
                INSERT OR REPLACE INTO whatsapp_groups (
                    target_id, phase_id, group_jid, subject, creator_jid, description,
                    role, profile_pic_path, created_at_utc, created_at_brt, total_participants
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                target_id, phase_id, g.get("group_jid", "unknown"), g.get("subject"),
                g.get("creator_jid"), g.get("description"), g.get("role", "participating"),
                g.get("profile_pic_path"), c_utc, c_brt, g.get("total_participants", 0)
            ))

        # Inserir Contatos da Agenda (em lotes com substituição em caso de reimportação)
        contacts_batches = []
        for c in data.get("contacts", []):
            contacts_batches.append((
                target_id, phase_id, c["phone_number"], c.get("display_name"),
                1 if c.get("is_symmetric") else 0, None
            ))

        if contacts_batches:
            cursor.executemany("""
                INSERT OR REPLACE INTO whatsapp_contacts (
                    target_id, phase_id, phone_number, display_name, is_symmetric, raw_info
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, contacts_batches)

        # Inserir Conexões de IP (em lotes particionados de alta performance para suportar 70k+ registros)
        conn_batches = []
        for c in data.get("connections", []):
            conn_batches.append((
                target_id, phase_id, c["timestamp_utc"], c.get("timestamp_brt"),
                c.get("event_type", "connection"), c["source_ip"], c.get("source_port")
            ))

        if conn_batches:
            chunk_size = 5000
            for i in range(0, len(conn_batches), chunk_size):
                cursor.executemany("""
                    INSERT OR IGNORE INTO whatsapp_connections (
                        target_id, phase_id, timestamp_utc, timestamp_brt, event_type, source_ip, source_port
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, conn_batches[i:i + chunk_size])

        # Linha do tempo pericial
        timeline_events = []
        if first_service_utc:
            timeline_events.append((
                operation_id, phase_id, target_id, "whatsapp", "account_created",
                first_service_utc, first_service_brt or first_service_utc,
                f"Ativação do WhatsApp ({phone or 'Alvo'})",
                f"Conta ativada com IP {last_ip or 'não informado'}. Nome: {push_name or 'N/A'}",
                phone, push_name, json.dumps(t_info)
            ))

        for g in data.get("groups", []):
            if g.get("created_at_utc") and g.get("role") == "owned":
                timeline_events.append((
                    operation_id, phase_id, target_id, "whatsapp", "group_created",
                    g["created_at_utc"], self.utc_to_brt(g["created_at_utc"]),
                    f"Criação de Grupo WhatsApp: {g.get('subject') or g.get('group_jid')}",
                    f"Grupo criado com {g.get('total_participants', 0)} membros. Descrição: {g.get('description') or 'Sem descrição'}",
                    g.get("group_jid"), g.get("subject"), json.dumps(g)
                ))

        if timeline_events:
            cursor.executemany("""
                INSERT INTO timeline_events (
                    operation_id, phase_id, target_id, platform, event_type, timestamp_utc, timestamp_brt,
                    title, description, entity_id, entity_name, extra_data
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, timeline_events)

        conn.commit()
        conn.close()
        return wa_target_id

import os
import re
import zipfile
import json
import bs4
import shutil
from typing import Dict, Any, List, Optional
from collections import defaultdict
from backend.parsers.base_parser import BaseParser
from backend.database import get_db_connection
from backend.config import MEDIA_BASE_DIR

class InstagramParser(BaseParser):
    """
    Parser forense avançado para relatórios judiciais do Instagram / Meta (LERS).
    Vincula os dados à Operação, Fase e Alvo específicos.
    """

    def parse_file(
        self,
        file_path: str,
        operation_id: int,
        phase_id: int,
        target_id: int,
        phase_target_id: Optional[int] = None
    ) -> Dict[str, Any]:
        extracted_data = {
            "case_info": {},
            "target_info": {},
            "followers": [],
            "following": [],
            "threads_followers": [],
            "threads_following": [],
            "ip_connections": [],
            "threads": defaultdict(list)
        }

        case_media_dir = os.path.join(MEDIA_BASE_DIR, f"target_{target_id}")
        os.makedirs(case_media_dir, exist_ok=True)

        if zipfile.is_zipfile(file_path):
            with zipfile.ZipFile(file_path, "r") as z:
                # 1. Extrair mídias anexadas se existirem (suporta qualquer prefixo como annerufino/linked_media/...)
                for name in z.namelist():
                    if "linked_media/" in name and not name.endswith("/"):
                        out_path = os.path.join(case_media_dir, os.path.basename(name))
                        if not os.path.exists(out_path):
                            with z.open(name) as src, open(out_path, "wb") as dst:
                                shutil.copyfileobj(src, dst)

                # 2. Processar preservation-*.html primeiro
                preservation_files = [f for f in z.namelist() if "preservation" in f.lower() and f.endswith(".html")]
                for pf in sorted(preservation_files):
                    pres_data = self._parse_html_content(z.read(pf).decode("utf-8", errors="ignore"), target_id)
                    self._merge_data(extracted_data, pres_data)

                # 3. Processar records.html (relatório principal)
                if "records.html" in z.namelist():
                    rec_data = self._parse_html_content(z.read("records.html").decode("utf-8", errors="ignore"), target_id)
                    self._merge_data(extracted_data, rec_data)
                elif any(f.endswith(".html") for f in z.namelist()):
                    for hf in z.namelist():
                        if hf.endswith(".html") and hf not in preservation_files:
                            rec_data = self._parse_html_content(z.read(hf).decode("utf-8", errors="ignore"), target_id)
                            self._merge_data(extracted_data, rec_data)
        elif os.path.isfile(file_path) and file_path.endswith(".html"):
            # Se for arquivo HTML direto, copiar pasta linked_media adjacente se existir
            file_dir = os.path.dirname(os.path.abspath(file_path))
            for root, _, files in os.walk(file_dir):
                if os.path.basename(root) == "linked_media":
                    for f in files:
                        src_media = os.path.join(root, f)
                        dst_media = os.path.join(case_media_dir, f)
                        if not os.path.exists(dst_media):
                            shutil.copy2(src_media, dst_media)
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                rec_data = self._parse_html_content(f.read(), target_id)
                self._merge_data(extracted_data, rec_data)

        # Salvar e indexar no banco SQLite
        ig_target_db_id = self._save_to_database(extracted_data, operation_id, phase_id, target_id, phase_target_id)
        extracted_data["ig_target_id"] = ig_target_db_id
        return extracted_data

    def _parse_html_content(self, html_str: str, target_id: int) -> Dict[str, Any]:
        soup = bs4.BeautifulSoup(html_str, "html.parser")
        records_output = soup.find("div", class_="records_output")
        if not records_output:
            return {}

        case_media_dir = os.path.join(MEDIA_BASE_DIR, f"target_{target_id}")
        os.makedirs(case_media_dir, exist_ok=True)

        result = {
            "case_info": {},
            "target_info": {},
            "followers": [],
            "following": [],
            "threads_followers": [],
            "threads_following": [],
            "ip_connections": [],
            "devices": [],
            "comments": [],
            "threads": defaultdict(list)
        }

        current_prop = None
        prop_blocks: Dict[str, List[bs4.element.Tag]] = {}

        for child in records_output.children:
            if not hasattr(child, "get"):
                continue
            cid = child.get("id", "")
            if cid.startswith("property-"):
                current_prop = cid.replace("property-", "")
                if current_prop not in prop_blocks:
                    prop_blocks[current_prop] = []
                prop_blocks[current_prop].append(child)
            elif child.get("class") == ["pageBreak"]:
                continue
            elif current_prop:
                prop_blocks[current_prop].append(child)

        # 1. Informações do Caso / Request Parameters
        if "request_parameters" in prop_blocks:
            for b in prop_blocks["request_parameters"]:
                for to in b.find_all("div", class_="t o"):
                    ti = to.find("div", class_="t i")
                    if ti:
                        m = ti.find("div", class_="m")
                        key = ti.contents[0].strip() if ti.contents and isinstance(ti.contents[0], str) else ""
                        if not key:
                            key_text = ti.get_text(separator=" | ", strip=True).split("|")[0].strip()
                            key = key_text
                        val = m.get_text(strip=True) if m else ""
                        val = re.sub(r'Meta Platforms Business Record Page \d+', '', val).strip()
                        if key and val:
                            k = key.lower().replace(" ", "_")
                            result["case_info"][k] = val

            # Fallback seguro para capturar via regex caso a estrutura HTML mude
            raw_text = " | ".join([b.get_text(separator=" | ", strip=True) for b in prop_blocks["request_parameters"]])
            raw_text = re.sub(r'Meta Platforms Business Record Page \d+', ' ', raw_text)
            
            ticket_m = re.search(r'Internal Ticket Number\s*\|\s*(\d+)', raw_text, re.I)
            if ticket_m and not result["case_info"].get("internal_ticket_number"):
                result["case_info"]["internal_ticket_number"] = ticket_m.group(1).strip()
            
            target_m = re.search(r'Target\s*\|\s*(\d+)', raw_text, re.I)
            if target_m and not result["case_info"].get("target"):
                result["case_info"]["target"] = target_m.group(1).strip()

            acc_id_m = re.search(r'Account Identifier\s*\|\s*([^|]+)', raw_text, re.I)
            if acc_id_m and not result["case_info"].get("account_identifier"):
                result["case_info"]["account_identifier"] = acc_id_m.group(1).strip()

            date_range_m = re.search(r'Date Range\s*\|\s*([^|]+)', raw_text, re.I)
            if date_range_m and not result["case_info"].get("date_range"):
                result["case_info"]["date_range"] = date_range_m.group(1).strip()

            gen_m = re.search(r'Generated\s*\|\s*(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+UTC)', raw_text, re.I)
            if gen_m and not result["case_info"].get("generated"):
                result["case_info"]["generated"] = gen_m.group(1).strip()

        # 2. Dados Cadastrais do Alvo
        target_fields = [
            "name", "vanity", "registration_date",
            "registration_ip", "phone_numbers", "threads_registration_date"
        ]
        for field in target_fields:
            if field in prop_blocks:
                data_values = []
                for b in prop_blocks[field]:
                    tos = b.find_all("div", class_="t o")
                    for to in tos:
                        to_text = to.get_text(separator=" | ", strip=True)
                        if "Definition" not in to_text and "unverified: list of" not in to_text.lower() and "provided by the account holder" not in to_text.lower():
                            parts = [p.strip() for p in to_text.split("|") if p.strip()]
                            if parts:
                                val = parts[-1]
                                if val and val not in ["Name", "First", "Emails", "Vanity Name", "Registration Date", "Registration Ip", "Phone Numbers", "Threads Registration Date", "No responsive records located"]:
                                    if field == "phone_numbers" and not re.search(r'\d{6,}', val):
                                        continue
                                    data_values.append(val)
                
                if data_values:
                    final_val = data_values[-1]
                    if field == "registration_ip":
                        # Captura universal de IP de cadastro (IPv4 ou IPv6)
                        ip_match = re.search(r'([0-9a-fA-F:.]+(?:::?[0-9a-fA-F]+)*)', final_val)
                        final_val = ip_match.group(0).strip() if ip_match else final_val
                    elif field in ["registration_date", "threads_registration_date"]:
                        date_match = re.search(r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+UTC', final_val)
                        final_val = date_match.group(0) if date_match else final_val
                    result["target_info"][field] = final_val

        # 2.1 E-mails Cadastrais (Captura universal de múltiplos e-mails com status e verificação)
        if "emails" in prop_blocks:
            raw_em_text = " ".join([b.get_text(separator=" ", strip=True) for b in prop_blocks["emails"]])
            em_matches = re.findall(r'([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)(?:\s*\(([^)]+)\))?', raw_em_text)
            if em_matches:
                clean_emails = []
                seen_em = set()
                for em, status in em_matches:
                    em_entry = f"{em} ({status.strip()})" if status else em
                    if em_entry not in seen_em:
                        seen_em.add(em_entry)
                        clean_emails.append(em_entry)
                result["target_info"]["emails"] = "\n".join(clean_emails)
            else:
                result["target_info"]["emails"] = None


        # 3. Seguidores e Seguidos
        if "followers" in prop_blocks:
            result["followers"] = self._parse_accounts_list(prop_blocks["followers"], has_timestamp=True)
        if "following" in prop_blocks:
            result["following"] = self._parse_accounts_list(prop_blocks["following"], has_timestamp=False)
        if "threads_followers" in prop_blocks:
            result["threads_followers"] = self._parse_accounts_list(prop_blocks["threads_followers"], has_timestamp=True)
        if "threads_following" in prop_blocks:
            result["threads_following"] = self._parse_accounts_list(prop_blocks["threads_following"], has_timestamp=True)

        # 3.5. Comentários Públicos/Privados do Alvo (property-comments / Comments Definition)
        if "comments" in prop_blocks:
            result["comments"] = self._parse_comments(prop_blocks["comments"])

        # 4. Histórico de IPs de Conexão (Universal IPv4 e IPv6 com suporte total a quebras de página)
        ip_section_match = re.search(r'id=["\']property-ip_addresses["\']', html_str)
        if ip_section_match:
            start_pos = ip_section_match.start()
            next_prop = re.search(r'id=["\']property-(?!ip_addresses)', html_str[start_pos + 30:])
            end_pos = start_pos + 30 + next_prop.start() if next_prop else len(html_str)
            ip_section_html = html_str[start_pos:end_pos]
            ip_section_html = re.sub(r'<div id="page_\d+"[^>]*>.*?</div>', '', ip_section_html)
            ip_section_html = re.sub(r'Meta Platforms Business Record Page \d+', '', ip_section_html)

            soup_ips = bs4.BeautifulSoup(ip_section_html, 'html.parser')
            text_chunks = [t.strip() for t in soup_ips.stripped_strings if t.strip()]

            time_regex = re.compile(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+UTC$')
            seen_ips = set()
            current_ip = None
            i = 0
            while i < len(text_chunks):
                chunk = text_chunks[i]
                if chunk in ["IP Address", "IPAddress", "Ip Addresses"]:
                    i += 1
                    if i < len(text_chunks):
                        candidate_ip = text_chunks[i]
                        clean_ip = re.sub(r'^(?:IP\s*Address|Ip\s*Addresses|IPAddress)+', '', candidate_ip, flags=re.I).strip()
                        clean_ip = re.sub(r'\s+', '', clean_ip)
                        if ('.' in clean_ip or ':' in clean_ip) and not time_regex.match(clean_ip):
                            current_ip = clean_ip
                elif chunk in ["Time", "Timestamp", "Data"]:
                    i += 1
                    if i < len(text_chunks):
                        candidate_time = text_chunks[i]
                        if time_regex.match(candidate_time):
                            if current_ip:
                                ip_key = f"{current_ip}_{candidate_time}"
                                if ip_key not in seen_ips:
                                    seen_ips.add(ip_key)
                                    result["ip_connections"].append({
                                        "ip_address": current_ip,
                                        "timestamp_utc": candidate_time,
                                        "timestamp_brt": self.utc_to_brt(candidate_time)
                                    })
                                current_ip = None
                elif time_regex.match(chunk) and current_ip:
                    ip_key = f"{current_ip}_{chunk}"
                    if ip_key not in seen_ips:
                        seen_ips.add(ip_key)
                        result["ip_connections"].append({
                            "ip_address": current_ip,
                            "timestamp_utc": chunk,
                            "timestamp_brt": self.utc_to_brt(chunk)
                        })
                    current_ip = None
                i += 1

        # 4.5. Dispositivos e Aparelhos Físicos (property-devices)
        dev_match = re.search(r'id=["\']property-devices["\']', html_str)
        if dev_match:
            start_pos = dev_match.start()
            next_prop = re.search(r'id=["\']property-(?!devices)', html_str[start_pos + 25:])
            end_pos = start_pos + 25 + next_prop.start() if next_prop else len(html_str)
            dev_section_html = html_str[start_pos:end_pos]
            dev_section_html = re.sub(r'<div id="page_\d+"[^>]*>.*?</div>', '', dev_section_html)
            dev_section_html = re.sub(r'<div class="pageBreak"[^>]*>.*?</div>', '', dev_section_html)
            dev_section_html = re.sub(r'Meta Platforms Business Record Page \d+', '', dev_section_html)

            soup_devs = bs4.BeautifulSoup(dev_section_html, 'html.parser')
            current_dev = {}
            seen_ids = set()

            for to in soup_devs.find_all('div', class_='t o'):
                ti = to.find('div', class_='t i')
                if not ti:
                    continue

                header_text = ti.contents[0].strip() if ti.contents and isinstance(ti.contents[0], str) else ti.get_text(separator='|', strip=True).split('|')[0].strip()
                m_div = ti.find('div', class_='m')
                val_text = m_div.get_text(strip=True) if m_div else ''

                if 'Definition' in header_text or 'Information about' in val_text:
                    continue

                header_lower = header_text.lower()
                if header_lower == 'type':
                    if current_dev.get('id'):
                        dev_id = current_dev['id']
                        if dev_id not in seen_ids:
                            seen_ids.add(dev_id)
                            result["devices"].append(current_dev)
                    current_dev = {'type': val_text or 'UUID', 'id': '', 'active': False, 'users': ''}
                elif header_lower == 'id':
                    if not current_dev:
                        current_dev = {'type': 'UUID', 'id': '', 'active': False, 'users': ''}
                    current_dev['id'] = val_text
                    if val_text.lower().startswith('android-') and (not current_dev.get('type') or current_dev['type'] == 'UUID'):
                        current_dev['type'] = 'Android'
                    elif '-' in val_text and len(val_text) == 36 and (not current_dev.get('type') or current_dev['type'] == 'UUID'):
                        current_dev['type'] = 'Apple iOS (UUID)'
                elif header_lower == 'active':
                    if current_dev:
                        current_dev['active'] = (val_text.lower() in ['true', '1', 'yes', 'ativo'])
                elif header_lower in ['user', 'users']:
                    if current_dev:
                        current_dev['users'] = val_text

            if current_dev.get('id') and current_dev['id'] not in seen_ids:
                result["devices"].append(current_dev)

        # 5. Mensagens Diretas (DMs / Unified Messages)
        prop_idx = html_str.find("Property Details")
        if prop_idx != -1:
            um_idx = html_str.find("Unified Messages", prop_idx)
            html_section = html_str[um_idx:] if um_idx != -1 else html_str[prop_idx:]
        else:
            html_section = html_str

        thread_blocks = re.split(r'<div class="t o"><div class="t i">Thread<div class="m"><div>\s*\((\d+)\)', html_section)
        seen_msg_keys = set()

        for i in range(1, len(thread_blocks), 2):
            current_thread_id = thread_blocks[i].strip()
            thread_content = thread_blocks[i+1]

            # Extrair Current Participants atravessando quebras de página até o primeiro Author
            cp_section = thread_content.split('<div class="t o"><div class="t i">Author')[0]
            cp_clean = re.sub(r'Meta Platforms Business Record Page \d+', ' ', cp_section)
            cp_clean = re.sub(r'<[^>]+>', ' ', cp_clean)
            p_users = re.findall(r'([a-zA-Z0-9._]+)\s*\(\s*Instagram:\s*(\d+)\s*\)', cp_clean)
            
            clean_participants = []
            seen_u = set()
            for u in p_users:
                uname = u[0].strip()
                if uname and uname not in seen_u:
                    seen_u.add(uname)
                    clean_participants.append(uname)

            # Fatiar mensagens dentro desta thread por Author
            msg_blocks = re.split(r'<div class="t o"><div class="t i">Author', thread_content)
            for m_blk in msg_blocks[1:]:
                author_m = re.search(r'<div class="m"><div>(.*?)<div class="p">', m_blk, re.DOTALL)
                if not author_m:
                    continue
                author_raw = re.sub(r'Meta Platforms Business Record Page \d+', ' ', author_m.group(1))
                author_raw = re.sub(r'<[^>]+>', ' ', author_raw).strip()
                author_user_m = re.search(r'([a-zA-Z0-9._]+)\s*\(\s*Instagram:\s*(\d+)\s*\)', author_raw)
                sender_user = author_user_m.group(1).strip() if author_user_m else author_raw
                sender_uid = author_user_m.group(2).strip() if author_user_m else ''

                sent_m = re.search(r'Sent<div class="m"><div>(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+UTC)', m_blk)
                if not sent_m:
                    continue
                sent_time = sent_m.group(1).strip()

                # Extrair Body de forma literal com remoção estrita de paginação Meta
                body_m = re.search(r'Body<div class="m"><div>(.*?)(?:<div class="p">|<div class="t o">|$)', m_blk, re.DOTALL)
                body_raw = body_m.group(1) if body_m else ''
                # Remover blocos HTML de quebra de página e cabeçalhos/rodapés da Meta
                body_clean = re.sub(r'<div\s+id=["\']page_\d+["\'][^>]*>.*?</div>', '', body_raw, flags=re.DOTALL | re.IGNORECASE)
                body_clean = re.sub(r'<div\s+class=["\']header["\'][^>]*>.*?</div>', '', body_clean, flags=re.DOTALL | re.IGNORECASE)
                body_clean = re.sub(r'<div\s+class=["\']footer["\'][^>]*>.*?</div>', '', body_clean, flags=re.DOTALL | re.IGNORECASE)
                body_clean = re.sub(r'Meta Platforms Business Record(?: Page \d+)?', '', body_clean, flags=re.IGNORECASE)
                body_text = re.sub(r'<[^>]+>', '', body_clean).strip()
                body_text = re.sub(r'Meta Platforms Business Record(?: Page \d+)?', '', body_text, flags=re.IGNORECASE).strip()

                # Extrair bloco Share completo (Publicação, Story ou Reel compartilhado)
                share_text_m = re.search(r'Share.*?Text<div class="m"><div>(.*?)(?:<div class="p">|<div class="t o">|</div></div>)', m_blk, re.DOTALL)
                share_text = ""
                if share_text_m:
                    raw_st = re.sub(r'<[^>]+>', ' ', share_text_m.group(1))
                    raw_st = re.sub(r'Meta Platforms Business Record(?: Page \d+)?', '', raw_st, flags=re.IGNORECASE)
                    share_text = re.sub(r'\s+', ' ', raw_st).strip()

                share_url_m = re.search(r'Share.*?Url<div class="m"><div>(https?://[^\s<]+)', m_blk, re.DOTALL)
                share_url = share_url_m.group(1).strip() if share_url_m else ""

                share_date_m = re.search(r'Share.*?Date Created<div class="m"><div>(.*?)(?:<div class="p">|<div class="t o">|</div></div>)', m_blk, re.DOTALL)
                share_date = ""
                if share_date_m:
                    raw_sd = re.sub(r'<[^>]+>', '', share_date_m.group(1)).strip()
                    if raw_sd and raw_sd.lower() != "unknown":
                        share_date = raw_sd

                if share_text or share_url:
                    share_lines = []
                    if share_text:
                        share_lines.append(f"📝 Publicação: \"{share_text}\"")
                    if share_url:
                        share_lines.append(f"🔗 Link: {share_url}")
                    if share_date:
                        share_lines.append(f"📅 Postado em: {share_date}")

                    share_block_str = "\n".join(share_lines)
                    clean_body_lower = body_text.lower().strip()
                    if clean_body_lower and not any(k in clean_body_lower for k in ["sent an attachment", "sent an attachment."]):
                        body_text = f"{body_text}\n\n[Publicação Compartilhada]\n{share_block_str}"
                    else:
                        body_text = f"[Publicação Compartilhada]\n{share_block_str}"

                # Mensagens Temporárias (Disappearing Messages)
                disappearing_m = re.search(r'Disappearing Message<div class="m"><div>(On|Off)', m_blk, re.IGNORECASE)
                disappearing_dur_m = re.search(r'Disappearing Duration<div class="m"><div>([^<]+)', m_blk, re.IGNORECASE)
                if disappearing_m and disappearing_m.group(1).strip().lower() == "on":
                    dur_str = f" ({disappearing_dur_m.group(1).strip()})" if disappearing_dur_m else ""
                    body_text = f"{body_text}\n⏳ [Mensagem Temporária{dur_str}]".strip()

                # Mensagens Apagadas pelo Remetente (Unsend / Removed by Sender)
                removed_m = re.search(r'Removed by Sender<div class="m"><div>(True|Yes|1)', m_blk, re.IGNORECASE)
                if removed_m:
                    body_text = f"🚫 [Mensagem Apagada pelo Remetente (Unsend)]\n{body_text}".strip()

                # Extrair Mídia
                media_src_m = re.search(r'linked_media/([^"\'<\s]+)', m_blk)
                att_id_m = re.search(r'\((\d{10,20})\)', m_blk)
                media_filename = None
                msg_type = "text"

                if media_src_m:
                    media_filename = media_src_m.group(1).strip()
                elif att_id_m:
                    att_id = att_id_m.group(1).strip()
                    for ext in [".mp3", ".m4a", ".aac", ".mp4", ".jpg", ".jpeg", ".png", ".webp"]:
                        possible = f"unified_message_{att_id}{ext}"
                        if os.path.exists(os.path.join(case_media_dir, possible)):
                            media_filename = possible
                            break

                if media_filename:
                    ext = os.path.splitext(media_filename)[1].lower()
                    if ext in [".mp3", ".aac", ".m4a", ".ogg", ".wav"]:
                        msg_type = "audio"
                    elif ext in [".mp4", ".mov", ".avi", ".webm"]:
                        msg_type = "video"
                    elif ext in [".jpg", ".jpeg", ".png", ".webp", ".gif"]:
                        msg_type = "image"

                # Formatação de prefixos forenses
                if "sent a sticker" in body_text.lower() and not body_text.startswith("🏷️"):
                    body_text = f"🏷️ {body_text}"
                elif "sent a voice message" in body_text.lower() and not body_text.startswith("🎤"):
                    body_text = f"🎤 {body_text}"
                elif "sent a video" in body_text.lower() and not body_text.startswith("🎥"):
                    body_text = f"🎥 {body_text}"
                elif "sent an attachment" in body_text.lower() and not body_text.startswith("📎") and not body_text.startswith("[Publicação"):
                    body_text = f"📎 {body_text}"

                # Se o corpo for vazio (""), mantemos "" 100% literal!

                msg_fingerprint = f"{current_thread_id}_{sender_uid}_{sent_time}_{body_text}_{media_filename}"
                if msg_fingerprint not in seen_msg_keys:
                    seen_msg_keys.add(msg_fingerprint)
                    result["threads"][current_thread_id].append({
                        "thread_id": current_thread_id,
                        "sender_username": sender_user,
                        "sender_name": sender_user,
                        "sender_id": sender_uid,
                        "timestamp_utc": sent_time,
                        "timestamp_brt": self.utc_to_brt(sent_time),
                        "content": body_text,
                        "message_type": msg_type,
                        "media_path": f"/media/target_{target_id}/{media_filename}" if media_filename else None,
                        "participants": clean_participants
                    })

        return result

    def _parse_accounts_list(self, blocks: List[bs4.element.Tag], has_timestamp: bool) -> List[Dict[str, Any]]:
        accounts = []
        seen_uids = set()

        # 1. Estratégia Principal: Processamento de Div-Table estruturado (com remoção de quebras de página da Meta)
        combined_html = "".join([str(b) for b in blocks])
        clean_html = re.sub(r'<div class="pageBreak"[^>]*>.*?</div>', '', combined_html)
        clean_html = re.sub(r'<div id="page_\d+"[^>]*>.*?</div>', '', clean_html)
        clean_html = re.sub(r'Meta Platforms Business Record Page \d+', '', clean_html)

        p_soup = bs4.BeautifulSoup(clean_html, 'html.parser')
        text_chunks = [t.strip() for t in p_soup.stripped_strings if t.strip()]

        start_idx = 0
        for idx, c in enumerate(text_chunks):
            if 'Definition' in c:
                continue
            if c in ['Followers', 'Following', 'Threads Followers', 'Threads Following']:
                start_idx = idx + 1
                break

        # Padrão flexível: username (Instagram: 123) [Nome] ou username (123) [Nome]
        account_re = re.compile(r'^([a-zA-Z0-9._]+)\s*\((?:Instagram:\s*|Threads:\s*)?(\d+)\)\s*(?:\[(.*?)\])?$')
        time_re = re.compile(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+UTC$')

        current_acc = None
        i = start_idx
        while i < len(text_chunks):
            chunk = text_chunks[i]
            m = account_re.match(chunk)
            if m:
                uname = m.group(1).strip()
                uid = m.group(2).strip()
                dname = m.group(3).strip() if m.group(3) else ""
                if uid not in seen_uids:
                    seen_uids.add(uid)
                    current_acc = {
                        "username": uname,
                        "uid": uid,
                        "display_name": dname,
                        "timestamp_utc": None,
                        "timestamp_brt": None
                    }
                    accounts.append(current_acc)
            elif time_re.match(chunk) and current_acc and not current_acc["timestamp_utc"]:
                current_acc["timestamp_utc"] = chunk
                current_acc["timestamp_brt"] = self.utc_to_brt(chunk)
            i += 1

        # 2. Estratégia Fallback: Tabelas HTML convencionais ou regex em texto plano
        if not accounts:
            raw_text = " | ".join([b.get_text(separator=" | ", strip=True) for b in blocks])
            pattern = re.compile(r'([a-zA-Z0-9._]+)\s*[\(\[](?:\w+:\s*)?(\d+)[\)\]]\s*(?:\[(.*?)\])?(?:.*?(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+UTC))?')
            for m in pattern.finditer(raw_text):
                uname = m.group(1).strip()
                uid = m.group(2).strip()
                dname = m.group(3).strip() if m.group(3) else ""
                t_utc = m.group(4).strip() if m.group(4) else None
                if uname.lower() not in ["follower", "following", "timestamp", "time", "definition", "thread"] and uid not in seen_uids:
                    seen_uids.add(uid)
                    accounts.append({
                        "username": uname,
                        "uid": uid,
                        "display_name": dname,
                        "timestamp_utc": t_utc,
                        "timestamp_brt": self.utc_to_brt(t_utc) if t_utc else None
                    })

        return accounts

    def _parse_comments(self, blocks: List[bs4.element.Tag]) -> List[Dict[str, Any]]:
        comments = []
        combined_html = "".join([str(b) for b in blocks])
        clean_html = re.sub(r'<div class="pageBreak"[^>]*>.*?</div>', '', combined_html)
        clean_html = re.sub(r'<div id="page_\d+"[^>]*>.*?</div>', '', clean_html)
        clean_html = re.sub(r'Meta Platforms Business Record Page \d+', '', clean_html)

        soup_c = bs4.BeautifulSoup(clean_html, 'html.parser')
        text_all = soup_c.get_text(separator=' | ', strip=True)
        if "No responsive records" in text_all:
            return []

        # Fatiar blocos por ID de comentário
        id_blocks = re.split(r'<div class="t o"><div class="t i">ID<div class="m"><div>', clean_html)
        for b in id_blocks[1:]:
            cid_m = re.match(r'(\d+)', b)
            cid = cid_m.group(1).strip() if cid_m else ""

            mcid_m = re.search(r'Media Content ID<div class="m"><div>([^<]+)', b)
            mcid = mcid_m.group(1).strip() if mcid_m else ""

            mowner_m = re.search(r'Media Owner<div class="m"><div>([^<]+)', b)
            mowner = mowner_m.group(1).strip() if mowner_m else ""

            date_m = re.search(r'Date Created<div class="m"><div>(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+UTC)', b)
            d_utc = date_m.group(1).strip() if date_m else None

            status_m = re.search(r'Status<div class="m"><div>([^<]+)', b)
            status = status_m.group(1).strip() if status_m else ""

            text_m = re.search(r'Text<div class="m"><div>(.*?)(?:<div class="p">|<div class="t o">|</div></div>)', b, re.DOTALL)
            c_text = re.sub(r'<[^>]+>', ' ', text_m.group(1)).strip() if text_m else ""

            owner_m = re.search(r'Owner<div class="m"><div>([^<]+)', b)
            owner = owner_m.group(1).strip() if owner_m else ""

            author_m = re.search(r'Author<div class="m"><div>([^<]+)', b)
            author = author_m.group(1).strip() if author_m else ""

            priv_m = re.search(r'Privacy Setting<div class="m"><div>([^<]+)', b)
            priv = priv_m.group(1).strip() if priv_m else ""

            if cid or c_text:
                comments.append({
                    "comment_id": cid,
                    "media_content_id": mcid,
                    "media_owner": mowner,
                    "date_created_utc": d_utc,
                    "date_created_brt": self.utc_to_brt(d_utc) if d_utc else None,
                    "status": status,
                    "text": c_text,
                    "owner": owner,
                    "author": author,
                    "privacy_setting": priv
                })

        return comments

    def _merge_data(self, target: Dict[str, Any], source: Dict[str, Any]):
        for k, v in source.get("case_info", {}).items():
            if v and (k not in target["case_info"] or not target["case_info"][k]):
                target["case_info"][k] = v

        for k, v in source.get("target_info", {}).items():
            if v and v != "No responsive records located" and (k not in target["target_info"] or not target["target_info"][k]):
                target["target_info"][k] = v
            elif k not in target["target_info"]:
                target["target_info"][k] = v

        for key in ["followers", "following", "threads_followers", "threads_following"]:
            existing_uids = {item["uid"] for item in target.get(key, [])}
            for item in source.get(key, []):
                if item["uid"] not in existing_uids:
                    existing_uids.add(item["uid"])
                    target[key].append(item)

        target.setdefault("devices", [])
        existing_devs = {d.get("id") for d in target.get("devices", [])}
        for d in source.get("devices", []):
            if d.get("id") and d["id"] not in existing_devs:
                existing_devs.add(d["id"])
                target["devices"].append(d)

        target.setdefault("comments", [])
        existing_cids = {c.get("comment_id") for c in target.get("comments", []) if c.get("comment_id")}
        for c in source.get("comments", []):
            if c.get("comment_id") and c["comment_id"] not in existing_cids:
                existing_cids.add(c["comment_id"])
                target["comments"].append(c)

        existing_ips = {f"{c['ip_address']}_{c['timestamp_utc']}" for c in target.get("ip_connections", [])}
        for c in source.get("ip_connections", []):
            k = f"{c['ip_address']}_{c['timestamp_utc']}"
            if k not in existing_ips:
                existing_ips.add(k)
                target["ip_connections"].append(c)

        for tid, msgs in source.get("threads", {}).items():
            existing_msg_keys = {
                f"{m.get('sender_id')}_{m.get('timestamp_utc')}_{m.get('content')}_{m.get('media_path')}"
                for m in target["threads"][tid]
            }
            for m in msgs:
                mk = f"{m.get('sender_id')}_{m.get('timestamp_utc')}_{m.get('content')}_{m.get('media_path')}"
                if mk not in existing_msg_keys:
                    existing_msg_keys.add(mk)
                    target["threads"][tid].append(m)

    def _save_to_database(
        self,
        data: Dict[str, Any],
        operation_id: int,
        phase_id: int,
        target_id: int,
        phase_target_id: Optional[int]
    ) -> int:
        conn = get_db_connection()
        cursor = conn.cursor()

        target_info = data.get("target_info", {})
        case_info = data.get("case_info", {})

        target_uid = case_info.get("target") or "UNKNOWN_UID"
        full_name = target_info.get("name")
        acc_id = (case_info.get("account_identifier") or "").strip().rstrip("/")
        vanity_name = target_info.get("vanity")
        if not vanity_name and acc_id:
            vanity_name = acc_id.split("/")[-1] if "/" in acc_id else acc_id
        if not vanity_name:
            vanity_name = "unknown"
        email = target_info.get("emails")
        phone = target_info.get("phone_numbers")
        if phone and (phone == "No responsive records located" or "unverified: list of" in phone.lower() or not re.search(r'\d{6,}', phone)):
            phone = None
        reg_date_utc = target_info.get("registration_date")
        reg_date_brt = self.utc_to_brt(reg_date_utc) if reg_date_utc else None
        reg_ip = target_info.get("registration_ip")
        threads_reg_utc = target_info.get("threads_registration_date")
        threads_reg_brt = self.utc_to_brt(threads_reg_utc) if threads_reg_utc else None

        # Atualizar dados do Alvo na tabela Targets master se aplicável
        clean_handle = f"@{vanity_name}" if vanity_name and vanity_name != "unknown" else None
        clean_name = full_name if (full_name and full_name != "No responsive records located") else clean_handle

        cursor.execute("""
            UPDATE targets SET
                main_identifier = CASE 
                    WHEN main_identifier IS NULL OR main_identifier = '' OR main_identifier = '@alvo' OR main_identifier LIKE 'Alvo_%' THEN COALESCE(?, main_identifier)
                    ELSE main_identifier
                END,
                name_or_alias = CASE 
                    WHEN name_or_alias IS NULL OR name_or_alias = '' OR name_or_alias = 'Alvo_Meta' OR name_or_alias LIKE 'Alvo_%' OR name_or_alias LIKE 'Investigado%' THEN COALESCE(?, main_identifier)
                    ELSE name_or_alias
                END,
                email = COALESCE(NULLIF(?, ''), email),
                phone = COALESCE(phone, ?),
                registration_ip = COALESCE(registration_ip, ?),
                registration_date = COALESCE(registration_date, ?),
                verified_phone = COALESCE(verified_phone, ?)
            WHERE id = ?
        """, (
            clean_handle,
            clean_name,
            email,
            phone,
            reg_ip,
            reg_date_brt or reg_date_utc,
            phone,
            target_id
        ))

        # Inserir ou atualizar Alvo Instagram na Fase (por UID ou Vanity Name)
        if target_uid and target_uid != "UNKNOWN_UID":
            cursor.execute("SELECT id FROM instagram_targets WHERE phase_id = ? AND target_id = ? AND target_uid = ?", (phase_id, target_id, target_uid))
        elif vanity_name and vanity_name != "unknown":
            cursor.execute("SELECT id FROM instagram_targets WHERE phase_id = ? AND target_id = ? AND vanity_name = ?", (phase_id, target_id, vanity_name))
        else:
            cursor.execute("SELECT id FROM instagram_targets WHERE phase_id = ? AND target_id = ?", (phase_id, target_id))
        
        existing = cursor.fetchone()
        internal_ticket = case_info.get("internal_ticket_number")
        date_range = case_info.get("date_range")
        generated = case_info.get("generated")
        raw_meta = json.dumps(case_info, ensure_ascii=False)

        if existing:
            ig_target_id = existing["id"]
            cursor.execute("""
                UPDATE instagram_targets SET
                    target_uid = CASE WHEN ? != 'UNKNOWN_UID' THEN ? ELSE target_uid END,
                    internal_ticket = COALESCE(?, internal_ticket),
                    date_range = COALESCE(?, date_range),
                    report_generated_utc = COALESCE(?, report_generated_utc),
                    raw_metadata = COALESCE(?, raw_metadata),
                    vanity_name = COALESCE(?, vanity_name),
                    full_name = COALESCE(?, full_name),
                    email = COALESCE(NULLIF(?, ''), email),
                    phone = COALESCE(?, phone),
                    registration_date_utc = COALESCE(?, registration_date_utc),
                    registration_date_brt = COALESCE(?, registration_date_brt),
                    registration_ip = COALESCE(?, registration_ip),
                    threads_registration_date_utc = COALESCE(?, threads_registration_date_utc),
                    threads_registration_date_brt = COALESCE(?, threads_registration_date_brt)
                WHERE id = ?
            """, (
                target_uid, target_uid, internal_ticket, date_range, generated, raw_meta,
                vanity_name, full_name, email, phone, reg_date_utc, reg_date_brt, reg_ip,
                threads_reg_utc, threads_reg_brt, ig_target_id
            ))
        else:
            cursor.execute("""
                INSERT INTO instagram_targets (
                    phase_target_id, phase_id, target_id, service, internal_ticket, target_uid, vanity_name, full_name,
                    email, phone, registration_date_utc, registration_date_brt,
                    registration_ip, threads_registration_date_utc, threads_registration_date_brt,
                    date_range, report_generated_utc, raw_metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                phase_target_id,
                phase_id,
                target_id,
                case_info.get("service", "Instagram"),
                case_info.get("internal_ticket_number"),
                target_uid,
                vanity_name,
                full_name,
                email,
                phone,
                reg_date_utc,
                reg_date_brt,
                reg_ip,
                threads_reg_utc,
                threads_reg_brt,
                case_info.get("date_range"),
                case_info.get("generated"),
                json.dumps(case_info, ensure_ascii=False)
            ))
            ig_target_id = cursor.lastrowid

        # Inserir Relacionamentos (vinculados ao target_uid da conta)
        cursor.execute("DELETE FROM instagram_relationships WHERE target_id = ? AND phase_id = ?", (target_id, phase_id))
        rel_batches = []
        for f in data.get("followers", []):
            rel_batches.append((target_id, phase_id, target_uid, "follower", "instagram", f["username"], f["uid"], f["display_name"], f["timestamp_utc"], f["timestamp_brt"]))
        for f in data.get("following", []):
            rel_batches.append((target_id, phase_id, target_uid, "following", "instagram", f["username"], f["uid"], f["display_name"], f["timestamp_utc"], f["timestamp_brt"]))
        for f in data.get("threads_followers", []):
            rel_batches.append((target_id, phase_id, target_uid, "threads_follower", "threads", f["username"], f["uid"], f["display_name"], f["timestamp_utc"], f["timestamp_brt"]))
        for f in data.get("threads_following", []):
            rel_batches.append((target_id, phase_id, target_uid, "threads_following", "threads", f["username"], f["uid"], f["display_name"], f["timestamp_utc"], f["timestamp_brt"]))

        if rel_batches:
            cursor.executemany("""
                INSERT OR IGNORE INTO instagram_relationships (
                    target_id, phase_id, target_uid, rel_type, platform, username, uid, display_name, timestamp_utc, timestamp_brt
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, rel_batches)

        # Inserir Dispositivos (vinculados ao target_uid da conta)
        cursor.execute("DELETE FROM instagram_devices WHERE target_id = ? AND phase_id = ?", (target_id, phase_id))
        dev_batches = []
        for d in data.get("devices", []):
            dev_batches.append((target_id, phase_id, target_uid, d.get("type"), d.get("id"), 1 if d.get("active") else 0, d.get("users")))
        if dev_batches:
            cursor.executemany("""
                INSERT OR IGNORE INTO instagram_devices (target_id, phase_id, target_uid, device_type, device_id, is_active, associated_users)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, dev_batches)

        # Inserir Conexões de IP (vinculados ao target_uid da conta)
        ip_batches = []
        for conn_ip in data.get("ip_connections", []):
            ip_batches.append((target_id, phase_id, target_uid, conn_ip["timestamp_utc"], conn_ip["timestamp_brt"], conn_ip["ip_address"]))
        if ip_batches:
            cursor.executemany("""
                INSERT OR IGNORE INTO instagram_connections (target_id, phase_id, target_uid, timestamp_utc, timestamp_brt, ip_address)
                VALUES (?, ?, ?, ?, ?, ?)
            """, ip_batches)

        # Inserir Mensagens (remover apenas as threads reimportadas no mesmo arquivo)
        thread_keys = list(data.get("threads", {}).keys())
        if thread_keys:
            placeholders = ",".join(["?"] * len(thread_keys))
            cursor.execute(f"DELETE FROM messages WHERE target_id = ? AND phase_id = ? AND platform = 'instagram' AND thread_id IN ({placeholders})", [target_id, phase_id] + thread_keys)

        msg_batches = []
        for tid, msgs in data.get("threads", {}).items():
            for m in msgs:
                msg_batches.append((
                    operation_id, phase_id, target_id, phase_target_id, "instagram", tid, m["sender_id"],
                    m["sender_username"], m.get("sender_name"), None, None,
                    json.dumps(m.get("participants", []), ensure_ascii=False),
                    m["timestamp_utc"], m["timestamp_brt"], m["message_type"],
                    m["content"], m["media_path"], None
                ))

        if msg_batches:
            cursor.executemany("""
                INSERT INTO messages (
                    operation_id, phase_id, target_id, phase_target_id, platform, thread_id, sender_id,
                    sender_username, sender_name, receiver_id, receiver_username,
                    participants, timestamp_utc, timestamp_brt, message_type,
                    content, media_path, duration_seconds
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, msg_batches)

        # Inserir Comentários Públicos/Privados do Alvo (property-comments)
        cursor.execute("DELETE FROM instagram_comments WHERE target_id = ? AND phase_id = ?", (target_id, phase_id))
        comment_batches = []
        for c in data.get("comments", []):
            comment_batches.append((
                target_id, phase_id, target_uid, c.get("comment_id"), c.get("media_content_id"),
                c.get("media_owner"), c.get("date_created_utc"), c.get("date_created_brt"),
                c.get("status"), c.get("text"), c.get("owner"), c.get("author"), c.get("privacy_setting")
            ))
        if comment_batches:
            cursor.executemany("""
                INSERT INTO instagram_comments (
                    target_id, phase_id, target_uid, comment_id, media_content_id,
                    media_owner, date_created_utc, date_created_brt, status, text,
                    owner, author, privacy_setting
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, comment_batches)

        # Linha do tempo
        timeline_events = []
        if reg_date_utc:
            timeline_events.append((
                operation_id, phase_id, target_id, "instagram", "account_created",
                reg_date_utc, reg_date_brt or reg_date_utc,
                f"Criação da Conta Instagram (@{vanity_name})",
                f"Conta criada com IP {reg_ip or 'não informado'}. Nome: {full_name or 'N/A'}",
                target_uid, vanity_name, json.dumps({"ip": reg_ip, "email": email})
            ))
        for conn_ip in data.get("ip_connections", []):
            timeline_events.append((
                operation_id, phase_id, target_id, "instagram", "ip_login",
                conn_ip["timestamp_utc"], conn_ip["timestamp_brt"],
                f"Conexão/Login Instagram (IP: {conn_ip['ip_address']})",
                f"Sessão registrada com o endereço IP {conn_ip['ip_address']}.",
                target_uid, vanity_name, json.dumps(conn_ip)
            ))

        if timeline_events:
            cursor.executemany("""
                INSERT INTO timeline_events (
                    operation_id, phase_id, target_id, platform, event_type, timestamp_utc, timestamp_brt,
                    title, description, entity_id, entity_name, extra_data
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, timeline_events)

        conn.commit()
        conn.close()
        return ig_target_id

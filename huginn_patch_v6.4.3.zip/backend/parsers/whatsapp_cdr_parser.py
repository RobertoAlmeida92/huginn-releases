import os
import re
import zipfile
import json
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional, Tuple
from bs4 import BeautifulSoup

from backend.database import get_db_connection
from backend.services.ip_service import IpService

# Fuso Horário de Brasília (UTC-3)
BRT_TZ = timezone(timedelta(hours=-3))

def parse_utc_to_brt(utc_str: str) -> Tuple[str, str]:
    """
    Converte timestamp em UTC ('2025-07-14 22:29:38 UTC') para strings formatadas:
    retorna (iso_utc, formatted_brt).
    """
    if not utc_str:
        return "", ""
    try:
        clean = utc_str.replace("UTC", "").strip()
        dt_utc = datetime.strptime(clean, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        dt_brt = dt_utc.astimezone(BRT_TZ)
        iso_utc = dt_utc.strftime("%Y-%m-%d %H:%M:%S UTC")
        formatted_brt = dt_brt.strftime("%d/%m/%Y %H:%M:%S (BRT)")
        return iso_utc, formatted_brt
    except Exception:
        return utc_str, utc_str

class WhatsAppCdrParser:
    """
    Parser forense para extratos de conexão e bilhetagem diária do WhatsApp (Meta Business Record).
    Suporta importação incremental lote a lote ou em massa (15 dias).
    """

    @classmethod
    def inspect_cdr(cls, zip_path_or_bytes) -> Dict[str, Any]:
        """
        Pré-analisa rapidamente o ZIP da bilhetagem para exibir na janela de importação.
        """
        result = {
            "platform": "whatsapp_cdr",
            "is_valid": False,
            "target_identifier": "",
            "target_name": "",
            "ticket_number": "",
            "account_type": "WhatsAppUser",
            "date_range": "",
            "generated_utc": "",
            "generated_brt": "",
            "total_messages": 0,
            "total_calls": 0,
            "unique_contacts_count": 0
        }

        try:
            with zipfile.ZipFile(zip_path_or_bytes, "r") as zf:
                if "records.html" not in zf.namelist():
                    return result

                html_content = zf.read("records.html").decode("utf-8", errors="ignore")
                
                # Checagem estrita de serviço: Se for Instagram ou NÃO for WhatsApp, abortar
                header_check = html_content[:8000].lower()
                if "service | instagram" in header_check or "service: instagram" in header_check or "instagramuser" in header_check:
                    return result
                if "service | whatsapp" not in header_check and "whatsappuser" not in header_check and "whatsapp" not in header_check:
                    return result

                soup = BeautifulSoup(html_content, "html.parser")

                blocks = soup.find_all("div", class_="o")
                senders = set()
                recipients = set()

                for b in blocks:
                    txt = b.get_text(separator=" | ", strip=True)
                    if "Account Identifier |" in txt:
                        parts = txt.split("Account Identifier |")
                        if len(parts) > 1:
                            val = parts[1].split("|")[0].strip()
                            result["target_identifier"] = val
                    elif "Internal Ticket Number |" in txt:
                        parts = txt.split("Internal Ticket Number |")
                        if len(parts) > 1:
                            result["ticket_number"] = parts[1].split("|")[0].strip()
                    elif "Date Range |" in txt:
                        parts = txt.split("Date Range |")
                        if len(parts) > 1:
                            result["date_range"] = parts[1].split("|")[0].strip()
                    elif "Generated |" in txt:
                        parts = txt.split("Generated |")
                        if len(parts) > 1:
                            gen_raw = parts[1].split("|")[0].strip()
                            _, brt = parse_utc_to_brt(gen_raw)
                            result["generated_utc"] = gen_raw
                            result["generated_brt"] = brt

                    if "Message Id |" in txt and "Sender |" in txt:
                        result["total_messages"] += 1
                        m_s = re.search(r'Sender\s*\|\s*(\+?\d+)', txt)
                        if m_s:
                            senders.add(m_s.group(1))
                        m_r = re.search(r'Recipients\s*\|\s*(\+?\d+)', txt)
                        if m_r:
                            recipients.add(m_r.group(1))
                    elif "Call Id |" in txt or ("From |" in txt and "To |" in txt):
                        result["total_calls"] += 1

                result["unique_contacts_count"] = len(senders.union(recipients))
                result["target_name"] = f"Alvo WhatsApp ({result['target_identifier']})"
                is_phone = bool(re.match(r'^\+?\d{8,15}$', result["target_identifier"]))
                result["is_valid"] = bool((result["total_messages"] > 0 or result["total_calls"] > 0) or (is_phone and result["target_identifier"]))
                return result

        except Exception as e:
            print(f"[WhatsAppCdrParser] Erro no pré-scanner: {e}")
            return result

    @classmethod
    def parse_and_store(cls, zip_path: str, operation_id: int, phase_id: int, target_id: int) -> Dict[str, Any]:
        """
        Extrai e persiste todas as mensagens e chamadas da bilhetagem no SQLite.
        Aplica deduplicação estrita via UNIQUE(target_id, message_id) e enriquece os IPs.
        """
        file_name = os.path.basename(zip_path)
        stats = {
            "file_name": file_name,
            "messages_imported": 0,
            "calls_imported": 0,
            "unique_ips": set(),
            "target_identifier": ""
        }

        conn = get_db_connection()
        cursor = conn.cursor()

        # Obter identificador do alvo no banco para determinar se a mensagem foi enviada ou recebida por ele
        cursor.execute("SELECT main_identifier, phone, name_or_alias FROM targets WHERE id = ?", (target_id,))
        t_row = cursor.fetchone()
        target_clean_phone = ""
        if t_row:
            raw_ident = t_row["phone"] or t_row["main_identifier"] or ""
            target_clean_phone = re.sub(r'\D', '', raw_ident)

        with zipfile.ZipFile(zip_path, "r") as zf:
            html_content = zf.read("records.html").decode("utf-8", errors="ignore")
            soup = BeautifulSoup(html_content, "html.parser")

            # 1. Metadados do cabeçalho
            target_ident_doc = ""
            batch_date_label = ""
            for b in soup.find_all("div", class_="o"):
                txt = b.get_text(separator=" | ", strip=True)
                if "Account Identifier |" in txt:
                    parts = txt.split("Account Identifier |")
                    if len(parts) > 1:
                        target_ident_doc = parts[1].split("|")[0].strip()
                elif "Date Range |" in txt:
                    parts = txt.split("Date Range |")
                    if len(parts) > 1:
                        batch_date_label = parts[1].split("|")[0].strip()

            if not target_clean_phone and target_ident_doc:
                target_clean_phone = re.sub(r'\D', '', target_ident_doc)

            stats["target_identifier"] = target_ident_doc or target_clean_phone

            # 2. Parsing de Messages Log
            # Cada bloco de mensagem no HTML da Meta possui 'Message Id'
            raw_msg_blocks = []
            for div in soup.find_all("div", class_="o"):
                txt = div.get_text(separator=" | ", strip=True)
                if "Message Id |" in txt and "Sender |" in txt:
                    raw_msg_blocks.append(txt)

            for txt in raw_msg_blocks:
                # Extração dos campos via regex robusto
                m_time = re.search(r'Timestamp\s*\|\s*([^|]+)', txt)
                m_id = re.search(r'Message Id\s*\|\s*([^|]+)', txt)
                m_sender = re.search(r'Sender\s*\|\s*([^|]+)', txt)
                m_recip = re.search(r'Recipients\s*\|\s*([^|]+)', txt)
                m_ip = re.search(r'Sender Ip\s*\|\s*([^|]+)', txt)
                m_port = re.search(r'Sender Port\s*\|\s*([^|]+)', txt)
                m_dev = re.search(r'Sender Device\s*\|\s*([^|]+)', txt)
                m_type = re.search(r'Type\s*\|\s*([^|]+)', txt)
                m_style = re.search(r'Message Style\s*\|\s*([^|]+)', txt)
                m_size = re.search(r'Message Size\s*\|\s*(\d+)', txt)

                msg_id = m_id.group(1).strip() if m_id else None
                if not msg_id:
                    continue

                raw_time = m_time.group(1).strip() if m_time else ""
                iso_utc, formatted_brt = parse_utc_to_brt(raw_time)

                sender_raw = m_sender.group(1).strip() if m_sender else ""
                recip_raw = m_recip.group(1).strip() if m_recip else ""
                sender_clean = re.sub(r'[^\d+]', '', sender_raw)
                recip_clean = re.sub(r'[^\d+]', '', recip_raw)

                sender_digits = re.sub(r'\D', '', sender_clean)
                is_target_sender = 1 if (target_clean_phone and sender_digits == target_clean_phone) else 0

                raw_sender_ip = m_ip.group(1).strip() if m_ip else ""
                port_val = int(m_port.group(1).strip()) if (m_port and m_port.group(1).strip().isdigit()) else None
                clean_ip, extracted_port = IpService.extract_ip_and_port(raw_sender_ip)
                final_port = port_val if port_val is not None else extracted_port

                if clean_ip:
                    stats["unique_ips"].add(clean_ip)

                dev_val = m_dev.group(1).strip().lower() if m_dev else "android"
                type_val = m_type.group(1).strip().lower() if m_type else "text"
                style_val = m_style.group(1).strip().lower() if m_style else "individual"
                size_val = int(m_size.group(1)) if m_size else 0

                cursor.execute("""
                    INSERT OR IGNORE INTO whatsapp_cdr_messages (
                        operation_id, phase_id, target_id, batch_file_name, batch_day_date,
                        message_id, timestamp_utc, timestamp_brt, sender, recipients,
                        is_target_sender, sender_ip, sender_port, clean_ip, sender_device,
                        msg_type, msg_style, msg_size
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    operation_id, phase_id, target_id, file_name, batch_date_label,
                    msg_id, iso_utc, formatted_brt, sender_clean or sender_raw, recip_clean or recip_raw,
                    is_target_sender, raw_sender_ip, final_port, clean_ip, dev_val,
                    type_val, style_val, size_val
                ))

                if cursor.rowcount > 0:
                    stats["messages_imported"] += 1

            # 3. Parsing de Call Logs (Chamadas de Áudio e Vídeo)
            # Agrupar eventos de chamadas por Call Id
            call_blocks = {}
            for div in soup.find_all("div", class_="o"):
                txt = div.get_text(separator=" | ", strip=True)
                if "Call Id |" in txt or ("From |" in txt and "To |" in txt):
                    m_cid = re.search(r'Call Id\s*\|\s*([a-fA-F0-9]+)', txt)
                    call_id = m_cid.group(1).strip() if m_cid else f"call_{len(call_blocks)+1}"
                    if call_id not in call_blocks:
                        call_blocks[call_id] = []
                    call_blocks[call_id].append(txt)

            for call_id, events_txts in call_blocks.items():
                parsed_events = []
                for ev_txt in events_txts:
                    m_ev_type = re.search(r'Type\s*\|\s*([a-zA-Z]+)', ev_txt)
                    m_ev_time = re.search(r'Timestamp\s*\|\s*([^|]+)', ev_txt)
                    m_from = re.search(r'From\s*\|\s*([^|]+)', ev_txt)
                    m_to = re.search(r'To\s*\|\s*([^|]+)', ev_txt)
                    m_fip = re.search(r'From Ip\s*\|\s*([^|]+)', ev_txt)
                    m_fport = re.search(r'From Port\s*\|\s*([^|]+)', ev_txt)
                    m_media = re.search(r'Media Type\s*\|\s*([^|]+)', ev_txt)
                    m_creator = re.search(r'Call Creator\s*\|\s*([^|]+)', ev_txt)

                    ev_type = m_ev_type.group(1).strip().lower() if m_ev_type else "offer"
                    raw_time = m_ev_time.group(1).strip() if m_ev_time else ""
                    from_num = re.sub(r'[^\d+]', '', m_from.group(1).strip()) if m_from else ""
                    to_num = re.sub(r'[^\d+]', '', m_to.group(1).strip()) if m_to else ""
                    creator_num = re.sub(r'[^\d+]', '', m_creator.group(1).strip()) if m_creator else from_num
                    media_t = m_media.group(1).strip().lower() if m_media else "audio"

                    raw_fip = m_fip.group(1).strip() if m_fip else ""
                    fport_val = int(m_fport.group(1).strip()) if (m_fport and m_fport.group(1).strip().isdigit()) else None
                    clean_fip, extracted_fport = IpService.extract_ip_and_port(raw_fip)
                    final_fport = fport_val if fport_val is not None else extracted_fport

                    if clean_fip:
                        stats["unique_ips"].add(clean_fip)

                    parsed_events.append({
                        "event_type": ev_type,
                        "raw_time": raw_time,
                        "from": from_num,
                        "to": to_num,
                        "creator": creator_num,
                        "raw_ip": raw_fip,
                        "clean_ip": clean_fip,
                        "port": final_fport,
                        "media_type": media_t
                    })

                # Calcular duração e status da ligação
                duration_sec = 0
                status_call = "atendida"
                accept_ev = next((e for e in parsed_events if e["event_type"] == "accept"), None)
                terminate_ev = next((e for e in parsed_events if e["event_type"] == "terminate"), None)
                reject_ev = next((e for e in parsed_events if e["event_type"] == "reject"), None)

                if accept_ev and terminate_ev:
                    try:
                        t_acc = datetime.strptime(accept_ev["raw_time"].replace("UTC", "").strip(), "%Y-%m-%d %H:%M:%S")
                        t_term = datetime.strptime(terminate_ev["raw_time"].replace("UTC", "").strip(), "%Y-%m-%d %H:%M:%S")
                        duration_sec = max(0, int((t_term - t_acc).total_seconds()))
                        status_call = "atendida"
                    except Exception:
                        duration_sec = 0
                elif reject_ev:
                    status_call = "recusada"
                else:
                    status_call = "perdida"

                # Persistir os eventos
                for ev in parsed_events:
                    iso_utc, formatted_brt = parse_utc_to_brt(ev["raw_time"])
                    creator_digits = re.sub(r'\D', '', ev["creator"])
                    is_target_creator = 1 if (target_clean_phone and creator_digits == target_clean_phone) else 0

                    cursor.execute("""
                        INSERT OR IGNORE INTO whatsapp_cdr_calls (
                            operation_id, phase_id, target_id, batch_file_name, batch_day_date,
                            call_id, call_creator, is_target_creator, from_number, to_number,
                            event_type, status, timestamp_utc, timestamp_brt,
                            from_ip, from_port, clean_ip, media_type, duration_seconds
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        operation_id, phase_id, target_id, file_name, batch_date_label,
                        call_id, ev["creator"], is_target_creator, ev["from"], ev["to"],
                        ev["event_type"], status_call, iso_utc, formatted_brt,
                        ev["raw_ip"], ev["port"], ev["clean_ip"], ev["media_type"], duration_sec
                    ))

                    if cursor.rowcount > 0:
                        stats["calls_imported"] += 1

        conn.commit()
        conn.close()

        # Enriquecer os novos IPs encontrados em lote no banco
        if stats["unique_ips"]:
            try:
                IpService.batch_enrich_ips(list(stats["unique_ips"]))
            except Exception as e:
                print(f"[WhatsAppCdrParser] Erro ao enriquecer IPs em lote: {e}")

        return stats

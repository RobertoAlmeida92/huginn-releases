import sqlite3
import os
import re
import json
from datetime import datetime
from typing import Optional, List, Dict, Any

from backend.config import DB_PATH

def get_db_connection():
    conn = sqlite3.connect(DB_PATH, timeout=60.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 60000")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db(reset=False):
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    conn = get_db_connection()
    conn.execute("PRAGMA journal_mode = WAL")
    cursor = conn.cursor()
    
    # 1. Tabela de Operações / Inquéritos / Processos
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS operations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        police_unit TEXT,
        court_docket TEXT, -- Número do Processo Judicial / Vara
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)
    
    # 2. Tabela de Fases da Operação
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS phases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        name TEXT NOT NULL, -- Ex: 'Fase 1 - Preservação Inicial', 'Fase 2 - Quebra de DMs'
        court_order_number TEXT, -- Número do Mandado / Ofício
        date_range TEXT,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE
    );
    """)
    
    # 3. Tabela de Alvos da Operação (Reaproveitáveis em múltiplas fases)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS targets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        name_or_alias TEXT NOT NULL, -- Ex: 'Otavio Couto Henrique' ou 'Alvo 01'
        main_identifier TEXT NOT NULL, -- Ex: '@071_benee', '+5521968104889', UID
        email TEXT,
        phone TEXT,
        platform TEXT DEFAULT 'both', -- 'instagram', 'whatsapp', 'both'
        cpf_cnpj TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE
    );
    """)

    # Migração segura para colunas email e phone em targets
    cursor.execute("PRAGMA table_info(targets)")
    target_cols = [r[1] for r in cursor.fetchall()]
    if "email" not in target_cols:
        cursor.execute("ALTER TABLE targets ADD COLUMN email TEXT")
    if "phone" not in target_cols:
        cursor.execute("ALTER TABLE targets ADD COLUMN phone TEXT")
    
    # 4. Vinculação Alvo <-> Fase (Phase Targets)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS phase_targets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        UNIQUE(phase_id, target_id)
    );
    """)

    # 5. Cadeia de Custódia (Arquivos importados e Hashes SHA-256)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS custody_files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        phase_target_id INTEGER,
        platform TEXT NOT NULL, -- 'instagram' ou 'whatsapp'
        file_name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        file_size INTEGER NOT NULL,
        sha256_hash TEXT NOT NULL,
        declared_hash TEXT, -- Hash SHA-256 declarado pelo portal/provedor (Meta/LERS)
        imported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE
    );
    """)

    # Migração segura para tabela existente
    try:
        cursor.execute("ALTER TABLE custody_files ADD COLUMN declared_hash TEXT")
    except Exception:
        pass
    
    # 6. Instagram - Dossiê Cadastral por Fase/Alvo
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS instagram_targets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phase_target_id INTEGER,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        service TEXT DEFAULT 'Instagram',
        internal_ticket TEXT,
        target_uid TEXT NOT NULL,
        vanity_name TEXT,
        full_name TEXT,
        email TEXT,
        phone TEXT,
        registration_date_utc TEXT,
        registration_date_brt TEXT,
        registration_ip TEXT,
        registration_isp TEXT,
        registration_location TEXT,
        threads_registration_date_utc TEXT,
        threads_registration_date_brt TEXT,
        date_range TEXT,
        report_generated_utc TEXT,
        raw_metadata TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE
    );
    """)
    
    # 7. Instagram - Relacionamentos (Seguidores, Seguidos, Threads)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS instagram_relationships (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_uid TEXT, -- UID da conta do alvo proprietária deste relacionamento
        rel_type TEXT NOT NULL, -- 'follower', 'following', 'threads_follower', 'threads_following'
        platform TEXT DEFAULT 'instagram',
        username TEXT NOT NULL,
        uid TEXT,
        display_name TEXT,
        timestamp_utc TEXT,
        timestamp_brt TEXT,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_ig_rel_target ON instagram_relationships (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_ig_rel_user ON instagram_relationships (username, uid);")

    # Migração segura para instagram_relationships
    try:
        cursor.execute("ALTER TABLE instagram_relationships ADD COLUMN target_uid TEXT")
    except Exception:
        pass

    # 7.1 Instagram - Dispositivos / Aparelhos Físicos Usados pelo Alvo
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS instagram_devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_uid TEXT, -- UID da conta do alvo
        device_type TEXT,
        device_id TEXT NOT NULL,
        is_active BOOLEAN DEFAULT 1,
        associated_users TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_ig_devices_target ON instagram_devices (target_id, phase_id);")

    # Migração segura para instagram_devices
    try:
        cursor.execute("ALTER TABLE instagram_devices ADD COLUMN target_uid TEXT")
    except Exception:
        pass

    # 8. Instagram - Logs de Conexão / IPs de Acesso
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS instagram_connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_uid TEXT, -- UID da conta do alvo
        timestamp_utc TEXT NOT NULL,
        timestamp_brt TEXT,
        ip_address TEXT NOT NULL,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_ig_conn_target ON instagram_connections (target_id, phase_id);")

    # Migração segura para instagram_connections
    try:
        cursor.execute("ALTER TABLE instagram_connections ADD COLUMN target_uid TEXT")
    except Exception:
        pass

    # 8.1 Instagram - Comentários Públicos/Privados do Alvo (Comments Definition)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS instagram_comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_uid TEXT,
        comment_id TEXT,
        media_content_id TEXT,
        media_owner TEXT,
        date_created_utc TEXT,
        date_created_brt TEXT,
        status TEXT,
        text TEXT,
        owner TEXT,
        author TEXT,
        privacy_setting TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_ig_comments_target ON instagram_comments (target_id, phase_id);")


    # 9. WhatsApp - Dados Cadastrais
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS whatsapp_targets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phase_target_id INTEGER,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        phone_number TEXT NOT NULL,
        push_name TEXT,
        email TEXT,
        logical_id TEXT,
        account_type TEXT,
        internal_ticket TEXT,
        date_range TEXT,
        report_generated_utc TEXT,
        profile_pic_path TEXT,
        business_name TEXT,
        business_email TEXT,
        business_address TEXT,
        business_website TEXT,
        status_text TEXT,
        account_created_utc TEXT,
        account_created_brt TEXT,
        registration_ip TEXT,
        registration_isp TEXT,
        registration_location TEXT,
        device_details TEXT,
        raw_metadata TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE
    );
    """)

    # Migrações seguras para whatsapp_targets
    for col in [
        "logical_id TEXT", "account_type TEXT", "internal_ticket TEXT", "date_range TEXT",
        "report_generated_utc TEXT", "profile_pic_path TEXT", "business_name TEXT",
        "business_email TEXT", "business_address TEXT", "business_website TEXT", "status_text TEXT"
    ]:
        try:
            cursor.execute(f"ALTER TABLE whatsapp_targets ADD COLUMN {col}")
        except Exception:
            pass
    
    # 10. WhatsApp - Logs de Conexão
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS whatsapp_connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        timestamp_utc TEXT NOT NULL,
        timestamp_brt TEXT,
        event_type TEXT,
        source_ip TEXT NOT NULL,
        source_port INTEGER,
        dest_ip TEXT,
        dest_port INTEGER,
        isp TEXT,
        location TEXT,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wa_conn_target ON whatsapp_connections (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wa_conn_ip ON whatsapp_connections (source_ip);")
    cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_wa_conn_uniq ON whatsapp_connections (target_id, timestamp_utc, source_ip);")
    
    # 11. WhatsApp - Grupos
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS whatsapp_groups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        group_jid TEXT NOT NULL,
        subject TEXT,
        creator_jid TEXT,
        description TEXT,
        role TEXT DEFAULT 'participating', -- 'owned' ou 'participating'
        profile_pic_path TEXT,
        created_at_utc TEXT,
        created_at_brt TEXT,
        total_participants INTEGER DEFAULT 0,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wa_groups_target ON whatsapp_groups (target_id, phase_id);")
    cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_wa_groups_uniq ON whatsapp_groups (target_id, group_jid);")

    # Migrações seguras para whatsapp_groups
    for col in ["description TEXT", "role TEXT DEFAULT 'participating'", "profile_pic_path TEXT"]:
        try:
            cursor.execute(f"ALTER TABLE whatsapp_groups ADD COLUMN {col}")
        except Exception:
            pass
    
    # 12. WhatsApp - Membros de Grupos
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS whatsapp_group_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        user_jid TEXT NOT NULL,
        phone_number TEXT,
        is_admin BOOLEAN DEFAULT 0,
        joined_at_utc TEXT,
        joined_at_brt TEXT,
        FOREIGN KEY (group_id) REFERENCES whatsapp_groups (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wa_members_group ON whatsapp_group_members (group_id);")

    # 12.1 WhatsApp - Agenda de Contatos Sincronizada
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS whatsapp_contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        phone_number TEXT NOT NULL,
        display_name TEXT,
        is_symmetric BOOLEAN DEFAULT 1,
        profile_pic_path TEXT,
        raw_info TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wa_contacts_target ON whatsapp_contacts (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wa_contacts_phone ON whatsapp_contacts (phone_number);")
    cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_wa_contacts_uniq ON whatsapp_contacts (target_id, phone_number);")

    # Migração segura para profile_pic_path
    cursor.execute("PRAGMA table_info(whatsapp_contacts)")
    wa_c_cols = [row[1] for row in cursor.fetchall()]
    if "profile_pic_path" not in wa_c_cols:
        cursor.execute("ALTER TABLE whatsapp_contacts ADD COLUMN profile_pic_path TEXT;")

    # 12.2 WhatsApp - Dispositivos Físicos e Sessões Web/Desktop
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS whatsapp_devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        target_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        device_id TEXT,
        device_type TEXT,
        app_version TEXT,
        os_version TEXT,
        device_manufacturer TEXT,
        device_model TEXT,
        service_start_utc TEXT,
        service_start_brt TEXT,
        last_seen_utc TEXT,
        last_seen_brt TEXT,
        last_ip TEXT,
        status TEXT,
        is_active BOOLEAN DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_wa_devices_uniq ON whatsapp_devices (target_id, device_id);")
    # 12.3 WhatsApp - Bilhetagem & CDRs de Mensagens (Interceptação Diária)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS whatsapp_cdr_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        batch_file_name TEXT,
        batch_day_date TEXT,
        message_id TEXT NOT NULL,
        timestamp_utc TEXT NOT NULL,
        timestamp_brt TEXT,
        sender TEXT NOT NULL,
        recipients TEXT NOT NULL,
        is_target_sender BOOLEAN DEFAULT 0,
        sender_ip TEXT,
        sender_port INTEGER,
        clean_ip TEXT,
        sender_device TEXT,
        msg_type TEXT DEFAULT 'text',
        msg_style TEXT DEFAULT 'individual',
        msg_size INTEGER,
        encrypted_content TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        UNIQUE(target_id, message_id) ON CONFLICT IGNORE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wacdr_msg_target ON whatsapp_cdr_messages (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wacdr_msg_sender ON whatsapp_cdr_messages (sender, recipients);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wacdr_msg_time ON whatsapp_cdr_messages (timestamp_utc);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wacdr_msg_ip ON whatsapp_cdr_messages (clean_ip);")

    # 12.4 WhatsApp - Bilhetagem & CDRs de Chamadas (Voz / Vídeo com Duração)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS whatsapp_cdr_calls (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        batch_file_name TEXT,
        batch_day_date TEXT,
        call_id TEXT NOT NULL,
        call_creator TEXT NOT NULL,
        is_target_creator BOOLEAN DEFAULT 0,
        from_number TEXT NOT NULL,
        to_number TEXT NOT NULL,
        event_type TEXT NOT NULL, -- 'offer', 'accept', 'terminate', 'reject'
        status TEXT DEFAULT 'atendida', -- 'atendida', 'recusada', 'perdida'
        timestamp_utc TEXT NOT NULL,
        timestamp_brt TEXT,
        from_ip TEXT,
        from_port INTEGER,
        clean_ip TEXT,
        media_type TEXT DEFAULT 'audio', -- 'audio', 'video'
        duration_seconds INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        UNIQUE(target_id, call_id, event_type, timestamp_utc) ON CONFLICT IGNORE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wacdr_calls_target ON whatsapp_cdr_calls (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wacdr_calls_pair ON whatsapp_cdr_calls (from_number, to_number);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_wacdr_calls_time ON whatsapp_cdr_calls (timestamp_utc);")
    
    # 13. Mensagens & DMs (WhatsApp & Instagram)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        phase_target_id INTEGER,
        platform TEXT NOT NULL,
        thread_id TEXT NOT NULL,
        sender_id TEXT NOT NULL,
        sender_username TEXT,
        sender_name TEXT,
        receiver_id TEXT,
        receiver_username TEXT,
        participants TEXT,
        timestamp_utc TEXT NOT NULL,
        timestamp_brt TEXT,
        message_type TEXT DEFAULT 'text',
        content TEXT,
        media_path TEXT,
        duration_seconds INTEGER,
        transcription TEXT,
        transcription_status TEXT DEFAULT 'pending',
        transcribed_at TIMESTAMP,
        transcribed_by TEXT,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_msg_op_thread ON messages (operation_id, phase_id, thread_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_msg_sender ON messages (sender_username, sender_id);")

    # Migrações seguras para mensagens (transcrição de áudio pericial)
    for col, col_type in [
        ("transcription", "TEXT"),
        ("transcription_status", "TEXT DEFAULT 'pending'"),
        ("transcribed_at", "TIMESTAMP"),
        ("transcribed_by", "TEXT")
    ]:
        try:
            cursor.execute(f"ALTER TABLE messages ADD COLUMN {col} {col_type}")
        except Exception:
            pass

    cursor.execute("CREATE INDEX IF NOT EXISTS idx_msg_transcription ON messages (transcription);")

    # 14. Linha do Tempo Unificada
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS timeline_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        platform TEXT NOT NULL,
        event_type TEXT NOT NULL,
        timestamp_utc TEXT NOT NULL,
        timestamp_brt TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        entity_id TEXT,
        entity_name TEXT,
        extra_data TEXT,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_timeline_op_phase ON timeline_events (operation_id, phase_id, timestamp_utc);")

    # 15. Anotações, Status e Marcadores de Leitura de DMs do Analista
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS dm_thread_annotations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        platform TEXT NOT NULL DEFAULT 'instagram',
        thread_id TEXT NOT NULL,
        is_read BOOLEAN DEFAULT 0,
        is_starred BOOLEAN DEFAULT 0,
        last_read_message_id INTEGER,
        notes TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(operation_id, platform, thread_id),
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE
    );
    """)

    # Migração segura para garantir a coluna platform em bases existentes
    cursor.execute("PRAGMA table_info(dm_thread_annotations)")
    dm_cols = [r[1] for r in cursor.fetchall()]
    if dm_cols and "platform" not in dm_cols:
        cursor.execute("ALTER TABLE dm_thread_annotations ADD COLUMN platform TEXT NOT NULL DEFAULT 'instagram'")

    cursor.execute("CREATE INDEX IF NOT EXISTS idx_dm_annotations ON dm_thread_annotations (operation_id, platform, thread_id);")

    # 16. Marcadores e Tags de Evidência para Relatório Pericial
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS message_evidence_tags (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        message_id INTEGER NOT NULL,
        tag_label TEXT DEFAULT 'Prova Chave',
        analyst_notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(operation_id, message_id),
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (message_id) REFERENCES messages (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_evidence_op_msg ON message_evidence_tags (operation_id, message_id);")

    # Migrações seguras para a tabela targets
    cursor.execute("PRAGMA table_info(targets)")
    target_cols = [r[1] for r in cursor.fetchall()]
    if "registration_ip" not in target_cols:
        cursor.execute("ALTER TABLE targets ADD COLUMN registration_ip TEXT")
    if "registration_date" not in target_cols:
        cursor.execute("ALTER TABLE targets ADD COLUMN registration_date TEXT")
    if "verified_phone" not in target_cols:
        cursor.execute("ALTER TABLE targets ADD COLUMN verified_phone TEXT")
    if "threads_registration_date" not in target_cols:
        cursor.execute("ALTER TABLE targets ADD COLUMN threads_registration_date TEXT")

    # 17. Sanitização automática de resquícios de paginação Meta em mensagens legadas
    try:
        cursor.execute("SELECT id, content FROM messages WHERE content LIKE '%Business Record%'")
        rows = cursor.fetchall()
        for r in rows:
            mid = r[0]
            txt = r[1]
            if txt:
                new_txt = re.sub(r'Meta Platforms Business Record(?: Page \d+)?', '', txt, flags=re.IGNORECASE).strip()
                if new_txt != txt:
                    cursor.execute("UPDATE messages SET content = ? WHERE id = ?", (new_txt, mid))
    except Exception:
        pass

    # 18. Google - Contas e Dados Cadastrais (SubscriberInfo)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_targets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        google_account_id TEXT NOT NULL,
        email TEXT NOT NULL,
        full_name TEXT,
        given_name TEXT,
        family_name TEXT,
        created_at_utc TEXT,
        created_at_brt TEXT,
        terms_ip TEXT,
        terms_language TEXT,
        terms_country TEXT,
        provider TEXT,
        birthday TEXT,
        services_list TEXT,
        status TEXT,
        last_updated_utc TEXT,
        last_logins TEXT,
        contact_email TEXT,
        recovery_email TEXT,
        recovery_sms TEXT,
        profile_pic_path TEXT,
        raw_metadata TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_targets_tid ON google_targets (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_targets_email ON google_targets (email);")

    # 19. Google - Dispositivos Android (DeviceAndUserProfile)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        google_target_id INTEGER,
        android_id TEXT,
        brand TEXT,
        model TEXT,
        product TEXT,
        build_fingerprint TEXT,
        radio_firmware TEXT,
        bootloader_firmware TEXT,
        play_services_version TEXT,
        roaming_state TEXT,
        connection_time_utc TEXT,
        connection_time_brt TEXT,
        http_response_code TEXT,
        raw_details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (google_target_id) REFERENCES google_targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_devices_target ON google_devices (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_devices_gtid ON google_devices (google_target_id);")

    # 20. Google - Geografia & Mobilidade (Maps Labeled Places + Waze)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_locations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        google_target_id INTEGER,
        source TEXT NOT NULL, -- 'maps' ou 'waze'
        location_type TEXT,   -- 'Home', 'Work', 'Favorite', 'Labeled'
        name TEXT,            -- ex: 'Home', 'Porto Sol Club'
        address TEXT,         -- Endereço formatado completo
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        timestamp_utc TEXT,
        timestamp_brt TEXT,
        raw_json TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (google_target_id) REFERENCES google_targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_locs_target ON google_locations (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_locs_gtid ON google_locations (google_target_id);")

    # 21. Google - Correio Eletrônico Gmail (MBOX + Metadados JSON)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_emails (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        google_target_id INTEGER,
        message_id TEXT,
        thread_id TEXT,
        server_id TEXT,
        folder TEXT DEFAULT 'INBOX', -- 'INBOX', 'Sent', 'Deleted', 'Trash', 'Spam', 'Archived'
        date_utc TEXT,
        date_brt TEXT,
        from_address TEXT,
        to_address TEXT,
        cc_address TEXT,
        bcc_address TEXT,
        subject TEXT,
        snippet TEXT,
        body_text TEXT,
        body_html TEXT,
        has_attachments BOOLEAN DEFAULT 0,
        attachments_json TEXT,
        is_read BOOLEAN DEFAULT 0,
        is_starred BOOLEAN DEFAULT 0,
        is_trash BOOLEAN DEFAULT 0,
        is_spam BOOLEAN DEFAULT 0,
        is_deleted BOOLEAN DEFAULT 0,
        status_action_date TEXT,
        size_bytes INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (google_target_id) REFERENCES google_targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_emails_target ON google_emails (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_emails_gtid ON google_emails (google_target_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_emails_gtid_folder ON google_emails (google_target_id, folder);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_emails_folder ON google_emails (folder);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_emails_date ON google_emails (date_utc);")

    # 22. Google - Auditoria de Conexões e Logs de IPs (Access Log + Subscriber Logins)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_ip_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        google_target_id INTEGER,
        timestamp_utc TEXT,
        timestamp_brt TEXT,
        ip_address TEXT NOT NULL,
        clean_ip TEXT,
        event_type TEXT, -- 'Login', 'OAuth Session', 'Token Creation', 'Service Access'
        android_id TEXT,
        user_agent TEXT,
        isp TEXT,
        is_mobile BOOLEAN DEFAULT 0,
        city TEXT,
        region TEXT,
        country TEXT,
        raw_info TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (google_target_id) REFERENCES google_targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_ip_target ON google_ip_logs (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_ip_gtid ON google_ip_logs (google_target_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_ip_addr ON google_ip_logs (clean_ip);")

    # 23. Google - Fotos & Mídias da Nuvem (Google Photos)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_photos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER NOT NULL,
        phase_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        google_target_id INTEGER,
        title TEXT,
        file_name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        file_size INTEGER DEFAULT 0,
        media_type TEXT DEFAULT 'image', -- 'image' ou 'video'
        capture_time_utc TEXT,
        capture_time_brt TEXT,
        exif_hash TEXT,
        latitude REAL,
        longitude REAL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (google_target_id) REFERENCES google_targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_photos_target ON google_photos (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_photos_gtid ON google_photos (google_target_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_photos_gtid_time ON google_photos (google_target_id, capture_time_utc);")

    # ==================== GOOGLE CHROME: HISTÓRICO DE NAVEGAÇÃO ====================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_chrome_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER,
        phase_id INTEGER,
        target_id INTEGER,
        google_target_id INTEGER,
        url TEXT NOT NULL,
        title TEXT,
        visit_time_utc TEXT,
        visit_time_brt TEXT,
        visit_count INTEGER DEFAULT 1,
        typed_count INTEGER DEFAULT 0,
        transition TEXT,
        raw_json TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (google_target_id) REFERENCES google_targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_chrome_hist_target ON google_chrome_history (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_chrome_hist_gtid ON google_chrome_history (google_target_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_chrome_hist_time ON google_chrome_history (google_target_id, visit_time_utc);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_chrome_hist_url ON google_chrome_history (url);")

    # ==================== GOOGLE CHROME: FAVORITOS ====================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_chrome_bookmarks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER,
        phase_id INTEGER,
        target_id INTEGER,
        google_target_id INTEGER,
        title TEXT,
        url TEXT,
        folder TEXT,
        date_added_utc TEXT,
        date_added_brt TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (google_target_id) REFERENCES google_targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_chrome_bm_gtid ON google_chrome_bookmarks (google_target_id);")

    # ==================== MINHA ATIVIDADE: PESQUISAS & ÁUDIOS DE VOZ ====================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_activities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER,
        phase_id INTEGER,
        target_id INTEGER,
        google_target_id INTEGER,
        product TEXT,
        action_text TEXT,
        target_url TEXT,
        timestamp_utc TEXT,
        timestamp_brt TEXT,
        audio_file TEXT,
        has_audio INTEGER DEFAULT 0,
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (google_target_id) REFERENCES google_targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_act_target ON google_activities (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_act_gtid ON google_activities (google_target_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_act_time ON google_activities (google_target_id, timestamp_utc);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_act_audio ON google_activities (google_target_id, has_audio);")

    # ==================== GOOGLE DRIVE: ARQUIVOS & NUVEM ====================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_drive_files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER,
        phase_id INTEGER,
        target_id INTEGER,
        google_target_id INTEGER,
        file_id TEXT,
        name TEXT NOT NULL,
        original_path TEXT,
        mime_type TEXT,
        size_bytes INTEGER DEFAULT 0,
        size_formatted TEXT,
        sha256 TEXT,
        file_path TEXT,
        thumbnail_path TEXT,
        creation_date_utc TEXT,
        creation_date_brt TEXT,
        modified_date_utc TEXT,
        modified_date_brt TEXT,
        upload_ip TEXT,
        owner_email TEXT,
        owner_name TEXT,
        is_trashed INTEGER DEFAULT 0,
        is_cloud_only INTEGER DEFAULT 0,
        actions_summary TEXT,
        raw_metadata TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (google_target_id) REFERENCES google_targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_drive_target ON google_drive_files (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_drive_gtid ON google_drive_files (google_target_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_drive_name ON google_drive_files (name);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_drive_ip ON google_drive_files (upload_ip);")

    # ==================== TIMELINE: CONFIGURAÇÕES & HISTÓRICO DE DISPOSITIVOS ====================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS google_timeline_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        operation_id INTEGER,
        phase_id INTEGER,
        target_id INTEGER,
        google_target_id INTEGER,
        gaia_id TEXT,
        device_tag TEXT,
        device_pretty_name TEXT,
        platform_type TEXT,
        reporting_enabled INTEGER DEFAULT 0,
        device_creation_time_utc TEXT,
        device_creation_time_brt TEXT,
        setting_change_source TEXT,
        setting_change_time_utc TEXT,
        setting_change_time_brt TEXT,
        raw_json TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (operation_id) REFERENCES operations (id) ON DELETE CASCADE,
        FOREIGN KEY (phase_id) REFERENCES phases (id) ON DELETE CASCADE,
        FOREIGN KEY (target_id) REFERENCES targets (id) ON DELETE CASCADE,
        FOREIGN KEY (google_target_id) REFERENCES google_targets (id) ON DELETE CASCADE
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_tlset_target ON google_timeline_settings (target_id, phase_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_google_tlset_gtid ON google_timeline_settings (google_target_id);")

    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("Banco de dados SQLite estruturado com sucesso para Operações, Fases e Alvos!")

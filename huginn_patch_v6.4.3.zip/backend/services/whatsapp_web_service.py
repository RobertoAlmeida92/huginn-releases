import os
import re
import time
import queue
import base64
import logging
import threading
from typing import Optional, Dict, Any, List

from playwright.sync_api import sync_playwright
from backend.config import UPLOAD_DIR, AVATAR_DIR
from backend.database import get_db_connection

logger = logging.getLogger(__name__)

WPP_SESSION_DIR = os.path.join(UPLOAD_DIR, "wpp_session")
os.makedirs(WPP_SESSION_DIR, exist_ok=True)
os.makedirs(AVATAR_DIR, exist_ok=True)


class WhatsAppWorkerThread(threading.Thread):
    """Worker thread permanente que isola todo o ciclo de vida do Playwright Chromium."""
    def __init__(self):
        super().__init__(daemon=True, name="WhatsAppWebWorker")
        self.cmd_queue = queue.Queue()
        self.playwright = None
        self.browser_context = None
        self.page = None
        self.is_connected = False
        self.is_ready = False
        self.stop_requested = False
        self.sync_status: Dict[str, Any] = {
            "running": False,
            "total": 0,
            "processed": 0,
            "success": 0,
            "failed": 0,
            "current_phone": "",
            "error": None
        }
        self.start()

    def run(self):
        logger.info("Iniciando WhatsAppWorkerThread...")
        try:
            self._ensure_browser()
            self.is_ready = True

            while not self.stop_requested:
                try:
                    task = self.cmd_queue.get(timeout=1.0)
                except queue.Empty:
                    continue

                if task is None:
                    break

                cmd_name, args, resp_queue = task
                try:
                    if cmd_name == "get_qr_code":
                        res = self._handle_get_qr_code()
                    elif cmd_name == "get_status":
                        res = self._handle_get_status()
                    elif cmd_name == "logout":
                        res = self._handle_logout()
                    elif cmd_name == "sync_avatars":
                        res = self._handle_sync_avatars(*args)
                    else:
                        res = {"error": f"Comando desconhecido: {cmd_name}"}

                    if resp_queue:
                        resp_queue.put((True, res))
                except Exception as e:
                    logger.error(f"Erro ao processar comando {cmd_name} no worker: {e}")
                    if resp_queue:
                        resp_queue.put((False, str(e)))
        finally:
            self._cleanup_browser()

    def _ensure_browser(self):
        if self.playwright is None or self.browser_context is None:
            self.playwright = sync_playwright().start()
            self.browser_context = self.playwright.chromium.launch_persistent_context(
                user_data_dir=WPP_SESSION_DIR,
                headless=True,
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
                viewport={"width": 1280, "height": 900},
                args=["--no-sandbox", "--disable-dev-shm-usage"]
            )
            self.page = self.browser_context.pages[0] if self.browser_context.pages else self.browser_context.new_page()
            try:
                self.page.goto("https://web.whatsapp.com/", timeout=30000)
            except Exception as e:
                logger.warning(f"Aviso ao abrir WhatsApp Web: {e}")

    def _cleanup_browser(self):
        try:
            if self.browser_context:
                self.browser_context.close()
            if self.playwright:
                self.playwright.stop()
        except Exception:
            pass
        self.browser_context = None
        self.playwright = None
        self.page = None
        self.is_connected = False

    def _handle_get_status(self):
        if self.page:
            try:
                is_logged = self.page.query_selector("#pane-side, [data-icon='chat'], [aria-label='Chat list']") is not None
                self.is_connected = is_logged
            except Exception:
                pass
        sync_copy = dict(self.sync_status)
        tot = sync_copy.get("total", 0)
        proc = sync_copy.get("processed", 0)
        sync_copy["progress_pct"] = int((proc / tot) * 100) if tot > 0 else 0
        sync_copy["is_running"] = sync_copy.get("running", False)
        sync_copy["found"] = sync_copy.get("success", 0)
        return {
            "connected": self.is_connected,
            "is_logged_in": self.is_connected,
            "has_session_files": os.path.exists(WPP_SESSION_DIR) and len(os.listdir(WPP_SESSION_DIR)) > 3,
            "sync": sync_copy
        }

    def _handle_get_qr_code(self):
        self._ensure_browser()
        if "web.whatsapp.com" not in self.page.url:
            self.page.goto("https://web.whatsapp.com/", timeout=30000)

        try:
            self.page.wait_for_selector("canvas, #pane-side, [data-icon='chat']", timeout=12000)
        except Exception:
            pass

        # 1. Checar se já logado
        is_logged = self.page.query_selector("#pane-side, [data-icon='chat'], [aria-label='Chat list']") is not None
        if is_logged:
            self.is_connected = True
            return {
                "connected": True,
                "is_logged_in": True,
                "qr_code": None,
                "qr_code_base64": None,
                "message": "WhatsApp Web já está conectado e autenticado."
            }

        self.is_connected = False

        # 2. Localizar canvas do QR Code
        qr_canvas = self.page.query_selector("canvas")
        if qr_canvas:
            png_bytes = qr_canvas.screenshot()
            b64_qr = base64.b64encode(png_bytes).decode("utf-8")
            return {
                "connected": False,
                "is_logged_in": False,
                "qr_code": f"data:image/png;base64,{b64_qr}",
                "qr_code_base64": b64_qr,
                "message": "Aponte o WhatsApp do celular para este QR Code."
            }

        # Fallback container do QR
        qr_container = self.page.query_selector("div[data-ref]") or self.page.query_selector("div[role='textbox']")
        if qr_container:
            png_bytes = qr_container.screenshot()
            b64_qr = base64.b64encode(png_bytes).decode("utf-8")
            return {
                "connected": False,
                "is_logged_in": False,
                "qr_code": f"data:image/png;base64,{b64_qr}",
                "qr_code_base64": b64_qr,
                "message": "Aponte o WhatsApp do celular para este QR Code."
            }

        return {
            "connected": False,
            "is_logged_in": False,
            "qr_code": None,
            "qr_code_base64": None,
            "message": "Aguardando carregamento do QR Code pelo WhatsApp Web..."
        }

    def _handle_logout(self):
        self._cleanup_browser()
        import shutil
        if os.path.exists(WPP_SESSION_DIR):
            try:
                shutil.rmtree(WPP_SESSION_DIR)
                os.makedirs(WPP_SESSION_DIR, exist_ok=True)
            except Exception as e:
                logger.warning(f"Erro ao limpar pasta de sessão: {e}")
        self.is_connected = False
        self._ensure_browser()
        return {"success": True, "message": "Sessão do WhatsApp desconectada com sucesso."}

    def _handle_sync_avatars(self, operation_id: int, target_id: Optional[int] = None):
        self.sync_status = {
            "running": True,
            "total": 0,
            "processed": 0,
            "success": 0,
            "failed": 0,
            "current_phone": "",
            "error": None
        }

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            query = """
                SELECT c.id, c.phone_number, c.display_name, c.profile_pic_path
                FROM whatsapp_contacts c
                JOIN targets t ON c.target_id = t.id
                WHERE t.operation_id = ?
            """
            params = [operation_id]
            if target_id:
                query += " AND c.target_id = ?"
                params.append(target_id)

            cursor.execute(query, params)
            contacts = [dict(r) for r in cursor.fetchall()]
            conn.close()

            if not contacts:
                self.sync_status["running"] = False
                self.sync_status["error"] = "Nenhum contato encontrado para sincronizar."
                return {"success": False, "message": "Nenhum contato encontrado."}

            self.sync_status["total"] = len(contacts)
            self._ensure_browser()

            if "web.whatsapp.com" not in self.page.url:
                self.page.goto("https://web.whatsapp.com/", timeout=30000)

            try:
                self.page.wait_for_selector("#pane-side, [data-icon='chat']", timeout=15000)
                self.is_connected = True
            except Exception:
                self.is_connected = False
                self.sync_status["running"] = False
                self.sync_status["error"] = "WhatsApp Web não está conectado. Escaneie o QR Code primeiro."
                return {"success": False, "message": "WhatsApp Web não conectado."}

            for c in contacts:
                if self.stop_requested:
                    break

                phone_raw = c.get("phone_number") or ""
                clean_phone = re.sub(r"\D", "", phone_raw)
                if not clean_phone:
                    self.sync_status["processed"] += 1
                    continue

                self.sync_status["current_phone"] = phone_raw

                local_fname = f"wa_{clean_phone}.jpg"
                local_fpath = os.path.join(AVATAR_DIR, local_fname)
                if os.path.exists(local_fpath) and os.path.getsize(local_fpath) > 100:
                    self._update_contact_pic_in_db(c["id"], local_fname)
                    self.sync_status["processed"] += 1
                    self.sync_status["success"] += 1
                    continue

                try:
                    url = f"https://web.whatsapp.com/send?phone={clean_phone}"
                    self.page.goto(url, timeout=20000)

                    try:
                        self.page.wait_for_selector("#main header, div[role='dialog']", timeout=8000)
                    except Exception:
                        pass

                    err_modal = self.page.query_selector("div[role='dialog']")
                    if err_modal:
                        btn_ok = err_modal.query_selector("button")
                        if btn_ok:
                            btn_ok.click()
                        self.sync_status["processed"] += 1
                        self.sync_status["failed"] += 1
                        time.sleep(1.5)
                        continue

                    avatar_base64 = self.page.evaluate("""
                        () => {
                            const img = document.querySelector('#main header img');
                            if (!img) return null;
                            try {
                                const canvas = document.createElement('canvas');
                                canvas.width = img.naturalWidth || img.width || 96;
                                canvas.height = img.naturalHeight || img.height || 96;
                                const ctx = canvas.getContext('2d');
                                ctx.drawImage(img, 0, 0);
                                return canvas.toDataURL('image/jpeg', 0.9);
                            } catch (e) {
                                return null;
                            }
                        }
                    """)

                    if avatar_base64 and "," in avatar_base64:
                        img_data = base64.b64decode(avatar_base64.split(",")[1])
                        with open(local_fpath, "wb") as f_out:
                            f_out.write(img_data)

                        self._update_contact_pic_in_db(c["id"], local_fname)
                        self.sync_status["success"] += 1
                    else:
                        self.sync_status["failed"] += 1

                except Exception as ex:
                    logger.warning(f"Erro ao consultar contato {clean_phone}: {ex}")
                    self.sync_status["failed"] += 1

                self.sync_status["processed"] += 1
                time.sleep(3.0)

            return {"success": True, "message": "Sincronização finalizada."}

        except Exception as e:
            logger.error(f"Erro fatal na sincronização de contatos do WhatsApp: {e}")
            self.sync_status["error"] = str(e)
            return {"success": False, "error": str(e)}
        finally:
            self.sync_status["running"] = False

    def _update_contact_pic_in_db(self, contact_id: int, pic_filename: str):
        try:
            conn = get_db_connection()
            conn.execute(
                "UPDATE whatsapp_contacts SET profile_pic_path = ? WHERE id = ?",
                (pic_filename, contact_id)
            )
            conn.commit()
            conn.close()
        except Exception as e:
            logger.warning(f"Erro ao salvar foto de contato no DB: {e}")


class WhatsAppWebService:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(WhatsAppWebService, cls).__new__(cls)
                cls._instance._worker = WhatsAppWorkerThread()
            return cls._instance

    def get_status(self) -> Dict[str, Any]:
        sync_copy = dict(self._worker.sync_status)
        tot = sync_copy.get("total", 0)
        proc = sync_copy.get("processed", 0)
        sync_copy["progress_pct"] = int((proc / tot) * 100) if tot > 0 else 0
        sync_copy["is_running"] = sync_copy.get("running", False)
        sync_copy["found"] = sync_copy.get("success", 0)
        return {
            "connected": self._worker.is_connected,
            "is_logged_in": self._worker.is_connected,
            "has_session_files": os.path.exists(WPP_SESSION_DIR) and len(os.listdir(WPP_SESSION_DIR)) > 3,
            "sync": sync_copy
        }

    def get_qr_code(self) -> Dict[str, Any]:
        resp_q = queue.Queue()
        self._worker.cmd_queue.put(("get_qr_code", (), resp_q))
        success, res = resp_q.get(timeout=30)
        if not success:
            return {"connected": False, "is_logged_in": False, "qr_code": None, "error": str(res)}
        return res

    def logout(self) -> Dict[str, Any]:
        resp_q = queue.Queue()
        self._worker.cmd_queue.put(("logout", (), resp_q))
        success, res = resp_q.get(timeout=30)
        return res if success else {"success": False, "error": str(res)}

    def start_avatar_sync(self, operation_id: int, target_id: Optional[int] = None) -> Dict[str, Any]:
        if self._worker.sync_status.get("running", False):
            return {"success": False, "message": "Sincronização já está em andamento."}
        
        # Enfileira o comando para execução assíncrona na thread do worker sem bloquear o HTTP
        self._worker.cmd_queue.put(("sync_avatars", (operation_id, target_id), None))
        return {"success": True, "message": "Sincronização de fotos iniciada em segundo plano."}

    def close(self):
        self._worker.stop_requested = True
        self._worker.cmd_queue.put(None)


# Instância Singleton
whatsapp_web_service = WhatsAppWebService()

import io
import pandas as pd
from typing import Optional
from backend.database import get_db_connection

class ExportService:
    @staticmethod
    def export_operation_to_excel(operation_id: int, phase_id: Optional[int] = None) -> io.BytesIO:
        conn = get_db_connection()
        output = io.BytesIO()

        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            # 1. Resumo da Operação
            df_op = pd.read_sql_query("SELECT * FROM operations WHERE id = ?", conn, params=(operation_id,))
            df_op.to_excel(writer, sheet_name="Operacao", index=False)

            # 2. Fases
            df_phases = pd.read_sql_query("SELECT * FROM phases WHERE operation_id = ?", conn, params=(operation_id,))
            df_phases.to_excel(writer, sheet_name="Fases", index=False)

            # 3. Alvos
            df_targets = pd.read_sql_query("SELECT * FROM targets WHERE operation_id = ?", conn, params=(operation_id,))
            df_targets.to_excel(writer, sheet_name="Alvos", index=False)

            # 4. Cadeia de Custódia
            custody_q = "SELECT file_name, platform, file_size, sha256_hash, imported_at, phase_id, target_id FROM custody_files WHERE operation_id = ?"
            custody_params = [operation_id]
            if phase_id:
                custody_q += " AND phase_id = ?"
                custody_params.append(phase_id)
            df_custody = pd.read_sql_query(custody_q, conn, params=custody_params)
            if not df_custody.empty:
                df_custody.to_excel(writer, sheet_name="Cadeia de Custodia", index=False)

            # 5. Instagram - Cadastral
            ig_q = """
                SELECT it.target_uid, it.vanity_name, it.full_name, it.email, it.phone,
                       it.registration_date_brt, it.registration_ip,
                       it.threads_registration_date_brt, it.internal_ticket, it.phase_id, t.name_or_alias as alvo
                FROM instagram_targets it
                JOIN targets t ON it.target_id = t.id
                WHERE t.operation_id = ?
            """
            ig_params = [operation_id]
            if phase_id:
                ig_q += " AND it.phase_id = ?"
                ig_params.append(phase_id)
            df_ig = pd.read_sql_query(ig_q, conn, params=ig_params)
            if not df_ig.empty:
                df_ig.to_excel(writer, sheet_name="Instagram Cadastral", index=False)

            # 6. Instagram - Seguidores
            f_q = """
                SELECT r.username, r.uid, r.display_name, r.timestamp_brt as data_follow, t.name_or_alias as alvo, r.phase_id
                FROM instagram_relationships r
                JOIN targets t ON r.target_id = t.id
                WHERE t.operation_id = ? AND r.rel_type = 'follower'
            """
            f_params = [operation_id]
            if phase_id:
                f_q += " AND r.phase_id = ?"
                f_params.append(phase_id)
            f_q += " ORDER BY r.timestamp_utc DESC"
            df_followers = pd.read_sql_query(f_q, conn, params=f_params)
            if not df_followers.empty:
                df_followers.to_excel(writer, sheet_name="Instagram Seguidores", index=False)

            # 7. Mensagens / DMs Gerais
            msg_q = """
                SELECT m.thread_id, m.sender_username, m.timestamp_brt, m.message_type, m.content, m.media_path, t.name_or_alias as alvo
                FROM messages m
                JOIN targets t ON m.target_id = t.id
                WHERE m.operation_id = ?
            """
            msg_params = [operation_id]
            if phase_id:
                msg_q += " AND m.phase_id = ?"
                msg_params.append(phase_id)
            msg_q += " ORDER BY m.timestamp_utc ASC"
            df_msgs = pd.read_sql_query(msg_q, conn, params=msg_params)
            if not df_msgs.empty:
                df_msgs.to_excel(writer, sheet_name="Mensagens DMs", index=False)

            # 8. Evidências Marcadas para Laudo (com Tags)
            ev_q = """
                SELECT t.name_or_alias as alvo, m.platform as plataforma, m.thread_id, m.sender_username as remetente,
                       m.timestamp_brt as data_hora, m.message_type as tipo, m.content as mensagem, m.media_path as midia,
                       et.tag_label as tags, et.analyst_notes as notas_perito
                FROM messages m
                JOIN message_evidence_tags et ON m.id = et.message_id
                JOIN targets t ON m.target_id = t.id
                WHERE et.operation_id = ?
            """
            ev_params = [operation_id]
            if phase_id:
                ev_q += " AND m.phase_id = ?"
                ev_params.append(phase_id)
            ev_q += " ORDER BY m.thread_id ASC, m.timestamp_utc ASC"
            df_ev = pd.read_sql_query(ev_q, conn, params=ev_params)
            if not df_ev.empty:
                # Limpar tags se estiverem em JSON
                def clean_tags_field(val):
                    if not val:
                        return "Prova Chave"
                    s = str(val).strip()
                    if s.startswith("[") and s.endswith("]"):
                        try:
                            l = json.loads(s)
                            return ", ".join(l)
                        except Exception:
                            return s
                    return s
                df_ev["tags"] = df_ev["tags"].apply(clean_tags_field)
                df_ev.to_excel(writer, sheet_name="Evidencias Laudo", index=False)

        conn.close()
        output.seek(0)
        return output

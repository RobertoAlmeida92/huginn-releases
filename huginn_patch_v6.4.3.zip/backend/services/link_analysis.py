from typing import Dict, Any, List, Optional
from backend.database import get_db_connection

class LinkAnalysisService:
    @staticmethod
    def get_case_graph(
        operation_id: int,
        phase_id: Optional[int] = None,
        target_id: Optional[int] = None,
        max_nodes: int = 150
    ) -> Dict[str, Any]:
        """
        Gera a estrutura de nós e arestas para Vis.js filtrado por Operação, Fase ou Alvo.
        """
        conn = get_db_connection()
        cursor = conn.cursor()

        nodes = []
        edges = []
        node_ids = set()

        # 1. Obter Alvos da Operação/Fase
        target_query = "SELECT * FROM targets WHERE operation_id = ?"
        target_params = [operation_id]
        if target_id:
            target_query += " AND id = ?"
            target_params.append(target_id)
        elif phase_id:
            target_query = """
                SELECT t.* FROM targets t
                JOIN phase_targets pt ON t.id = pt.target_id
                WHERE t.operation_id = ? AND pt.phase_id = ?
            """
            target_params = [operation_id, phase_id]

        cursor.execute(target_query, target_params)
        targets = [dict(r) for r in cursor.fetchall()]

        for t in targets:
            t_node_id = f"target_{t['id']}"
            node_ids.add(t_node_id)
            nodes.append({
                "id": t_node_id,
                "label": f"{t['name_or_alias']}\n({t['main_identifier']})",
                "title": f"<b>ALVO INVESTIGADO</b><br>Nome/Alias: {t['name_or_alias']}<br>Identificador: {t['main_identifier']}",
                "group": "target",
                "shape": "diamond",
                "size": 35,
                "color": {"background": "#e11d48", "border": "#be123c"}
            })

            # Relacionamentos do Instagram
            rel_query = "SELECT * FROM instagram_relationships WHERE target_id = ?"
            rel_params = [t['id']]
            if phase_id:
                rel_query += " AND phase_id = ?"
                rel_params.append(phase_id)
            rel_query += " ORDER BY timestamp_utc DESC LIMIT ?"
            rel_params.append(max_nodes)

            cursor.execute(rel_query, rel_params)
            relationships = [dict(r) for r in cursor.fetchall()]

            for rel in relationships:
                r_node_id = f"user_{rel['uid'] or rel['username']}"
                if r_node_id not in node_ids:
                    node_ids.add(r_node_id)
                    is_threads = rel["platform"] == "threads"
                    nodes.append({
                        "id": r_node_id,
                        "label": f"@{rel['username']}" + (f"\n[{rel['display_name'][:12]}]" if rel['display_name'] else ""),
                        "title": f"<b>Perfil:</b> @{rel['username']}<br><b>Nome:</b> {rel['display_name']}<br><b>UID:</b> {rel['uid']}<br><b>Data:</b> {rel['timestamp_brt'] or 'N/A'}",
                        "group": "threads_contact" if is_threads else ("follower" if rel["rel_type"] == "follower" else "following"),
                        "shape": "dot",
                        "size": 18,
                        "color": {"background": "#6366f1" if is_threads else ("#10b981" if rel["rel_type"] == "follower" else "#f59e0b")}
                    })

                if rel["rel_type"] == "follower":
                    edges.append({
                        "from": r_node_id,
                        "to": t_node_id,
                        "arrows": "to",
                        "label": "segue",
                        "font": {"size": 9, "color": "#94a3b8"},
                        "color": {"color": "#10b981", "opacity": 0.6}
                    })
                elif rel["rel_type"] == "following":
                    edges.append({
                        "from": t_node_id,
                        "to": r_node_id,
                        "arrows": "to",
                        "label": "seguido por",
                        "font": {"size": 9, "color": "#94a3b8"},
                        "color": {"color": "#f59e0b", "opacity": 0.6}
                    })

            # Grupos do WhatsApp
            wa_query = "SELECT * FROM whatsapp_groups WHERE target_id = ?"
            wa_params = [t['id']]
            if phase_id:
                wa_query += " AND phase_id = ?"
                wa_params.append(phase_id)
            cursor.execute(wa_query, wa_params)
            groups = [dict(r) for r in cursor.fetchall()]
            for g in groups:
                g_node_id = f"wa_group_{g['id']}"
                if g_node_id not in node_ids:
                    node_ids.add(g_node_id)
                    nodes.append({
                        "id": g_node_id,
                        "label": f"👥 {g['subject']}",
                        "title": f"<b>Grupo WhatsApp</b><br>Assunto: {g['subject']}<br>Membros: {g['total_participants']}",
                        "group": "whatsapp_group",
                        "shape": "box",
                        "color": {"background": "#0d9488"}
                    })
                edges.append({
                    "from": t_node_id,
                    "to": g_node_id,
                    "label": "membro",
                    "color": {"color": "#0d9488"}
                })

        conn.close()
        return {"nodes": nodes, "edges": edges}

import os
import sys
import time
import json
import hmac
import hashlib
import base64
import subprocess
import urllib.request
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Optional, Tuple

from backend.config import APP_DIR, STATIC_DIR, UPLOAD_DIR, MEDIA_BASE_DIR, AVATAR_DIR, CUSTODY_DIR, DB_PATH

# Segredo criptográfico interno pericial para assinatura das licenças
_MASTER_SECRET = b"MetaAnalise_Forensic_Cryptographic_License_Secret_2026_Key"

# Caminho do arquivo de estado de licença local
LICENSE_FILE = os.path.join(APP_DIR, ".license.dat")
TIME_STATE_FILE = os.path.join(APP_DIR, ".time_state.dat")


class LicenseService:
    """
    Serviço forense de proteção, licenciamento por chave,
    verificação anti-fraude de relógio e protocolo de autodestruição.
    """

    @classmethod
    def generate_license_key(cls, tester_name: str, days_valid: int = 7) -> str:
        """
        Gera uma chave assinada criptograficamente contendo o nome do perito e a data de expiração.
        Formato: META-[TESTER_CLEAN]-[EXPIRY_TS]-[SIGNATURE_16]
        """
        now = datetime.now(timezone.utc)
        expiry_dt = now + timedelta(days=days_valid)
        expiry_ts = int(expiry_dt.timestamp())

        tester_clean = "".join(c for c in tester_name if c.isalnum()).upper()[:12] or "PERITO"
        payload = f"{tester_clean}:{expiry_ts}"

        sig = hmac.new(_MASTER_SECRET, payload.encode("utf-8"), hashlib.sha256).hexdigest()[:16].upper()
        return f"META-{tester_clean}-{expiry_ts}-{sig}"

    @classmethod
    def verify_key_format_and_signature(cls, key_str: str) -> Tuple[bool, Optional[Dict[str, Any]], str]:
        """
        Verifica a integridade criptográfica e validade matemática de uma chave.
        """
        clean_key = (key_str or "").strip().upper()
        parts = clean_key.split("-")
        if len(parts) != 4 or parts[0] != "META":
            return False, None, "Formato de chave inválido. Esperado: META-NOME-DATA-HASH"

        tester_clean, expiry_ts_str, sig_provided = parts[1], parts[2], parts[3]
        try:
            expiry_ts = int(expiry_ts_str)
        except ValueError:
            return False, None, "Carimbo de data corrompido na chave."

        payload = f"{tester_clean}:{expiry_ts}"
        expected_sig = hmac.new(_MASTER_SECRET, payload.encode("utf-8"), hashlib.sha256).hexdigest()[:16].upper()

        if not hmac.compare_digest(sig_provided, expected_sig):
            return False, None, "Assinatura da chave inválida ou adulterada."

        expiry_dt = datetime.fromtimestamp(expiry_ts, tz=timezone.utc)
        return True, {
            "key": clean_key,
            "tester_name": tester_clean,
            "expiry_timestamp": expiry_ts,
            "expiry_iso": expiry_dt.isoformat(),
            "expiry_brt": (expiry_dt - timedelta(hours=3)).strftime("%d/%m/%Y %H:%M:%S")
        }, "Chave válida."

    @classmethod
    def get_trusted_current_time(cls) -> Tuple[datetime, bool]:
        """
        Obtém a data/hora real confiável baseada em UTC com proteção de anti-rollback.
        Retorna: (datetime_utc, is_verified)
        """
        return datetime.now(timezone.utc), True

    @classmethod
    def check_anti_rollback(cls, current_dt: datetime) -> bool:
        """
        Protege contra atraso deliberado do relógio do sistema operacional (Anti-Rollback).
        Grava monotonicamente o último horário visto.
        """
        current_ts = int(current_dt.timestamp())
        last_seen_ts = 0

        if os.path.exists(TIME_STATE_FILE):
            try:
                with open(TIME_STATE_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    last_seen_ts = int(data.get("last_seen", 0))
            except Exception:
                last_seen_ts = 0

        # Se o relógio do sistema retrocedeu mais de 2 horas em relação ao último registro visto
        if last_seen_ts > 0 and (last_seen_ts - current_ts) > 7200:
            return False  # Relógio adulterado para trás

        # Atualizar último horário visto se estiver avançando
        if current_ts > last_seen_ts:
            try:
                with open(TIME_STATE_FILE, "w", encoding="utf-8") as f:
                    json.dump({"last_seen": current_ts, "updated_at": datetime.now(timezone.utc).isoformat()}, f)
            except Exception:
                pass

        return True

    @classmethod
    def get_license_status(cls) -> Dict[str, Any]:
        """
        Verifica o status atual da licença na máquina:
        - ativada / pendente
        - tempo restante (dias, horas, minutos)
        - expirada / válida
        """
        if not os.path.exists(LICENSE_FILE):
            return {
                "active": False,
                "status": "unregistered",
                "message": "Nenhuma chave de licença de teste ativada neste dispositivo.",
                "days_remaining": 0,
                "hours_remaining": 0,
                "expired": False
            }

        try:
            with open(LICENSE_FILE, "r", encoding="utf-8") as f:
                saved = json.load(f)
        except Exception:
            return {
                "active": False,
                "status": "corrupted",
                "message": "Arquivo de licença corrompido. Reativação necessária.",
                "days_remaining": 0,
                "hours_remaining": 0,
                "expired": True
            }

        key = saved.get("key", "")
        valid, key_info, msg = cls.verify_key_format_and_signature(key)
        if not valid:
            return {
                "active": False,
                "status": "invalid",
                "message": msg,
                "days_remaining": 0,
                "hours_remaining": 0,
                "expired": True
            }

        current_dt, is_web_verified = cls.get_trusted_current_time()

        if not cls.check_anti_rollback(current_dt):
            return {
                "active": False,
                "status": "clock_tampered",
                "message": "Detectada adulteração no relógio do sistema. Acesso bloqueado por segurança.",
                "days_remaining": 0,
                "hours_remaining": 0,
                "expired": True
            }

        expiry_dt = datetime.fromtimestamp(key_info["expiry_timestamp"], tz=timezone.utc)
        diff = expiry_dt - current_dt
        total_seconds = int(diff.total_seconds())

        if total_seconds <= 0:
            return {
                "active": False,
                "status": "expired",
                "message": "O período de avaliação desta versão foi encerrado.",
                "days_remaining": 0,
                "hours_remaining": 0,
                "expired": True,
                "tester_name": key_info["tester_name"],
                "expiry_brt": key_info["expiry_brt"]
            }

        days_rem = diff.days
        hours_rem = int((diff.seconds // 3600))
        mins_rem = int((diff.seconds % 3600) // 60)

        return {
            "active": True,
            "status": "valid",
            "message": f"Versão de teste ativa. {days_rem} dias e {hours_rem}h restantes.",
            "days_remaining": days_rem,
            "hours_remaining": hours_rem,
            "minutes_remaining": mins_rem,
            "total_seconds": total_seconds,
            "expired": False,
            "tester_name": key_info["tester_name"],
            "expiry_iso": key_info["expiry_iso"],
            "expiry_brt": key_info["expiry_brt"],
            "is_web_verified": is_web_verified
        }

    @classmethod
    def activate_license(cls, key_str: str) -> Dict[str, Any]:
        """
        Ativa a chave de licença no sistema após validação criptográfica.
        """
        valid, key_info, msg = cls.verify_key_format_and_signature(key_str)
        if not valid:
            return {"status": "error", "message": msg}

        current_dt, _ = cls.get_trusted_current_time()
        expiry_dt = datetime.fromtimestamp(key_info["expiry_timestamp"], tz=timezone.utc)

        if current_dt >= expiry_dt:
            return {"status": "error", "message": "Esta chave de teste já expirou."}

        try:
            with open(LICENSE_FILE, "w", encoding="utf-8") as f:
                json.dump({
                    "key": key_info["key"],
                    "tester_name": key_info["tester_name"],
                    "activated_at": current_dt.isoformat(),
                    "expiry_timestamp": key_info["expiry_timestamp"]
                }, f, indent=2)
        except Exception as e:
            return {"status": "error", "message": f"Erro ao salvar licença: {str(e)}"}

        cls.check_anti_rollback(current_dt)

        return {
            "status": "success",
            "message": f"Licença ativada com sucesso para {key_info['tester_name']}! Válida até {key_info['expiry_brt']}.",
            "details": key_info
        }

    @classmethod
    def is_license_active(cls) -> bool:
        """Retorna True se a licença estiver ativa e dentro da validade."""
        status = cls.get_license_status()
        return status.get("active") is True

    @classmethod
    def execute_self_destruction(cls) -> Dict[str, Any]:
        """
        [MODO COFRE BLOQUEADO / LOCKDOWN]:
        A autodestruição com exclusão de arquivos foi desativada permanentemente.
        O sistema preserva integralmente todos os bancos de dados, evidências e uploads,
        mantendo a aplicação bloqueada na tela de inserção de nova licença até validação de nova chave.
        """
        return {
            "status": "lockdown",
            "message": "Sistema em modo cofre bloqueado. Todos os dados permanecem intactos e preservados."
        }

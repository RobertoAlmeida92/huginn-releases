import hashlib
import os
import shutil
from typing import Dict, Any, List, Optional
from backend.database import get_db_connection
from backend.parsers.instagram_parser import InstagramParser
from backend.parsers.whatsapp_parser import WhatsAppParser

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

class CaseService:
    @staticmethod
    def calculate_sha256(file_path: str) -> str:
        """
        Calcula o hash SHA-256 de um arquivo para fins de cadeia de custódia pericial.
        """
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha256.update(chunk)
        return sha256.hexdigest()

    @staticmethod
    def create_case(name: str, description: Optional[str] = "") -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO cases (name, description) VALUES (?, ?)", (name, description))
        case_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return {"id": case_id, "name": name, "description": description}

    @staticmethod
    def list_cases() -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT c.*,
                   (SELECT COUNT(*) FROM instagram_targets WHERE case_id = c.id) as ig_targets_count,
                   (SELECT COUNT(*) FROM whatsapp_targets WHERE case_id = c.id) as wa_targets_count,
                   (SELECT COUNT(*) FROM custody_files WHERE case_id = c.id) as files_count
            FROM cases c
            ORDER BY c.created_at DESC
        """)
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    @staticmethod
    def get_case_details(case_id: int) -> Optional[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM cases WHERE id = ?", (case_id,))
        case_row = cursor.fetchone()
        if not case_row:
            conn.close()
            return None
        
        case = dict(case_row)
        
        # Arquivos de Custódia
        cursor.execute("SELECT * FROM custody_files WHERE case_id = ? ORDER BY imported_at DESC", (case_id,))
        case["custody_files"] = [dict(r) for r in cursor.fetchall()]
        
        # Alvos Instagram
        cursor.execute("SELECT * FROM instagram_targets WHERE case_id = ?", (case_id,))
        case["instagram_targets"] = [dict(r) for r in cursor.fetchall()]
        
        # Alvos WhatsApp
        cursor.execute("SELECT * FROM whatsapp_targets WHERE case_id = ?", (case_id,))
        case["whatsapp_targets"] = [dict(r) for r in cursor.fetchall()]

        conn.close()
        return case

    @classmethod
    def import_file(cls, case_id: int, file_path: str, platform_hint: Optional[str] = None) -> Dict[str, Any]:
        """
        Registra o arquivo na cadeia de custódia, detecta a plataforma e aciona o parser correspondente.
        """
        file_name = os.path.basename(file_path)
        file_size = os.path.getsize(file_path)
        file_hash = cls.calculate_sha256(file_path)

        # Detectar plataforma se não especificada
        platform = platform_hint
        if not platform:
            if "instagram" in file_name.lower() or "instagram" in file_path.lower():
                platform = "instagram"
            elif "whatsapp" in file_name.lower() or "whatsapp" in file_path.lower():
                platform = "whatsapp"
            else:
                # Padrão Instagram para testes
                platform = "instagram"

        # Registrar na tabela de custódia
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO custody_files (case_id, platform, file_name, file_path, file_size, sha256_hash)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (case_id, platform, file_name, file_path, file_size, file_hash))
        conn.commit()
        conn.close()

        # Executar Parser Específico
        if platform == "instagram":
            parser = InstagramParser()
            parse_result = parser.parse_file(file_path, case_id)
        else:
            parser = WhatsAppParser()
            parse_result = parser.parse_file(file_path, case_id)

        return {
            "status": "success",
            "file_name": file_name,
            "sha256_hash": file_hash,
            "platform": platform,
            "parse_summary": {
                "followers_count": len(parse_result.get("followers", [])),
                "following_count": len(parse_result.get("following", [])),
                "connections_count": len(parse_result.get("connections", [])),
                "groups_count": len(parse_result.get("groups", []))
            }
        }

import os
import threading
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List

from backend.config import MEDIA_BASE_DIR, WHISPER_MODELS_DIR
from backend.database import get_db_connection

logger = logging.getLogger(__name__)

import time
import shutil
import requests
import certifi

TOTAL_WHISPER_BYTES = 486226725
WHISPER_REMOTE_FILES = [
    {
        "filename": "config.json",
        "url": "https://huggingface.co/Systran/faster-whisper-small/resolve/main/config.json",
        "size": 2356
    },
    {
        "filename": "vocabulary.txt",
        "url": "https://huggingface.co/Systran/faster-whisper-small/resolve/main/vocabulary.txt",
        "size": 460111
    },
    {
        "filename": "tokenizer.json",
        "url": "https://huggingface.co/Systran/faster-whisper-small/resolve/main/tokenizer.json",
        "size": 2217356
    },
    {
        "filename": "model.bin",
        "url": "https://huggingface.co/Systran/faster-whisper-small/resolve/main/model.bin",
        "size": 483546902
    }
]

class AudioTranscriptionService:
    _instance = None
    _lock = threading.Lock()
    _model = None
    _model_name = "small"
    _is_loading = False
    _download_thread: Optional[threading.Thread] = None
    _download_state: Dict[str, Any] = {
        "status": "idle",
        "progress": 0,
        "downloaded_bytes": 0,
        "total_bytes": TOTAL_WHISPER_BYTES,
        "downloaded_mb": 0.0,
        "total_mb": round(TOTAL_WHISPER_BYTES / (1024 * 1024), 1),
        "speed_mb_s": 0.0,
        "eta_seconds": 0,
        "current_file": "",
        "error_message": None
    }

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def is_model_installed(self) -> bool:
        """Verifica se o modelo Whisper small está instalado e completo no disco local."""
        target_dir = os.path.join(WHISPER_MODELS_DIR, "small")
        required_files = ["config.json", "vocabulary.txt", "tokenizer.json", "model.bin"]
        if os.path.exists(target_dir) and all(os.path.exists(os.path.join(target_dir, f)) for f in required_files):
            model_bin = os.path.join(target_dir, "model.bin")
            if os.path.getsize(model_bin) > 400_000_000:
                return True

        snapshots_dir = os.path.join(WHISPER_MODELS_DIR, "models--Systran--faster-whisper-small", "snapshots")
        if os.path.exists(snapshots_dir):
            for snap in os.listdir(snapshots_dir):
                snap_path = os.path.join(snapshots_dir, snap)
                bin_path = os.path.join(snap_path, "model.bin")
                if os.path.isdir(snap_path) and os.path.exists(bin_path):
                    if os.path.getsize(bin_path) > 400_000_000:
                        return True

        return False

    def get_model_path(self) -> Optional[str]:
        """Retorna o caminho do diretório local do modelo Whisper small."""
        target_dir = os.path.join(WHISPER_MODELS_DIR, "small")
        required_files = ["config.json", "vocabulary.txt", "tokenizer.json", "model.bin"]
        if os.path.exists(target_dir) and all(os.path.exists(os.path.join(target_dir, f)) for f in required_files):
            if os.path.getsize(os.path.join(target_dir, "model.bin")) > 400_000_000:
                return target_dir

        snapshots_dir = os.path.join(WHISPER_MODELS_DIR, "models--Systran--faster-whisper-small", "snapshots")
        if os.path.exists(snapshots_dir):
            for snap in os.listdir(snapshots_dir):
                snap_path = os.path.join(snapshots_dir, snap)
                bin_path = os.path.join(snap_path, "model.bin")
                if os.path.isdir(snap_path) and os.path.exists(bin_path):
                    if os.path.getsize(bin_path) > 400_000_000:
                        return snap_path
        return None

    def get_status(self) -> Dict[str, Any]:
        """Retorna o status atual do modelo (instalado, progresso do download ou erro)."""
        if self.is_model_installed():
            return {
                "installed": True,
                "status": "completed",
                "progress": 100,
                "downloaded_bytes": TOTAL_WHISPER_BYTES,
                "total_bytes": TOTAL_WHISPER_BYTES,
                "downloaded_mb": round(TOTAL_WHISPER_BYTES / (1024 * 1024), 1),
                "total_mb": round(TOTAL_WHISPER_BYTES / (1024 * 1024), 1),
                "speed_mb_s": 0.0,
                "eta_seconds": 0,
                "current_file": "",
                "error_message": None
            }
        with self._lock:
            state = dict(self._download_state)
            state["installed"] = False
            return state

    def start_download_async(self) -> Dict[str, Any]:
        """Dispara o download seguro em segundo plano se o modelo ainda não estiver instalado."""
        if self.is_model_installed():
            return self.get_status()

        with self._lock:
            if self._download_thread and self._download_thread.is_alive():
                return self.get_status()

            self._download_state = {
                "status": "downloading",
                "progress": 0,
                "downloaded_bytes": 0,
                "total_bytes": TOTAL_WHISPER_BYTES,
                "downloaded_mb": 0.0,
                "total_mb": round(TOTAL_WHISPER_BYTES / (1024 * 1024), 1),
                "speed_mb_s": 0.0,
                "eta_seconds": 0,
                "current_file": "Conectando ao servidor...",
                "error_message": None
            }
            self._download_thread = threading.Thread(target=self._download_worker, daemon=True)
            self._download_thread.start()

        return self.get_status()

    def _download_worker(self):
        """Worker que baixa os arquivos do modelo com cálculo contínuo de taxa de transferência e ETA."""
        target_dir = os.path.join(WHISPER_MODELS_DIR, "small")
        os.makedirs(target_dir, exist_ok=True)

        downloaded_bytes = 0
        last_calc_time = time.time()
        last_downloaded_bytes = 0

        try:
            ca_cert = certifi.where()
            for item in WHISPER_REMOTE_FILES:
                fname = item["filename"]
                url = item["url"]
                dest_file = os.path.join(target_dir, fname)
                part_file = dest_file + ".part"

                with self._lock:
                    self._download_state["current_file"] = f"Baixando {fname}..."

                logger.info(f"Iniciando download de {fname} de {url}...")
                resp = requests.get(url, stream=True, verify=ca_cert, timeout=(15, 60))
                resp.raise_for_status()

                with open(part_file, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=65536):
                        if chunk:
                            f.write(chunk)
                            downloaded_bytes += len(chunk)

                            now = time.time()
                            elapsed = now - last_calc_time
                            if elapsed >= 0.4:
                                bytes_diff = downloaded_bytes - last_downloaded_bytes
                                speed_bytes = bytes_diff / elapsed
                                speed_mb = round(speed_bytes / (1024 * 1024), 2)
                                remaining = max(0, TOTAL_WHISPER_BYTES - downloaded_bytes)
                                eta = int(remaining / speed_bytes) if speed_bytes > 0 else 0

                                last_calc_time = now
                                last_downloaded_bytes = downloaded_bytes

                                pct = min(99, int((downloaded_bytes / TOTAL_WHISPER_BYTES) * 100))
                                with self._lock:
                                    self._download_state["downloaded_bytes"] = downloaded_bytes
                                    self._download_state["downloaded_mb"] = round(downloaded_bytes / (1024 * 1024), 1)
                                    self._download_state["progress"] = pct
                                    self._download_state["speed_mb_s"] = speed_mb
                                    self._download_state["eta_seconds"] = eta

                # Download do arquivo concluído com sucesso, renomeia .part
                if os.path.exists(dest_file):
                    os.remove(dest_file)
                shutil.move(part_file, dest_file)
                logger.info(f"Arquivo {fname} salvo com sucesso em {dest_file}.")

            # Verificação final
            if self.is_model_installed():
                with self._lock:
                    self._download_state["status"] = "completed"
                    self._download_state["progress"] = 100
                    self._download_state["downloaded_bytes"] = TOTAL_WHISPER_BYTES
                    self._download_state["downloaded_mb"] = round(TOTAL_WHISPER_BYTES / (1024 * 1024), 1)
                    self._download_state["current_file"] = "Instalação concluída!"
                    self._download_state["speed_mb_s"] = 0.0
                    self._download_state["eta_seconds"] = 0
                    self._download_state["error_message"] = None
                logger.info("Download e instalação do modelo Whisper small concluídos com sucesso!")
            else:
                raise RuntimeError("Arquivos do modelo baixados mas validação local falhou.")

        except Exception as e:
            logger.error(f"Erro durante download do modelo Whisper: {e}", exc_info=True)
            with self._lock:
                self._download_state["status"] = "error"
                self._download_state["error_message"] = str(e)
                self._download_state["current_file"] = "Erro no download"

    def _get_model(self):
        """Carrega o modelo Whisper small do disco local com quantização otimizada int8"""
        if self._model is None:
            with self._lock:
                if self._model is None:
                    model_path = self.get_model_path()
                    if not model_path:
                        raise RuntimeError(
                            "O modelo Whisper AI não está instalado. "
                            "Utilize o botão de download na interface para instalá-lo."
                        )

                    try:
                        from faster_whisper import WhisperModel
                        logger.info(f"Carregando modelo faster-whisper localmente a partir de {model_path}...")
                        self._is_loading = True
                        
                        try:
                            self._model = WhisperModel(
                                model_path,
                                device="cuda",
                                compute_type="float16"
                            )
                            logger.info("faster-whisper carregado com aceleração GPU (CUDA)!")
                        except Exception as cuda_err:
                            logger.info(f"GPU indisponível ({cuda_err}), utilizando CPU com quantização int8...")
                            self._model = WhisperModel(
                                model_path,
                                device="cpu",
                                compute_type="int8"
                            )
                            logger.info("faster-whisper carregado com sucesso na CPU (int8)!")
                    finally:
                        self._is_loading = False
        return self._model

    def resolve_audio_file(self, media_path: str, target_id: Optional[int] = None) -> Optional[str]:
        """Localiza o arquivo físico de áudio no sistema de arquivos local"""
        if not media_path:
            return None

        clean_path = media_path.strip().replace("\\", "/")
        if clean_path.startswith("/media/"):
            clean_path = clean_path[7:]

        candidates = [
            os.path.join(MEDIA_BASE_DIR, clean_path),
            os.path.join(MEDIA_BASE_DIR, os.path.basename(clean_path))
        ]
        if target_id:
            candidates.insert(0, os.path.join(MEDIA_BASE_DIR, f"target_{target_id}", os.path.basename(clean_path)))

        for p in candidates:
            if os.path.exists(p) and os.path.isfile(p):
                return p

        # Fallback inteligente: buscar nos pacotes ZIP da custódia e auto-extrair
        from backend.config import CUSTODY_DIR
        import shutil, zipfile
        if os.path.exists(CUSTODY_DIR):
            for c_file in os.listdir(CUSTODY_DIR):
                c_path = os.path.join(CUSTODY_DIR, c_file)
                if zipfile.is_zipfile(c_path):
                    try:
                        with zipfile.ZipFile(c_path, 'r') as z:
                            for z_item in z.namelist():
                                if os.path.basename(z_item) == base_name and not z_item.endswith('/'):
                                    dest = candidates[0]
                                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                                    with z.open(z_item) as src, open(dest, 'wb') as dst:
                                        shutil.copyfileobj(src, dst)
                                    if os.path.exists(dest):
                                        return dest
                    except Exception:
                        pass

        return None

    def transcribe_file(self, file_path: str, language: str = "pt") -> Dict[str, Any]:
        """Executa a transcrição do áudio diretamente pelo modelo Whisper"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Arquivo de áudio não encontrado: {file_path}")

        model = self._get_model()
        segments, info = model.transcribe(
            file_path,
            language=language,
            beam_size=5,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500)
        )

        segment_list = []
        text_parts = []
        for segment in segments:
            clean_text = segment.text.strip()
            if clean_text:
                text_parts.append(clean_text)
                segment_list.append({
                    "start": round(segment.start, 2),
                    "end": round(segment.end, 2),
                    "text": clean_text
                })

        full_text = " ".join(text_parts).strip()
        return {
            "text": full_text,
            "language": info.language,
            "language_probability": round(info.language_probability, 4),
            "duration": round(info.duration, 2),
            "segments": segment_list
        }

    def transcribe_message(self, message_id: int, force: bool = False) -> Dict[str, Any]:
        """Transcreve uma mensagem de áudio individual e grava no banco de dados"""
        conn = get_db_connection()
        cursor = conn.cursor()

        msg = cursor.execute("SELECT * FROM messages WHERE id = ?", (message_id,)).fetchone()
        if not msg:
            conn.close()
            raise ValueError(f"Mensagem {message_id} não encontrada.")

        msg = dict(msg)
        if msg.get("message_type") != "audio":
            conn.close()
            raise ValueError(f"A mensagem {message_id} não é do tipo áudio.")

        if msg.get("transcription") and msg.get("transcription_status") == "completed" and not force:
            conn.close()
            return {
                "message_id": message_id,
                "transcription": msg["transcription"],
                "transcription_status": msg["transcription_status"],
                "transcribed_at": msg["transcribed_at"],
                "transcribed_by": msg["transcribed_by"],
                "cached": True
            }

        file_path = self.resolve_audio_file(msg.get("media_path"), msg.get("target_id"))
        if not file_path:
            cursor.execute("UPDATE messages SET transcription_status = 'failed' WHERE id = ?", (message_id,))
            conn.commit()
            conn.close()
            raise FileNotFoundError(f"Arquivo físico do áudio não foi localizado para a mensagem {message_id}.")

        cursor.execute("UPDATE messages SET transcription_status = 'processing' WHERE id = ?", (message_id,))
        conn.commit()

        try:
            res = self.transcribe_file(file_path, language="pt")
            text = res["text"]
            duration = int(res.get("duration", 0))

            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute("""
                UPDATE messages 
                SET transcription = ?, 
                    transcription_status = 'completed', 
                    transcribed_at = ?, 
                    transcribed_by = ?,
                    duration_seconds = COALESCE(duration_seconds, ?)
                WHERE id = ?
            """, (text, now_str, f"whisper_{self._model_name}", duration, message_id))
            conn.commit()

            return {
                "message_id": message_id,
                "transcription": text,
                "transcription_status": "completed",
                "transcribed_at": now_str,
                "transcribed_by": f"whisper_{self._model_name}",
                "duration_seconds": duration,
                "language": res.get("language"),
                "segments": res.get("segments", [])
            }
        except Exception as e:
            cursor.execute("UPDATE messages SET transcription_status = 'failed' WHERE id = ?", (message_id,))
            conn.commit()
            raise e
        finally:
            conn.close()

    def update_analyst_review(self, message_id: int, text: str) -> Dict[str, Any]:
        """Salva a revisão manual feita pelo perito analista"""
        conn = get_db_connection()
        cursor = conn.cursor()

        msg = cursor.execute("SELECT id FROM messages WHERE id = ?", (message_id,)).fetchone()
        if not msg:
            conn.close()
            raise ValueError(f"Mensagem {message_id} não encontrada.")

        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("""
            UPDATE messages 
            SET transcription = ?, 
                transcription_status = 'edited', 
                transcribed_at = ?, 
                transcribed_by = 'analyst'
            WHERE id = ?
        """, (text.strip(), now_str, message_id))
        conn.commit()
        conn.close()

        return {
            "message_id": message_id,
            "transcription": text.strip(),
            "transcription_status": "edited",
            "transcribed_at": now_str,
            "transcribed_by": "analyst"
        }

    def transcribe_thread_batch(self, thread_id: str, operation_id: int, limit: int = 50) -> Dict[str, Any]:
        """Transcreve todos os áudios pendentes de uma conversa em lote"""
        conn = get_db_connection()
        cursor = conn.cursor()

        rows = cursor.execute("""
            SELECT id FROM messages 
            WHERE operation_id = ? AND thread_id = ? AND message_type = 'audio' 
              AND (transcription IS NULL OR transcription = '' OR transcription_status = 'pending' OR transcription_status = 'failed')
            ORDER BY timestamp_utc ASC
            LIMIT ?
        """, (operation_id, str(thread_id), limit)).fetchall()
        conn.close()

        total = len(rows)
        transcribed = 0
        errors = []

        for r in rows:
            msg_id = r["id"]
            try:
                self.transcribe_message(msg_id)
                transcribed += 1
            except Exception as e:
                logger.error(f"Erro ao transcrever mensagem {msg_id}: {e}")
                errors.append({"message_id": msg_id, "error": str(e)})

        return {
            "thread_id": thread_id,
            "total_pending": total,
            "transcribed_count": transcribed,
            "errors": errors
        }
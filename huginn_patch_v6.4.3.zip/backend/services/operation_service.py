import hashlib
import os
import shutil
import zipfile
import re
import bs4
import json
from typing import Dict, Any, List, Optional
from backend.database import get_db_connection
from backend.config import UPLOAD_DIR, MEDIA_BASE_DIR, AVATAR_DIR, CUSTODY_DIR
from backend.parsers.instagram_parser import InstagramParser
from backend.parsers.whatsapp_parser import WhatsAppParser

class OperationService:
    @staticmethod
    def calculate_sha256(file_path: str) -> str:
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha256.update(chunk)
        return sha256.hexdigest()

    @staticmethod
    def calculate_md5(file_path: str) -> str:
        md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                md5.update(chunk)
        return md5.hexdigest()

    # ==================== OPERAÇÕES ====================
    @staticmethod
    def create_operation(
        name: str,
        police_unit: str = "",
        court_docket: str = "",
        description: str = "",
        initial_phase_name: str = "Fase 1 - Preservação e Quebra Inicial",
        initial_phase_court_order: str = "",
        initial_phase_date_range: str = ""
    ) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO operations (name, police_unit, court_docket, description)
            VALUES (?, ?, ?, ?)
        """, (name, police_unit, court_docket, description))
        op_id = cursor.lastrowid

        p_name = initial_phase_name.strip() if initial_phase_name else "Fase 1 - Preservação e Quebra Inicial"
        cursor.execute("""
            INSERT INTO phases (operation_id, name, court_order_number, date_range, description)
            VALUES (?, ?, ?, ?, 'Fase inicial cadastrada junto à operação.')
        """, (op_id, p_name, initial_phase_court_order, initial_phase_date_range))
        phase_id = cursor.lastrowid

        conn.commit()
        conn.close()
        return {"id": op_id, "name": name, "default_phase_id": phase_id}

    @staticmethod
    def update_operation(operation_id: int, name: str, police_unit: str = "", court_docket: str = "", description: str = "") -> bool:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE operations
            SET name = ?, police_unit = ?, court_docket = ?, description = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (name, police_unit, court_docket, description, operation_id))
        conn.commit()
        conn.close()
        return True

    @staticmethod
    def list_operations() -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT o.*,
                   (SELECT COUNT(*) FROM phases WHERE operation_id = o.id) as phases_count,
                   (SELECT COUNT(*) FROM targets WHERE operation_id = o.id) as targets_count,
                   (SELECT COUNT(*) FROM custody_files WHERE operation_id = o.id) as files_count
            FROM operations o
            ORDER BY o.created_at DESC
        """)
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    @staticmethod
    def get_operation(operation_id: int) -> Optional[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM operations WHERE id = ?", (operation_id,))
        row = cursor.fetchone()
        if not row:
            conn.close()
            return None
        
        op = dict(row)
        cursor.execute("SELECT * FROM phases WHERE operation_id = ? ORDER BY id ASC", (operation_id,))
        op["phases"] = [dict(r) for r in cursor.fetchall()]

        cursor.execute("SELECT * FROM targets WHERE operation_id = ? ORDER BY id ASC", (operation_id,))
        op["targets"] = [dict(r) for r in cursor.fetchall()]

        cursor.execute("SELECT * FROM custody_files WHERE operation_id = ? ORDER BY imported_at DESC", (operation_id,))
        op["custody_files"] = [dict(r) for r in cursor.fetchall()]

        conn.close()
        return op

    @staticmethod
    def delete_operation(operation_id: int) -> bool:
        conn = get_db_connection()
        cursor = conn.cursor()

        # 1. Coletar e excluir todos os alvos da operação (físico + banco)
        cursor.execute("SELECT id FROM targets WHERE operation_id = ?", (operation_id,))
        op_targets = cursor.fetchall()
        for t in op_targets:
            OperationService.delete_target(t["id"])

        # 2. Excluir todas as fases e registros da operação
        cursor.execute("DELETE FROM phases WHERE operation_id = ?", (operation_id,))
        cursor.execute("DELETE FROM phase_targets WHERE phase_id NOT IN (SELECT id FROM phases)")
        cursor.execute("DELETE FROM custody_files WHERE operation_id = ?", (operation_id,))
        cursor.execute("DELETE FROM messages WHERE operation_id = ?", (operation_id,))
        cursor.execute("DELETE FROM timeline_events WHERE operation_id = ?", (operation_id,))
        cursor.execute("DELETE FROM dm_thread_annotations WHERE operation_id = ?", (operation_id,))
        cursor.execute("DELETE FROM operations WHERE id = ?", (operation_id,))

        conn.commit()
        conn.close()
        return True

    # ==================== FASES ====================
    @staticmethod
    def create_phase(operation_id: int, name: str, court_order: str = "", date_range: str = "", description: str = "") -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO phases (operation_id, name, court_order_number, date_range, description)
            VALUES (?, ?, ?, ?, ?)
        """, (operation_id, name, court_order, date_range, description))
        phase_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return {"id": phase_id, "operation_id": operation_id, "name": name}

    @staticmethod
    def update_phase(phase_id: int, name: str, court_order: str = "", date_range: str = "", description: str = "") -> bool:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE phases
            SET name = ?, court_order_number = ?, date_range = ?, description = ?
            WHERE id = ?
        """, (name, court_order, date_range, description, phase_id))
        conn.commit()
        conn.close()
        return True

    @staticmethod
    def delete_phase(phase_id: int) -> bool:
        conn = get_db_connection()
        cursor = conn.cursor()

        # 1. Coletar todos os alvos vinculados a essa fase
        cursor.execute("SELECT target_id FROM phase_targets WHERE phase_id = ?", (phase_id,))
        phase_targets = cursor.fetchall()

        # 2. Excluir os alvos que pertencem exclusivamente a essa fase (limpeza física + lógica)
        for pt in phase_targets:
            t_id = pt["target_id"]
            cursor.execute("SELECT COUNT(*) as cnt FROM phase_targets WHERE target_id = ? AND phase_id != ?", (t_id, phase_id))
            other_phases = cursor.fetchone()
            if not other_phases or other_phases["cnt"] == 0:
                OperationService.delete_target(t_id)

        # 3. Remover a fase e vínculos restantes
        cursor.execute("DELETE FROM phases WHERE id = ?", (phase_id,))
        cursor.execute("DELETE FROM phase_targets WHERE phase_id = ?", (phase_id,))
        cursor.execute("DELETE FROM custody_files WHERE phase_id = ?", (phase_id,))
        cursor.execute("DELETE FROM messages WHERE phase_id = ?", (phase_id,))
        cursor.execute("DELETE FROM timeline_events WHERE phase_id = ?", (phase_id,))
        conn.commit()
        conn.close()
        return True

    @staticmethod
    def get_phase(phase_id: int) -> Optional[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM phases WHERE id = ?", (phase_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    @staticmethod
    def list_phases(operation_id: int) -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.*,
                   (SELECT COUNT(*) FROM phase_targets WHERE phase_id = p.id) as targets_count,
                   (SELECT COUNT(*) FROM custody_files WHERE phase_id = p.id) as files_count
            FROM phases p
            WHERE p.operation_id = ?
            ORDER BY p.id ASC
        """, (operation_id,))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    # ==================== ALVOS ====================
    @staticmethod
    def create_target(operation_id: int, name_or_alias: str, main_identifier: str, platform: str = "both", cpf_cnpj: str = "", notes: str = "", phase_id_to_bind: Optional[int] = None) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO targets (operation_id, name_or_alias, main_identifier, platform, cpf_cnpj, notes)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (operation_id, name_or_alias, main_identifier, platform, cpf_cnpj, notes))
        target_id = cursor.lastrowid

        phase_target_id = None
        if phase_id_to_bind:
            cursor.execute("""
                INSERT OR IGNORE INTO phase_targets (phase_id, target_id)
                VALUES (?, ?)
            """, (phase_id_to_bind, target_id))
            phase_target_id = cursor.lastrowid

        conn.commit()
        conn.close()
        return {"id": target_id, "operation_id": operation_id, "name_or_alias": name_or_alias, "main_identifier": main_identifier, "phase_target_id": phase_target_id}

    @staticmethod
    def delete_target(target_id: int) -> bool:
        conn = get_db_connection()
        cursor = conn.cursor()

        # 1. Coletar arquivos físicos de custódia para exclusão segura
        cursor.execute("SELECT file_path FROM custody_files WHERE target_id = ?", (target_id,))
        custody_rows = cursor.fetchall()
        custody_paths = [r["file_path"] for r in custody_rows if r["file_path"]]

        # 2. Exclusão física em disco
        # A. Pasta de mídia do alvo: uploads/media/target_{target_id}
        target_media_dir = os.path.join(MEDIA_BASE_DIR, f"target_{target_id}")
        if os.path.exists(target_media_dir):
            try:
                shutil.rmtree(target_media_dir, ignore_errors=True)
            except Exception as e:
                print(f"[OperationService] Erro ao remover pasta de mídia {target_media_dir}: {e}")

        # B. Pasta de avatares do alvo: uploads/avatars/target_{target_id}
        target_avatar_dir = os.path.join(AVATAR_DIR, f"target_{target_id}")
        if os.path.exists(target_avatar_dir):
            try:
                shutil.rmtree(target_avatar_dir, ignore_errors=True)
            except Exception as e:
                print(f"[OperationService] Erro ao remover pasta de avatares {target_avatar_dir}: {e}")

        # C. Arquivos ZIP de custódia (se não estiverem sendo usados por outro alvo)
        for c_path in custody_paths:
            if os.path.exists(c_path):
                cursor.execute("SELECT COUNT(*) as cnt FROM custody_files WHERE file_path = ? AND target_id != ?", (c_path, target_id))
                other_use = cursor.fetchone()
                if not other_use or other_use["cnt"] == 0:
                    try:
                        os.remove(c_path)
                    except Exception as e:
                        print(f"[OperationService] Erro ao remover arquivo de custódia {c_path}: {e}")

        # 3. Exclusão lógica em cascata no banco de dados
        cursor.execute("DELETE FROM targets WHERE id = ?", (target_id,))
        cursor.execute("DELETE FROM phase_targets WHERE target_id = ?", (target_id,))
        cursor.execute("DELETE FROM custody_files WHERE target_id = ?", (target_id,))
        cursor.execute("DELETE FROM instagram_targets WHERE target_id = ?", (target_id,))
        cursor.execute("DELETE FROM instagram_relationships WHERE target_id = ?", (target_id,))
        cursor.execute("DELETE FROM instagram_connections WHERE target_id = ?", (target_id,))
        cursor.execute("DELETE FROM instagram_devices WHERE target_id = ?", (target_id,))
        cursor.execute("DELETE FROM whatsapp_targets WHERE target_id = ?", (target_id,))
        cursor.execute("DELETE FROM whatsapp_connections WHERE target_id = ?", (target_id,))
        cursor.execute("DELETE FROM whatsapp_groups WHERE target_id = ?", (target_id,))
        cursor.execute("DELETE FROM messages WHERE target_id = ?", (target_id,))
        cursor.execute("DELETE FROM timeline_events WHERE target_id = ?", (target_id,))

        # Limpar anotações e evidências órfãs que não pertencem mais a nenhuma mensagem
        cursor.execute("""
            DELETE FROM message_evidence_tags 
            WHERE message_id NOT IN (SELECT id FROM messages)
        """)
        cursor.execute("""
            DELETE FROM dm_thread_annotations 
            WHERE thread_id NOT IN (SELECT DISTINCT thread_id FROM messages)
        """)

        conn.commit()
        conn.close()
        return True

    @staticmethod
    def list_targets(operation_id: int, phase_id: Optional[int] = None) -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        if phase_id:
            cursor.execute("""
                SELECT t.*, pt.id as phase_target_id, pt.notes as phase_notes
                FROM targets t
                JOIN phase_targets pt ON t.id = pt.target_id
                WHERE t.operation_id = ? AND pt.phase_id = ?
                ORDER BY t.id ASC
            """, (operation_id, phase_id))
        else:
            cursor.execute("SELECT * FROM targets WHERE operation_id = ? ORDER BY id ASC", (operation_id,))
        rows = [dict(r) for r in cursor.fetchall()]

        for r in rows:
            cursor.execute("""
                SELECT DISTINCT vanity_name, target_uid
                FROM instagram_targets
                WHERE target_id = ?
            """, (r["id"],))
            acc_rows = cursor.fetchall()
            accounts = []
            for a in acc_rows:
                v = (a["vanity_name"] or "").strip()
                if v and v != "unknown":
                    handle = f"@{v}" if not v.startswith("@") else v
                    if handle not in accounts:
                        accounts.append(handle)
            r["linked_accounts"] = accounts

        conn.close()
        return rows

    @staticmethod
    def bind_target_to_phase(phase_id: int, target_id: int, notes: str = "") -> int:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR IGNORE INTO phase_targets (phase_id, target_id, notes)
            VALUES (?, ?, ?)
        """, (phase_id, target_id, notes))
        pt_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return pt_id

    # ==================== DETECÇÃO AUTOMÁTICA DE ALVO ====================
    @staticmethod
    def auto_detect_target(operation_id: int, file_path: str, platform: str) -> int:
        """
        Inspeciona o arquivo da Meta antes da importação para extrair nome, @username ou telefone,
        e encontra o alvo existente ou cria um novo alvo automaticamente no banco.
        """
        detected_name = None
        detected_identifier = None
        detected_email = None
        detected_phone = None
        detected_uid = None

        try:
            if platform == "instagram":
                if zipfile.is_zipfile(file_path):
                    with zipfile.ZipFile(file_path, "r") as z:
                        html_files = [f for f in z.namelist() if f.endswith(".html")]
                        for hf in sorted(html_files):
                            content = z.read(hf).decode("utf-8", errors="ignore")
                            soup = bs4.BeautifulSoup(content, "html.parser")
                            
                            # Buscar em Request Parameters
                            req_p = soup.find("div", id="property-request_parameters")
                            if req_p:
                                text = req_p.get_text(separator=" | ")
                                u_match = re.search(r'Account Identifier\s*\|\s*(?:https?://(?:www\.)?instagram\.com/)?([a-zA-Z0-9._]+)', text)
                                if u_match and not u_match.group(1).strip().isdigit():
                                    clean_u = u_match.group(1).strip().rstrip('/').split('/')[-1].replace('@', '')
                                    if clean_u and clean_u.lower() not in ['reel', 'reels', 'p', 'stories', 'explore', 'direct', 'accounts']:
                                        detected_identifier = f"@{clean_u}"
                                uid_match = re.search(r'Target\s*\|\s*(\d+)', text)
                                if uid_match:
                                    detected_uid = uid_match.group(1).strip()

                            # Vanity fallback
                            if not detected_identifier:
                                v_div = soup.find("div", id="property-vanity")
                                if v_div:
                                    for to in v_div.find_all("div", class_="t o"):
                                        to_txt = to.get_text(separator=" | ", strip=True)
                                        if "Definition" not in to_txt:
                                            parts = [p.strip() for p in to_txt.split("|") if p.strip()]
                                            if parts and parts[-1] not in ["Vanity", "Definition", "No responsive records located"]:
                                                detected_identifier = f"@{parts[-1].replace('@', '').strip()}"
                                                break

                            # Buscar Nome e Email
                            name_div = soup.find("div", id="property-name")
                            if name_div and not detected_name:
                                for to in name_div.find_all("div", class_="t o"):
                                    to_txt = to.get_text(separator=" | ", strip=True)
                                    if "Definition" not in to_txt:
                                        parts = [p.strip() for p in to_txt.split("|") if p.strip()]
                                        if parts:
                                            val = parts[-1]
                                            if val and val not in ["Name", "First", "Last", "Definition", "No responsive records located"]:
                                                detected_name = val
                                                break
                            
                            email_div = soup.find("div", id="property-emails")
                            if email_div and not detected_email:
                                raw_em_text = email_div.get_text(separator=" ", strip=True)
                                # Capturar todos os e-mails com status opcional: email@dominio.com (Verified on ...)
                                em_matches = re.findall(r'([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)(?:\s*\(([^)]+)\))?', raw_em_text)
                                if em_matches:
                                    clean_emails = []
                                    for em, status in em_matches:
                                        if status:
                                            clean_emails.append(f"{em} ({status.strip()})")
                                        else:
                                            clean_emails.append(em)
                                    detected_email = "\n".join(clean_emails)
                                        
                            if detected_identifier and detected_name:
                                break
            else: # WhatsApp
                # Extrair telefone e nome do WhatsApp
                if zipfile.is_zipfile(file_path):
                    from backend.parsers.whatsapp_cdr_parser import WhatsAppCdrParser
                    cdr_insp = WhatsAppCdrParser.inspect_cdr(file_path)
                    if cdr_insp.get("is_valid") and cdr_insp.get("target_identifier"):
                        detected_phone = cdr_insp.get("target_identifier")
                        detected_identifier = detected_phone
                        detected_name = f"Alvo WhatsApp ({detected_phone})"
                    else:
                        with zipfile.ZipFile(file_path, "r") as z:
                            for name in ["records.html", "preservation-1.html"] + [n for n in z.namelist() if n.endswith(".html")]:
                                if name in z.namelist():
                                    text = z.read(name).decode("utf-8", errors="ignore")
                                    p_match = re.search(r'(?:Target|Account Identifier|MSISDN|Phone Number|Telefone)(?:<[^>]+>|\s|[:|=])+(\+?\d{10,15})', text, re.IGNORECASE)
                                    if p_match:
                                        detected_phone = p_match.group(1).strip()
                                        detected_identifier = detected_phone
                                    
                                    # Buscar nome comercial ou push name real
                                    smb_match = re.search(r'Small Medium Business[^>]*?Name(?:<[^>]+>|\s|[:|=])+([^|<]+)', text, re.IGNORECASE)
                                    if smb_match and not any(k in smb_match.group(1).lower() for k in ["definition", "provided", "account holder"]):
                                        detected_name = smb_match.group(1).strip()
                                    else:
                                        n_match = re.search(r'Push Name(?:<[^>]+>|\s|[:|=])+([^\n\r|<]{2,50})', text, re.IGNORECASE)
                                        if n_match and not any(k in n_match.group(1).lower() for k in ["definition", "provided", "account holder", "if available", "no responsive"]):
                                            detected_name = n_match.group(1).strip()

                                    if detected_identifier and detected_name:
                                        break
                elif file_path.endswith(".html"):
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                        text = f.read()
                        p_match = re.search(r'(?:Target|Account Identifier|MSISDN|Phone Number|Telefone)\s*[:|=]\s*(\+?\d{10,15})', text, re.IGNORECASE)
                        if p_match:
                            detected_phone = p_match.group(1).strip()
                            detected_identifier = detected_phone
                        
                        smb_match = re.search(r'Small Medium Business[^>]*?Name\s*\|\s*([^|<]+)', text, re.IGNORECASE)
                        if smb_match and not any(k in smb_match.group(1).lower() for k in ["definition", "provided", "account holder"]):
                            detected_name = smb_match.group(1).strip()
                        else:
                            n_match = re.search(r'(?:Push Name|Nome)\s*[:|=]\s*([^\n\r|<]{2,50})', text, re.IGNORECASE)
                            if n_match and not any(k in n_match.group(1).lower() for k in ["definition", "provided", "account holder", "if available"]):
                                detected_name = n_match.group(1).strip()
        except Exception as e:
            print(f"[AutoDetectTarget] Aviso ao inspecionar arquivo: {e}")

        # Se não detectou identifier, extrair de forma limpa
        if not detected_identifier:
            detected_identifier = f"@{detected_uid}" if detected_uid else (detected_phone or "@alvo")
        
        # Nome padrão limpo: se não tiver nome real, usar apenas o próprio @username ou telefone
        is_generic_name = not detected_name or detected_name in ["@alvo", "alvo", "Alvo", "Alvo_Meta"] or detected_name.startswith("Alvo_") or any(k in detected_name.lower() for k in ["provided", "definition", "account holder"])
        if is_generic_name:
            detected_name = detected_identifier

        conn = get_db_connection()
        cursor = conn.cursor()

        # Normalizar telefone para busca flexível
        clean_phone = detected_identifier.replace("+", "").replace("@", "").strip()

        # Verificar se já existe um alvo na operação com este identificador, telefone ou UID
        # NUNCA fazer match por apelido genérico '@alvo'
        if is_generic_name or detected_identifier == "@alvo":
            cursor.execute("""
                SELECT id, name_or_alias, main_identifier, phone FROM targets
                WHERE operation_id = ? AND (
                    (main_identifier != '@alvo' AND main_identifier = ?) OR
                    (main_identifier != '@alvo' AND main_identifier = ?) OR
                    (phone IS NOT NULL AND (phone = ? OR phone = ?))
                )
            """, (
                operation_id,
                detected_identifier,
                f"+{clean_phone}",
                detected_identifier,
                f"+{clean_phone}"
            ))
        else:
            cursor.execute("""
                SELECT id, name_or_alias, main_identifier, phone FROM targets
                WHERE operation_id = ? AND (
                    main_identifier = ? OR
                    main_identifier = ? OR
                    main_identifier = ? OR
                    phone = ? OR
                    phone = ? OR
                    (name_or_alias != '@alvo' AND name_or_alias = ?)
                )
            """, (
                operation_id,
                detected_identifier,
                f"+{clean_phone}",
                clean_phone,
                detected_identifier,
                f"+{clean_phone}",
                detected_name
            ))
        existing = cursor.fetchone()

        if existing:
            target_id = existing["id"]
            # Atualizar nome real se o atual for provisório ou se foi encontrado nome completo
            should_update_name = detected_name and (detected_name != detected_identifier or "Alvo_" in existing["name_or_alias"] or "Investigado" in existing["name_or_alias"])
            cursor.execute("""
                UPDATE targets SET
                    name_or_alias = CASE WHEN ? THEN ? ELSE name_or_alias END,
                    email = COALESCE(?, email),
                    phone = COALESCE(?, phone)
                WHERE id = ?
            """, (1 if should_update_name else 0, detected_name, detected_email, detected_phone, target_id))
        else:
            # Criar novo alvo automaticamente com identificação limpa (@username)
            cursor.execute("""
                INSERT INTO targets (operation_id, name_or_alias, main_identifier, email, phone, platform)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (operation_id, detected_name, detected_identifier, detected_email, detected_phone, platform))
            target_id = cursor.lastrowid

        conn.commit()
        conn.close()
        return target_id

    # ==================== IMPORTAÇÃO DE EVIDÊNCIA ====================
    @classmethod
    def import_evidence(
        cls,
        operation_id: int,
        phase_id: int,
        target_id: Optional[int],
        file_path: str,
        platform_hint: Optional[str] = None,
        declared_hash: Optional[str] = None
    ) -> Dict[str, Any]:
        # Auto-resolver se o usuário passou caminho sem extensão .zip ou pasta de múltiplos ZIPs
        if not os.path.exists(file_path):
            if os.path.exists(file_path + ".zip"):
                file_path = file_path + ".zip"
            else:
                raise FileNotFoundError(f"Arquivo de evidência não encontrado: {file_path}")
        elif os.path.isdir(file_path):
            zip_files = [os.path.join(file_path, f) for f in os.listdir(file_path) if f.lower().endswith(".zip")]
            if zip_files:
                def natural_sort_key(s):
                    return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', s)]
                zip_files.sort(key=natural_sort_key)

                if not target_id or target_id <= 0:
                    target_id = cls.auto_detect_target(operation_id, zip_files[0], "whatsapp")

                cls.bind_target_to_phase(phase_id, target_id)

                total_msgs = 0
                total_calls = 0
                last_hash = ""

                for zp in zip_files:
                    sub_res = cls.import_evidence(operation_id, phase_id, target_id, zp, "whatsapp", declared_hash)
                    total_msgs += sub_res.get("summary", {}).get("messages_count", 0)
                    total_calls += sub_res.get("summary", {}).get("calls_count", 0)
                    last_hash = sub_res.get("sha256_hash", "")

                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT name_or_alias, main_identifier FROM targets WHERE id = ?", (target_id,))
                tgt_row = cursor.fetchone()
                target_name = tgt_row["name_or_alias"] if tgt_row else "Investigado"
                target_identifier = tgt_row["main_identifier"] if tgt_row else ""
                conn.close()

                return {
                    "status": "success",
                    "operation_id": operation_id,
                    "phase_id": phase_id,
                    "target_id": target_id,
                    "target_name": target_name,
                    "target_identifier": target_identifier,
                    "file_name": f"{os.path.basename(file_path.rstrip('/\\\\'))} ({len(zip_files)} arquivos ZIP de Bilhetagem)",
                    "sha256_hash": last_hash,
                    "platform": "whatsapp",
                    "summary": {
                        "followers_count": 0,
                        "following_count": 0,
                        "ip_count": 0,
                        "threads_count": 0,
                        "messages_count": total_msgs,
                        "calls_count": total_calls
                    }
                }
            elif os.path.exists(file_path + ".zip"):
                file_path = file_path + ".zip"
            else:
                raise ValueError("Nenhum arquivo ZIP encontrado na pasta informada.")

        if not zipfile.is_zipfile(file_path):
            raise ValueError("Formato inválido. O sistema aceita exclusivamente pacotes forenses compactados em formato ZIP (.zip).")

        file_name = os.path.basename(file_path)

        # Garantir armazenamento na pasta de custódia
        os.makedirs(CUSTODY_DIR, exist_ok=True)
        dest_custody_path = os.path.join(CUSTODY_DIR, file_name)
        if os.path.abspath(file_path) != os.path.abspath(dest_custody_path):
            shutil.copy2(file_path, dest_custody_path)
            file_path = dest_custody_path

        file_size = os.path.getsize(file_path)
        file_hash = cls.calculate_sha256(file_path)
        clean_declared = declared_hash.strip().lower() if declared_hash else None

        # Auto-detectar plataforma inspecionando o cabeçalho do arquivo
        detected_service = None
        if zipfile.is_zipfile(file_path):
            with zipfile.ZipFile(file_path, "r") as z:
                for name in ["records.html", "preservation-1.html"] + [n for n in z.namelist() if n.endswith(".html")]:
                    if name in z.namelist():
                        header_sample = z.read(name)[:5000].decode("utf-8", errors="ignore")
                        if "service | whatsapp" in header_sample.lower() or "whatsapp" in header_sample.lower():
                            detected_service = "whatsapp"
                            break
                        elif "service | instagram" in header_sample.lower() or "instagram" in header_sample.lower():
                            detected_service = "instagram"
                            break

        platform = detected_service or platform_hint
        if not platform:
            if "whatsapp" in file_name.lower() or "whatsapp" in file_path.lower():
                platform = "whatsapp"
            else:
                platform = "instagram"

        # Se target_id não foi informado ou é 0, identificar/criar automaticamente!
        if not target_id or target_id <= 0:
            target_id = cls.auto_detect_target(operation_id, file_path, platform)

        # Garantir vínculo alvo <-> fase
        cls.bind_target_to_phase(phase_id, target_id)

        # Registrar custódia (com deduplicação por hash SHA-256)
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM custody_files WHERE target_id = ? AND sha256_hash = ?", (target_id, file_hash))
        existing_custody = cursor.fetchone()
        if not existing_custody:
            cursor.execute("""
                INSERT INTO custody_files (operation_id, phase_id, target_id, platform, file_name, file_path, file_size, sha256_hash, declared_hash)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (operation_id, phase_id, target_id, platform, file_name, file_path, file_size, file_hash, clean_declared))
            conn.commit()
        conn.close()

        # Executar Parser
        if platform == "instagram":
            parser = InstagramParser()
            parse_result = parser.parse_file(file_path, operation_id, phase_id, target_id)
        else:
            # Verificar se é WhatsApp CDR / Bilhetagem (Message Log & Call Logs)
            is_cdr = False
            if zipfile.is_zipfile(file_path):
                try:
                    with zipfile.ZipFile(file_path, "r") as z:
                        if "records.html" in z.namelist():
                            sample = z.read("records.html")[:8000].decode("utf-8", errors="ignore")
                            if "message log" in sample.lower() or "call log" in sample.lower():
                                is_cdr = True
                except Exception:
                    pass

            if is_cdr:
                from backend.parsers.whatsapp_cdr_parser import WhatsAppCdrParser
                cdr_res = WhatsAppCdrParser.parse_and_store(file_path, operation_id, phase_id, target_id)
                parse_result = {
                    "followers": [],
                    "following": [],
                    "threads": {},
                    "groups": [],
                    "ip_connections": list(cdr_res.get("unique_ips", [])),
                    "messages": [{"id": i} for i in range(cdr_res.get("messages_imported", 0))],
                    "calls": [{"id": i} for i in range(cdr_res.get("calls_imported", 0))]
                }
            else:
                parser = WhatsAppParser()
                parse_result = parser.parse_file(file_path, operation_id, phase_id, target_id)

        if not isinstance(parse_result, dict):
            parse_result = {}

        # Buscar dados cadastrais do alvo para o resumo
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT name_or_alias, main_identifier FROM targets WHERE id = ?", (target_id,))
        tgt_row = cursor.fetchone()
        target_name = tgt_row["name_or_alias"] if tgt_row else "Investigado"
        target_identifier = tgt_row["main_identifier"] if tgt_row else ""

        # Imediato: Baixar foto de perfil do alvo via link do ID do perfil
        if platform == "instagram":
            try:
                cursor.execute("SELECT target_uid, vanity_name FROM instagram_targets WHERE target_id = ?", (target_id,))
                it_row = cursor.fetchone()
                if it_row:
                    from backend.services.avatar_service import fetch_and_cache_avatar
                    fetch_and_cache_avatar(
                        username=it_row["vanity_name"],
                        user_id=it_row["target_uid"],
                        target_id=target_id
                    )
            except Exception as e:
                logger.warning(f"Erro ao auto-baixar foto do alvo pós-importação: {e}")

        conn.close()

        followers_cnt = len(parse_result.get("followers", []))
        following_cnt = len(parse_result.get("following", []))
        threads_cnt = len(parse_result.get("threads", {})) or len(parse_result.get("groups", []))
        ip_cnt = len(parse_result.get("ip_connections", [])) or len(parse_result.get("connections", []))
        msgs_cnt = len(parse_result.get("messages", []))
        if not msgs_cnt and parse_result.get("threads"):
            msgs_cnt = sum(len(m_list) for m_list in parse_result.get("threads", {}).values())

        hash_match = None
        if clean_declared:
            hash_match = (clean_declared.lower() == file_hash.lower())

        return {
            "status": "success",
            "operation_id": operation_id,
            "phase_id": phase_id,
            "target_id": target_id,
            "target_name": target_name,
            "target_identifier": target_identifier,
            "file_name": file_name,
            "sha256_hash": file_hash,
            "declared_hash": clean_declared,
            "hash_match": hash_match,
            "platform": platform,
            "summary": {
                "followers_count": followers_cnt,
                "following_count": following_cnt,
                "ip_count": ip_cnt,
                "threads_count": threads_cnt,
                "messages_count": msgs_cnt
            }
        }

    # ==================== CADEIA DE CUSTÓDIA & AUDITORIA ====================
    @classmethod
    def get_custody_files(
        cls,
        operation_id: int,
        phase_id: Optional[int] = None,
        target_id: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = """
            SELECT cf.*,
                   o.name as operation_name,
                   p.name as phase_name,
                   t.name_or_alias as target_name,
                   t.main_identifier as target_identifier
            FROM custody_files cf
            LEFT JOIN operations o ON cf.operation_id = o.id
            LEFT JOIN phases p ON cf.phase_id = p.id
            LEFT JOIN targets t ON cf.target_id = t.id
            WHERE cf.operation_id = ?
        """
        params = [operation_id]
        if phase_id:
            query += " AND cf.phase_id = ?"
            params.append(phase_id)
        if target_id:
            query += " AND cf.target_id = ?"
            params.append(target_id)
        query += " ORDER BY cf.imported_at DESC, cf.id DESC"
        cursor.execute(query, tuple(params))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()

        for r in rows:
            fpath = r.get("file_path") or os.path.join(CUSTODY_DIR, r["file_name"])
            r["file_exists"] = os.path.exists(fpath) or os.path.exists(os.path.join(CUSTODY_DIR, r["file_name"]))
            
            decl = (r.get("declared_hash") or "").strip().lower()
            comp = (r.get("sha256_hash") or "").strip().lower()
            if not decl:
                r["declared_match_status"] = "uninformed"
            elif decl == comp:
                r["declared_match_status"] = "match"
            else:
                r["declared_match_status"] = "divergent"

        return rows

    @classmethod
    def update_declared_hash(cls, custody_id: int, declared_hash: Optional[str]) -> Dict[str, Any]:
        clean_declared = declared_hash.strip().lower() if (declared_hash and declared_hash.strip()) else None
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE custody_files SET declared_hash = ? WHERE id = ?", (clean_declared, custody_id))
        conn.commit()
        conn.close()
        return cls.verify_custody_file(custody_id)

    @classmethod
    def verify_custody_file(cls, custody_id: int) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT cf.*,
                   o.name as operation_name,
                   p.name as phase_name,
                   t.name_or_alias as target_name,
                   t.main_identifier as target_identifier
            FROM custody_files cf
            LEFT JOIN operations o ON cf.operation_id = o.id
            LEFT JOIN phases p ON cf.phase_id = p.id
            LEFT JOIN targets t ON cf.target_id = t.id
            WHERE cf.id = ?
        """, (custody_id,))
        row = cursor.fetchone()
        conn.close()
        if not row:
            return {"status": "not_found", "message": "Registro de custódia não encontrado."}

        rec = dict(row)
        file_path = rec.get("file_path") or os.path.join(CUSTODY_DIR, rec["file_name"])

        if not os.path.exists(file_path):
            fallback = os.path.join(CUSTODY_DIR, rec["file_name"])
            if os.path.exists(fallback):
                file_path = fallback

        decl = (rec.get("declared_hash") or "").strip().lower()
        
        if not os.path.exists(file_path):
            return {
                "id": rec["id"],
                "file_name": rec["file_name"],
                "status": "missing",
                "is_valid": False,
                "expected_sha256": rec["sha256_hash"],
                "declared_hash": rec.get("declared_hash"),
                "declared_match_status": "uninformed" if not decl else ("match" if decl == rec["sha256_hash"].lower() else "divergent"),
                "current_sha256": None,
                "current_md5": None,
                "expected_size": rec["file_size"],
                "current_size": None,
                "message": "Arquivo físico não encontrado na pasta de custódia.",
                "target_name": rec.get("target_name") or rec.get("target_identifier") or "Alvo",
                "platform": rec["platform"],
                "imported_at": rec["imported_at"]
            }

        current_size = os.path.getsize(file_path)
        current_sha256 = cls.calculate_sha256(file_path)
        current_md5 = cls.calculate_md5(file_path)
        is_valid = (current_sha256.lower() == rec["sha256_hash"].lower())

        declared_match_status = "uninformed"
        if decl:
            declared_match_status = "match" if (decl == current_sha256.lower()) else "divergent"

        return {
            "id": rec["id"],
            "file_name": rec["file_name"],
            "file_path": file_path,
            "status": "valid" if is_valid else "corrupted",
            "is_valid": is_valid,
            "expected_sha256": rec["sha256_hash"],
            "declared_hash": rec.get("declared_hash"),
            "declared_match_status": declared_match_status,
            "current_sha256": current_sha256,
            "current_md5": current_md5,
            "expected_size": rec["file_size"],
            "current_size": current_size,
            "target_name": rec.get("target_name") or rec.get("target_identifier") or "Alvo",
            "platform": rec["platform"],
            "imported_at": rec["imported_at"],
            "message": "Integridade forense 100% verificada e autêntica." if is_valid else "Alerta: Hash diverge do registro inicial!"
        }

    @classmethod
    def verify_all_operation_custody(
        cls,
        operation_id: int,
        phase_id: Optional[int] = None,
        target_id: Optional[int] = None
    ) -> Dict[str, Any]:
        files = cls.get_custody_files(operation_id, phase_id, target_id)
        results = []
        valid_count = 0
        corrupted_count = 0
        missing_count = 0

        for f in files:
            ver = cls.verify_custody_file(f["id"])
            results.append(ver)
            if ver["status"] == "valid":
                valid_count += 1
            elif ver["status"] == "corrupted":
                corrupted_count += 1
            elif ver["status"] == "missing":
                missing_count += 1

        total = len(results)
        all_valid = (total > 0 and valid_count == total)

        return {
            "total": total,
            "valid_count": valid_count,
            "corrupted_count": corrupted_count,
            "missing_count": missing_count,
            "all_valid": all_valid,
            "results": results
        }

    # ==================== PRÉ-SCANNER & GESTÃO AVANÇADA DE ALVOS ====================

    @classmethod
    def inspect_evidence(cls, file_path: str, operation_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Inspeciona o arquivo ou pasta em memória antes da ingestão e extrai os metadados do alvo,
        plataforma, identificador e sugere vínculos com alvos existentes na operação.
        """
        # Auto-resolver se o usuário passou caminho sem extensão .zip ou pasta de ZIPs
        is_folder_batch = False
        batch_count = 0
        original_folder_name = ""

        if not os.path.exists(file_path):
            if os.path.exists(file_path + ".zip"):
                file_path = file_path + ".zip"
            else:
                raise FileNotFoundError(f"Arquivo para inspeção não encontrado: {file_path}")
        elif os.path.isdir(file_path):
            zip_files = [os.path.join(file_path, f) for f in os.listdir(file_path) if f.lower().endswith(".zip")]
            if zip_files:
                is_folder_batch = True
                batch_count = len(zip_files)
                original_folder_name = os.path.basename(file_path.rstrip("\\/"))
                file_path = sorted(zip_files)[0]
            elif os.path.exists(file_path + ".zip"):
                file_path = file_path + ".zip"
            else:
                raise ValueError("Nenhum arquivo ZIP encontrado na pasta informada.")

        if not zipfile.is_zipfile(file_path):
            raise ValueError("Formato de arquivo inválido. O sistema aceita exclusivamente pacotes forenses compactados em formato ZIP (.zip).")

        file_name = f"{original_folder_name} ({batch_count} arquivos ZIP de Bilhetagem)" if is_folder_batch else os.path.basename(file_path)
        file_size = os.path.getsize(file_path)
        file_hash = cls.calculate_sha256(file_path)

        platform = "instagram"
        detected_identifier = None
        detected_name = None
        detected_email = None
        detected_phone = None
        ticket = None
        logical_id = None
        date_range = None
        profile_pic_filename = None

        if zipfile.is_zipfile(file_path):
            # 1. Determinar com precisão cirúrgica a plataforma inspecionando o cabeçalho
            is_wa = False
            with zipfile.ZipFile(file_path, "r") as z:
                for name in ["records.html", "preservation-1.html"] + [n for n in z.namelist() if n.endswith(".html")]:
                    if name in z.namelist():
                        raw_sample = z.read(name)[:8000].decode("utf-8", errors="ignore").lower()
                        if "service | instagram" in raw_sample or "service: instagram" in raw_sample or "instagramuser" in raw_sample:
                            is_wa = False
                            platform = "instagram"
                            break
                        elif "service | whatsapp" in raw_sample or "service: whatsapp" in raw_sample or "whatsappuser" in raw_sample:
                            is_wa = True
                            platform = "whatsapp"
                            break

            if is_wa:
                # Verificar se é WhatsApp CDR / Extrato de Conexão
                from backend.parsers.whatsapp_cdr_parser import WhatsAppCdrParser
                cdr_insp = WhatsAppCdrParser.inspect_cdr(file_path)
                if cdr_insp.get("is_valid") and cdr_insp.get("target_identifier"):
                    platform = "whatsapp"
                    detected_phone = cdr_insp.get("target_identifier")
                    detected_identifier = detected_phone
                    detected_name = f"Alvo WhatsApp ({detected_phone})"
                    ticket = cdr_insp.get("ticket_number")
                    date_range = cdr_insp.get("date_range")
                else:
                    with zipfile.ZipFile(file_path, "r") as z:
                        for name in ["records.html", "preservation-1.html"] + [n for n in z.namelist() if n.endswith(".html")]:
                            if name in z.namelist():
                                html_content = z.read(name).decode("utf-8", errors="ignore")
                                soup = bs4.BeautifulSoup(html_content, "html.parser")
                                txt = soup.get_text(" | ", strip=True)

                                p_match = re.search(r'(?:Target|Account Identifier|MSISDN|Phone Number|Telefone)\s*[:|=]\s*(\+?\d{10,15})', txt, re.IGNORECASE)
                                if p_match:
                                    detected_phone = p_match.group(1).strip()
                                    detected_identifier = detected_phone

                                t_match = re.search(r'Internal Ticket Number\s*\|\s*([^|]+)', txt, re.IGNORECASE)
                                if t_match: ticket = t_match.group(1).strip()

                                l_match = re.search(r'Logical ID\s*\|\s*([^|]+)', txt, re.IGNORECASE)
                                if l_match: logical_id = l_match.group(1).strip()

                                d_match = re.search(r'Date Range\s*\|\s*([^|]+)', txt, re.IGNORECASE)
                                if d_match: date_range = d_match.group(1).strip()

                                # E-mail
                                email_div = soup.find("div", id="property-emails")
                                if email_div:
                                    m_em = re.search(r'Registered Email Addresses\s*\|\s*([^|]+)', email_div.get_text(" | ", strip=True), re.IGNORECASE)
                                    if m_em and "no responsive" not in m_em.group(1).lower():
                                        detected_email = m_em.group(1).strip()

                                # SMB / Nome comercial
                                smb_div = soup.find("div", id="property-small_medium_business")
                                if smb_div:
                                    smb_txt = smb_div.get_text(" | ", strip=True)
                                    m_smb = re.search(r'Small Medium Business\s*\|\s*Name\s*\|\s*([^|]+)', smb_txt, re.IGNORECASE)
                                    if m_smb and not any(k in m_smb.group(1).lower() for k in ["definition", "provided", "account holder"]):
                                        detected_name = m_smb.group(1).strip()

                                if not detected_name:
                                    n_match = re.search(r'(?:Push Name|Nome)\s*[:|=]\s*([^\n\r|<]{2,50})', txt, re.IGNORECASE)
                                    if n_match and not any(k in n_match.group(1).lower() for k in ["definition", "provided", "account holder", "if available"]):
                                        detected_name = n_match.group(1).strip()

                                # Foto de perfil
                                pic_div = soup.find("div", id="property-profile_picture")
                                if pic_div:
                                    m_pic = re.search(r'Linked Media File:\s*\|\s*([^|]+)', pic_div.get_text(" | ", strip=True), re.IGNORECASE)
                                    if m_pic:
                                        profile_pic_filename = os.path.basename(m_pic.group(1).strip())
                                break
            else: # Instagram
                platform = "instagram"
                with zipfile.ZipFile(file_path, "r") as z:
                    html_names = sorted(
                        [n for n in z.namelist() if n.endswith(".html")],
                        key=lambda x: 0 if "records.html" in x.lower() else (1 if "preservation" in x.lower() else 2)
                    )
                    for name in html_names:
                        html_content = z.read(name).decode("utf-8", errors="ignore")
                        soup = bs4.BeautifulSoup(html_content, "html.parser")
                        txt = soup.get_text(" | ", strip=True)

                        # 1. Ticket do Meta LERS
                        if not ticket:
                            t_match = re.search(r'Internal Ticket Number\s*\|\s*([^|]+)', txt, re.IGNORECASE)
                            if t_match:
                                ticket = t_match.group(1).strip()

                        # 2. UID / Logical ID
                        if not logical_id:
                            uid_match = re.search(r'Target\s*\|\s*(\d+)', txt)
                            if uid_match:
                                logical_id = uid_match.group(1).strip()

                        # 2.1 Período Requisitado (Date Range)
                        if not date_range:
                            d_match = re.search(r'Date Range\s*\|\s*([^|]+)', txt, re.IGNORECASE)
                            if d_match:
                                date_range = d_match.group(1).strip()

                        # 3. Identificador / @username
                        if not detected_identifier or "@" in detected_identifier[1:] or detected_identifier in ["@reel", "@reels", "@p", "@stories", "@explore", "@direct", "@alvo"]:
                            # Prioridade 1: Account Identifier no cabeçalho do relatório
                            u_match = re.search(r'Account Identifier\s*\|\s*([^|\n\r]+)', txt)
                            if u_match and not u_match.group(1).strip().isdigit():
                                raw_u = u_match.group(1).strip().rstrip('/').split('/')[-1]
                                clean_u = raw_u.replace('@', '').strip()
                                if clean_u and clean_u.lower() not in ['reel', 'reels', 'p', 'stories', 'explore', 'direct', 'accounts']:
                                    detected_identifier = f"@{clean_u}"

                            # Prioridade 2: Propriedade Vanity Name
                            if not detected_identifier or detected_identifier in ["@reel", "@reels", "@p", "@stories"]:
                                v_div = soup.find("div", id="property-vanity")
                                if v_div:
                                    for to in v_div.find_all("div", class_="t o"):
                                        to_txt = to.get_text(separator=" | ", strip=True)
                                        if "Definition" not in to_txt:
                                            parts = [p.strip() for p in to_txt.split("|") if p.strip()]
                                            if parts and parts[-1] not in ["Vanity", "Definition", "No responsive records located"]:
                                                detected_identifier = f"@{parts[-1].replace('@', '').strip()}"
                                                break

                            # Prioridade 3: URL do perfil
                            if not detected_identifier or detected_identifier in ["@reel", "@reels", "@p", "@stories"]:
                                url_matches = re.findall(r'https?://(?:www\.)?instagram\.com/([a-zA-Z0-9_.-]+)', txt, re.IGNORECASE)
                                for u_cand in url_matches:
                                    if u_cand.lower() not in ['reel', 'reels', 'p', 'stories', 'explore', 'direct', 'accounts', 'developer', 'about']:
                                        detected_identifier = f"@{u_cand.strip()}"
                                        break

                        # 4. Nome / Titular
                        if not detected_name:
                            name_div = soup.find("div", id="property-name")
                            if name_div:
                                for to in name_div.find_all("div", class_="t o"):
                                    to_txt = to.get_text(separator=" | ", strip=True)
                                    if "Definition" not in to_txt:
                                        parts = [p.strip() for p in to_txt.split("|") if p.strip()]
                                        if parts:
                                            val = parts[-1]
                                            if val and val not in ["Name", "First", "Last", "Definition", "No responsive records located"]:
                                                detected_name = val
                                                break

                        # 5. E-mail higienizado
                        if not detected_email:
                            email_div = soup.find("div", id="property-emails")
                            if email_div:
                                em_txt = email_div.get_text(" ", strip=True)
                                em_match = re.search(r'([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)', em_txt)
                                if em_match:
                                    is_ver = "(Verified)" in em_txt or "Verified" in em_txt
                                    detected_email = f"{em_match.group(1).strip()}{' (Verificado)' if is_ver else ''}"
        elif file_path.endswith(".html"):
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                html_content = f.read()
                if "service | whatsapp" in html_content[:6000].lower() or "whatsapp" in html_content[:6000].lower():
                    platform = "whatsapp"
                    p_match = re.search(r'(?:Target|Account Identifier|MSISDN|Phone Number|Telefone)\s*[:|=]\s*(\+?\d{10,15})', html_content, re.IGNORECASE)
                    if p_match:
                        detected_phone = p_match.group(1).strip()
                        detected_identifier = detected_phone
                else:
                    platform = "instagram"
                    u_match = re.search(r'Account Identifier\s*\|\s*([^|\n\r]+)', html_content)
                    if u_match and not u_match.group(1).strip().isdigit():
                        detected_identifier = f"@{u_match.group(1).strip()}"

        suggested_name = detected_name or detected_identifier or (f"Alvo {platform.capitalize()}")
        if suggested_name in ["@alvo", "Alvo", "Alvo_Meta"] or suggested_name.startswith("Alvo_"):
            suggested_name = detected_identifier or f"Alvo {platform.capitalize()}"

        # Buscar correspondência com alvos existentes na operação
        matching_suggestion = None
        existing_targets = []

        if operation_id:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT id, name_or_alias, main_identifier, email, phone FROM targets WHERE operation_id = ?", (operation_id,))
            existing_targets = [dict(r) for r in cursor.fetchall()]

            clean_phone = (detected_phone or detected_identifier or "").replace("+", "").replace("@", "").strip()

            for t in existing_targets:
                # 1. Correspondência por e-mail
                if detected_email and t.get("email") and detected_email.lower() in t["email"].lower():
                    matching_suggestion = {
                        "target_id": t["id"],
                        "target_name": t["name_or_alias"] or t["main_identifier"],
                        "match_reason": f"E-mail coincidente: {detected_email}"
                    }
                    break
                # 2. Correspondência por telefone
                if clean_phone and len(clean_phone) >= 8 and t.get("phone") and clean_phone in t["phone"].replace("+", ""):
                    matching_suggestion = {
                        "target_id": t["id"],
                        "target_name": t["name_or_alias"] or t["main_identifier"],
                        "match_reason": f"Telefone coincidente: {detected_phone or clean_phone}"
                    }
                    break
                # 3. Correspondência por @username
                if detected_identifier and detected_identifier.startswith("@") and t.get("main_identifier") == detected_identifier:
                    matching_suggestion = {
                        "target_id": t["id"],
                        "target_name": t["name_or_alias"] or t["main_identifier"],
                        "match_reason": f"Identificador coincidente: {detected_identifier}"
                    }
                    break
            conn.close()

        return {
            "file_name": file_name,
            "file_size": file_size,
            "sha256_hash": file_hash,
            "platform": platform,
            "detected_identifier": detected_identifier or "---",
            "detected_name": detected_name,
            "suggested_name": suggested_name,
            "detected_email": detected_email or "Não identificado",
            "detected_phone": detected_phone,
            "internal_ticket": ticket or "---",
            "logical_id": logical_id or "---",
            "date_range": date_range or "---",
            "profile_pic_filename": profile_pic_filename,
            "matching_suggestion": matching_suggestion,
            "existing_targets": existing_targets
        }

    @classmethod
    def update_target(
        cls,
        target_id: int,
        name_or_alias: Optional[str] = None,
        notes: Optional[str] = None,
        main_identifier: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Atualiza o nome oficial, vulgo ou anotações periciais do alvo.
        """
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM targets WHERE id = ?", (target_id,))
        target_row = cursor.fetchone()
        if not target_row:
            conn.close()
            raise ValueError("Alvo não encontrado.")

        t_dict = dict(target_row)
        new_name = name_or_alias.strip() if name_or_alias and name_or_alias.strip() else t_dict.get("name_or_alias")
        new_notes = notes if notes is not None else t_dict.get("notes")
        new_identifier = main_identifier.strip() if main_identifier and main_identifier.strip() else t_dict.get("main_identifier")

        cursor.execute("""
            UPDATE targets SET
                name_or_alias = ?,
                main_identifier = ?,
                notes = ?
            WHERE id = ?
        """, (new_name, new_identifier, new_notes, target_id))

        conn.commit()
        cursor.execute("SELECT * FROM targets WHERE id = ?", (target_id,))
        updated = dict(cursor.fetchone())
        conn.close()

        return updated

    @classmethod
    def merge_targets(
        cls,
        operation_id: int,
        source_target_id: int,
        destination_target_id: int
    ) -> Dict[str, Any]:
        """
        Mescla (unifica) dois alvos da mesma operação:
        Transfere todas as evidências, arquivos de custódia, chats, IPs, dispositivos
        e grupos do source_target_id para o destination_target_id e exclui o alvo fonte.
        """
        if source_target_id == destination_target_id:
            raise ValueError("O alvo de origem e o alvo de destino não podem ser iguais.")

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM targets WHERE id = ? AND operation_id = ?", (source_target_id, operation_id))
        src = cursor.fetchone()
        cursor.execute("SELECT * FROM targets WHERE id = ? AND operation_id = ?", (destination_target_id, operation_id))
        dest = cursor.fetchone()

        if not src or not dest:
            conn.close()
            raise ValueError("Alvo de origem ou destino não encontrado na operação.")

        src_dict = dict(src)
        dest_dict = dict(dest)

        # 1. Migrar arquivos de custódia
        cursor.execute("UPDATE custody_files SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))

        # 2. Migrar Instagram
        cursor.execute("UPDATE instagram_targets SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))
        cursor.execute("UPDATE instagram_relationships SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))
        cursor.execute("UPDATE instagram_connections SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))
        cursor.execute("UPDATE instagram_devices SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))

        # 3. Migrar WhatsApp
        cursor.execute("UPDATE whatsapp_targets SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))
        cursor.execute("UPDATE whatsapp_groups SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))
        cursor.execute("UPDATE whatsapp_contacts SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))
        cursor.execute("UPDATE whatsapp_devices SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))
        cursor.execute("UPDATE whatsapp_connections SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))

        # 4. Migrar Mensagens e Linha do Tempo
        cursor.execute("UPDATE messages SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))
        cursor.execute("UPDATE timeline_events SET target_id = ? WHERE target_id = ?", (destination_target_id, source_target_id))

        # 5. Consolidar campos vazios do destino com dados da fonte
        merged_email = dest_dict.get("email") or src_dict.get("email")
        merged_phone = dest_dict.get("phone") or src_dict.get("phone")
        merged_ip = dest_dict.get("registration_ip") or src_dict.get("registration_ip")
        
        cursor.execute("""
            UPDATE targets SET
                email = ?,
                phone = ?,
                registration_ip = ?
            WHERE id = ?
        """, (merged_email, merged_phone, merged_ip, destination_target_id))

        # 6. Remover vínculos de fase e o alvo fonte
        cursor.execute("DELETE FROM phase_targets WHERE target_id = ?", (source_target_id,))
        cursor.execute("DELETE FROM targets WHERE id = ?", (source_target_id,))

        conn.commit()
        conn.close()

        return {
            "status": "success",
            "message": f"Alvo '{src_dict.get('name_or_alias')}' mesclado com sucesso em '{dest_dict.get('name_or_alias')}'.",
            "destination_target_id": destination_target_id,
            "source_target_id": source_target_id
        }

import os
import re
import json
import time
import urllib.request
import asyncio
import logging
from typing import Optional, Dict, Any, List

from backend.config import AVATAR_DIR

logger = logging.getLogger(__name__)

_sync_status: Dict[str, Any] = {
    "running": False,
    "total": 0,
    "processed": 0,
    "success": 0,
    "failed": 0,
    "current": "",
    "error": None
}

# Cache negativo de IDs que falharam (404 / conta deletada / indisponível)
# Evita reconsultas repetidas imediatas, mas com expiração curta (5 minutos)
_failed_avatar_uids: Dict[str, float] = {}
NEGATIVE_CACHE_TTL = 300  # 5 minutos de retenção (permite novas tentativas rápidas)

def is_uid_negative_cached(clean_uid: str) -> bool:
    if not clean_uid:
        return False
    fail_time = _failed_avatar_uids.get(clean_uid)
    if fail_time:
        if time.time() - fail_time < NEGATIVE_CACHE_TTL:
            return True
        else:
            _failed_avatar_uids.pop(clean_uid, None)
    return False

def mark_uid_negative_cache(clean_uid: str):
    if clean_uid:
        _failed_avatar_uids[clean_uid] = time.time()

def clear_uid_negative_cache(identifier: Optional[str] = None):
    """Limpa o cache negativo para forçar uma nova tentativa imediata."""
    if not identifier:
        _failed_avatar_uids.clear()
        return
    clean = str(identifier).replace('@', '').strip().lower()
    _failed_avatar_uids.pop(clean, None)

def sanitize_filename(name: str) -> str:
    return re.sub(r'[^a-zA-Z0-9_\-\.]', '_', name)

def get_avatar_local_filename(identifier: str) -> str:
    clean = sanitize_filename(str(identifier).replace('@', '').strip().lower())
    return f"ig_{clean}.jpg"

def get_cached_avatar_url(identifier: str, target_id: Optional[int] = None) -> Optional[str]:
    if not identifier:
        return None
    fname = get_avatar_local_filename(identifier)

    if target_id:
        t_path = os.path.join(AVATAR_DIR, f"target_{target_id}", fname)
        if os.path.exists(t_path) and os.path.getsize(t_path) > 100:
            return f"/media/avatars/target_{target_id}/{fname}"

    fpath = os.path.join(AVATAR_DIR, fname)
    if os.path.exists(fpath) and os.path.getsize(fpath) > 100:
        return f"/media/avatars/{fname}"

    if os.path.exists(AVATAR_DIR):
        for item in os.listdir(AVATAR_DIR):
            sub_dir = os.path.join(AVATAR_DIR, item)
            if os.path.isdir(sub_dir) and item.startswith("target_"):
                sub_path = os.path.join(sub_dir, fname)
                if os.path.exists(sub_path) and os.path.getsize(sub_path) > 100:
                    return f"/media/avatars/{item}/{fname}"

    return None

def get_all_cached_avatars_map(target_id: Optional[int] = None) -> Dict[str, str]:
    mapping = {}
    if not os.path.exists(AVATAR_DIR):
        return mapping

    if target_id:
        t_dir = os.path.join(AVATAR_DIR, f"target_{target_id}")
        if os.path.exists(t_dir):
            for fn in os.listdir(t_dir):
                if fn.startswith("ig_") and fn.endswith(".jpg"):
                    ident = fn[3:-4]
                    mapping[ident] = f"/media/avatars/target_{target_id}/{fn}"

    for root, _, files in os.walk(AVATAR_DIR):
        for fn in files:
            if fn.startswith("ig_") and fn.endswith(".jpg"):
                ident = fn[3:-4]
                if ident not in mapping:
                    rel = os.path.relpath(os.path.join(root, fn), AVATAR_DIR).replace("\\", "/")
                    mapping[ident] = f"/media/avatars/{rel}"
    return mapping

def get_pending_avatars_count(operation_id: Optional[int] = None, target_id: Optional[int] = None, usernames: Optional[List[str]] = None) -> int:
    if usernames:
        pending = 0
        for u in usernames:
            if not get_cached_avatar_url(u, target_id):
                pending += 1
        return pending
    return 0

def get_avatar_sync_status() -> Dict[str, Any]:
    st = dict(_sync_status)
    st["in_progress"] = st.get("running", False)
    st["downloaded"] = st.get("success", 0)
    st["current"] = st.get("processed", 0)
    st["current_user"] = _sync_status.get("current", "")
    return st

def find_user_id_for_username(clean_username: str, target_id: Optional[int] = None) -> Optional[str]:
    """Tenta localizar o user_id numérico correspondente a um username no banco de dados local."""
    if not clean_username:
        return None
    clean = (clean_username or '').replace('@', '').strip().lower()
    try:
        from backend.database import get_db_connection
        conn = get_db_connection()
        # 1. Checar na tabela instagram_targets
        row = conn.execute(
            "SELECT target_uid FROM instagram_targets WHERE LOWER(REPLACE(vanity_name, '@', '')) = ? AND target_uid IS NOT NULL AND target_uid != '' LIMIT 1",
            (clean,)
        ).fetchone()
        if row and row["target_uid"]:
            return str(row["target_uid"]).strip()

        # 2. Checar na tabela messages
        row = conn.execute(
            "SELECT sender_id FROM messages WHERE LOWER(REPLACE(sender_username, '@', '')) = ? AND sender_id IS NOT NULL AND sender_id != '' LIMIT 1",
            (clean,)
        ).fetchone()
        if row and row["sender_id"]:
            return str(row["sender_id"]).strip()

        # 3. Checar em instagram_relationships (coluna é uid)
        row = conn.execute(
            "SELECT uid FROM instagram_relationships WHERE LOWER(REPLACE(username, '@', '')) = ? AND uid IS NOT NULL AND uid != '' LIMIT 1",
            (clean,)
        ).fetchone()
        if row and row["uid"]:
            return str(row["uid"]).strip()

        conn.close()
    except Exception:
        pass
    return None

def fetch_and_cache_avatar(
    username: Optional[str] = None,
    user_id: Optional[str] = None,
    target_id: Optional[int] = None,
    identifier: Optional[str] = None
) -> Optional[str]:
    """
    Busca e salva localmente a foto de perfil do Instagram EXCLUSIVAMENTE pelo ID numérico do perfil.
    Não realiza buscas por @ (username), prevenindo erros 401 e bloqueios de rede.
    Utiliza cache negativo para evitar reconsultar contas inexistentes/deletadas a cada F5/clique.
    """
    clean_username = str(username or identifier or '').replace('@', '').strip().lower()
    clean_uid = str(user_id or '').strip()

    if clean_username.isdigit() and not clean_uid:
        clean_uid = clean_username
        clean_username = ""

    # Se não temos o ID numérico diretamente, tentar resolver no banco de dados local
    if not clean_uid and clean_username:
        clean_uid = find_user_id_for_username(clean_username, target_id) or ""

    # REGRA: Fotos só são buscadas usando o ID numérico. Sem ID numérico, não faz requisições externas por @.
    if not clean_uid or not clean_uid.isdigit():
        return None

    # 1. Checar se já temos o avatar em cache local no disco
    cached = get_cached_avatar_url(clean_uid, target_id)
    if not cached and clean_username:
        cached = get_cached_avatar_url(clean_username, target_id)
    if cached:
        return cached

    # 2. Checar cache negativo (se já falhou com 404/inexistente recentemente)
    if is_uid_negative_cached(clean_uid):
        return None

    out_dir = os.path.join(AVATAR_DIR, f"target_{target_id}") if target_id else AVATAR_DIR
    os.makedirs(out_dir, exist_ok=True)

    # 3. Buscar usando o endpoint móvel oficial por ID do perfil
    try:
        url = f"https://i.instagram.com/api/v1/users/{clean_uid}/info/"
        req = urllib.request.Request(url)
        req.add_header("User-Agent", "Instagram 219.0.0.12.117 Android (29/10; 480dpi; 1080x2280; Xiaomi; Redmi Note 7; lavender; qcom; pt_BR; 348398188)")
        req.add_header("Accept", "*/*")
        req.add_header("x-ig-app-id", "936619743392459")

        with urllib.request.urlopen(req, timeout=5) as res:
            if res.getcode() == 200:
                data = json.loads(res.read().decode('utf-8'))
                user_data = data.get("user", {})
                pic_url = user_data.get("hd_profile_pic_url_info", {}).get("url") or user_data.get("profile_pic_url")
                ret_username = (user_data.get("username") or clean_username or "").strip().lower()

                if pic_url:
                    img_req = urllib.request.Request(pic_url)
                    img_req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                    with urllib.request.urlopen(img_req, timeout=5) as img_res:
                        img_bytes = img_res.read()

                    files_to_save = [
                        os.path.join(out_dir, get_avatar_local_filename(clean_uid)),
                        os.path.join(AVATAR_DIR, get_avatar_local_filename(clean_uid))
                    ]
                    if ret_username:
                        files_to_save.append(os.path.join(out_dir, get_avatar_local_filename(ret_username)))
                        files_to_save.append(os.path.join(AVATAR_DIR, get_avatar_local_filename(ret_username)))
                    if clean_username and clean_username != ret_username:
                        files_to_save.append(os.path.join(out_dir, get_avatar_local_filename(clean_username)))
                        files_to_save.append(os.path.join(AVATAR_DIR, get_avatar_local_filename(clean_username)))

                    for fpath in set(files_to_save):
                        os.makedirs(os.path.dirname(fpath), exist_ok=True)
                        with open(fpath, "wb") as f_out:
                            f_out.write(img_bytes)

                    return get_cached_avatar_url(clean_uid, target_id) or get_cached_avatar_url(ret_username, target_id)
    except Exception as e:
        mark_uid_negative_cache(clean_uid)
        logger.info(f"Avatar não disponível para ID {clean_uid} ({e})")

    return None

def batch_sync_avatars(operation_id: Optional[int] = None, target_id: Optional[int] = None, limit: Optional[int] = None, usernames: Optional[List[str]] = None):
    global _sync_status
    if _sync_status["running"]:
        return

    items_to_sync = []
    
    # 1. Se lista de usernames foi informada diretamente
    if usernames:
        for u in usernames:
            clean = (u or "").strip().replace('@', '')
            if clean:
                items_to_sync.append((clean, None))

    # 2. Coletar do banco de dados (priorizando o ALVO como primeiro item)
    if not items_to_sync and (operation_id or target_id):
        from backend.database import get_db_connection
        conn = get_db_connection()
        cursor = conn.cursor()

        # OBRIGATÓRIO: O Alvo é SEMPRE a PRIMEIRA busca!
        if target_id:
            cursor.execute("SELECT target_uid, vanity_name FROM instagram_targets WHERE target_id = ?", (target_id,))
            t_row = cursor.fetchone()
            if t_row:
                t_user = (t_row["vanity_name"] or "").strip().replace('@', '')
                t_uid = (t_row["target_uid"] or "").strip()
                if t_user or t_uid:
                    items_to_sync.append((t_user, t_uid))
            else:
                cursor.execute("SELECT main_identifier FROM targets WHERE id = ?", (target_id,))
                t_row_tgt = cursor.fetchone()
                if t_row_tgt:
                    t_user = (t_row_tgt["main_identifier"] or "").strip().replace('@', '')
                    if t_user:
                        items_to_sync.append((t_user, None))

        # Coletar remetentes das conversas de DM com seus respectivos sender_id numéricos
        query_msg = """
            SELECT DISTINCT sender_username, sender_id 
            FROM messages 
            WHERE platform = 'instagram' 
              AND ((sender_username IS NOT NULL AND sender_username != '') 
                   OR (sender_id IS NOT NULL AND sender_id != ''))
        """
        params_msg = []
        if target_id:
            query_msg += " AND target_id = ?"
            params_msg.append(target_id)
        elif operation_id:
            query_msg += " AND operation_id = ?"
            params_msg.append(operation_id)

        cursor.execute(query_msg, params_msg)
        for r in cursor.fetchall():
            u = (r["sender_username"] or "").strip().replace('@', '')
            uid = (r["sender_id"] or "").strip()
            if u.lower() in ['desconhecido', '---', 'n/a', 'instagram', 'facebook']:
                u = ""
            if uid or u:
                pair = (u, uid)
                if pair not in items_to_sync:
                    items_to_sync.append(pair)

        # Coletar perfis da rede de relacionamentos
        if target_id:
            cursor.execute("""
                SELECT DISTINCT username, uid 
                FROM instagram_relationships 
                WHERE target_id = ? 
                  AND ((username IS NOT NULL AND username != '') 
                       OR (uid IS NOT NULL AND uid != ''))
            """, (target_id,))
            for r in cursor.fetchall():
                u = (r["username"] or "").strip().replace('@', '')
                uid = (r["uid"] or "").strip()
                if uid or u:
                    pair = (u, uid)
                    if pair not in items_to_sync:
                        items_to_sync.append(pair)

        conn.close()

    if limit and limit > 0:
        items_to_sync = items_to_sync[:limit]

    _sync_status = {
        "running": True,
        "total": len(items_to_sync),
        "processed": 0,
        "success": 0,
        "failed": 0,
        "current": "",
        "error": None
    }

    try:
        for (u, uid) in items_to_sync:
            _sync_status["current"] = u or f"ID:{uid}"
            
            # Verificar se já estava em cache antes de disparar requisição
            already_cached = False
            if uid and get_cached_avatar_url(str(uid), target_id):
                already_cached = True
            elif u and get_cached_avatar_url(str(u), target_id):
                already_cached = True

            res = fetch_and_cache_avatar(username=u, user_id=uid, target_id=target_id)
            _sync_status["processed"] += 1
            if res:
                _sync_status["success"] += 1
            else:
                _sync_status["failed"] += 1

            # Aplica o delay solicitado de 1.2s apenas se realizou busca na rede
            if not already_cached:
                time.sleep(1.2)
    except Exception as e:
        _sync_status["error"] = str(e)
    finally:
        _sync_status["running"] = False
        _sync_status["current"] = ""

import json
import os
import re
import ipaddress
import urllib.request
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Any, List, Optional, Tuple
from backend.database import get_db_connection

class IpService:
    @classmethod
    def init_cache_table(cls):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ip_lookups_cache (
                ip_address TEXT PRIMARY KEY,
                isp TEXT,
                org TEXT,
                asn TEXT,
                asname TEXT,
                city TEXT,
                district TEXT,
                region TEXT,
                country TEXT,
                country_code TEXT,
                zip TEXT,
                timezone TEXT,
                lat REAL,
                lon REAL,
                is_brazil INTEGER DEFAULT 1,
                is_mobile INTEGER DEFAULT 0,
                is_proxy INTEGER DEFAULT 0,
                is_hosting INTEGER DEFAULT 0,
                whois_url TEXT,
                raw_data TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Migração dinâmica de colunas para bancos existentes
        cursor.execute("PRAGMA table_info(ip_lookups_cache)")
        existing_cols = {row["name"] for row in cursor.fetchall()}
        new_cols = {
            "asname": "TEXT",
            "district": "TEXT",
            "zip": "TEXT",
            "timezone": "TEXT",
            "is_mobile": "INTEGER DEFAULT 0",
            "is_proxy": "INTEGER DEFAULT 0",
            "is_hosting": "INTEGER DEFAULT 0"
        }
        for col_name, col_def in new_cols.items():
            if col_name not in existing_cols:
                try:
                    cursor.execute(f"ALTER TABLE ip_lookups_cache ADD COLUMN {col_name} {col_def}")
                except Exception:
                    pass

        # Sanitizar e normalizar registros legados na tabela de cache (remover portas e normalizar IPv6 para formato canônico)
        cursor.execute("SELECT ip_address FROM ip_lookups_cache")
        dirty_rows = cursor.fetchall()
        for r in dirty_rows:
            old_ip = r["ip_address"]
            clean_ip, _ = cls.extract_ip_and_port(old_ip)
            if clean_ip and clean_ip != old_ip:
                try:
                    cursor.execute("""
                        UPDATE OR IGNORE ip_lookups_cache
                        SET ip_address = ?
                        WHERE ip_address = ?
                    """, (clean_ip, old_ip))
                    cursor.execute("DELETE FROM ip_lookups_cache WHERE ip_address = ?", (old_ip,))
                except Exception:
                    pass

        conn.commit()
        conn.close()

    @staticmethod
    def extract_ip_and_port(raw_ip: str) -> Tuple[str, Optional[int]]:
        """
        Sanitiza e normaliza o IP separando o endereço puro da porta lógica.
        Normaliza IPv6 para o formato canônico compatível com o Whois e a API ip-api.com.
        Exemplos:
          '[2804:8e40:1140:0000:9993:8c36:efc6:6035]:52080' -> ('2804:8e40:1140::9993:8c36:efc6:6035', 52080)
          '45.71.93.189:45623' -> ('45.71.93.189', 45623)
          '179.151.168.90:0' -> ('179.151.168.90', 0)
          '2804:0018:1133:0327:a1ed:0efb:e320:8064' -> ('2804:18:1133:327:a1ed:efb:e320:8064', None)
        """
        if not raw_ip:
            return "", None
        raw_ip = str(raw_ip).strip()

        # 1. IPv6 entre colchetes com ou sem porta: [2804:...]:52080 ou [2a01:...]
        m_v6 = re.match(r'^\[([a-fA-F0-9:]+)\](?::(\d+))?$', raw_ip)
        if m_v6:
            clean_ip = m_v6.group(1).strip()
            port = int(m_v6.group(2)) if m_v6.group(2) else None
            try:
                clean_ip = ipaddress.ip_address(clean_ip).compressed
            except Exception:
                pass
            return clean_ip, port

        # 2. IPv4 com ou sem porta: 45.71.93.189:45623 ou 179.151.168.90
        m_v4 = re.match(r'^(\d{1,3}(?:\.\d{1,3}){3})(?::(\d+))?$', raw_ip)
        if m_v4:
            clean_ip = m_v4.group(1).strip()
            port = int(m_v4.group(2)) if m_v4.group(2) else None
            return clean_ip, port

        # 3. IPv6 direto sem colchetes: 2804:0018:1133:0327:a1ed:0efb:e320:8064
        clean_ip = raw_ip.strip('[]').strip()
        try:
            clean_ip = ipaddress.ip_address(clean_ip).compressed
        except Exception:
            pass
        return clean_ip, None

    @classmethod
    def is_brazilian_ip(cls, ip: str, country_code: str = "") -> bool:
        if country_code:
            return country_code.upper() == "BR"
        return True

    @classmethod
    def get_whois_url(cls, ip: str, is_br: bool = True) -> str:
        clean_ip, _ = cls.extract_ip_and_port(ip)
        if is_br:
            return f"https://registro.br/tecnologia/ferramentas/whois/?search={urllib.parse.quote(clean_ip)}"
        return f"https://whois.arin.net/ui/query.do?q={urllib.parse.quote(clean_ip)}"

    @classmethod
    def lookup_ip_from_cache(cls, ip: str) -> Optional[Dict[str, Any]]:
        clean_ip, _ = cls.extract_ip_and_port(ip)
        cls.init_cache_table()
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM ip_lookups_cache WHERE ip_address = ?", (clean_ip,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    @classmethod
    def save_to_cache(cls, data: Dict[str, Any]):
        cls.init_cache_table()
        clean_ip, _ = cls.extract_ip_and_port(data["ip_address"])
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO ip_lookups_cache (
                ip_address, isp, org, asn, asname, city, district, region, country, country_code,
                zip, timezone, lat, lon, is_brazil, is_mobile, is_proxy, is_hosting,
                whois_url, raw_data, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(ip_address) DO UPDATE SET
                isp = excluded.isp,
                org = excluded.org,
                asn = excluded.asn,
                asname = excluded.asname,
                city = excluded.city,
                district = excluded.district,
                region = excluded.region,
                country = excluded.country,
                country_code = excluded.country_code,
                zip = excluded.zip,
                timezone = excluded.timezone,
                lat = excluded.lat,
                lon = excluded.lon,
                is_brazil = excluded.is_brazil,
                is_mobile = excluded.is_mobile,
                is_proxy = excluded.is_proxy,
                is_hosting = excluded.is_hosting,
                whois_url = excluded.whois_url,
                raw_data = excluded.raw_data,
                updated_at = CURRENT_TIMESTAMP
        """, (
            clean_ip,
            data.get("isp", ""),
            data.get("org", ""),
            data.get("asn", ""),
            data.get("asname", ""),
            data.get("city", ""),
            data.get("district", ""),
            data.get("region", ""),
            data.get("country", ""),
            data.get("country_code", "BR"),
            data.get("zip", ""),
            data.get("timezone", ""),
            data.get("lat", 0.0),
            data.get("lon", 0.0),
            data.get("is_brazil", 1),
            data.get("is_mobile", 0),
            data.get("is_proxy", 0),
            data.get("is_hosting", 0),
            data.get("whois_url", ""),
            data.get("raw_data", "")
        ))
        conn.commit()
        conn.close()

    @classmethod
    def fetch_batch_from_api(cls, clean_ips: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Consulta em lote usando o endpoint oficial POST http://ip-api.com/batch (até 100 IPs por chamada).
        Obtém informações enriquecidas: mobile, proxy, hosting, ASN, asname, geolocalização e timezone.
        """
        if not clean_ips:
            return {}

        results = {}
        valid_query_ips = []

        for ip in clean_ips:
            if not ip or ip.startswith("127.") or ip.startswith("192.168.") or ip.startswith("10.") or ip == "::1":
                local_res = {
                    "ip_address": ip,
                    "clean_ip": ip,
                    "isp": "Rede Local / Privada",
                    "org": "Local",
                    "asn": "---",
                    "asname": "LOCAL",
                    "city": "Rede Local",
                    "district": "",
                    "region": "---",
                    "country": "Brasil",
                    "country_code": "BR",
                    "zip": "",
                    "timezone": "America/Sao_Paulo",
                    "lat": -14.235,
                    "lon": -51.925,
                    "is_brazil": 1,
                    "is_mobile": 0,
                    "is_proxy": 0,
                    "is_hosting": 0,
                    "whois_url": cls.get_whois_url(ip, True),
                    "raw_data": "{}"
                }
                cls.save_to_cache(local_res)
                results[ip] = local_res
            else:
                valid_query_ips.append(ip)

        if not valid_query_ips:
            return results

        url = "http://ip-api.com/batch?fields=status,message,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,isp,org,as,asname,mobile,proxy,hosting,query"
        try:
            req_data = json.dumps(valid_query_ips).encode("utf-8")
            req = urllib.request.Request(
                url,
                data=req_data,
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": "MetaAnalise/1.0 (Polícia Judiciária; Perícia Forense)"
                }
            )
            with urllib.request.urlopen(req, timeout=5.0) as response:
                data_list = json.loads(response.read().decode("utf-8"))

            for item in data_list:
                raw_item_query = item.get("query", "").strip()
                if not raw_item_query:
                    continue
                try:
                    ip = ipaddress.ip_address(raw_item_query).compressed
                except Exception:
                    ip = raw_item_query

                if item.get("status") == "success":
                    asn_raw = item.get("as", "")
                    asn_match = re.search(r'(AS\d+)', asn_raw)
                    asn = asn_match.group(1) if asn_match else asn_raw

                    country_code = item.get("countryCode", "BR")
                    is_br = (country_code.upper() == "BR")

                    isp = item.get("isp", "") or item.get("org", "Provedor Não Identificado")
                    org = item.get("org", "")
                    asname = item.get("asname", "")
                    city = item.get("city", "") or "Não identificada"
                    district = item.get("district", "")
                    region = item.get("regionName", "") or item.get("region", "")
                    country = item.get("country", "Brasil")
                    zip_code = item.get("zip", "")
                    timezone = item.get("timezone", "")

                    is_mobile = 1 if item.get("mobile") else 0
                    is_proxy = 1 if item.get("proxy") else 0
                    is_hosting = 1 if item.get("hosting") else 0

                    res_dict = {
                        "ip_address": ip,
                        "clean_ip": ip,
                        "isp": isp,
                        "org": org,
                        "asn": asn or "---",
                        "asname": asname or "---",
                        "city": city,
                        "district": district,
                        "region": region,
                        "country": country,
                        "country_code": country_code,
                        "zip": zip_code,
                        "timezone": timezone,
                        "lat": float(item.get("lat", 0.0)),
                        "lon": float(item.get("lon", 0.0)),
                        "is_brazil": 1 if is_br else 0,
                        "is_mobile": is_mobile,
                        "is_proxy": is_proxy,
                        "is_hosting": is_hosting,
                        "whois_url": cls.get_whois_url(ip, is_br),
                        "raw_data": json.dumps(item)
                    }
                    cls.save_to_cache(res_dict)
                    results[ip] = res_dict
                else:
                    # Falha de IP ou IP reservado/inválido
                    fallback_dict = {
                        "ip_address": ip,
                        "clean_ip": ip,
                        "isp": "Consulta Pendente / Não Identificado",
                        "org": "---",
                        "asn": "---",
                        "asname": "---",
                        "city": "Não Identificada",
                        "district": "",
                        "region": "---",
                        "country": "Brasil",
                        "country_code": "BR",
                        "zip": "",
                        "timezone": "",
                        "lat": -12.9777,
                        "lon": -38.5016,
                        "is_brazil": 1,
                        "is_mobile": 0,
                        "is_proxy": 0,
                        "is_hosting": 0,
                        "whois_url": cls.get_whois_url(ip, True),
                        "raw_data": json.dumps(item)
                    }
                    results[ip] = fallback_dict
        except Exception as e:
            print(f"[IpService] Erro ao consultar lote de IPs: {e}")
            for ip in valid_query_ips:
                if ip not in results:
                    results[ip] = {
                        "ip_address": ip,
                        "clean_ip": ip,
                        "isp": "Consulta Pendente / Não Identificado",
                        "org": "---",
                        "asn": "---",
                        "asname": "---",
                        "city": "Não Identificada",
                        "district": "",
                        "region": "---",
                        "country": "Brasil",
                        "country_code": "BR",
                        "zip": "",
                        "timezone": "",
                        "lat": -12.9777,
                        "lon": -38.5016,
                        "is_brazil": 1,
                        "is_mobile": 0,
                        "is_proxy": 0,
                        "is_hosting": 0,
                        "whois_url": cls.get_whois_url(ip, True),
                        "raw_data": "{}"
                    }

        return results

    @classmethod
    def enrich_ip(cls, ip: str, force_refresh: bool = False) -> Dict[str, Any]:
        clean_ip, _ = cls.extract_ip_and_port(ip)
        if not clean_ip:
            return {}

        if not force_refresh:
            cached = cls.lookup_ip_from_cache(clean_ip)
            if cached and cached.get("isp") and cached.get("isp") != "Consulta Pendente / Não Identificado":
                return cached

        batch_res = cls.fetch_batch_from_api([clean_ip])
        return batch_res.get(clean_ip, {})

    @classmethod
    def batch_enrich_ips(cls, ip_list: List[str], force_refresh: bool = False) -> Dict[str, Dict[str, Any]]:
        """
        Enriquece uma lista de IPs usando cache local primeiro (em consulta SQL única) e resolvendo os faltantes em lote (batch).
        """
        clean_set = set()
        for raw in ip_list:
            clean, _ = cls.extract_ip_and_port(raw)
            if clean:
                clean_set.add(clean)

        unique_clean_ips = list(clean_set)
        if not unique_clean_ips:
            return {}

        results = {}
        cls.init_cache_table()
        conn = get_db_connection()
        cursor = conn.cursor()

        if not force_refresh:
            placeholders = ",".join(["?"] * len(unique_clean_ips))
            cursor.execute(f"SELECT * FROM ip_lookups_cache WHERE ip_address IN ({placeholders})", unique_clean_ips)
            for r in cursor.fetchall():
                results[r["ip_address"]] = dict(r)

        conn.close()

        if force_refresh:
            missing_clean_ips = unique_clean_ips
        else:
            missing_clean_ips = [ip for ip in unique_clean_ips if ip not in results]

        if missing_clean_ips:
            chunk_size = 100
            for i in range(0, len(missing_clean_ips), chunk_size):
                chunk = missing_clean_ips[i:i + chunk_size]
                batch_res = cls.fetch_batch_from_api(chunk)
                for clean_ip, data in batch_res.items():
                    results[clean_ip] = data

        return results

    @classmethod
    def get_ip_intelligence(
        cls,
        operation_id: int,
        phase_id: Optional[int] = None,
        target_id: Optional[int] = None,
        account_uid: Optional[str] = None
    ) -> Dict[str, Any]:
        cls.init_cache_table()
        conn = get_db_connection()
        cursor = conn.cursor()

        where = "WHERE t.operation_id = ?"
        params = [operation_id]
        if target_id:
            where += " AND c.target_id = ?"
            params.append(target_id)
        if phase_id:
            where += " AND c.phase_id = ?"
            params.append(phase_id)
        if account_uid:
            where += " AND (c.target_uid = ? OR c.target_uid IS NULL)"
            params.append(account_uid)

        cursor.execute(f"""
            SELECT c.id, c.target_id, c.ip_address, c.timestamp_utc, c.timestamp_brt
            FROM instagram_connections c
            JOIN targets t ON c.target_id = t.id
            {where}
            ORDER BY c.timestamp_utc DESC
        """, params)

        raw_conns = [dict(r) for r in cursor.fetchall()]

        reg_ip = None
        reg_date_brt = None
        if target_id:
            if account_uid:
                cursor.execute("SELECT registration_ip, registration_date_brt FROM instagram_targets WHERE target_id = ? AND target_uid = ?", (target_id, account_uid))
            else:
                cursor.execute("SELECT registration_ip, registration_date_brt FROM instagram_targets WHERE target_id = ? ORDER BY id ASC LIMIT 1", (target_id,))
            t_row = cursor.fetchone()
            if t_row:
                reg_ip = t_row["registration_ip"]
                reg_date_brt = t_row["registration_date_brt"]

        conn.close()

        clean_reg_ip, _ = cls.extract_ip_and_port(reg_ip or "")

        if not raw_conns:
            return {
                "stats": {
                    "total_connections": 0,
                    "unique_ips_count": 0,
                    "mobile_conns_count": 0,
                    "proxy_conns_count": 0,
                    "hosting_conns_count": 0,
                    "top_ip": "---",
                    "top_ip_clean": "---",
                    "top_ip_count": 0,
                    "top_ip_percent": 0,
                    "top_ip_isp": "---",
                    "top_ip_city": "---",
                    "first_activity_brt": "---",
                    "last_activity_brt": "---",
                    "registration_ip": reg_ip or "Não informado",
                    "registration_ip_clean": clean_reg_ip or "",
                    "registration_whois_url": cls.get_whois_url(clean_reg_ip, True) if clean_reg_ip else "",
                    "registration_date_brt": reg_date_brt or "---"
                },
                "ranked_ips": [],
                "geo_points": [],
                "raw_connections": []
            }

        total_count = len(raw_conns)
        clean_ip_counts = {}
        clean_ip_first_seen = {}
        clean_ip_last_seen = {}
        clean_ip_ports = {}

        formatted_conns = []
        for c in raw_conns:
            raw_ip = (c.get("ip_address") or "").strip()
            if not raw_ip:
                continue
            clean_ip, port = cls.extract_ip_and_port(raw_ip)
            if not clean_ip:
                clean_ip = raw_ip

            c_dict = dict(c)
            c_dict["clean_ip"] = clean_ip
            c_dict["port"] = port
            c_dict["display_ip"] = raw_ip
            formatted_conns.append(c_dict)

            clean_ip_counts[clean_ip] = clean_ip_counts.get(clean_ip, 0) + 1
            if port is not None:
                clean_ip_ports.setdefault(clean_ip, set()).add(port)

            t_brt = c.get("timestamp_brt") or c.get("timestamp_utc") or ""
            t_utc = c.get("timestamp_utc") or ""

            if clean_ip not in clean_ip_first_seen or t_utc < clean_ip_first_seen[clean_ip]["utc"]:
                clean_ip_first_seen[clean_ip] = {"utc": t_utc, "brt": t_brt}
            if clean_ip not in clean_ip_last_seen or t_utc > clean_ip_last_seen[clean_ip]["utc"]:
                clean_ip_last_seen[clean_ip] = {"utc": t_utc, "brt": t_brt}

        unique_clean_ips = list(clean_ip_counts.keys())
        cached_info = cls.batch_enrich_ips(unique_clean_ips)

        ranked = []
        total_mobile = 0
        total_proxy = 0
        total_hosting = 0

        for clean_ip, count in sorted(clean_ip_counts.items(), key=lambda x: x[1], reverse=True):
            info = cached_info.get(clean_ip, {})
            percent = round((count / total_count) * 100, 1) if total_count > 0 else 0.0
            is_ipv6 = ":" in clean_ip
            ports_list = sorted(list(clean_ip_ports.get(clean_ip, [])))

            is_mob = bool(info.get("is_mobile", 0))
            is_prx = bool(info.get("is_proxy", 0))
            is_hst = bool(info.get("is_hosting", 0))

            if is_mob: total_mobile += count
            if is_prx: total_proxy += count
            if is_hst: total_hosting += count

            ranked.append({
                "ip_address": clean_ip,
                "clean_ip": clean_ip,
                "ports": ports_list,
                "ports_str": ", ".join(f":{p}" for p in ports_list) if ports_list else "",
                "ip_version": "IPv6" if is_ipv6 else "IPv4",
                "count": count,
                "percent": percent,
                "first_seen_brt": clean_ip_first_seen.get(clean_ip, {}).get("brt", "---"),
                "last_seen_brt": clean_ip_last_seen.get(clean_ip, {}).get("brt", "---"),
                "isp": info.get("isp", "Pendente de consulta"),
                "org": info.get("org", ""),
                "asn": info.get("asn", "---"),
                "asname": info.get("asname", "---"),
                "city": info.get("city", "Não identificada"),
                "district": info.get("district", ""),
                "region": info.get("region", "---"),
                "country": info.get("country", "Brasil"),
                "country_code": info.get("country_code", "BR"),
                "zip": info.get("zip", ""),
                "timezone": info.get("timezone", ""),
                "lat": info.get("lat", 0.0),
                "lon": info.get("lon", 0.0),
                "is_brazil": info.get("is_brazil", 1),
                "is_mobile": info.get("is_mobile", 0),
                "is_proxy": info.get("is_proxy", 0),
                "is_hosting": info.get("is_hosting", 0),
                "whois_url": info.get("whois_url") or cls.get_whois_url(clean_ip, True)
            })

        city_groups = {}
        for r in ranked:
            lat = r.get("lat")
            lon = r.get("lon")
            city = r.get("city")
            if lat and lon and lat != 0.0 and lon != 0.0:
                geo_key = f"{round(lat, 2)}_{round(lon, 2)}"
                if geo_key not in city_groups:
                    city_groups[geo_key] = {
                        "city": city,
                        "region": r.get("region"),
                        "country": r.get("country"),
                        "lat": lat,
                        "lon": lon,
                        "total_count": 0,
                        "top_isp": r.get("isp"),
                        "ips": []
                    }
                city_groups[geo_key]["total_count"] += r["count"]
                city_groups[geo_key]["ips"].append({
                    "ip": r["clean_ip"],
                    "count": r["count"],
                    "isp": r.get("isp"),
                    "is_mobile": r.get("is_mobile", 0),
                    "is_proxy": r.get("is_proxy", 0)
                })

        geo_points = list(city_groups.values())
        geo_points.sort(key=lambda x: x["total_count"], reverse=True)

        top_item = ranked[0] if ranked else {}
        first_global = min([c.get("timestamp_brt") for c in raw_conns if c.get("timestamp_brt")], default="---")
        last_global = max([c.get("timestamp_brt") for c in raw_conns if c.get("timestamp_brt")], default="---")

        return {
            "stats": {
                "total_connections": total_count,
                "unique_ips_count": len(unique_clean_ips),
                "mobile_conns_count": total_mobile,
                "proxy_conns_count": total_proxy,
                "hosting_conns_count": total_hosting,
                "top_ip": top_item.get("clean_ip", "---"),
                "top_ip_clean": top_item.get("clean_ip", "---"),
                "top_ip_count": top_item.get("count", 0),
                "top_ip_percent": top_item.get("percent", 0),
                "top_ip_isp": top_item.get("isp", "---"),
                "top_ip_city": top_item.get("city", "---"),
                "first_activity_brt": first_global,
                "last_activity_brt": last_global,
                "registration_ip": reg_ip or "Não informado",
                "registration_ip_clean": clean_reg_ip or "",
                "registration_whois_url": cls.get_whois_url(clean_reg_ip, True) if clean_reg_ip else "",
                "registration_date_brt": reg_date_brt or "---"
            },
            "ranked_ips": ranked,
            "geo_points": geo_points,
            "raw_connections": formatted_conns[:1000]
        }


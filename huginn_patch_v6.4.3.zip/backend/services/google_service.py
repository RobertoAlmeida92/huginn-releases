import os
import re
import json
import zipfile
import io
import shutil
import hashlib
import mimetypes
from typing import Dict, Any, List, Optional, Tuple
from difflib import SequenceMatcher
import threading

from backend.database import get_db_connection
from backend.config import UPLOAD_DIR, MEDIA_BASE_DIR, CUSTODY_DIR
from backend.services.operation_service import OperationService
from backend.services.ip_service import IpService
from backend.parsers.google_parser import GoogleParser

_google_import_lock = threading.Lock()

class GoogleService:
    """
    Serviço central de inteligência para processamento de quebras Google LERS.
    """

    @staticmethod
    def _format_size(size_bytes: int) -> str:
        if not size_bytes or size_bytes <= 0:
            return "0 B"
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if abs(size_bytes) < 1024.0:
                return f"{size_bytes:3.1f} {unit}".replace(".0 ", " ")
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} PB"

    @staticmethod
    def _calculate_sha256(file_path: str) -> str:
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha256.update(chunk)
        return sha256.hexdigest()

    @staticmethod
    def _normalize_phone(phone: Optional[str]) -> str:
        if not phone:
            return ""
        digits = re.sub(r'\D', '', phone)
        # Se for número do Brasil sem 55 no início mas com DDD (10 ou 11 dígitos)
        if len(digits) in (10, 11) and not digits.startswith("55"):
            digits = "55" + digits
        return digits

    @staticmethod
    def scan_google_packages(file_paths: List[str], operation_id: int) -> Dict[str, Any]:
        """
        Varre os ZIPs do Google LERS em segundos e cruza identificadores com a Operação,
        retornando o mapeamento assistido para decisão do analista.
        """
        conn = get_db_connection()
        cursor = conn.cursor()

        # 1. Carregar Alvos Existentes da Operação
        cursor.execute("SELECT id, name_or_alias, main_identifier, phone, email, cpf_cnpj FROM targets WHERE operation_id = ?", (operation_id,))
        existing_targets = [dict(r) for r in cursor.fetchall()]

        # Carregar telefones do WhatsApp já cadastrados
        cursor.execute("""
            SELECT wt.target_id, wt.phone_number, t.name_or_alias 
            FROM whatsapp_targets wt
            JOIN targets t ON t.id = wt.target_id
            WHERE t.operation_id = ?
        """, (operation_id,))
        wa_target_phones = cursor.fetchall()

        # Carregar e-mails do Instagram já cadastrados
        cursor.execute("""
            SELECT it.target_id, it.email, it.vanity_name, t.name_or_alias 
            FROM instagram_targets it
            JOIN targets t ON t.id = it.target_id
            WHERE t.operation_id = ? AND it.email IS NOT NULL AND it.email != ''
        """, (operation_id,))
        ig_target_emails = cursor.fetchall()

        conn.close()

        # Mapear telefones conhecidos: normalized_phone -> (target_id, target_name, source)
        known_phones = {}
        for t in existing_targets:
            if t.get("phone"):
                norm = GoogleService._normalize_phone(t["phone"])
                if norm:
                    known_phones[norm] = (t["id"], t["name_or_alias"], "Cadastro Geral")
        for r in wa_target_phones:
            norm = GoogleService._normalize_phone(r["phone_number"])
            if norm:
                known_phones[norm] = (r["target_id"], r["name_or_alias"], "WhatsApp")

        # Mapear e-mails conhecidos: email.lower() -> (target_id, target_name, source)
        known_emails = {}
        for t in existing_targets:
            if t.get("email"):
                known_emails[t["email"].strip().lower()] = (t["id"], t["name_or_alias"], "Cadastro Geral")
        for r in ig_target_emails:
            e = r["email"].strip().lower()
            if e:
                known_emails[e] = (r["target_id"], r["name_or_alias"], f"Instagram (@{r['vanity_name']})")

        # 2. Varrer os arquivos ZIP fornecidos
        accounts_map = {}

        for zpath in file_paths:
            if not os.path.exists(zpath) or not zpath.endswith('.zip'):
                continue
            
            try:
                with zipfile.ZipFile(zpath, 'r') as root_z:
                    names = root_z.namelist()
                    for item in names:
                        parts = item.split('@')
                        if len(parts) < 2:
                            continue
                        prefix = parts[0]
                        domain_rest = parts[1].split('.')
                        domain = domain_rest[0]
                        tld = domain_rest[1] if len(domain_rest) > 1 else 'com'
                        email_clean = f"{prefix}@{domain}.{tld}".lower()

                        if email_clean not in accounts_map:
                            accounts_map[email_clean] = {
                                "email": email_clean,
                                "full_name": "",
                                "recovery_sms": "",
                                "recovery_email": "",
                                "total_files": 0,
                                "total_size_mb": 0.0,
                                "services": set(),
                                "subscriber_info_zip": None,
                                "subscriber_info_path": None,
                                "waze_activity_zip": None,
                                "waze_account_zip": None,
                                "root_zips": set()
                            }

                        acc = accounts_map[email_clean]
                        acc["total_files"] += 1
                        acc["total_size_mb"] += root_z.getinfo(item).file_size / (1024**2)
                        acc["root_zips"].add(zpath)

                        item_l = item.lower()
                        if "subscriberinfo" in item_l and not acc["subscriber_info_zip"]:
                            acc["subscriber_info_zip"] = (zpath, item)
                            acc["services"].add("Dossiê Cadastral")
                        elif "deviceanduserprofile" in item_l:
                            acc["services"].add("Dispositivos Android")
                        elif "mail.messages" in item_l:
                            acc["services"].add("Gmail (Mensagens MBOX)")
                        elif "googlephotos" in item_l:
                            acc["services"].add("Google Fotos")
                        elif "aliasedplaces" in item_l:
                            acc["services"].add("Google Maps")
                        elif "waze" in item_l:
                            acc["services"].add("Waze")
                            if "wazeactivity" in item_l:
                                acc["waze_activity_zip"] = (zpath, item)
                            elif "wazeaccount" in item_l:
                                acc["waze_account_zip"] = (zpath, item)
                        elif "accesslogactivity" in item_l:
                            acc["services"].add("Logs de Conexão & IPs")
                        elif "chrome" in item_l:
                            acc["services"].add("Google Chrome (Navegação)")
                        elif "myactivity" in item_l:
                            acc["services"].add("Minha Atividade (Pesquisas & Voz)")
                        elif ".drive." in item_l:
                            acc["services"].add("Google Drive (Arquivos)")
                        elif "timeline" in item_l:
                            acc["services"].add("Linha do Tempo (Deslocamento)")
                        elif "googlepay" in item_l:
                            acc["services"].add("Google Pay (Financeiro)")
                        elif "googlechat" in item_l:
                            acc["services"].add("Google Chat (Mensagens)")
                        elif "calendar" in item_l:
                            acc["services"].add("Google Calendar (Agenda)")
                        elif "contact" in item_l:
                            acc["services"].add("Contatos Telefônicos")
            except Exception as ex:
                print(f"[GoogleService] Erro ao escanear {zpath}: {ex}")

        # 3. Extrair dados cadastrais básicos de cada conta encontrada
        for email_clean, acc in accounts_map.items():
            if acc["subscriber_info_zip"]:
                zpath, sub_name = acc["subscriber_info_zip"]
                try:
                    with zipfile.ZipFile(zpath, 'r') as root_z:
                        b = root_z.read(sub_name)
                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                            html_files = [f for f in sub_z.namelist() if f.endswith('.html')]
                            if html_files:
                                html = sub_z.read(html_files[0]).decode('utf-8', errors='replace')
                                sub_data = GoogleParser.parse_subscriber_info(html)
                                acc["full_name"] = sub_data["full_name"]
                                acc["recovery_sms"] = sub_data["recovery_sms"]
                                acc["recovery_email"] = sub_data["recovery_email"]
                except Exception as ex:
                    print(f"[GoogleService] Erro ao extrair SubscriberInfo de {email_clean}: {ex}")

            # Se ainda não tiver nome, tentar pelo Waze
            if not acc["full_name"] and acc["waze_account_zip"]:
                zpath, w_name = acc["waze_account_zip"]
                try:
                    with zipfile.ZipFile(zpath, 'r') as root_z:
                        content = root_z.read(w_name).decode('utf-8', errors='replace')
                        for line in content.splitlines():
                            if line.lower().startswith("full name,"):
                                acc["full_name"] = line.split(",", 1)[1].strip()
                except Exception:
                    pass

        # 4. Motor de Correlação Forense (Verde, Amarelo ou Cinza)
        analyzed_accounts = []
        for email_clean, acc in sorted(accounts_map.items()):
            full_name = acc["full_name"] or email_clean.split('@')[0]
            rec_sms = acc["recovery_sms"]
            norm_sms = GoogleService._normalize_phone(rec_sms)
            rec_email = acc["recovery_email"].strip().lower()

            confidence = "none" # 'high', 'medium', 'none'
            action = "create"   # 'link' ou 'create'
            target_id = None
            evidence_reason = "Nenhum vínculo prévio localizado na operação."
            matched_target_name = ""

            # REGRA 1 (ALTA CERTEZA - TELEFONE DE RECUPERAÇÃO):
            if norm_sms and norm_sms in known_phones:
                t_id, t_name, src = known_phones[norm_sms]
                confidence = "high"
                action = "link"
                target_id = t_id
                matched_target_name = t_name
                evidence_reason = f"Telefone de recuperação ({rec_sms}) é IDÊNTICO ao telefone de {t_name} [{src}]."

            # REGRA 2 (ALTA CERTEZA - E-MAIL COINCIDENTE):
            elif email_clean in known_emails:
                t_id, t_name, src = known_emails[email_clean]
                confidence = "high"
                action = "link"
                target_id = t_id
                matched_target_name = t_name
                evidence_reason = f"E-mail da conta bate 100% com o e-mail de {t_name} [{src}]."

            # REGRA 3 (ALTA CERTEZA - E-MAIL DE RECUPERAÇÃO COINCIDENTE):
            elif rec_email and rec_email in known_emails:
                t_id, t_name, src = known_emails[rec_email]
                confidence = "high"
                action = "link"
                target_id = t_id
                matched_target_name = t_name
                evidence_reason = f"E-mail de recuperação ({rec_email}) bate com o cadastro de {t_name} [{src}]."

            # REGRA 4 (MÉDIA CERTEZA - SIMILARIDADE DE NOME CIVIL):
            elif full_name and len(full_name) > 5:
                best_ratio = 0.0
                best_t = None
                for t in existing_targets:
                    ratio = SequenceMatcher(None, full_name.lower(), t["name_or_alias"].lower()).ratio()
                    if ratio > best_ratio:
                        best_ratio = ratio
                        best_t = t
                if best_ratio >= 0.82 and best_t:
                    confidence = "medium"
                    action = "link"
                    target_id = best_t["id"]
                    matched_target_name = best_t["name_or_alias"]
                    evidence_reason = f"Alta similaridade fonética no nome ({int(best_ratio*100)}%): '{full_name}' vs '{best_t['name_or_alias']}'."

            analyzed_accounts.append({
                "email": email_clean,
                "full_name": full_name,
                "recovery_sms": rec_sms,
                "recovery_email": rec_email,
                "total_size_mb": round(acc["total_size_mb"], 2),
                "services": sorted(list(acc["services"])),
                "confidence": confidence,
                "suggested_action": action,
                "suggested_target_id": target_id,
                "matched_target_name": matched_target_name,
                "evidence_reason": evidence_reason,
                "root_zips": list(acc["root_zips"])
            })

        return {
            "operation_id": operation_id,
            "total_accounts_found": len(analyzed_accounts),
            "accounts": analyzed_accounts,
            "existing_targets": existing_targets
        }

    @staticmethod
    def import_google_packages(
        file_paths: List[str],
        operation_id: int,
        phase_id: int,
        mapping: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Executa a importação completa das contas selecionadas, gravando em banco
        de dados relacional e gerando cadeia de custódia com commit atômico por conta.
        """
        if not _google_import_lock.acquire(blocking=False):
            raise RuntimeError("Uma importação do Google LERS já está em andamento. Aguarde a conclusão da tarefa atual antes de iniciar outra.")

        try:
            # 1. Pré-calcular hashes e metadados dos arquivos raiz UMA ÚNICA VEZ (otimização massiva de I/O)
            file_custody_cache = {}
            for zpath in file_paths:
                if os.path.exists(zpath):
                    file_custody_cache[zpath] = {
                        "sha256": GoogleService._calculate_sha256(zpath),
                        "size": os.path.getsize(zpath),
                        "name": os.path.basename(zpath)
                    }

            conn = get_db_connection()
            try:
                cursor = conn.cursor()
                imported_targets_count = 0
                total_emails_count = 0
                total_devices_count = 0
                total_locations_count = 0
                total_ips_count = 0
                total_photos_count = 0
                total_chrome_history_count = 0
                total_activities_count = 0
                total_drive_files_count = 0
                total_timeline_settings_count = 0

                # Validar ou resolver phase_id da operação
                if phase_id:
                    cursor.execute("SELECT id FROM phases WHERE id = ? AND operation_id = ?", (phase_id, operation_id))
                    if not cursor.fetchone():
                        phase_id = None
                if not phase_id:
                    cursor.execute("SELECT id FROM phases WHERE operation_id = ? ORDER BY id ASC LIMIT 1", (operation_id,))
                    p_row = cursor.fetchone()
                    if p_row:
                        phase_id = p_row[0]
                    else:
                        cursor.execute("INSERT INTO phases (operation_id, name) VALUES (?, 'Fase 1 - Preservação e Quebra')", (operation_id,))
                        phase_id = cursor.lastrowid
                conn.commit()

                # Iterar sobre as contas aprovadas no mapping
                for email_clean, map_info in mapping.items():
                    action = map_info.get("action", "create")
                    target_id = map_info.get("target_id")
                    target_name = map_info.get("full_name") or email_clean.split('@')[0]

                    if action == "create" or not target_id:
                        # Criar novo alvo na operação
                        cursor.execute("""
                            INSERT INTO targets (operation_id, name_or_alias, main_identifier, platform, email, phone, notes)
                            VALUES (?, ?, ?, 'google', ?, ?, 'Alvo importado via Google LERS')
                        """, (operation_id, target_name, email_clean, email_clean, map_info.get("recovery_sms", "")))
                        target_id = cursor.lastrowid

                        # Vincular à fase
                        cursor.execute("INSERT OR IGNORE INTO phase_targets (phase_id, target_id) VALUES (?, ?)", (phase_id, target_id))
                    else:
                        target_id = int(target_id)
                        # Garantir vínculo à fase
                        cursor.execute("INSERT OR IGNORE INTO phase_targets (phase_id, target_id) VALUES (?, ?)", (phase_id, target_id))

                    imported_targets_count += 1

                    # Registrar arquivos de custódia vinculados ao alvo usando cache pré-calculado
                    for zpath, cinfo in file_custody_cache.items():
                        cursor.execute("SELECT id FROM custody_files WHERE target_id = ? AND sha256_hash = ?", (target_id, cinfo["sha256"]))
                        if not cursor.fetchone():
                            cursor.execute("""
                                INSERT INTO custody_files (operation_id, phase_id, target_id, platform, file_name, file_path, file_size, sha256_hash)
                                VALUES (?, ?, ?, 'google', ?, ?, ?, ?)
                            """, (operation_id, phase_id, target_id, cinfo["name"], zpath, cinfo["size"], cinfo["sha256"]))

                    # Criar pasta de mídias do alvo
                    target_media_dir = os.path.join(MEDIA_BASE_DIR, f"target_{target_id}", "google")
                    os.makedirs(target_media_dir, exist_ok=True)

                    google_target_id = None
                    subscriber_data = None

                    # Processar sub-zips pertencentes a este e-mail nos arquivos raiz
                    for zpath in file_paths:
                        if not os.path.exists(zpath):
                            continue
                        try:
                            with zipfile.ZipFile(zpath, 'r') as root_z:
                                sub_names = [n for n in root_z.namelist() if n.lower().startswith(f"{email_clean}.")]

                                # 1. Primeiro Passo: SubscriberInfo (Criação do google_target)
                                sub_info_files = [n for n in sub_names if "subscriberinfo" in n.lower()]
                                if sub_info_files and not google_target_id:
                                    b = root_z.read(sub_info_files[0])
                                    with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                        html_f = [f for f in sub_z.namelist() if f.endswith('.html')]
                                        if html_f:
                                            html = sub_z.read(html_f[0]).decode('utf-8', errors='replace')
                                            subscriber_data = GoogleParser.parse_subscriber_info(html)

                                            cursor.execute("""
                                                INSERT INTO google_targets (
                                                    operation_id, phase_id, target_id, google_account_id, email,
                                                    full_name, given_name, family_name, created_at_utc, created_at_brt,
                                                    terms_ip, terms_language, terms_country, provider, birthday,
                                                    services_list, status, last_updated_utc, last_logins,
                                                    contact_email, recovery_email, recovery_sms, raw_metadata
                                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                            """, (
                                                operation_id, phase_id, target_id,
                                                subscriber_data.get("google_account_id", ""),
                                                email_clean,
                                                subscriber_data.get("full_name") or target_name,
                                                subscriber_data.get("given_name", ""),
                                                subscriber_data.get("family_name", ""),
                                                subscriber_data.get("created_at_utc", ""),
                                                subscriber_data.get("created_at_brt", ""),
                                                subscriber_data.get("terms_ip", ""),
                                                subscriber_data.get("terms_language", ""),
                                                subscriber_data.get("terms_country", ""),
                                                subscriber_data.get("provider", ""),
                                                subscriber_data.get("birthday", ""),
                                                subscriber_data.get("services_list", ""),
                                                subscriber_data.get("status", ""),
                                                subscriber_data.get("last_updated_utc", ""),
                                                subscriber_data.get("last_logins", ""),
                                                subscriber_data.get("contact_email", ""),
                                                subscriber_data.get("recovery_email", ""),
                                                subscriber_data.get("recovery_sms", ""),
                                                json.dumps(subscriber_data)
                                            ))
                                            google_target_id = cursor.lastrowid

                                            # Gravar logins do SubscriberInfo na tabela de IP logs
                                            for log in subscriber_data.get("login_history", []):
                                                clean_ip = IpService.clean_ip(log["ip_address"]) if hasattr(IpService, 'clean_ip') else log["ip_address"]
                                                cursor.execute("""
                                                    INSERT INTO google_ip_logs (
                                                        operation_id, phase_id, target_id, google_target_id,
                                                        timestamp_utc, timestamp_brt, ip_address, clean_ip,
                                                        event_type, android_id, user_agent
                                                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                """, (
                                                    operation_id, phase_id, target_id, google_target_id,
                                                    log["timestamp_utc"], log["timestamp_brt"],
                                                    log["ip_address"], clean_ip,
                                                    log["event_type"], log.get("android_id", ""),
                                                    log.get("user_agent", "")
                                                ))
                                                total_ips_count += 1

                                # Se não tinha SubscriberInfo, criar registro base para google_targets
                                if not google_target_id:
                                    cursor.execute("""
                                        INSERT INTO google_targets (
                                            operation_id, phase_id, target_id, google_account_id, email,
                                            full_name, status
                                        ) VALUES (?, ?, ?, ?, ?, ?, 'Imported')
                                    """, (operation_id, phase_id, target_id, email_clean, email_clean, target_name))
                                    google_target_id = cursor.lastrowid

                                # 2. Segundo Passo: Dispositivos Android
                                for dev_name in [n for n in sub_names if "deviceanduserprofile" in n.lower()]:
                                    try:
                                        b = root_z.read(dev_name)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            html_f = [f for f in sub_z.namelist() if f.endswith('.html')]
                                            if html_f:
                                                html = sub_z.read(html_f[0]).decode('utf-8', errors='replace')
                                                # Pegar Android ID a partir do nome do arquivo
                                                # Ex: email.4328179570309243043.Android...
                                                m_aid = re.search(r'\.([0-9]{10,25})\.', dev_name)
                                                f_aid = m_aid.group(1) if m_aid else ""
                                                dev_list = GoogleParser.parse_device_profile(html, f_aid)
                                                for d in dev_list:
                                                    cursor.execute("""
                                                        INSERT INTO google_devices (
                                                            operation_id, phase_id, target_id, google_target_id,
                                                            android_id, brand, model, product, build_fingerprint,
                                                            radio_firmware, bootloader_firmware, play_services_version,
                                                            connection_time_utc, connection_time_brt, http_response_code
                                                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                    """, (
                                                        operation_id, phase_id, target_id, google_target_id,
                                                        d["android_id"], d["brand"], d["model"], d["product"],
                                                        d["build_fingerprint"], d["radio_firmware"],
                                                        d["bootloader_firmware"], d["play_services_version"],
                                                        d["connection_time_utc"], d["connection_time_brt"],
                                                        d["http_response_code"]
                                                    ))
                                                    total_devices_count += 1
                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao importar dispositivo {dev_name}: {ex}")

                                # 2.1 Passo Adicional de Dispositivos: AccessLogActivity (Apple iOS, Androids e Computadores)
                                for act_name in [n for n in sub_names if "accesslogactivity" in n.lower() and "activity" in n.lower()]:
                                    try:
                                        b = root_z.read(act_name)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            csv_f = [f for f in sub_z.namelist() if f.endswith('.csv')]
                                            for cf in csv_f:
                                                csv_text = sub_z.read(cf).decode('utf-8', errors='replace')
                                                act_devices = GoogleParser.parse_access_log_devices(csv_text)
                                                for d in act_devices:
                                                    cursor.execute("""
                                                        INSERT INTO google_devices (
                                                            operation_id, phase_id, target_id, google_target_id,
                                                            android_id, brand, model, product, build_fingerprint,
                                                            radio_firmware, bootloader_firmware, play_services_version,
                                                            connection_time_utc, connection_time_brt, http_response_code
                                                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                    """, (
                                                        operation_id, phase_id, target_id, google_target_id,
                                                        d["android_id"], d["brand"], d["model"], d["product"],
                                                        d["build_fingerprint"], d["radio_firmware"],
                                                        d["bootloader_firmware"], d["play_services_version"],
                                                        d["connection_time_utc"], d["connection_time_brt"],
                                                        d["http_response_code"]
                                                    ))
                                                    total_devices_count += 1
                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao importar AccessLogActivity {act_name}: {ex}")

                                # 3. Terceiro Passo: Geografia & Mobilidade (Maps + Waze)
                                for map_name in [n for n in sub_names if "aliasedplaces" in n.lower()]:
                                    try:
                                        b = root_z.read(map_name)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            json_f = [f for f in sub_z.namelist() if f.endswith('.json')]
                                            if json_f:
                                                js = sub_z.read(json_f[0]).decode('utf-8', errors='replace')
                                                places = GoogleParser.parse_maps_places(js)
                                                for p in places:
                                                    cursor.execute("""
                                                        INSERT INTO google_locations (
                                                            operation_id, phase_id, target_id, google_target_id,
                                                            source, location_type, name, address, latitude, longitude, raw_json
                                                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                    """, (
                                                        operation_id, phase_id, target_id, google_target_id,
                                                        p["source"], p["location_type"], p["name"], p["address"],
                                                        p["latitude"], p["longitude"], p["raw_json"]
                                                    ))
                                                    total_locations_count += 1
                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao importar Maps {map_name}: {ex}")

                                # Waze
                                for waze_name in [n for n in sub_names if "wazeactivity" in n.lower()]:
                                    try:
                                        csv_text = root_z.read(waze_name).decode('utf-8-sig', errors='replace')
                                        w_places = GoogleParser.parse_waze(activity_csv=csv_text)
                                        for p in w_places:
                                            cursor.execute("""
                                                INSERT INTO google_locations (
                                                    operation_id, phase_id, target_id, google_target_id,
                                                    source, location_type, name, address, latitude, longitude, raw_json
                                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                            """, (
                                                operation_id, phase_id, target_id, google_target_id,
                                                p["source"], p["location_type"], p["name"], p["address"],
                                                p["latitude"], p["longitude"], p["raw_json"]
                                            ))
                                            total_locations_count += 1
                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao importar Waze {waze_name}: {ex}")

                                # 4. Quarto Passo: E-mails (MBOX)
                                # Coletar metadados JSON do MessageInformation se houver
                                meta_map = {}
                                for minfo_name in [n for n in sub_names if "mail.messageinformation" in n.lower()]:
                                    try:
                                        b = root_z.read(minfo_name)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            for jf in [f for f in sub_z.namelist() if f.endswith('.json')]:
                                                try:
                                                    j_obj = json.loads(sub_z.read(jf).decode('utf-8', errors='replace'))
                                                    item = j_obj.get("item", {})
                                                    sid = str(item.get("item_key", {}).get("server_id", ""))
                                                    attrs = item.get("attributes", {})
                                                    meta_map[sid] = {
                                                        "server_id": sid,
                                                        "thread_id": str(item.get("thread_key", {}).get("server_id", "")),
                                                        "is_trash": "//label_date/trash" in attrs,
                                                        "is_deleted": "//label_date/deleted" in attrs,
                                                        "is_spam": "//label_date/spam" in attrs,
                                                        "is_opened": "//label_date/opened" in attrs,
                                                        "status_date": attrs.get("//label_date/trash") or attrs.get("//label_date/deleted") or ""
                                                    }
                                                except Exception:
                                                    continue
                                    except Exception:
                                        pass

                                for mbox_name in [n for n in sub_names if "mail.messages" in n.lower()]:
                                    try:
                                        b = root_z.read(mbox_name)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            for mf in [f for f in sub_z.namelist() if f.endswith('.mbox')]:
                                                temp_mbox = os.path.join(target_media_dir, f"temp_{os.path.basename(mf)}")
                                                with open(temp_mbox, "wb") as out_m:
                                                    out_m.write(sub_z.read(mf))

                                                def_folder = "Caixa de Entrada"
                                                if "deleted" in mf.lower():
                                                    def_folder = "Excluídos"
                                                elif "spam" in mf.lower():
                                                    def_folder = "Spam"

                                                email_records = GoogleParser.parse_mbox(temp_mbox, def_folder, meta_map)
                                                for em in email_records:
                                                    cursor.execute("""
                                                        INSERT INTO google_emails (
                                                            operation_id, phase_id, target_id, google_target_id,
                                                            message_id, thread_id, server_id, folder,
                                                            date_utc, date_brt, from_address, to_address,
                                                            cc_address, bcc_address, subject, snippet,
                                                            body_text, body_html, has_attachments, attachments_json,
                                                            is_read, is_starred, is_trash, is_spam, is_deleted,
                                                            status_action_date, size_bytes
                                                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                    """, (
                                                        operation_id, phase_id, target_id, google_target_id,
                                                        em["message_id"], em["thread_id"], em["server_id"], em["folder"],
                                                        em["date_utc"], em["date_brt"], em["from_address"], em["to_address"],
                                                        em["cc_address"], em["bcc_address"], em["subject"], em["snippet"],
                                                        em["body_text"], em["body_html"], em["has_attachments"], em["attachments_json"],
                                                        em["is_read"], em["is_starred"], em["is_trash"], em["is_spam"], em["is_deleted"],
                                                        em["status_action_date"], em["size_bytes"]
                                                    ))
                                                    total_emails_count += 1

                                                try:
                                                    os.remove(temp_mbox)
                                                except Exception:
                                                    pass
                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao processar MBOX {mbox_name}: {ex}")

                                # 5. Quinto Passo: Fotos & Mídias da Nuvem (Google Photos)
                                for photo_name in [n for n in sub_names if "googlephotos" in n.lower()]:
                                    try:
                                        b = root_z.read(photo_name)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            target_photos_dir = os.path.join(MEDIA_BASE_DIR, f"target_{target_id}", "google", "photos")
                                            os.makedirs(target_photos_dir, exist_ok=True)

                                            all_files = sub_z.namelist()
                                            json_files = {f: f for f in all_files if f.endswith('.json')}
                                            media_exts = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.mp4', '.mov', '.avi', '.m4v')

                                            for mf in all_files:
                                                if not mf.lower().endswith(media_exts):
                                                    continue

                                                media_bytes = sub_z.read(mf)
                                                base_fname = os.path.basename(mf)
                                                media_type = 'video' if mf.lower().endswith(('.mp4', '.mov', '.avi', '.m4v')) else 'image'

                                                matching_json = f"{mf}.json"
                                                meta_data = {}
                                                if matching_json in json_files:
                                                    try:
                                                        j_text = sub_z.read(matching_json).decode('utf-8', errors='replace')
                                                        meta_data = GoogleParser.parse_google_photo_metadata(j_text, base_fname)
                                                    except Exception:
                                                        pass

                                                dest_path = os.path.join(target_photos_dir, base_fname)
                                                with open(dest_path, "wb") as f_out:
                                                    f_out.write(media_bytes)

                                                rel_path = f"target_{target_id}/google/photos/{base_fname}"
                                                cursor.execute("""
                                                    INSERT INTO google_photos (
                                                        operation_id, phase_id, target_id, google_target_id,
                                                        title, file_name, file_path, file_size, media_type,
                                                        capture_time_utc, capture_time_brt, exif_hash,
                                                        latitude, longitude, description
                                                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                """, (
                                                    operation_id, phase_id, target_id, google_target_id,
                                                    meta_data.get("title") or base_fname,
                                                    base_fname,
                                                    rel_path,
                                                    len(media_bytes),
                                                    media_type,
                                                    meta_data.get("capture_time_utc", ""),
                                                    meta_data.get("capture_time_brt", ""),
                                                    meta_data.get("exif_hash", ""),
                                                    meta_data.get("latitude"),
                                                    meta_data.get("longitude"),
                                                    meta_data.get("description", "")
                                                ))
                                                total_photos_count += 1
                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao importar Google Photos {photo_name}: {ex}")

                                # 6. Sexto Passo: Google Chrome (Navegação & Favoritos)
                                for chrome_name in [n for n in sub_names if "chrome." in n.lower()]:
                                    try:
                                        b = root_z.read(chrome_name)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            for c_file in sub_z.namelist():
                                                if c_file.endswith("History.json"):
                                                    hist_data = GoogleParser.parse_chrome_history(sub_z.read(c_file).decode('utf-8', errors='replace'))
                                                    for h in hist_data:
                                                        cursor.execute("""
                                                            INSERT INTO google_chrome_history (
                                                                operation_id, phase_id, target_id, google_target_id,
                                                                url, title, visit_time_utc, visit_time_brt, transition, raw_json
                                                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                        """, (
                                                            operation_id, phase_id, target_id, google_target_id,
                                                            h["url"], h["title"], h["visit_time_utc"], h["visit_time_brt"],
                                                            h["transition"], h.get("raw_json", "")
                                                        ))
                                                        total_chrome_history_count += 1
                                                elif c_file.endswith("Bookmarks.json"):
                                                    bm_data = GoogleParser.parse_chrome_bookmarks(sub_z.read(c_file).decode('utf-8', errors='replace'))
                                                    for bm in bm_data:
                                                        cursor.execute("""
                                                            INSERT INTO google_chrome_bookmarks (
                                                                operation_id, phase_id, target_id, google_target_id,
                                                                title, url, folder, date_added_utc, date_added_brt
                                                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                        """, (
                                                            operation_id, phase_id, target_id, google_target_id,
                                                            bm["title"], bm["url"], bm["folder"], bm["date_added_utc"], bm["date_added_brt"]
                                                        ))
                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao importar Chrome {chrome_name}: {ex}")

                                # 7. Sétimo Passo: Minha Atividade & Áudios de Busca por Voz (MyActivity)
                                for act_name in [n for n in sub_names if "myactivity." in n.lower()]:
                                    try:
                                        b = root_z.read(act_name)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            inner_names = sub_z.namelist()
                                            
                                            # Extrair arquivos de áudio .mp3 primeiro
                                            target_voice_dir = os.path.join(MEDIA_BASE_DIR, f"target_{target_id}", "google", "voice")
                                            os.makedirs(target_voice_dir, exist_ok=True)

                                            mp3_saved = {}
                                            for mf in inner_names:
                                                if mf.lower().endswith(".mp3"):
                                                    mp3_base = os.path.basename(mf)
                                                    dest_mp3 = os.path.join(target_voice_dir, mp3_base)
                                                    with open(dest_mp3, "wb") as f_out:
                                                        f_out.write(sub_z.read(mf))
                                                    mp3_saved[mp3_base] = f"target_{target_id}/google/voice/{mp3_base}"

                                            # Processar arquivos MyActivity.html
                                            for hf in inner_names:
                                                if hf.endswith("MyActivity.html"):
                                                    product_folder = os.path.basename(os.path.dirname(hf)) or "Search"
                                                    html_text = sub_z.read(hf).decode('utf-8', errors='replace')
                                                    activities = GoogleParser.parse_my_activity_html(html_text, default_product=product_folder)
                                                    for act in activities:
                                                        rel_audio = ""
                                                        has_aud = 0
                                                        if act.get("audio_file"):
                                                            aud_base = os.path.basename(act["audio_file"])
                                                            if aud_base in mp3_saved:
                                                                rel_audio = mp3_saved[aud_base]
                                                                has_aud = 1
                                                            else:
                                                                rel_audio = f"target_{target_id}/google/voice/{aud_base}"
                                                                has_aud = 1

                                                        cursor.execute("""
                                                            INSERT INTO google_activities (
                                                                operation_id, phase_id, target_id, google_target_id,
                                                                product, action_text, target_url, timestamp_utc, timestamp_brt,
                                                                audio_file, has_audio, details
                                                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                        """, (
                                                            operation_id, phase_id, target_id, google_target_id,
                                                            act["product"], act["action_text"], act["target_url"],
                                                            act["timestamp_utc"], act["timestamp_brt"],
                                                            rel_audio, has_aud, act.get("details", "")
                                                        ))
                                                        total_activities_count += 1
                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao importar MyActivity {act_name}: {ex}")

                                # 8. Oitavo Passo: Google Drive (Nuvem, Documentos, Planilhas e Metadados)
                                for drive_name in [n for n in sub_names if "drive.drivefiles" in n.lower() or "drivefiles" in n.lower()]:
                                    try:
                                        b = root_z.read(drive_name)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            inner_names = sub_z.namelist()
                                            target_drive_dir = os.path.join(MEDIA_BASE_DIR, f"target_{target_id}", "google", "drive")
                                            os.makedirs(target_drive_dir, exist_ok=True)

                                            # Mapear metadados dos arquivos -info.json
                                            info_map = {}
                                            for info_fn in [fn for fn in inner_names if fn.endswith("-info.json")]:
                                                try:
                                                    info_text = sub_z.read(info_fn).decode('utf-8', errors='replace')
                                                    base_key = os.path.basename(info_fn).replace("-info.json", "")
                                                    info_map[base_key] = GoogleParser.parse_drive_info_json(info_text, default_filename=base_key)
                                                except Exception as ex_inf:
                                                    print(f"[GoogleService] Erro ao parsear Drive info {info_fn}: {ex_inf}")

                                            # Mapear thumbnails
                                            thumb_map = {}
                                            for th_fn in [fn for fn in inner_names if "thumbnail-" in fn.lower()]:
                                                try:
                                                    th_bytes = sub_z.read(th_fn)
                                                    th_base = os.path.basename(th_fn)
                                                    dest_th = os.path.join(target_drive_dir, th_base)
                                                    with open(dest_th, "wb") as fth:
                                                        fth.write(th_bytes)
                                                    thumb_map[th_base] = f"target_{target_id}/google/drive/{th_base}"
                                                except Exception:
                                                    pass

                                            processed_keys = set()

                                            # Extrair e salvar arquivos binários reais
                                            for mf in inner_names:
                                                if mf.endswith("/") or mf.endswith("-info.json") or mf.endswith(".txt") or "thumbnail-" in os.path.basename(mf).lower() or mf.endswith(".json"):
                                                    continue

                                                base_fname = os.path.basename(mf)
                                                file_bytes = sub_z.read(mf)
                                                file_size = len(file_bytes)
                                                file_sha256 = hashlib.sha256(file_bytes).hexdigest()

                                                safe_fname = base_fname
                                                dest_file = os.path.join(target_drive_dir, safe_fname)
                                                if os.path.exists(dest_file):
                                                    safe_fname = f"{file_sha256[:8]}_{base_fname}"
                                                    dest_file = os.path.join(target_drive_dir, safe_fname)

                                                with open(dest_file, "wb") as f_out:
                                                    f_out.write(file_bytes)

                                                rel_file_path = f"target_{target_id}/google/drive/{safe_fname}"

                                                meta = info_map.get(base_fname) or {}
                                                processed_keys.add(base_fname)

                                                mime = meta.get("mime_type")
                                                if not mime:
                                                    mime, _ = mimetypes.guess_type(base_fname)
                                                    mime = mime or "application/octet-stream"

                                                rel_thumb = ""
                                                for th_k, th_v in thumb_map.items():
                                                    if base_fname in th_k:
                                                        rel_thumb = th_v
                                                        break

                                                size_fmt = GoogleService._format_size(file_size)

                                                cursor.execute("""
                                                    INSERT INTO google_drive_files (
                                                        operation_id, phase_id, target_id, google_target_id,
                                                        file_id, name, original_path, mime_type,
                                                        size_bytes, size_formatted, sha256, file_path,
                                                        thumbnail_path, creation_date_utc, creation_date_brt,
                                                        modified_date_utc, modified_date_brt, upload_ip,
                                                        owner_email, owner_name, is_trashed, is_cloud_only,
                                                        actions_summary, raw_metadata
                                                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                """, (
                                                    operation_id, phase_id, target_id, google_target_id,
                                                    meta.get("file_id", ""),
                                                    meta.get("title") or base_fname,
                                                    mf,
                                                    mime,
                                                    file_size,
                                                    size_fmt,
                                                    file_sha256,
                                                    rel_file_path,
                                                    rel_thumb,
                                                    meta.get("creation_date_utc", ""),
                                                    meta.get("creation_date_brt", ""),
                                                    meta.get("modified_date_utc", ""),
                                                    meta.get("modified_date_brt", ""),
                                                    meta.get("upload_ip", ""),
                                                    meta.get("owner_email", ""),
                                                    meta.get("owner_name", ""),
                                                    meta.get("is_trashed", 0),
                                                    0,
                                                    meta.get("actions_summary", ""),
                                                    meta.get("raw_metadata", "")
                                                ))
                                                total_drive_files_count += 1

                                            # Processar itens que só existem em nuvem (Google Docs, etc.)
                                            for base_k, meta in info_map.items():
                                                if base_k in processed_keys or "account-level user metadata" in base_k.lower():
                                                    continue

                                                mime = meta.get("mime_type") or "application/vnd.google-apps.document"
                                                cursor.execute("""
                                                    INSERT INTO google_drive_files (
                                                        operation_id, phase_id, target_id, google_target_id,
                                                        file_id, name, original_path, mime_type,
                                                        size_bytes, size_formatted, sha256, file_path,
                                                        thumbnail_path, creation_date_utc, creation_date_brt,
                                                        modified_date_utc, modified_date_brt, upload_ip,
                                                        owner_email, owner_name, is_trashed, is_cloud_only,
                                                        actions_summary, raw_metadata
                                                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                """, (
                                                    operation_id, phase_id, target_id, google_target_id,
                                                    meta.get("file_id", ""),
                                                    meta.get("title") or base_k,
                                                    f"Drive/{base_k}",
                                                    mime,
                                                    0,
                                                    "0 B (Nuvem)",
                                                    "",
                                                    "",
                                                    "",
                                                    meta.get("creation_date_utc", ""),
                                                    meta.get("creation_date_brt", ""),
                                                    meta.get("modified_date_utc", ""),
                                                    meta.get("modified_date_brt", ""),
                                                    meta.get("upload_ip", ""),
                                                    meta.get("owner_email", ""),
                                                    meta.get("owner_name", ""),
                                                    meta.get("is_trashed", 0),
                                                    1,
                                                    meta.get("actions_summary", ""),
                                                    meta.get("raw_metadata", "")
                                                ))
                                                total_drive_files_count += 1

                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao importar Drive {drive_name}: {ex}")

                                # 9. Nono Passo: Linha do Tempo & Configurações de Rastreamento (Timeline)
                                for tl_name in [n for n in sub_names if "timeline.settings" in n.lower()]:
                                    try:
                                        b = root_z.read(tl_name)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            for fn in sub_z.namelist():
                                                if fn.endswith("Settings.json"):
                                                    txt = sub_z.read(fn).decode('utf-8', errors='replace')
                                                    dev_settings = GoogleParser.parse_timeline_settings(txt)
                                                    for dev in dev_settings:
                                                        cursor.execute("""
                                                            INSERT INTO google_timeline_settings (
                                                                operation_id, phase_id, target_id, google_target_id,
                                                                gaia_id, device_tag, device_pretty_name, platform_type,
                                                                reporting_enabled, device_creation_time_utc, device_creation_time_brt,
                                                                setting_change_source, setting_change_time_utc, setting_change_time_brt,
                                                                raw_json
                                                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                        """, (
                                                            operation_id, phase_id, target_id, google_target_id,
                                                            dev["gaia_id"], dev["device_tag"], dev["device_pretty_name"],
                                                            dev["platform_type"], dev["reporting_enabled"],
                                                            dev["device_creation_time_utc"], dev["device_creation_time_brt"],
                                                            dev["setting_change_source"], dev["setting_change_time_utc"],
                                                            dev["setting_change_time_brt"], dev["raw_json"]
                                                        ))
                                                        total_timeline_settings_count += 1
                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao importar Timeline Settings {tl_name}: {ex}")

                                for tl_geo in [n for n in sub_names if ("semanticlocationhistory" in n.lower() or "records" in n.lower()) and "timeline" in n.lower()]:
                                    try:
                                        b = root_z.read(tl_geo)
                                        with zipfile.ZipFile(io.BytesIO(b)) as sub_z:
                                            for fn in sub_z.namelist():
                                                if fn.endswith(".json") and not fn.endswith(".txt"):
                                                    txt = sub_z.read(fn).decode('utf-8', errors='replace')
                                                    geo_points = GoogleParser.parse_timeline_semantic_or_records(txt)
                                                    for p in geo_points:
                                                        cursor.execute("""
                                                            INSERT INTO google_locations (
                                                                operation_id, phase_id, target_id, google_target_id,
                                                                source, location_type, name, address, latitude, longitude,
                                                                timestamp_utc, timestamp_brt, raw_json
                                                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                                        """, (
                                                            operation_id, phase_id, target_id, google_target_id,
                                                            p["source"], p["location_type"], p["name"], p["address"],
                                                            p["latitude"], p["longitude"], p["timestamp_utc"],
                                                            p["timestamp_brt"], p["raw_json"]
                                                        ))
                                                        total_locations_count += 1
                                    except Exception as ex:
                                        print(f"[GoogleService] Erro ao importar Timeline Geo {tl_geo}: {ex}")

                        except Exception as ex:
                            print(f"[GoogleService] Erro ao ler pacote {zpath}: {ex}")

                    # Commit atômico ao concluir o processamento completo de cada conta (libera locks no SQLite)
                    conn.commit()

                return {
                    "status": "success",
                    "imported_targets": imported_targets_count,
                    "total_emails": total_emails_count,
                    "total_devices": total_devices_count,
                    "total_locations": total_locations_count,
                    "total_ips": total_ips_count,
                    "total_photos": total_photos_count,
                    "total_chrome_history": total_chrome_history_count,
                    "total_activities": total_activities_count,
                    "total_drive_files": total_drive_files_count,
                    "total_timeline_settings": total_timeline_settings_count
                }
            finally:
                conn.close()
        finally:
            _google_import_lock.release()

    # ==================== CONSULTAS DA API ====================

    @staticmethod
    def get_google_targets(operation_id: int, phase_id: Optional[int] = None, target_id: Optional[int] = None) -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = """
            SELECT gt.*, t.name_or_alias as target_name_or_alias,
                   (SELECT COUNT(*) FROM google_emails WHERE google_target_id = gt.id) as emails_count,
                   (SELECT COUNT(DISTINCT brand || model || android_id) FROM google_devices WHERE google_target_id = gt.id) as devices_count,
                   (SELECT COUNT(*) FROM google_locations WHERE google_target_id = gt.id) as locations_count,
                   (SELECT COUNT(*) FROM google_ip_logs WHERE google_target_id = gt.id) as ips_count,
                   (SELECT COUNT(*) FROM google_photos WHERE google_target_id = gt.id) as photos_count,
                   (SELECT COUNT(*) FROM google_chrome_history WHERE google_target_id = gt.id) as chrome_history_count,
                   (SELECT COUNT(*) FROM google_chrome_bookmarks WHERE google_target_id = gt.id) as bookmarks_count,
                   (SELECT COUNT(*) FROM google_activities WHERE google_target_id = gt.id) as activities_count,
                   (SELECT COUNT(*) FROM google_activities WHERE google_target_id = gt.id AND has_audio = 1) as voice_audios_count,
                   (SELECT COUNT(*) FROM google_drive_files WHERE google_target_id = gt.id) as drive_files_count,
                   (SELECT COUNT(*) FROM google_timeline_settings WHERE google_target_id = gt.id) as timeline_devices_count
            FROM google_targets gt
            JOIN targets t ON t.id = gt.target_id
            WHERE gt.operation_id = ?
        """
        params = [operation_id]
        if phase_id:
            query += " AND gt.phase_id = ?"
            params.append(phase_id)
        if target_id:
            query += " AND gt.target_id = ?"
            params.append(target_id)

        query += " ORDER BY gt.id ASC"
        cursor.execute(query, tuple(params))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    @staticmethod
    def get_google_overview(google_target_id: int) -> Optional[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT gt.*, t.name_or_alias as target_name_or_alias,
                   (SELECT COUNT(*) FROM google_emails WHERE google_target_id = gt.id) as emails_count,
                   (SELECT COUNT(DISTINCT brand || model || android_id) FROM google_devices WHERE google_target_id = gt.id) as devices_count,
                   (SELECT COUNT(*) FROM google_locations WHERE google_target_id = gt.id) as locations_count,
                   (SELECT COUNT(*) FROM google_ip_logs WHERE google_target_id = gt.id) as ips_count,
                   (SELECT COUNT(*) FROM google_photos WHERE google_target_id = gt.id) as photos_count,
                   (SELECT COUNT(*) FROM google_chrome_history WHERE google_target_id = gt.id) as chrome_history_count,
                   (SELECT COUNT(*) FROM google_activities WHERE google_target_id = gt.id) as activities_count,
                   (SELECT COUNT(*) FROM google_drive_files WHERE google_target_id = gt.id) as drive_files_count,
                   (SELECT COUNT(*) FROM google_timeline_settings WHERE google_target_id = gt.id) as timeline_devices_count
            FROM google_targets gt
            JOIN targets t ON t.id = gt.target_id
            WHERE gt.id = ?
        """, (google_target_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    @staticmethod
    def get_google_devices(google_target_id: int) -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT 
                MIN(id) as id,
                google_target_id,
                brand,
                model,
                android_id,
                MAX(product) as product,
                MAX(build_fingerprint) as build_fingerprint,
                MAX(play_services_version) as play_services_version,
                MAX(connection_time_utc) as connection_time_utc,
                MAX(connection_time_brt) as connection_time_brt,
                MIN(connection_time_brt) as first_connection_time_brt,
                COUNT(*) as total_connections
            FROM google_devices 
            WHERE google_target_id = ?
            GROUP BY brand, model, android_id
            ORDER BY MAX(connection_time_utc) DESC
        """, (google_target_id,))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    @staticmethod
    def get_google_photos(
        google_target_id: int,
        media_type: Optional[str] = None,
        has_gps: Optional[bool] = None,
        search: Optional[str] = None,
        order: str = "desc",
        page: int = 1,
        limit: int = 30
    ) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        offset = (page - 1) * limit

        where_clauses = ["google_target_id = ?"]
        params = [google_target_id]

        if media_type and media_type != "all":
            if media_type == "gps":
                where_clauses.append("latitude IS NOT NULL AND longitude IS NOT NULL")
            else:
                where_clauses.append("media_type = ?")
                params.append(media_type)

        if has_gps and media_type != "gps":
            where_clauses.append("latitude IS NOT NULL AND longitude IS NOT NULL")

        if search:
            where_clauses.append("(title LIKE ? OR file_name LIKE ? OR description LIKE ?)")
            term = f"%{search}%"
            params.extend([term, term, term])

        where_sql = " AND ".join(where_clauses)

        cursor.execute(f"SELECT COUNT(*) as total FROM google_photos WHERE {where_sql}", tuple(params))
        total = cursor.fetchone()["total"]

        order_direction = "ASC" if str(order).lower() == "asc" else "DESC"
        query = f"""
            SELECT * FROM google_photos
            WHERE {where_sql}
            ORDER BY capture_time_utc {order_direction}, id {order_direction}
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])
        cursor.execute(query, tuple(params))
        photos = [dict(r) for r in cursor.fetchall()]

        # Estatísticas agregadas da conta para alimentar os badges das abas
        cursor.execute("""
            SELECT 
                COUNT(*) as total_all,
                SUM(CASE WHEN media_type = 'image' THEN 1 ELSE 0 END) as total_images,
                SUM(CASE WHEN media_type = 'video' THEN 1 ELSE 0 END) as total_videos,
                SUM(CASE WHEN latitude IS NOT NULL AND longitude IS NOT NULL THEN 1 ELSE 0 END) as total_gps
            FROM google_photos
            WHERE google_target_id = ?
        """, (google_target_id,))
        stats_row = cursor.fetchone()
        stats = {
            "all": int(stats_row["total_all"]) if stats_row and stats_row["total_all"] else 0,
            "image": int(stats_row["total_images"]) if stats_row and stats_row["total_images"] else 0,
            "video": int(stats_row["total_videos"]) if stats_row and stats_row["total_videos"] else 0,
            "gps": int(stats_row["total_gps"]) if stats_row and stats_row["total_gps"] else 0
        }

        conn.close()

        return {
            "photos": photos,
            "total": total,
            "page": page,
            "limit": limit,
            "stats": stats
        }

    @staticmethod
    def get_google_photo_detail(photo_id: int) -> Optional[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM google_photos WHERE id = ?", (photo_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    @staticmethod
    def get_google_locations(google_target_id: int) -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM google_locations 
            WHERE google_target_id = ?
            ORDER BY id ASC
        """, (google_target_id,))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    @staticmethod
    def get_google_emails(
        google_target_id: int,
        folder: Optional[str] = None,
        search: Optional[str] = None,
        page: int = 1,
        limit: int = 50
    ) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()

        offset = (page - 1) * limit
        where_clauses = ["google_target_id = ?"]
        params = [google_target_id]

        if folder and folder != "all":
            where_clauses.append("folder = ?")
            params.append(folder)

        if search:
            where_clauses.append("(subject LIKE ? OR from_address LIKE ? OR to_address LIKE ? OR snippet LIKE ?)")
            term = f"%{search}%"
            params.extend([term, term, term, term])

        where_sql = " AND ".join(where_clauses)

        # Contagem de pastas
        cursor.execute("""
            SELECT folder, COUNT(*) as cnt 
            FROM google_emails 
            WHERE google_target_id = ? 
            GROUP BY folder
        """, (google_target_id,))
        folder_counts = {r["folder"]: r["cnt"] for r in cursor.fetchall()}

        # Total filtrado
        cursor.execute(f"SELECT COUNT(*) as total FROM google_emails WHERE {where_sql}", tuple(params))
        total = cursor.fetchone()["total"]

        # Mensagens paginadas
        query = f"""
            SELECT id, message_id, thread_id, folder, date_utc, date_brt,
                   from_address, to_address, subject, snippet, has_attachments,
                   is_read, is_starred, is_trash, is_spam, is_deleted, size_bytes
            FROM google_emails
            WHERE {where_sql}
            ORDER BY id DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])
        cursor.execute(query, tuple(params))
        emails = [dict(r) for r in cursor.fetchall()]

        conn.close()
        return {
            "emails": emails,
            "total": total,
            "page": page,
            "limit": limit,
            "folder_counts": folder_counts
        }

    @staticmethod
    def get_google_email_detail(email_id: int) -> Optional[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM google_emails WHERE id = ?", (email_id,))
        row = cursor.fetchone()
        conn.close()
        if not row:
            return None
        res = dict(row)
        if res.get("attachments_json"):
            try:
                res["attachments"] = json.loads(res["attachments_json"])
            except Exception:
                res["attachments"] = []
        return res

    @staticmethod
    def get_google_ips(google_target_id: int, page: int = 1, limit: int = 100) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        offset = (page - 1) * limit

        cursor.execute("SELECT COUNT(*) as total FROM google_ip_logs WHERE google_target_id = ?", (google_target_id,))
        total = cursor.fetchone()["total"]

        cursor.execute("""
            SELECT * FROM google_ip_logs 
            WHERE google_target_id = ?
            ORDER BY id DESC
            LIMIT ? OFFSET ?
        """, (google_target_id, limit, offset))
        ips = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return {
            "ips": ips,
            "total": total,
            "page": page,
            "limit": limit
        }

    # ==================== MÉTODOS DE CONSULTA: CHROME & ATIVIDADES ====================

    @staticmethod
    def get_chrome_history(
        google_target_id: int,
        query: Optional[str] = None,
        page: int = 1,
        limit: int = 50
    ) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        offset = (page - 1) * limit

        where_clauses = ["google_target_id = ?"]
        params = [google_target_id]

        if query:
            q_clean = f"%{query.strip()}%"
            where_clauses.append("(title LIKE ? OR url LIKE ?)")
            params.extend([q_clean, q_clean])

        where_sql = " AND ".join(where_clauses)

        cursor.execute(f"SELECT COUNT(*) as total FROM google_chrome_history WHERE {where_sql}", tuple(params))
        total = cursor.fetchone()["total"]

        sql = f"""
            SELECT id, google_target_id, target_id, url, title, visit_time_utc, visit_time_brt, transition
            FROM google_chrome_history
            WHERE {where_sql}
            ORDER BY visit_time_utc DESC, id DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])
        cursor.execute(sql, tuple(params))
        history = [dict(r) for r in cursor.fetchall()]
        conn.close()

        return {
            "history": history,
            "total": total,
            "page": page,
            "limit": limit
        }

    @staticmethod
    def get_chrome_bookmarks(google_target_id: int) -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, google_target_id, target_id, title, url, folder, date_added_utc, date_added_brt
            FROM google_chrome_bookmarks
            WHERE google_target_id = ?
            ORDER BY folder ASC, id ASC
        """, (google_target_id,))
        bookmarks = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return bookmarks

    @staticmethod
    def get_activities(
        google_target_id: int,
        product: Optional[str] = None,
        has_audio: Optional[bool] = None,
        query: Optional[str] = None,
        page: int = 1,
        limit: int = 50
    ) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        offset = (page - 1) * limit

        where_clauses = ["google_target_id = ?"]
        params = [google_target_id]

        if product:
            where_clauses.append("product = ?")
            params.append(product)

        if has_audio is True:
            where_clauses.append("has_audio = 1")
        elif has_audio is False:
            where_clauses.append("has_audio = 0")

        if query:
            q_clean = f"%{query.strip()}%"
            where_clauses.append("(action_text LIKE ? OR target_url LIKE ?)")
            params.extend([q_clean, q_clean])

        where_sql = " AND ".join(where_clauses)

        cursor.execute(f"SELECT COUNT(*) as total FROM google_activities WHERE {where_sql}", tuple(params))
        total = cursor.fetchone()["total"]

        # Obter lista de produtos únicos para filtro
        cursor.execute("SELECT DISTINCT product FROM google_activities WHERE google_target_id = ? ORDER BY product ASC", (google_target_id,))
        products_list = [r["product"] for r in cursor.fetchall() if r["product"]]

        # Total com áudio
        cursor.execute("SELECT COUNT(*) as total_audio FROM google_activities WHERE google_target_id = ? AND has_audio = 1", (google_target_id,))
        total_audio = cursor.fetchone()["total_audio"]

        sql = f"""
            SELECT id, google_target_id, target_id, product, action_text, target_url,
                   timestamp_utc, timestamp_brt, audio_file, has_audio, details
            FROM google_activities
            WHERE {where_sql}
            ORDER BY timestamp_utc DESC, id DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])
        cursor.execute(sql, tuple(params))
        activities = [dict(r) for r in cursor.fetchall()]
        conn.close()

        return {
            "activities": activities,
            "total": total,
            "total_audio": total_audio,
            "products": products_list,
            "page": page,
            "limit": limit
        }

    # ==================== GOOGLE DRIVE & TIMELINE ====================

    @staticmethod
    def get_drive_files(
        google_target_id: int,
        search: Optional[str] = None,
        file_category: Optional[str] = None,
        only_trashed: Optional[bool] = None,
        page: int = 1,
        limit: int = 50
    ) -> Dict[str, Any]:
        conn = get_db_connection()
        cursor = conn.cursor()
        offset = (page - 1) * limit

        where_clauses = ["google_target_id = ?"]
        params = [google_target_id]

        if only_trashed is True:
            where_clauses.append("is_trashed = 1")
        elif only_trashed is False:
            where_clauses.append("is_trashed = 0")

        if file_category:
            cat = file_category.lower()
            if cat == "documents":
                where_clauses.append("(mime_type LIKE '%pdf%' OR mime_type LIKE '%document%' OR mime_type LIKE '%word%' OR mime_type LIKE '%kix%' OR name LIKE '%.pdf' OR name LIKE '%.doc%' OR name LIKE '%.txt')")
            elif cat == "spreadsheets":
                where_clauses.append("(mime_type LIKE '%sheet%' OR mime_type LIKE '%excel%' OR mime_type LIKE '%csv%' OR name LIKE '%.xls%' OR name LIKE '%.csv')")
            elif cat == "images":
                where_clauses.append("(mime_type LIKE 'image/%' OR name LIKE '%.jpg' OR name LIKE '%.jpeg' OR name LIKE '%.png' OR name LIKE '%.webp' OR name LIKE '%.gif')")
            elif cat == "media":
                where_clauses.append("(mime_type LIKE 'video/%' OR mime_type LIKE 'audio/%' OR name LIKE '%.mp4' OR name LIKE '%.mov' OR name LIKE '%.mp3')")
            elif cat == "archives":
                where_clauses.append("(mime_type LIKE '%zip%' OR mime_type LIKE '%compressed%' OR name LIKE '%.zip' OR name LIKE '%.rar' OR name LIKE '%.7z')")

        if search:
            s_clean = f"%{search.strip()}%"
            where_clauses.append("(name LIKE ? OR upload_ip LIKE ? OR owner_name LIKE ? OR owner_email LIKE ? OR actions_summary LIKE ?)")
            params.extend([s_clean, s_clean, s_clean, s_clean, s_clean])

        where_sql = " AND ".join(where_clauses)

        cursor.execute(f"SELECT COUNT(*) as total FROM google_drive_files WHERE {where_sql}", tuple(params))
        total = cursor.fetchone()["total"]

        # Total geral e contadores de categorias
        cursor.execute("SELECT COUNT(*) as c FROM google_drive_files WHERE google_target_id = ?", (google_target_id,))
        total_all = cursor.fetchone()["c"]

        cursor.execute("SELECT COUNT(*) as c FROM google_drive_files WHERE google_target_id = ? AND is_trashed = 1", (google_target_id,))
        total_trashed = cursor.fetchone()["c"]

        cursor.execute("SELECT COUNT(*) as c FROM google_drive_files WHERE google_target_id = ? AND (mime_type LIKE '%pdf%' OR mime_type LIKE '%document%' OR mime_type LIKE '%word%' OR mime_type LIKE '%kix%' OR name LIKE '%.pdf' OR name LIKE '%.doc%' OR name LIKE '%.txt')", (google_target_id,))
        total_docs = cursor.fetchone()["c"]

        cursor.execute("SELECT COUNT(*) as c FROM google_drive_files WHERE google_target_id = ? AND (mime_type LIKE 'image/%' OR name LIKE '%.jpg' OR name LIKE '%.jpeg' OR name LIKE '%.png')", (google_target_id,))
        total_images = cursor.fetchone()["c"]

        cursor.execute("SELECT SUM(size_bytes) as total_bytes FROM google_drive_files WHERE google_target_id = ?", (google_target_id,))
        bytes_row = cursor.fetchone()
        total_bytes = bytes_row["total_bytes"] if bytes_row and bytes_row["total_bytes"] else 0

        sql = f"""
            SELECT id, google_target_id, target_id, file_id, name, original_path,
                   mime_type, size_bytes, size_formatted, sha256, file_path, thumbnail_path,
                   creation_date_utc, creation_date_brt, modified_date_utc, modified_date_brt,
                   upload_ip, owner_email, owner_name, is_trashed, is_cloud_only, actions_summary
            FROM google_drive_files
            WHERE {where_sql}
            ORDER BY is_cloud_only ASC, size_bytes DESC, creation_date_utc DESC, id DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])
        cursor.execute(sql, tuple(params))
        files = [dict(r) for r in cursor.fetchall()]
        conn.close()

        return {
            "files": files,
            "total": total,
            "total_all": total_all,
            "total_docs": total_docs,
            "total_images": total_images,
            "total_trashed": total_trashed,
            "total_bytes": total_bytes,
            "total_size_formatted": GoogleService._format_size(total_bytes),
            "page": page,
            "limit": limit
        }

    @staticmethod
    def get_timeline_settings(google_target_id: int) -> List[Dict[str, Any]]:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, google_target_id, target_id, gaia_id, device_tag,
                   device_pretty_name, platform_type, reporting_enabled,
                   device_creation_time_utc, device_creation_time_brt,
                   setting_change_source, setting_change_time_utc, setting_change_time_brt,
                   raw_json
            FROM google_timeline_settings
            WHERE google_target_id = ?
            ORDER BY reporting_enabled DESC, setting_change_time_utc DESC, id DESC
        """, (google_target_id,))
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows


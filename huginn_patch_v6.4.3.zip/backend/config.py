import sys
import os

def get_app_dir():
    """Retorna o diretório base onde ficam o banco de dados e a pasta uploads (ao lado do .exe ou da raiz)"""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def get_bundle_dir():
    """Retorna o diretório interno dos assets empacotados pelo PyInstaller (_MEIPASS) ou a raiz do código"""
    if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
        return sys._MEIPASS
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

APP_DIR = get_app_dir()
BUNDLE_DIR = get_bundle_dir()

DB_PATH = os.path.join(APP_DIR, "huginn.db")
UPLOAD_DIR = os.path.join(APP_DIR, "uploads")
MEDIA_BASE_DIR = os.path.join(UPLOAD_DIR, "media")
AVATAR_DIR = os.path.join(UPLOAD_DIR, "avatars")
CUSTODY_DIR = os.path.join(UPLOAD_DIR, "custody")
MODELS_DIR = os.path.join(APP_DIR, "models")
WHISPER_MODELS_DIR = os.path.join(MODELS_DIR, "whisper")

# Arquivos estáticos da interface web (HTML/CSS/JS)
STATIC_DIR = os.path.join(BUNDLE_DIR, "backend", "static")
if not os.path.exists(STATIC_DIR):
    STATIC_DIR = os.path.join(APP_DIR, "backend", "static")

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(MEDIA_BASE_DIR, exist_ok=True)
os.makedirs(AVATAR_DIR, exist_ok=True)
os.makedirs(CUSTODY_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(WHISPER_MODELS_DIR, exist_ok=True)

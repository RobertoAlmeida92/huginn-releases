/**
 * MetaAnalise - Módulo Google LERS
 * Controlador de Interface Forense: Dossiê Cadastral, Aparelhos Android,
 * Webmail Pericial (Gmail), Mapa de Mobilidade (Maps + Waze) e Auditoria de IPs.
 */

let googleCurrentOpId = null;
let googleCurrentPhaseId = null;
let googleCurrentTargetId = null;
let googleTargets = [];
let googleCurrentAccount = null;
let googleActiveSubTab = 'overview';

// Estado do Webmail
let googleEmailFolder = 'all';
let googleEmailPage = 1;
let googleEmailLimit = 25;
let googleEmailSearch = '';
let googleEmailSearchTimer = null;

// Estado de Conexões e IPs
let googleIpsPage = 1;
let googleIpsLimit = 50;

// Estado do Google Fotos
let googlePhotoFilterType = 'all'; // 'all', 'image', 'video', 'gps'
let googlePhotoSortOrder = 'desc'; // 'desc', 'asc'
let googlePhotoGpsOnly = false;
let googlePhotoSearch = '';
let googlePhotoSearchTimer = null;
let googlePhotoPage = 1;
let googlePhotoLimit = 30;
let googlePhotosList = [];
let googleCurrentPhotoIndex = -1;

// Instância do Mapa Leaflet
let googleMapInstance = null;
let googleMapMarkers = [];
let googlePendingPhotoPin = null;
let googlePhotoMarker = null;

// Estado do Google Chrome
let googleChromePage = 1;
let googleChromeSearch = '';
let googleChromeSearchTimer = null;
let googleChromeCurrentSubView = 'history';

// Estado de Minha Atividade & Gravações de Voz
let googleActivityPage = 1;
let googleActivitySearch = '';
let googleActivitySearchTimer = null;
let googleActivityProduct = '';
let googleActivityAudioOnly = false;

// ==================== CARREGAMENTO PRINCIPAL ====================

async function loadGoogleView(opId, phaseId, targetId) {
    googleCurrentOpId = opId;
    googleCurrentPhaseId = phaseId;
    googleCurrentTargetId = targetId;

    let url = `/api/google/targets?operation_id=${opId}`;
    if (phaseId) url += `&phase_id=${phaseId}`;
    if (targetId) url += `&target_id=${targetId}`;

    try {
        const res = await fetch(url);
        googleTargets = await res.json();

        // Atualizar contador na aba superior
        const badge = document.getElementById('badge-google-count');
        if (badge) badge.innerText = googleTargets.length;

        const emptyView = document.getElementById('google-empty');
        const contentView = document.getElementById('google-content');

        if (googleTargets.length === 0) {
            if (emptyView) {
                emptyView.classList.remove('hidden');
                const emptyTitle = document.getElementById('google-empty-title');
                const emptyDesc = document.getElementById('google-empty-desc');
                if (targetId) {
                    if (emptyTitle) emptyTitle.innerText = "Nenhuma conta Google vinculada ao alvo selecionado";
                    if (emptyDesc) emptyDesc.innerHTML = `O alvo ativo no topo não possui conta Google vinculada diretamente.<br><button onclick="clearTargetFilterAndReloadGoogle()" class="mt-2.5 px-3 py-1 bg-blue-600/10 hover:bg-blue-600/20 text-blue-600 dark:text-cyan-300 border border-blue-500/20 rounded-lg text-xs font-semibold inline-flex items-center space-x-1 cursor-pointer transition"><span>Visualizar todas as contas Google desta operação</span></button>`;
                } else {
                    if (emptyTitle) emptyTitle.innerText = "Nenhum dado do Google LERS encontrado nesta operação";
                    if (emptyDesc) emptyDesc.innerText = "Importe o pacote judicial recebido do Google LERS (.zip) para indexar o dossiê cadastral, aparelhos, fotos, webmail Gmail, mobilidade e auditoria de IPs.";
                }
            }
            if (contentView) contentView.classList.add('hidden');
            return;
        }

        if (emptyView) emptyView.classList.add('hidden');
        if (contentView) contentView.classList.remove('hidden');

        // Renderizar barra de contas/alvos do Google
        renderGoogleTargetPills();

        // Selecionar o primeiro se não houver um ativo selecionado
        if (!googleCurrentAccount || !googleTargets.some(t => t.id === googleCurrentAccount.id)) {
            googleCurrentAccount = googleTargets[0];
        }

        highlightActiveGooglePill();
        switchGoogleSubTab(googleActiveSubTab || 'overview');

    } catch (err) {
        console.error("Erro ao carregar alvos do Google:", err);
    }
}

function renderGoogleTargetPills() {
    const container = document.getElementById('google-account-selector-container');
    const select = document.getElementById('google-account-select');
    if (!container || !select) return;

    if (googleTargets.length <= 1) {
        container.classList.add('hidden');
        return;
    }

    container.classList.remove('hidden');
    let html = '';
    googleTargets.forEach(t => {
        const isSelected = (googleCurrentAccount && googleCurrentAccount.id === t.id) ? 'selected' : '';
        html += `<option value="${t.id}" ${isSelected}>${escapeHtml(t.email)} (${t.emails_count || 0} msgs)</option>`;
    });

    select.innerHTML = html;
}

function highlightActiveGooglePill() {
    const select = document.getElementById('google-account-select');
    if (select && googleCurrentAccount) {
        select.value = googleCurrentAccount.id;
    }

    if (googleCurrentAccount) {
        const bChrome = document.getElementById('google-badge-chrome');
        if (bChrome) {
            const count = googleCurrentAccount.chrome_history_count || 0;
            bChrome.innerText = count.toLocaleString();
            if (count > 0) bChrome.classList.remove('hidden');
            else bChrome.classList.add('hidden');
        }

        const bActivities = document.getElementById('google-badge-activities');
        if (bActivities) {
            const count = googleCurrentAccount.activities_count || 0;
            bActivities.innerText = count.toLocaleString();
            if (count > 0) bActivities.classList.remove('hidden');
            else bActivities.classList.add('hidden');
        }

        const bDrive = document.getElementById('google-badge-drive');
        if (bDrive) {
            const count = googleCurrentAccount.drive_files_count || 0;
            bDrive.innerText = count.toLocaleString();
            if (count > 0) bDrive.classList.remove('hidden');
            else bDrive.classList.add('hidden');
        }
    }
}

function selectGoogleAccount(accountId) {
    const found = googleTargets.find(t => t.id === accountId);
    if (found) {
        googleCurrentAccount = found;
        
        // Reseta filtros, ordenação e busca de fotos para a nova conta selecionada
        googlePhotoFilterType = 'all';
        googlePhotoSortOrder = 'desc';
        googlePhotoPage = 1;
        googlePhotoSearch = '';
        const pSearchInput = document.getElementById('google-photo-search-input');
        if (pSearchInput) pSearchInput.value = '';
        const pSortSelect = document.getElementById('google-photo-sort-order');
        if (pSortSelect) pSortSelect.value = 'desc';

        // Reseta filtros de Chrome e Atividades
        googleChromePage = 1;
        googleChromeSearch = '';
        const cSearch = document.getElementById('google-chrome-search');
        if (cSearch) cSearch.value = '';

        googleActivityPage = 1;
        googleActivitySearch = '';
        googleActivityProduct = '';
        googleActivityAudioOnly = false;
        const aSearch = document.getElementById('google-activity-search');
        if (aSearch) aSearch.value = '';
        const aAudioCheck = document.getElementById('google-activity-audio-only');
        if (aAudioCheck) aAudioCheck.checked = false;

        // Reseta filtros do Google Drive
        googleDrivePage = 1;
        googleDriveCategory = '';
        googleDriveSearch = '';
        googleDriveTrashOnly = false;
        const dSearch = document.getElementById('google-drive-search');
        if (dSearch) dSearch.value = '';
        const dTrash = document.getElementById('google-drive-trash-only');
        if (dTrash) dTrash.checked = false;
        const dCat = document.getElementById('google-drive-category-select');
        if (dCat) dCat.value = '';

        ['all', 'image', 'video', 'gps'].forEach(t => {
            const btn = document.getElementById(`btn-photo-filter-${t}`);
            if (btn) {
                btn.className = (t === 'all')
                    ? 'px-3 py-1.5 rounded-lg bg-purple-600 text-white font-bold transition shadow-xs flex items-center space-x-1.5'
                    : 'px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition shadow-xs flex items-center space-x-1.5 font-medium';
            }
        });

        highlightActiveGooglePill();
        switchGoogleSubTab(googleActiveSubTab || 'overview');
    }
}

function clearTargetFilterAndReloadGoogle() {
    const targetSelect = document.getElementById('target-select');
    if (targetSelect) {
        targetSelect.value = '';
        targetSelect.dispatchEvent(new Event('change'));
    }
}

// ==================== SUB-ABAS DO GOOGLE ====================

function switchGoogleSubTab(subTabName) {
    googleActiveSubTab = subTabName;
    const subtabs = ['overview', 'devices', 'photos', 'emails', 'locations', 'ips', 'chrome', 'activities', 'drive'];

    subtabs.forEach(st => {
        const btn = document.getElementById(`google-tab-${st}`);
        const view = document.getElementById(`google-view-${st}`);

        if (btn && view) {
            if (st === subTabName) {
                btn.className = 'google-subtab-btn active flex-shrink-0 whitespace-nowrap h-7 px-2.5 rounded-md bg-blue-600 text-white font-semibold text-[11px] border border-blue-600 shadow-2xs flex items-center space-x-1.5 transition';
                view.classList.remove('hidden');
            } else {
                btn.className = 'google-subtab-btn flex-shrink-0 whitespace-nowrap h-7 px-2.5 rounded-md bg-slate-100/70 hover:bg-slate-200/70 text-slate-700 dark:bg-slate-950/50 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:bg-slate-800/70 border border-slate-200/80 dark:border-slate-800/80 font-semibold text-[11px] flex items-center space-x-1.5 transition';
                view.classList.add('hidden');
            }
        }
    });

    if (!googleCurrentAccount) return;

    if (subTabName === 'overview') {
        loadGoogleOverview();
    } else if (subTabName === 'devices') {
        loadGoogleDevices();
    } else if (subTabName === 'photos') {
        googlePhotoPage = 1;
        loadGooglePhotos();
    } else if (subTabName === 'emails') {
        googleEmailPage = 1;
        loadGoogleEmails();
    } else if (subTabName === 'locations') {
        loadGoogleLocations();
        loadTimelineSettings();
    } else if (subTabName === 'ips') {
        googleIpsPage = 1;
        loadGoogleIps();
    } else if (subTabName === 'chrome') {
        googleChromePage = 1;
        loadGoogleChromeHistory();
    } else if (subTabName === 'activities') {
        googleActivityPage = 1;
        loadGoogleActivities();
    } else if (subTabName === 'drive') {
        googleDrivePage = 1;
        loadGoogleDriveFiles();
    }

    if (window.lucide) lucide.createIcons();
}

// ==================== 1. DOSSIÊ CADASTRAL ====================

async function loadGoogleOverview() {
    if (!googleCurrentAccount) return;
    try {
        const res = await fetch(`/api/google/overview?google_target_id=${googleCurrentAccount.id}`);
        const data = await res.json();

        document.getElementById('google-account-id').innerText = data.google_account_id || '---';
        document.getElementById('google-full-name').innerText = data.full_name || 'Não informado';
        document.getElementById('google-email-address').innerText = data.email || '---';
        document.getElementById('google-created-at').innerText = data.created_at_brt || data.created_at_utc || '---';
        document.getElementById('google-account-status').innerText = data.status || 'Ativo';
        document.getElementById('google-terms-ip').innerText = data.terms_ip || '---';
        document.getElementById('google-recovery-sms').innerText = data.recovery_sms || 'Não cadastrado';
        document.getElementById('google-recovery-email').innerText = data.recovery_email || 'Não cadastrado';
        document.getElementById('google-services-list').innerText = data.services_list || 'Gmail, Contatos, Drive';
        document.getElementById('google-last-logins').innerText = data.last_logins || '---';

        // Atualizar KPI Cards
        document.getElementById('google-kpi-emails').innerText = (data.emails_count || 0).toLocaleString();
        document.getElementById('google-kpi-devices').innerText = (data.devices_count || 0).toLocaleString();
        const kpiPhotos = document.getElementById('google-kpi-photos');
        if (kpiPhotos) kpiPhotos.innerText = (data.photos_count || 0).toLocaleString();
        document.getElementById('google-kpi-locations').innerText = (data.locations_count || 0).toLocaleString();
        document.getElementById('google-kpi-ips').innerText = (data.ips_count || 0).toLocaleString();

    } catch (err) {
        console.error("Erro ao carregar dossiê do Google:", err);
    }
}

// ==================== 2. DISPOSITIVOS & HARDWARE ====================

async function loadGoogleDevices() {
    if (!googleCurrentAccount) return;
    const container = document.getElementById('google-devices-grid');
    if (!container) return;

    container.innerHTML = `<div class="col-span-3 text-center py-8 text-slate-400">Carregando dispositivos...</div>`;

    try {
        const res = await fetch(`/api/google/devices?google_target_id=${googleCurrentAccount.id}`);
        const devices = await res.json();

        const badge = document.getElementById('google-devices-count-badge');
        if (badge) badge.innerText = `${devices.length} dispositivo${devices.length === 1 ? '' : 's'}`;

        if (devices.length === 0) {
            container.innerHTML = `<div class="col-span-3 text-center py-8 text-slate-400">Nenhum dispositivo registrado para esta conta.</div>`;
            return;
        }

        let html = '';
        devices.forEach(d => {
            const brandLower = (d.brand || '').toLowerCase();
            const modelLower = (d.model || '').toLowerCase();

            let iconName = 'smartphone';
            let iconColor = 'bg-amber-500/10 text-amber-600 dark:text-amber-400';
            let badgeText = 'Android';
            let badgeColor = 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20';

            if (brandLower.includes('apple') || modelLower.includes('iphone') || modelLower.includes('ipad') || modelLower.includes('ios')) {
                iconName = 'apple';
                iconColor = 'bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200';
                badgeText = 'Apple iOS';
                badgeColor = 'bg-slate-500/10 text-slate-700 dark:text-slate-300 border-slate-500/20';
            } else if (brandLower.includes('microsoft') || brandLower.includes('linux') || modelLower.includes('computador') || modelLower.includes('windows') || modelLower.includes('mac')) {
                iconName = 'laptop';
                iconColor = 'bg-blue-500/10 text-blue-600 dark:text-cyan-400';
                badgeText = 'Desktop / Web';
                badgeColor = 'bg-blue-500/10 text-blue-600 dark:text-cyan-400 border-blue-500/20';
            }

            html += `
                <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm space-y-3">
                    <div class="flex items-start justify-between">
                        <div class="flex items-center space-x-2.5">
                            <div class="w-9 h-9 rounded-xl ${iconColor} flex items-center justify-center font-bold">
                                <i data-lucide="${iconName}" class="w-5 h-5"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-xs text-slate-900 dark:text-white">${escapeHtml(d.model || 'Aparelho Desconhecido')}</h4>
                                <p class="text-[10px] text-slate-500 font-mono">${escapeHtml(d.brand || '---')}</p>
                            </div>
                        </div>
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold border ${badgeColor}">${badgeText}</span>
                    </div>

                    <div class="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-[11px]">
                        ${d.android_id ? `
                            <div class="flex justify-between items-center">
                                <span class="text-slate-400">Android ID / Hardware:</span>
                                <span class="font-mono font-bold text-slate-800 dark:text-slate-200">${escapeHtml(d.android_id)}</span>
                            </div>
                        ` : ''}
                        ${d.total_connections ? `
                            <div class="flex justify-between items-center">
                                <span class="text-slate-400">Total de Conexões:</span>
                                <span class="font-mono font-bold text-blue-600 dark:text-cyan-400">${d.total_connections} registro(s)</span>
                            </div>
                        ` : ''}
                        ${d.first_connection_time_brt ? `
                            <div class="flex justify-between items-center">
                                <span class="text-slate-400">Primeiro Acesso:</span>
                                <span class="font-mono text-slate-700 dark:text-slate-300 text-[10px]">${escapeHtml(d.first_connection_time_brt)}</span>
                            </div>
                        ` : ''}
                        <div class="flex justify-between items-center">
                            <span class="text-slate-400">Última Atividade:</span>
                            <span class="font-mono text-slate-700 dark:text-slate-300 text-[10px]">${escapeHtml(d.connection_time_brt || d.connection_time_utc || '---')}</span>
                        </div>
                        ${d.play_services_version ? `
                            <div class="flex justify-between items-center">
                                <span class="text-slate-400">Play Services:</span>
                                <span class="font-mono text-slate-700 dark:text-slate-300">${escapeHtml(d.play_services_version)}</span>
                            </div>
                        ` : ''}
                    </div>

                    ${d.build_fingerprint ? `
                        <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/60 font-mono text-[9px] text-slate-500 break-all" title="User Agent / Build Fingerprint">
                            ${escapeHtml(d.build_fingerprint)}
                        </div>
                    ` : ''}
                </div>
            `;
        });

        container.innerHTML = html;
        if (window.lucide) lucide.createIcons({ root: container });

    } catch (err) {
        console.error("Erro ao carregar dispositivos do Google:", err);
        container.innerHTML = `<div class="col-span-3 text-center py-8 text-rose-400">Erro ao carregar dispositivos.</div>`;
    }
}

// ==================== GOOGLE FOTOS & MÍDIAS DA NUVEM ====================

function changeGooglePhotoSortOrder(order) {
    googlePhotoSortOrder = order || 'desc';
    googlePhotoPage = 1;
    loadGooglePhotos();
}
window.changeGooglePhotoSortOrder = changeGooglePhotoSortOrder;

async function loadGooglePhotos() {
    if (!googleCurrentAccount) return;
    const grid = document.getElementById('google-photos-grid');
    const emptyBox = document.getElementById('google-photos-empty');
    if (!grid) return;

    grid.classList.remove('hidden');
    grid.innerHTML = `<div class="col-span-full text-center py-10 text-slate-400 text-xs flex flex-col items-center justify-center space-y-2"><i data-lucide="loader-2" class="w-6 h-6 animate-spin text-purple-500"></i><span>Carregando galeria pericial da nuvem...</span></div>`;
    if (window.lucide) lucide.createIcons({ root: grid });
    if (emptyBox) emptyBox.classList.add('hidden');

    try {
        let url = `/api/google/photos?google_target_id=${googleCurrentAccount.id}&page=${googlePhotoPage}&limit=${googlePhotoLimit}&order=${googlePhotoSortOrder}`;
        if (googlePhotoFilterType && googlePhotoFilterType !== 'all') {
            url += `&media_type=${googlePhotoFilterType}`;
        }
        if (googlePhotoSearch) {
            url += `&search=${encodeURIComponent(googlePhotoSearch)}`;
        }

        const res = await fetch(url);
        const data = await res.json();
        googlePhotosList = data.photos || [];
        const total = data.total || 0;
        const stats = data.stats || { all: total, image: 0, video: 0, gps: 0 };

        // Atualizar contadores KPIs dos botões de filtro (estilo Instagram)
        const statAll = document.getElementById('stat-google-photos-all');
        const statPhotos = document.getElementById('stat-google-photos-image');
        const statVideos = document.getElementById('stat-google-photos-video');
        const statGps = document.getElementById('stat-google-photos-gps');

        if (statAll) statAll.innerText = (stats.all || 0).toLocaleString();
        if (statPhotos) statPhotos.innerText = (stats.image || 0).toLocaleString();
        if (statVideos) statVideos.innerText = (stats.video || 0).toLocaleString();
        if (statGps) statGps.innerText = (stats.gps || 0).toLocaleString();

        // Badges do cabeçalho
        const totalBadge = document.getElementById('google-photos-total-badge');
        if (totalBadge) totalBadge.innerText = `${(stats.all || 0).toLocaleString()} mídias`;

        const gpsBadge = document.getElementById('google-photos-gps-badge');
        if (gpsBadge) gpsBadge.innerText = `${(stats.gps || 0).toLocaleString()} com GPS`;

        // Sincronizar seletor de ordenação
        const sortSelect = document.getElementById('google-photo-sort-order');
        if (sortSelect && googlePhotoSortOrder) {
            sortSelect.value = googlePhotoSortOrder;
        }

        // Paginação (padrão Instagram)
        const totalPages = Math.max(1, Math.ceil(total / googlePhotoLimit));
        const pagInfo = document.getElementById('google-photos-page-info');
        if (pagInfo) {
            pagInfo.innerText = `Mostrando ${googlePhotosList.length} de ${total.toLocaleString()} mídias • Página ${googlePhotoPage} de ${totalPages}`;
        }

        const btnPrev = document.getElementById('btn-google-photos-prev');
        const btnNext = document.getElementById('btn-google-photos-next');
        if (btnPrev) btnPrev.disabled = (googlePhotoPage <= 1);
        const pagBar = document.getElementById('google-photos-pagination');

        if (googlePhotosList.length === 0) {
            grid.innerHTML = '';
            grid.classList.add('hidden');
            if (pagBar) pagBar.classList.add('hidden');
            if (emptyBox) {
                const emptyTitle = document.getElementById('google-photos-empty-title');
                const emptyDesc = document.getElementById('google-photos-empty-desc');
                const emptyAction = document.getElementById('google-photos-empty-action');
                const emptyActionText = document.getElementById('google-photos-empty-action-text');

                if (googlePhotoFilterType === 'gps') {
                    if (emptyTitle) emptyTitle.innerText = "Nenhuma mídia com coordenadas GPS";
                    if (emptyDesc) emptyDesc.innerText = `Esta conta (${googleCurrentAccount.email}) possui ${stats.all} mídias na nuvem, porém nenhuma contém coordenadas de latitude/longitude gravadas nos metadados EXIF.`;
                    if (emptyAction) emptyAction.classList.remove('hidden');
                    if (emptyActionText) emptyActionText.innerText = `Exibir Todas as ${stats.all} Mídias`;
                } else if (googlePhotoFilterType === 'video') {
                    if (emptyTitle) emptyTitle.innerText = "Nenhum vídeo localizado";
                    if (emptyDesc) emptyDesc.innerText = `Esta conta não possui gravações de vídeo no arquivo Google Fotos.`;
                    if (emptyAction) emptyAction.classList.remove('hidden');
                    if (emptyActionText) emptyActionText.innerText = `Exibir Todas as Mídias`;
                } else if (googlePhotoFilterType === 'image') {
                    if (emptyTitle) emptyTitle.innerText = "Nenhuma imagem localizada";
                    if (emptyDesc) emptyDesc.innerText = `Esta conta não possui fotografias preservadas no arquivo Google Fotos.`;
                    if (emptyAction) emptyAction.classList.remove('hidden');
                    if (emptyActionText) emptyActionText.innerText = `Exibir Todas as Mídias`;
                } else if (googlePhotoSearch) {
                    if (emptyTitle) emptyTitle.innerText = "Nenhum resultado para a busca";
                    if (emptyDesc) emptyDesc.innerText = `Nenhuma mídia encontrada contendo "${escapeHtml(googlePhotoSearch)}".`;
                    if (emptyAction) emptyAction.classList.remove('hidden');
                    if (emptyActionText) emptyActionText.innerText = `Limpar Pesquisa`;
                } else {
                    if (emptyTitle) emptyTitle.innerText = "Nenhuma foto ou mídia localizada";
                    if (emptyDesc) emptyDesc.innerText = "Não constam mídias preservadas no arquivo de quebra Google Fotos para este alvo.";
                    if (emptyAction) emptyAction.classList.add('hidden');
                }
                emptyBox.classList.remove('hidden');
                if (window.lucide) lucide.createIcons({ root: emptyBox });
            }
            return;
        }

        grid.classList.remove('hidden');
        if (pagBar) pagBar.classList.remove('hidden');
        if (emptyBox) emptyBox.classList.add('hidden');

        let html = '';
        googlePhotosList.forEach((p) => {
            const isVideo = p.media_type === 'video' || (p.file_name && p.file_name.toLowerCase().endsWith('.mp4'));
            const hasGps = (p.latitude != null && p.longitude != null);
            const mediaUrl = `/api/media/${p.file_path}`;

            html += `
                <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs hover:shadow-md transition duration-200 flex flex-col justify-between group/mcard">
                    <!-- Thumbnail com Lightbox ao Clicar (Estilo Insta) -->
                    <div class="relative aspect-square bg-slate-100 dark:bg-slate-950 overflow-hidden cursor-pointer" onclick="openGooglePhotoModal(${p.id})">
                        ${isVideo ? `
                            <video src="${mediaUrl}#t=0.5" preload="metadata" class="w-full h-full object-cover opacity-80 group-hover/mcard:opacity-100 transition duration-300"></video>
                            <div class="absolute inset-0 bg-black/30 flex items-center justify-center group-hover/mcard:bg-black/50 transition">
                                <div class="w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center shadow-lg group-hover/mcard:scale-110 transition">
                                    <i data-lucide="play" class="w-5 h-5 ml-0.5 fill-white"></i>
                                </div>
                            </div>
                            <span class="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-purple-600 text-white font-bold text-[9px] flex items-center space-x-1 shadow">
                                <i data-lucide="video" class="w-3 h-3"></i>
                                <span>Vídeo</span>
                            </span>
                        ` : `
                            <img src="${mediaUrl}" alt="${escapeHtml(p.title || p.file_name)}" loading="lazy" class="w-full h-full object-cover group-hover/mcard:scale-105 transition duration-300">
                            <div class="absolute inset-0 bg-black/40 opacity-0 group-hover/mcard:opacity-100 flex items-center justify-center transition text-white text-xs font-bold space-x-1 backdrop-blur-[1px]">
                                <i data-lucide="zoom-in" class="w-4 h-4"></i>
                                <span>Ampliar</span>
                            </div>
                            <span class="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-black/60 text-white font-bold text-[9px] backdrop-blur-xs flex items-center space-x-1 shadow">
                                <i data-lucide="image" class="w-3 h-3 text-indigo-400"></i>
                                <span>Foto</span>
                            </span>
                        `}

                        ${hasGps ? `
                            <span class="absolute top-2 right-2 px-1.5 py-0.5 rounded-full bg-emerald-600 text-white font-bold text-[9px] flex items-center space-x-1 shadow" title="Geolocalizado (GPS: ${p.latitude.toFixed(4)}, ${p.longitude.toFixed(4)})">
                                <i data-lucide="map-pin" class="w-3 h-3"></i>
                                <span>GPS</span>
                            </span>
                        ` : ''}
                    </div>

                    <!-- Rodapé do Card Forense (Estilo Insta) -->
                    <div class="p-2.5 space-y-1.5 text-[10px]">
                        <div class="flex items-center justify-between">
                            <span class="font-bold text-slate-800 dark:text-slate-200 truncate max-w-[130px]" title="${escapeHtml(p.title || p.file_name)}">
                                ${escapeHtml(p.title || p.file_name)}
                            </span>
                            <span class="font-mono text-slate-400 text-[9px]">${p.capture_time_brt ? p.capture_time_brt.split(' ')[0] : 'Data n/d'}</span>
                        </div>
                        ${p.description ? `<p class="text-[11px] text-slate-600 dark:text-slate-400 truncate font-medium" title="${escapeHtml(p.description)}">${escapeHtml(p.description)}</p>` : ''}
                        <div class="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800/80">
                            <button onclick="openGooglePhotoModal(${p.id})" class="px-2 py-0.5 rounded bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 hover:bg-purple-100 dark:hover:bg-purple-900/60 font-bold flex items-center space-x-1 transition text-[9px]">
                                <i data-lucide="maximize-2" class="w-2.5 h-2.5"></i>
                                <span>Metadados EXIF ↗</span>
                            </button>
                            ${hasGps ? `
                                <span class="font-mono text-emerald-600 dark:text-emerald-400 text-[9px] font-bold">📍 Fixado</span>
                            ` : `
                                <span class="text-slate-400 text-[9px]">Sem GPS</span>
                            `}
                        </div>
                    </div>
                </div>
            `;
        });

        grid.innerHTML = html;
        if (window.lucide) lucide.createIcons({ root: grid });

    } catch (err) {
        console.error("Erro ao carregar fotos do Google:", err);
        grid.innerHTML = `<div class="col-span-full text-center py-12 text-rose-400">Erro ao carregar fotos da nuvem.</div>`;
    }
}

function setGooglePhotoFilter(type) {
    googlePhotoFilterType = type;
    googlePhotoPage = 1;

    // Se estiver limpando a busca ao clicar em "Exibir Todas"
    if (type === 'all') {
        googlePhotoSearch = '';
        const input = document.getElementById('google-photo-search-input');
        if (input) input.value = '';
    }

    const filterTypes = ['all', 'image', 'video', 'gps'];
    filterTypes.forEach(t => {
        const btn = document.getElementById(`btn-photo-filter-${t}`);
        if (!btn) return;
        if (t === type) {
            btn.className = 'px-3 py-1.5 rounded-lg bg-purple-600 text-white font-bold transition shadow-xs flex items-center space-x-1.5';
        } else {
            btn.className = 'px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition shadow-xs flex items-center space-x-1.5 font-medium';
        }
    });

    loadGooglePhotos();
}

function handleGooglePhotoSearch(event) {
    clearTimeout(googlePhotoSearchTimer);
    googlePhotoSearchTimer = setTimeout(() => {
        const input = document.getElementById('google-photo-search-input');
        googlePhotoSearch = input ? input.value.trim() : '';
        googlePhotoPage = 1;
        loadGooglePhotos();
    }, 350);
}

function changeGooglePhotoPage(delta) {
    googlePhotoPage += delta;
    if (googlePhotoPage < 1) googlePhotoPage = 1;
    loadGooglePhotos();
}

async function openGooglePhotoModal(photoId) {
    try {
        if (!googlePhotosList || googlePhotosList.length === 0) {
            const res = await fetch(`/api/google/photos/${photoId}`);
            const p = await res.json();
            if (p) googlePhotosList = [p];
        }

        let current = googlePhotosList.find(item => item.id === photoId);
        if (!current) {
            const res = await fetch(`/api/google/photos/${photoId}`);
            current = await res.json();
            if (current) googlePhotosList.push(current);
        }
        if (!current) return;

        const customItems = googlePhotosList.map(p => {
            const isVid = p.media_type === 'video' || (p.file_name && p.file_name.toLowerCase().endsWith('.mp4'));
            return {
                url: `/api/media/${p.file_path}`,
                type: isVid ? 'video' : 'image',
                sender: p.title || p.file_name,
                id: p.id,
                photoData: p
            };
        });

        const initialUrl = `/api/media/${current.file_path}`;
        const initialType = (current.media_type === 'video' || (current.file_name && current.file_name.toLowerCase().endsWith('.mp4'))) ? 'video' : 'image';
        const initialTitle = current.title || current.file_name;

        if (typeof openMediaViewer === 'function') {
            openMediaViewer(initialUrl, initialType, initialTitle, customItems);
        } else {
            renderPhotoModalContent(current);
            const modal = document.getElementById('modal-google-photo-viewer');
            if (modal) modal.classList.remove('hidden');
        }
    } catch (err) {
        console.error("Erro ao abrir visualizador forense da foto do Google:", err);
    }
}

function renderPhotoModalContent(p) {
    const isVideo = p.media_type === 'video' || p.file_name.toLowerCase().endsWith('.mp4');
    const mediaUrl = `/api/media/${p.file_path}`;

    const imgEl = document.getElementById('modal-photo-img');
    const videoEl = document.getElementById('modal-photo-video');

    if (isVideo) {
        if (imgEl) imgEl.classList.add('hidden');
        if (videoEl) {
            videoEl.classList.remove('hidden');
            videoEl.src = mediaUrl;
            videoEl.load();
        }
    } else {
        if (videoEl) {
            videoEl.pause();
            videoEl.classList.add('hidden');
        }
        if (imgEl) {
            imgEl.classList.remove('hidden');
            imgEl.src = mediaUrl;
        }
    }

    // Metadados periciais
    document.getElementById('modal-photo-title').innerText = p.title || p.file_name;
    document.getElementById('modal-photo-filename').innerText = p.file_name;
    document.getElementById('modal-photo-time-brt').innerText = p.capture_time_brt || 'Não informado';
    document.getElementById('modal-photo-time-utc').innerText = p.capture_time_utc ? `${p.capture_time_utc} (UTC)` : '';
    
    const sizeKb = p.file_size ? (p.file_size / 1024).toFixed(1) : 0;
    const sizeMb = (sizeKb / 1024).toFixed(2);
    document.getElementById('modal-photo-size').innerText = `${p.media_type === 'video' ? 'Vídeo' : 'Fotografia'} • ${sizeKb > 1024 ? sizeMb + ' MB' : sizeKb + ' KB'}`;
    document.getElementById('modal-photo-exif-hash').innerText = p.exif_hash || 'Sem hash EXIF de origem';

    // GPS
    const gpsBox = document.getElementById('modal-photo-gps-box');
    const linkExt = document.getElementById('link-photo-external-map');
    const btnMap = document.getElementById('btn-photo-view-in-map');

    if (p.latitude != null && p.longitude != null) {
        if (gpsBox) gpsBox.classList.remove('hidden');
        document.getElementById('modal-photo-coords').innerText = `Lat: ${p.latitude.toFixed(6)}, Lon: ${p.longitude.toFixed(6)}`;
        if (linkExt) {
            linkExt.href = `https://www.google.com/maps?q=${p.latitude},${p.longitude}`;
        }
        if (btnMap) {
            btnMap.dataset.lat = p.latitude;
            btnMap.dataset.lon = p.longitude;
            btnMap.dataset.title = p.title || p.file_name;
        }
    } else {
        if (gpsBox) gpsBox.classList.add('hidden');
    }

    // Descrição
    const descBox = document.getElementById('modal-photo-desc-box');
    const descEl = document.getElementById('modal-photo-desc');
    if (p.description) {
        if (descBox) descBox.classList.remove('hidden');
        if (descEl) descEl.innerText = p.description;
    } else {
        if (descBox) descBox.classList.add('hidden');
    }

    // Download Link
    const dlLink = document.getElementById('modal-photo-download-link');
    if (dlLink) {
        dlLink.href = mediaUrl;
        dlLink.setAttribute('download', p.file_name);
    }

    // Contador e Navegação
    const counter = document.getElementById('modal-photo-counter');
    if (counter && googlePhotosList.length > 0) {
        counter.innerText = `${googleCurrentPhotoIndex + 1} / ${googlePhotosList.length}`;
    }

    const btnPrev = document.getElementById('btn-photo-nav-prev');
    const btnNext = document.getElementById('btn-photo-nav-next');
    if (btnPrev) btnPrev.style.visibility = (googleCurrentPhotoIndex > 0) ? 'visible' : 'hidden';
    if (btnNext) btnNext.style.visibility = (googleCurrentPhotoIndex < googlePhotosList.length - 1) ? 'visible' : 'hidden';

    if (window.lucide) lucide.createIcons();
}

function closeGooglePhotoModal() {
    const modal = document.getElementById('modal-google-photo-viewer');
    if (modal) modal.classList.add('hidden');

    const videoEl = document.getElementById('modal-photo-video');
    if (videoEl) {
        videoEl.pause();
        videoEl.src = '';
    }

    const imgEl = document.getElementById('modal-photo-img');
    if (imgEl) imgEl.src = '';
}

function navigateGooglePhoto(delta) {
    const nextIdx = googleCurrentPhotoIndex + delta;
    if (nextIdx >= 0 && nextIdx < googlePhotosList.length) {
        googleCurrentPhotoIndex = nextIdx;
        const nextPhoto = googlePhotosList[nextIdx];
        renderPhotoModalContent(nextPhoto);
    }
}

function viewPhotoInLeafletMap() {
    const btn = document.getElementById('btn-photo-view-in-map');
    if (!btn || !btn.dataset.lat) return;

    const lat = parseFloat(btn.dataset.lat);
    const lon = parseFloat(btn.dataset.lon);
    const title = btn.dataset.title || 'Foto com GPS';

    closeGooglePhotoModal();
    switchGoogleSubTab('locations');

    setTimeout(() => {
        if (googleMapInstance) {
            googleMapInstance.setView([lat, lon], 16);
            L.popup()
                .setLatLng([lat, lon])
                .setContent(`
                    <div style="font-size:12px; font-weight:bold; color:#1e293b;">
                        📸 ${escapeHtml(title)}
                        <div style="font-size:10px; color:#64748b; font-weight:normal; margin-top:2px;">
                            Coordenadas EXIF: ${lat.toFixed(6)}, ${lon.toFixed(6)}
                        </div>
                    </div>
                `)
                .openOn(googleMapInstance);
        }
    }, 400);
}

// Atalhos de teclado para o visualizador Lightbox
document.addEventListener('keydown', (e) => {
    const modal = document.getElementById('modal-google-photo-viewer');
    if (!modal || modal.classList.contains('hidden')) return;

    if (e.key === 'Escape') {
        closeGooglePhotoModal();
    } else if (e.key === 'ArrowLeft') {
        navigateGooglePhoto(-1);
    } else if (e.key === 'ArrowRight') {
        navigateGooglePhoto(1);
    }
});
// ==================== 3. GMAIL (WEBMAIL PERICIAL) ====================

function setGoogleEmailFolder(folder) {
    googleEmailFolder = folder;
    googleEmailPage = 1;

    ['all', 'inbox', 'sent', 'deleted', 'trash', 'spam'].forEach(f => {
        const btn = document.getElementById(`btn-gmail-folder-${f}`);
        if (!btn) return;
        if ((folder === 'all' && f === 'all') || (folder.toLowerCase().includes(f) && f !== 'all')) {
            btn.className = 'w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-bold bg-blue-600 text-white flex items-center justify-between shadow-2xs';
        } else {
            btn.className = 'w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between transition';
        }
    });

    loadGoogleEmails();
}

function handleGoogleEmailSearch() {
    clearTimeout(googleEmailSearchTimer);
    googleEmailSearchTimer = setTimeout(() => {
        googleEmailSearch = (document.getElementById('google-email-search-input')?.value || '').trim();
        googleEmailPage = 1;
        loadGoogleEmails();
    }, 300);
}

function changeGoogleEmailPage(delta) {
    googleEmailPage += delta;
    if (googleEmailPage < 1) googleEmailPage = 1;
    loadGoogleEmails();
}

async function loadGoogleEmails() {
    if (!googleCurrentAccount) return;
    const tbody = document.getElementById('google-emails-body');
    if (!tbody) return;

    tbody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-slate-400 font-sans">Carregando mensagens de e-mail...</td></tr>`;

    try {
        let url = `/api/google/emails?google_target_id=${googleCurrentAccount.id}&page=${googleEmailPage}&limit=${googleEmailLimit}`;
        if (googleEmailFolder && googleEmailFolder !== 'all') url += `&folder=${encodeURIComponent(googleEmailFolder)}`;
        if (googleEmailSearch) url += `&search=${encodeURIComponent(googleEmailSearch)}`;

        const res = await fetch(url);
        const data = await res.json();
        const emails = data.emails || [];
        const total = data.total || 0;
        const counts = data.folder_counts || {};

        // Atualizar contadores das pastas
        const totalAll = Object.values(counts).reduce((a, b) => a + b, 0);
        document.getElementById('cnt-gmail-all').innerText = totalAll.toLocaleString();
        document.getElementById('cnt-gmail-inbox').innerText = (counts['Caixa de Entrada'] || 0).toLocaleString();
        document.getElementById('cnt-gmail-sent').innerText = (counts['Enviados'] || 0).toLocaleString();
        document.getElementById('cnt-gmail-deleted').innerText = (counts['Excluídos'] || 0).toLocaleString();
        document.getElementById('cnt-gmail-trash').innerText = (counts['Lixeira'] || 0).toLocaleString();
        document.getElementById('cnt-gmail-spam').innerText = (counts['Spam'] || 0).toLocaleString();

        // Paginação
        const totalPages = Math.ceil(total / googleEmailLimit) || 1;
        document.getElementById('google-emails-page-info').innerText = `Página ${googleEmailPage} de ${totalPages} (${total.toLocaleString()} e-mails)`;
        document.getElementById('btn-gmail-prev').disabled = (googleEmailPage <= 1);
        document.getElementById('btn-gmail-next').disabled = (googleEmailPage >= totalPages);

        if (emails.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-slate-400 font-sans">Nenhum e-mail encontrado para esta pasta/filtro.</td></tr>`;
            return;
        }

        let html = '';
        emails.forEach(m => {
            let statusBadge = '';
            if (m.is_trash) {
                statusBadge = `<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/25">🗑️ Lixeira</span>`;
            } else if (m.is_deleted) {
                statusBadge = `<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/25">❌ Excluído</span>`;
            } else if (m.is_spam) {
                statusBadge = `<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/25">⚠️ Spam</span>`;
            } else {
                statusBadge = `<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-cyan-400 border border-blue-500/25">📥 Normal</span>`;
            }

            const attachIcon = m.has_attachments 
                ? `<span title="Contém anexos" class="text-slate-600 dark:text-slate-300">📎</span>`
                : `<span class="text-slate-300 dark:text-slate-700">·</span>`;

            html += `
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition cursor-pointer text-xs" onclick="openGoogleEmailModal(${m.id})">
                    <td class="py-2 px-3 font-mono text-[11px] whitespace-nowrap text-slate-600 dark:text-slate-400">
                        ${escapeHtml(m.date_brt || m.date_utc || '---')}
                    </td>
                    <td class="py-2 px-3">
                        ${statusBadge}
                    </td>
                    <td class="py-2 px-3 font-semibold text-slate-900 dark:text-white truncate max-w-[180px]" title="${escapeHtml(m.from_address)}">
                        ${escapeHtml(m.from_address || '---')}
                    </td>
                    <td class="py-2 px-3">
                        <div class="truncate max-w-[380px]">
                            <span class="font-bold text-slate-800 dark:text-slate-200">${escapeHtml(m.subject || 'Sem Assunto')}</span>
                            <span class="text-slate-400 text-[11px] font-normal"> — ${escapeHtml(m.snippet || '')}</span>
                        </div>
                    </td>
                    <td class="py-2 px-3 text-center">
                        ${attachIcon}
                    </td>
                    <td class="py-2 px-3 text-right">
                        <button onclick="event.stopPropagation(); openGoogleEmailModal(${m.id})" class="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-[11px] font-medium transition shadow-2xs">
                            Ver Mensagem
                        </button>
                    </td>
                </tr>
            `;
        });

        tbody.innerHTML = html;

    } catch (err) {
        console.error("Erro ao carregar e-mails do Google:", err);
        tbody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-rose-400 font-sans">Erro ao carregar e-mails.</td></tr>`;
    }
}

async function openGoogleEmailModal(emailId) {
    try {
        const res = await fetch(`/api/google/emails/${emailId}`);
        const m = await res.json();

        document.getElementById('modal-gmail-subject').innerText = m.subject || 'Sem Assunto';
        document.getElementById('modal-gmail-from').innerText = m.from_address || '---';
        document.getElementById('modal-gmail-to').innerText = m.to_address || '---';
        document.getElementById('modal-gmail-cc').innerText = m.cc_address || '---';
        document.getElementById('modal-gmail-date').innerText = m.date_brt || m.date_utc || '---';
        document.getElementById('modal-gmail-folder-badge').innerText = m.folder || 'Mensagem';

        // Anexos
        const attachBox = document.getElementById('modal-gmail-attachments-box');
        const attachList = document.getElementById('modal-gmail-attachments-list');
        if (m.attachments && m.attachments.length > 0) {
            attachBox.classList.remove('hidden');
            attachList.innerHTML = m.attachments.map(a => `
                <span class="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-[11px] font-mono inline-flex items-center space-x-1 border border-slate-200 dark:border-slate-700">
                    <span>📎</span>
                    <span>${escapeHtml(a.filename || 'anexo')}</span>
                    <span class="text-slate-400 text-[9px]">(${(a.size_bytes / 1024).toFixed(1)} KB)</span>
                </span>
            `).join('');
        } else {
            attachBox.classList.add('hidden');
            attachList.innerHTML = '';
        }

        // Corpo
        const bodyContainer = document.getElementById('modal-gmail-body-container');
        if (m.body_html) {
            bodyContainer.innerHTML = `<div class="p-3 bg-white text-black rounded-lg max-h-[450px] overflow-y-auto">${m.body_html}</div>`;
        } else {
            bodyContainer.innerHTML = `<pre class="p-3 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 rounded-lg max-h-[450px] overflow-y-auto whitespace-pre-wrap font-sans text-xs leading-relaxed">${escapeHtml(m.body_text || '(Mensagem sem conteúdo textual)')}</pre>`;
        }

        document.getElementById('modal-google-email-view').classList.remove('hidden');

    } catch (err) {
        console.error("Erro ao abrir detalhe do e-mail:", err);
        alert("Erro ao carregar conteúdo do e-mail.");
    }
}

function closeGoogleEmailModal() {
    document.getElementById('modal-google-email-view').classList.add('hidden');
}

// ==================== 4. GEOGRAFIA & MOBILIDADE (MAPS + WAZE) ====================

async function loadGoogleLocations() {
    if (!googleCurrentAccount) return;
    const tbody = document.getElementById('google-locations-body');
    if (!tbody) return;

    tbody.innerHTML = `<tr><td colspan="5" class="text-center py-6 text-slate-400">Carregando locais de mobilidade e fotos com GPS...</td></tr>`;

    try {
        // Buscar tanto os locais do Maps/Waze quanto as fotos que possuem coordenadas GPS
        const [resLoc, resPhotos] = await Promise.all([
            fetch(`/api/google/locations?google_target_id=${googleCurrentAccount.id}`),
            fetch(`/api/google/photos?google_target_id=${googleCurrentAccount.id}&media_type=gps&limit=200`)
        ]);

        const locations = await resLoc.json();
        const photosData = await resPhotos.json();
        const gpsPhotos = (photosData && photosData.photos) ? photosData.photos : [];

        const totalGeolocated = locations.length + gpsPhotos.length;
        const countBadge = document.getElementById('google-locations-count-badge');
        if (countBadge) {
            countBadge.innerText = `${totalGeolocated} pontos geolocalizados (${locations.length} Maps/Waze, ${gpsPhotos.length} Fotos GPS)`;
        }

        if (totalGeolocated === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-8 text-slate-400">
                        <div class="max-w-md mx-auto space-y-1">
                            <p class="font-semibold text-slate-700 dark:text-slate-300">Nenhum registro geográfico encontrado para esta conta</p>
                            <p class="text-xs text-slate-500">O pacote judicial Google deste alvo não continha favoritos salvos no Maps/Waze nem fotos com coordenadas GPS registradas.</p>
                        </div>
                    </td>
                </tr>
            `;
            renderGoogleLeafletMap([], []);
            return;
        }

        let html = '';

        // 1. Renderizar locais salvos (Google Maps & Waze)
        locations.forEach(loc => {
            const isMaps = (loc.source === 'maps');
            const sourceBadge = isMaps
                ? `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-cyan-400 border border-blue-500/20">🗺️ Google Maps</span>`
                : `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20">🚗 Waze</span>`;

            let typeBadge = `<span class="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">${escapeHtml(loc.location_type || 'Favorito')}</span>`;
            if (loc.location_type === 'Home') {
                typeBadge = `<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">🏠 Casa</span>`;
            } else if (loc.location_type === 'Work') {
                typeBadge = `<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30">💼 Trabalho</span>`;
            }

            html += `
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition text-xs">
                    <td class="py-2.5 px-3">${sourceBadge}</td>
                    <td class="py-2.5 px-3">${typeBadge}</td>
                    <td class="py-2.5 px-3 font-bold text-slate-900 dark:text-white">${escapeHtml(loc.name || 'Local Salvo')}</td>
                    <td class="py-2.5 px-3 text-slate-700 dark:text-slate-300">${escapeHtml(loc.address || '---')}</td>
                    <td class="py-2.5 px-3 font-mono text-[11px] text-right whitespace-nowrap">
                        <button onclick="copyToClipboard('${loc.latitude}, ${loc.longitude}')" class="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition shadow-2xs cursor-pointer inline-flex items-center space-x-1">
                            <i data-lucide="copy" class="w-3 h-3"></i>
                            <span>${loc.latitude.toFixed(4)}, ${loc.longitude.toFixed(4)}</span>
                        </button>
                    </td>
                </tr>
            `;
        });

        // 2. Renderizar fotos geolocalizadas
        gpsPhotos.forEach(p => {
            const photoBadge = `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20">📸 Google Fotos</span>`;
            const typeBadge = `<span class="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">Captura EXIF</span>`;
            const photoTitle = p.title || p.file_name || 'Foto com GPS';
            const photoDesc = p.description ? p.description : (p.capture_time_brt ? `Capturada em ${p.capture_time_brt}` : 'Mídia com GPS');

            html += `
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition text-xs cursor-pointer" onclick="focusGooglePhotoOnMap(${p.latitude}, ${p.longitude}, '${escapeHtml(photoTitle)}')">
                    <td class="py-2.5 px-3">${photoBadge}</td>
                    <td class="py-2.5 px-3">${typeBadge}</td>
                    <td class="py-2.5 px-3 font-bold text-slate-900 dark:text-white truncate max-w-[180px]" title="${escapeHtml(photoTitle)}">
                        ${escapeHtml(photoTitle)}
                    </td>
                    <td class="py-2.5 px-3 text-slate-700 dark:text-slate-300 truncate max-w-[280px]">
                        ${escapeHtml(photoDesc)}
                    </td>
                    <td class="py-2.5 px-3 font-mono text-[11px] text-right whitespace-nowrap">
                        <button onclick="event.stopPropagation(); copyToClipboard('${p.latitude}, ${p.longitude}')" class="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition shadow-2xs cursor-pointer inline-flex items-center space-x-1">
                            <i data-lucide="copy" class="w-3 h-3"></i>
                            <span>${p.latitude.toFixed(4)}, ${p.longitude.toFixed(4)}</span>
                        </button>
                    </td>
                </tr>
            `;
        });

        tbody.innerHTML = html;
        if (window.lucide) lucide.createIcons({ root: tbody });

        // Renderizar no Mapa Leaflet com os pontos do Maps/Waze e as Fotos com GPS
        renderGoogleLeafletMap(locations, gpsPhotos);

    } catch (err) {
        console.error("Erro ao carregar localizações do Google:", err);
        tbody.innerHTML = `<tr><td colspan="5" class="text-center py-6 text-rose-400">Erro ao carregar locais.</td></tr>`;
    }
}

function renderGoogleLeafletMap(locations = [], gpsPhotos = []) {
    const mapEl = document.getElementById('google-leaflet-map');
    if (!mapEl || typeof L === 'undefined') return;

    if (googleMapInstance) {
        googleMapInstance.remove();
        googleMapInstance = null;
        window.googleMapInstance = null;
    }

    const hasLocations = Array.isArray(locations) && locations.length > 0;
    const hasPhotos = Array.isArray(gpsPhotos) && gpsPhotos.length > 0;
    const hasAnyPoints = hasLocations || hasPhotos;

    let defaultLat = -14.235;
    let defaultLng = -51.925;
    let defaultZoom = 4;

    if (hasLocations && locations[0].latitude && locations[0].latitude !== -1) {
        defaultLat = locations[0].latitude;
        defaultLng = locations[0].longitude;
        defaultZoom = 13;
    } else if (hasPhotos && gpsPhotos[0].latitude) {
        defaultLat = gpsPhotos[0].latitude;
        defaultLng = gpsPhotos[0].longitude;
        defaultZoom = 13;
    }

    googleMapInstance = L.map('google-leaflet-map').setView([defaultLat, defaultLng], defaultZoom);
    window.googleMapInstance = googleMapInstance;

    // Definição das Camadas Base de Mapas
    const googleSatLayer = L.tileLayer('https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}', {
        attribution: 'Imagens © Google Maps',
        maxZoom: 20
    });

    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    });

    const googleRoadsLayer = L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
        attribution: 'Mapas © Google Maps',
        maxZoom: 20
    });

    const esriSatLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles © Esri',
        maxZoom: 19
    });

    const cartoDarkLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '© CARTO, © OpenStreetMap',
        maxZoom: 19
    });

    const topoLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles © Esri',
        maxZoom: 19
    });

    // Camada padrão inicial: Satélite Híbrido Google (fotografia real com nomes de ruas)
    googleSatLayer.addTo(googleMapInstance);

    const baseMaps = {
        "🛰️ Satélite Híbrido (Google)": googleSatLayer,
        "🗺️ Ruas Padrão (OpenStreetMap)": osmLayer,
        "🚗 Google Vias & Ruas": googleRoadsLayer,
        "🌍 Imagem Aérea (Esri)": esriSatLayer,
        "🌙 Modo Escuro (Forense)": cartoDarkLayer,
        "⛰️ Relevo Topográfico": topoLayer
    };

    // Grupos de Camadas de Sobreposição (Overlays com toggle liga/desliga)
    const locationsLayerGroup = L.layerGroup().addTo(googleMapInstance);
    const photosLayerGroup = L.layerGroup().addTo(googleMapInstance);

    const overlayMaps = {
        "📍 Locais Salvos (Maps & Waze)": locationsLayerGroup,
        "📸 Fotografias com GPS": photosLayerGroup
    };

    // Adiciona o Seletor de Camadas no canto superior direito
    L.control.layers(baseMaps, overlayMaps, {
        position: 'topright',
        collapsed: true
    }).addTo(googleMapInstance);

    const bounds = [];

    // 1. Marcadores de Maps e Waze
    if (hasLocations) {
        locations.forEach(loc => {
            if (loc.latitude == null || loc.longitude == null || (loc.latitude === -1 && loc.longitude === -1)) return;
            const pt = [loc.latitude, loc.longitude];
            bounds.push(pt);

            const marker = L.marker(pt).addTo(locationsLayerGroup);
            marker.bindPopup(`
                <div class="p-1 font-sans text-xs">
                    <b class="text-slate-900 block">${escapeHtml(loc.name)} (${escapeHtml(loc.location_type || '')})</b>
                    <span class="text-slate-600 block text-[11px] mt-0.5">${escapeHtml(loc.address)}</span>
                    <span class="text-slate-400 block font-mono text-[10px] mt-1">${loc.latitude}, ${loc.longitude} [${loc.source.toUpperCase()}]</span>
                </div>
            `);
        });
    }

    // 2. Marcadores de fotos com GPS
    if (hasPhotos) {
        gpsPhotos.forEach(p => {
            if (p.latitude == null || p.longitude == null) return;
            const pt = [p.latitude, p.longitude];
            bounds.push(pt);

            const photoIcon = L.divIcon({
                className: 'custom-photo-pin',
                html: `
                    <div style="background:#7c3aed; color:white; border-radius:50%; width:30px; height:30px; display:flex; align-items:center; justify-content:center; box-shadow:0 3px 10px rgba(124,58,237,0.5); border:2px solid white; font-size:14px; cursor:pointer;" title="${escapeHtml(p.title || p.file_name || 'Foto')}">
                        📸
                    </div>
                `,
                iconSize: [30, 30],
                iconAnchor: [15, 15],
                popupAnchor: [0, -15]
            });

            const marker = L.marker(pt, { icon: photoIcon }).addTo(photosLayerGroup);
            marker.bindPopup(`
                <div class="p-1.5 font-sans text-xs max-w-xs space-y-1">
                    <div class="flex items-center space-x-1.5 text-purple-600 dark:text-purple-400 font-bold border-b border-slate-100 dark:border-slate-800 pb-1">
                        <span>📸 Fotografia Preservada</span>
                        <span class="text-[9px] px-1 py-0.2 rounded bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 font-mono font-bold">GPS</span>
                    </div>
                    <p class="font-bold text-slate-900 dark:text-slate-100 break-all leading-snug">${escapeHtml(p.title || p.file_name || 'Fotografia')}</p>
                    <div class="text-[11px] text-slate-600 dark:text-slate-400 font-mono">
                        Coordenadas: <span class="font-bold text-emerald-600 dark:text-emerald-400">${p.latitude.toFixed(6)}, ${p.longitude.toFixed(6)}</span>
                    </div>
                    ${p.capture_time_brt ? `<div class="text-[10px] text-slate-500">Captura: ${p.capture_time_brt}</div>` : ''}
                    <div class="pt-1.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                        <button onclick="openGooglePhotoModal(${p.id})" class="text-purple-600 dark:text-purple-400 text-[10px] font-bold hover:underline">
                            Ver no Lightbox Forense ↗
                        </button>
                        <a href="https://www.google.com/maps?q=${p.latitude},${p.longitude}" target="_blank" rel="noopener noreferrer" class="text-blue-600 dark:text-cyan-400 text-[10px] underline">
                            Google Maps ↗
                        </a>
                    </div>
                </div>
            `);
        });
    }

    // Se houver uma foto pendente para focar
    if (googlePendingPhotoPin) {
        applyPhotoPinToMap(googlePendingPhotoPin);
        googlePendingPhotoPin = null;
    } else if (bounds.length > 1) {
        googleMapInstance.fitBounds(bounds, { padding: [30, 30] });
    }

    // Overlay de aviso caso não haja nenhum ponto no pacote deste alvo
    let emptyNotice = document.getElementById('google-map-empty-overlay');
    if (!hasAnyPoints) {
        if (!emptyNotice && mapEl.parentElement) {
            emptyNotice = document.createElement('div');
            emptyNotice.id = 'google-map-empty-overlay';
            emptyNotice.className = 'absolute inset-0 bg-slate-900/60 backdrop-blur-xs flex flex-col items-center justify-center text-center p-6 z-[500] pointer-events-none rounded-xl';
            emptyNotice.innerHTML = `
                <div class="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-2 shadow-xs">
                    <i data-lucide="map-pin-off" class="w-6 h-6"></i>
                </div>
                <h5 class="text-sm font-bold text-white">Nenhum Registro Geográfico no Pacote Judicial</h5>
                <p class="text-xs text-slate-300 max-w-sm mt-1">Este alvo não possuía locais salvos no Google Maps ou Waze, nem fotografias com coordenadas GPS registradas.</p>
            `;
            mapEl.parentElement.appendChild(emptyNotice);
            if (window.lucide) lucide.createIcons({ root: emptyNotice });
        } else if (emptyNotice) {
            emptyNotice.classList.remove('hidden');
        }
    } else if (emptyNotice) {
        emptyNotice.classList.add('hidden');
    }

    setTimeout(() => {
        if (googleMapInstance) googleMapInstance.invalidateSize();
    }, 250);
}

function applyPhotoPinToMap(pin) {
    if (!googleMapInstance || typeof L === 'undefined' || !pin || pin.lat == null || pin.lon == null) return;

    if (googlePhotoMarker) {
        googleMapInstance.removeLayer(googlePhotoMarker);
        googlePhotoMarker = null;
    }

    const pt = [pin.lat, pin.lon];
    const photoIcon = L.divIcon({
        className: 'custom-photo-pin',
        html: `
            <div style="background:#7c3aed; color:white; border-radius:50%; width:38px; height:38px; display:flex; align-items:center; justify-content:center; box-shadow:0 4px 14px rgba(124,58,237,0.6); border:2.5px solid white; font-size:19px; cursor:pointer;" title="Evidência Fotográfica">
                📸
            </div>
        `,
        iconSize: [38, 38],
        iconAnchor: [19, 19],
        popupAnchor: [0, -20]
    });

    googlePhotoMarker = L.marker(pt, { icon: photoIcon, zIndexOffset: 1000 }).addTo(googleMapInstance);

    googlePhotoMarker.bindPopup(`
        <div class="p-1.5 font-sans text-xs max-w-xs space-y-1">
            <div class="flex items-center space-x-1.5 text-purple-600 dark:text-purple-400 font-bold border-b border-slate-100 dark:border-slate-800 pb-1">
                <span>📸 Fotografia Preservada</span>
                <span class="text-[9px] px-1 py-0.2 rounded bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 font-mono font-bold">GPS</span>
            </div>
            <p class="font-bold text-slate-900 dark:text-slate-100 break-all leading-snug">${escapeHtml(pin.title || 'Fotografia')}</p>
            <div class="text-[11px] text-slate-600 dark:text-slate-400 font-mono">
                Coordenadas EXIF: <span class="font-bold text-emerald-600 dark:text-emerald-400">${pin.lat.toFixed(6)}, ${pin.lon.toFixed(6)}</span>
            </div>
            <div class="pt-1.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <a href="https://www.google.com/maps?q=${pin.lat},${pin.lon}" target="_blank" rel="noopener noreferrer" class="text-blue-600 dark:text-cyan-400 text-[10px] underline font-medium">
                    Google Maps Satélite ↗
                </a>
                <span class="text-[9px] text-slate-400 font-mono">LERS Custódia</span>
            </div>
        </div>
    `);

    googleMapInstance.setView(pt, 16);
    googlePhotoMarker.openPopup();

    setTimeout(() => {
        if (googleMapInstance) {
            googleMapInstance.invalidateSize();
            googleMapInstance.setView(pt, 16);
            if (googlePhotoMarker) googlePhotoMarker.openPopup();
        }
    }, 300);
}

function focusGooglePhotoOnMap(lat, lon, title) {
    if (typeof closeMediaViewer === 'function') {
        closeMediaViewer();
    }

    googlePendingPhotoPin = { lat, lon, title };

    // Se já estiver na sub-aba locations e o mapa existir
    if (googleActiveSubTab === 'locations' && googleMapInstance) {
        applyPhotoPinToMap(googlePendingPhotoPin);
        googlePendingPhotoPin = null;
        return;
    }

    // Ativa a sub-aba locations
    switchGoogleSubTab('locations');
}
window.focusGooglePhotoOnMap = focusGooglePhotoOnMap;


// ==================== 5. AUDITORIA DE CONEXÕES & IPS ====================

async function loadGoogleIps() {
    if (!googleCurrentAccount) return;
    const tbody = document.getElementById('google-ips-body');
    if (!tbody) return;

    tbody.innerHTML = `<tr><td colspan="5" class="text-center py-6 text-slate-400">Carregando logs de conexão e IPs...</td></tr>`;

    try {
        const res = await fetch(`/api/google/ips?google_target_id=${googleCurrentAccount.id}&page=${googleIpsPage}&limit=${googleIpsLimit}`);
        const data = await res.json();
        const ips = data.ips || [];
        const total = data.total || 0;

        document.getElementById('google-ips-total-badge').innerText = `${total.toLocaleString()} registros de acesso`;

        const totalPages = Math.ceil(total / googleIpsLimit) || 1;
        document.getElementById('google-ips-page-info').innerText = `Página ${googleIpsPage} de ${totalPages}`;
        document.getElementById('btn-google-ips-prev').disabled = (googleIpsPage <= 1);
        document.getElementById('btn-google-ips-next').disabled = (googleIpsPage >= totalPages);

        if (ips.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center py-6 text-slate-400">Nenhum log de conexão disponível.</td></tr>`;
            return;
        }

        let html = '';
        ips.forEach(ip => {
            html += `
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition text-xs font-mono">
                    <td class="py-2 px-3 whitespace-nowrap text-slate-800 dark:text-slate-200">
                        ${escapeHtml(ip.timestamp_brt || ip.timestamp_utc || '---')}
                    </td>
                    <td class="py-2 px-3 font-bold text-blue-600 dark:text-cyan-400">
                        ${escapeHtml(ip.clean_ip || ip.ip_address)}
                    </td>
                    <td class="py-2 px-3 font-sans">
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">${escapeHtml(ip.event_type || 'Login')}</span>
                    </td>
                    <td class="py-2 px-3 text-slate-500 font-mono text-[10px]">
                        ${escapeHtml(ip.android_id || '---')}
                    </td>
                    <td class="py-2 px-3 text-slate-500 font-sans text-[10px] truncate max-w-[280px]" title="${escapeHtml(ip.user_agent || '')}">
                        ${escapeHtml(ip.user_agent || '---')}
                    </td>
                </tr>
            `;
        });

        tbody.innerHTML = html;

    } catch (err) {
        console.error("Erro ao carregar logs de IP do Google:", err);
        tbody.innerHTML = `<tr><td colspan="5" class="text-center py-6 text-rose-400">Erro ao carregar logs de IP.</td></tr>`;
    }
}

function changeGoogleIpsPage(delta) {
    googleIpsPage += delta;
    if (googleIpsPage < 1) googleIpsPage = 1;
    loadGoogleIps();
}

// ==================== 6. MODAL DE IMPORTAÇÃO GOOGLE LERS ====================

let googleScanCache = null;
let googleImportLoadingInterval = null;

function setGoogleImportState(state) {
    const viewForm = document.getElementById('google-import-state-form');
    const viewLoading = document.getElementById('google-import-state-loading');
    const viewSuccess = document.getElementById('google-import-state-success');
    const closeBtn = document.getElementById('btn-close-google-modal');

    if (!viewForm || !viewLoading || !viewSuccess) return;

    if (state === 'form') {
        viewForm.classList.remove('hidden');
        viewLoading.classList.add('hidden');
        viewSuccess.classList.add('hidden');
        if (closeBtn) closeBtn.classList.remove('hidden');
        if (googleImportLoadingInterval) clearInterval(googleImportLoadingInterval);
    } else if (state === 'loading') {
        viewForm.classList.add('hidden');
        viewLoading.classList.remove('hidden');
        viewSuccess.classList.add('hidden');
        if (closeBtn) closeBtn.classList.add('hidden');
        startGoogleImportLoadingAnimation();
    } else if (state === 'success') {
        viewForm.classList.add('hidden');
        viewLoading.classList.add('hidden');
        viewSuccess.classList.remove('hidden');
        if (closeBtn) closeBtn.classList.remove('hidden');
        if (googleImportLoadingInterval) clearInterval(googleImportLoadingInterval);
    }
    if (window.lucide) lucide.createIcons();
}

function startGoogleImportLoadingAnimation() {
    const progressBar = document.getElementById('google-import-progress-bar');
    const loadingMsg = document.getElementById('google-import-loading-msg');
    const stepSha = document.getElementById('step-google-sha256');
    const stepSubscriber = document.getElementById('step-google-subscriber');
    const stepDevices = document.getElementById('step-google-devices');
    const stepEmails = document.getElementById('step-google-emails');
    const stepMobility = document.getElementById('step-google-mobility');

    let currentStep = 1;
    let progress = 15;

    // Resetar estilos
    if (progressBar) progressBar.style.width = '15%';
    if (loadingMsg) loadingMsg.innerText = 'Calculando integridade criptográfica SHA-256 e cadeia de custódia...';
    if (stepSha) {
        stepSha.className = 'flex items-center space-x-2 text-blue-600 dark:text-cyan-400 font-semibold';
        stepSha.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>1. Validação da cadeia de custódia e cálculo do Hash SHA-256</span>`;
    }
    if (stepSubscriber) {
        stepSubscriber.className = 'flex items-center space-x-2 text-slate-400';
        stepSubscriber.innerHTML = `<i data-lucide="circle" class="w-3.5 h-3.5"></i><span>2. Extração do Dossiê Cadastral Oficial (SubscriberInfo) e logins</span>`;
    }
    if (stepDevices) {
        stepDevices.className = 'flex items-center space-x-2 text-slate-400';
        stepDevices.innerHTML = `<i data-lucide="circle" class="w-3.5 h-3.5"></i><span>3. Mapeamento de aparelhos Android, hardware e Android IDs</span>`;
    }
    if (stepEmails) {
        stepEmails.className = 'flex items-center space-x-2 text-slate-400';
        stepEmails.innerHTML = `<i data-lucide="circle" class="w-3.5 h-3.5"></i><span>4. Indexação de webmail Gmail (MBOX), pastas e metadados</span>`;
    }
    if (stepMobility) {
        stepMobility.className = 'flex items-center space-x-2 text-slate-400';
        stepMobility.innerHTML = `<i data-lucide="circle" class="w-3.5 h-3.5"></i><span>5. Consolidação de mobilidade (Google Maps & Waze) e registros de IP</span>`;
    }
    if (window.lucide) lucide.createIcons();

    if (googleImportLoadingInterval) clearInterval(googleImportLoadingInterval);

    googleImportLoadingInterval = setInterval(() => {
        currentStep++;
        if (currentStep === 2) {
            progress = 35;
            if (progressBar) progressBar.style.width = `${progress}%`;
            if (loadingMsg) loadingMsg.innerText = 'Extraindo Dossiê Cadastral Oficial (SubscriberInfo) e logins...';
            if (stepSha) {
                stepSha.className = 'flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-medium';
                stepSha.innerHTML = `<i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-500"></i><span>1. Validação da cadeia de custódia e cálculo do Hash SHA-256</span>`;
            }
            if (stepSubscriber) {
                stepSubscriber.className = 'flex items-center space-x-2 text-blue-600 dark:text-cyan-400 font-semibold';
                stepSubscriber.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>2. Extração do Dossiê Cadastral Oficial (SubscriberInfo) e logins</span>`;
            }
        } else if (currentStep === 3) {
            progress = 60;
            if (progressBar) progressBar.style.width = `${progress}%`;
            if (loadingMsg) loadingMsg.innerText = 'Auditando aparelhos Android, hardware e conexões...';
            if (stepSubscriber) {
                stepSubscriber.className = 'flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-medium';
                stepSubscriber.innerHTML = `<i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-500"></i><span>2. Extração do Dossiê Cadastral Oficial (SubscriberInfo) e logins</span>`;
            }
            if (stepDevices) {
                stepDevices.className = 'flex items-center space-x-2 text-blue-600 dark:text-cyan-400 font-semibold';
                stepDevices.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>3. Mapeamento de aparelhos Android, hardware e Android IDs</span>`;
            }
        } else if (currentStep === 4) {
            progress = 80;
            if (progressBar) progressBar.style.width = `${progress}%`;
            if (loadingMsg) loadingMsg.innerText = 'Indexando webmail Gmail (MBOX), pastas periciais e status...';
            if (stepDevices) {
                stepDevices.className = 'flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-medium';
                stepDevices.innerHTML = `<i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-500"></i><span>3. Mapeamento de aparelhos Android, hardware e Android IDs</span>`;
            }
            if (stepEmails) {
                stepEmails.className = 'flex items-center space-x-2 text-blue-600 dark:text-cyan-400 font-semibold';
                stepEmails.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>4. Indexação de webmail Gmail (MBOX), pastas e metadados</span>`;
            }
        } else if (currentStep === 5) {
            progress = 92;
            if (progressBar) progressBar.style.width = `${progress}%`;
            if (loadingMsg) loadingMsg.innerText = 'Consolidando mobilidade geográfica e gravando no banco relacional...';
            if (stepEmails) {
                stepEmails.className = 'flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-medium';
                stepEmails.innerHTML = `<i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-500"></i><span>4. Indexação de webmail Gmail (MBOX), pastas e metadados</span>`;
            }
            if (stepMobility) {
                stepMobility.className = 'flex items-center space-x-2 text-blue-600 dark:text-cyan-400 font-semibold';
                stepMobility.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>5. Consolidação de mobilidade (Google Maps & Waze) e registros de IP</span>`;
            }
        }
        if (window.lucide) lucide.createIcons();
    }, 1500);
}

function finishGoogleImportAndGoToView() {
    closeGoogleImportModal();
    if (typeof switchTab === 'function') {
        switchTab('google');
    }
    loadGoogleView(googleCurrentOpId || currentOpId, googleCurrentPhaseId || currentPhaseId, googleCurrentTargetId || currentTargetId);
}

function openGoogleImportModal() {
    const modal = document.getElementById('modal-google-import');
    if (!modal) return;

    setGoogleImportState('form');

    // Resetar campos
    document.getElementById('google-import-folder').value = '';
    document.getElementById('google-scan-results-container').classList.add('hidden');
    document.getElementById('google-scan-initial-state').classList.remove('hidden');
    document.getElementById('btn-google-execute-import').classList.add('hidden');
    googleScanCache = null;

    modal.classList.remove('hidden');
    if (window.lucide) lucide.createIcons();
}

function closeGoogleImportModal() {
    document.getElementById('modal-google-import')?.classList.add('hidden');
    if (googleImportLoadingInterval) clearInterval(googleImportLoadingInterval);
}

async function startGooglePackageScan() {
    const folderPath = (document.getElementById('google-import-folder')?.value || '').trim();
    if (!folderPath) {
        return alert("Por favor, digite o caminho da pasta ou dos arquivos ZIP do Google.");
    }

    const opId = currentOpId || 1;
    const btnScan = document.getElementById('btn-google-start-scan');
    const originalText = btnScan.innerHTML;
    btnScan.disabled = true;
    btnScan.innerHTML = `<i data-lucide="loader" class="w-4 h-4 animate-spin inline-block"></i> <span>Escanendo e Cruzando Dados...</span>`;

    try {
        const res = await fetch('/api/google/scan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                operation_id: opId,
                folder_path: folderPath
            })
        });

        let scanResult;
        const cType = res.headers.get('content-type') || '';
        if (cType.includes('application/json')) {
            scanResult = await res.json();
        } else {
            const raw = await res.text();
            throw new Error(raw || `Erro no servidor (HTTP ${res.status})`);
        }

        if (!res.ok) {
            throw new Error(scanResult.detail || scanResult.message || `Erro ao escanear pacotes (HTTP ${res.status})`);
        }

        googleScanCache = scanResult;
        renderGoogleScanResults(googleScanCache);

    } catch (err) {
        console.error("Erro ao escanear pacotes Google:", err);
        alert(`Erro na varredura: ${err.message}`);
    } finally {
        btnScan.disabled = false;
        btnScan.innerHTML = originalText;
        if (window.lucide) lucide.createIcons();
    }
}

function renderGoogleScanResults(scanData) {
    const container = document.getElementById('google-scan-results-container');
    const listEl = document.getElementById('google-scan-accounts-list');
    const initBox = document.getElementById('google-scan-initial-state');
    const btnExec = document.getElementById('btn-google-execute-import');

    if (!container || !listEl) return;

    initBox.classList.add('hidden');
    container.classList.remove('hidden');
    btnExec.classList.remove('hidden');

    const accounts = scanData.accounts || [];
    const targets = scanData.existing_targets || [];

    document.getElementById('google-scan-total-count').innerText = `${accounts.length} contas identificadas`;

    let html = '';
    accounts.forEach((acc, idx) => {
        let confBadge = '';
        let borderClass = 'border-slate-200 dark:border-slate-800';

        if (acc.confidence === 'high') {
            confBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 inline-flex items-center space-x-1"><span>🟢</span><span>Vínculo Forte Detectado</span></span>`;
            borderClass = 'border-emerald-500/40 bg-emerald-50/20 dark:bg-emerald-950/10';
        } else if (acc.confidence === 'medium') {
            confBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30 inline-flex items-center space-x-1"><span>🟡</span><span>Sugestão por Nome</span></span>`;
            borderClass = 'border-amber-500/40 bg-amber-50/20 dark:bg-amber-950/10';
        } else {
            confBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-300 dark:border-slate-700 inline-flex items-center space-x-1"><span>⚪</span><span>Novo Alvo</span></span>`;
        }

        // Opções do Select
        let selectOptions = '';
        if (acc.suggested_action === 'link' && acc.suggested_target_id) {
            selectOptions += `<option value="link:${acc.suggested_target_id}" selected>🔗 Vincular ao Alvo: ${escapeHtml(acc.matched_target_name)} (Recomendado)</option>`;
            selectOptions += `<option value="create">➕ Criar como Novo Alvo Independente</option>`;
        } else {
            selectOptions += `<option value="create" selected>➕ Criar como Novo Alvo: ${escapeHtml(acc.full_name || acc.email)}</option>`;
        }

        targets.forEach(t => {
            if (t.id !== acc.suggested_target_id) {
                selectOptions += `<option value="link:${t.id}">Vincular ao Alvo existente: ${escapeHtml(t.name_or_alias)}</option>`;
            }
        });

        html += `
            <div class="p-3.5 rounded-xl border ${borderClass} shadow-2xs space-y-2.5">
                <div class="flex flex-wrap items-center justify-between gap-2">
                    <div class="flex items-center space-x-2">
                        <div class="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-600 dark:text-cyan-400 flex items-center justify-center font-bold">
                            <i data-lucide="mail" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <h4 class="font-bold text-xs text-slate-900 dark:text-white font-mono">${escapeHtml(acc.email)}</h4>
                            <p class="text-[11px] text-slate-600 dark:text-slate-400">${escapeHtml(acc.full_name || 'Nome não informado')} <span class="text-slate-400 font-mono">(${acc.total_size_mb} MB)</span></p>
                        </div>
                    </div>
                    ${confBadge}
                </div>

                <div class="p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800/80 text-[11px] text-slate-700 dark:text-slate-300">
                    <b>🔗 Evidência:</b> ${escapeHtml(acc.evidence_reason)}
                </div>

                <div class="flex items-center space-x-2">
                    <label class="text-[11px] font-semibold text-slate-500 whitespace-nowrap">Ação de Destino:</label>
                    <select id="google-acc-action-${idx}" class="flex-1 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-900 dark:text-slate-100 outline-none focus:border-blue-500">
                        ${selectOptions}
                    </select>
                </div>
            </div>
        `;
    });

    listEl.innerHTML = html;
    if (window.lucide) lucide.createIcons({ root: listEl });
}

async function submitGoogleExecuteImport() {
    if (!googleScanCache || !googleScanCache.accounts) return;

    const opId = currentOpId || 1;
    const phaseId = currentPhaseId || 1;

    // Montar o mapping
    const mapping = {};
    const rootFilesSet = new Set();

    googleScanCache.accounts.forEach((acc, idx) => {
        const sel = document.getElementById(`google-acc-action-${idx}`);
        const val = sel ? sel.value : 'create';

        let action = 'create';
        let targetId = null;

        if (val.startsWith('link:')) {
            action = 'link';
            targetId = parseInt(val.replace('link:', ''));
        }

        mapping[acc.email] = {
            action: action,
            target_id: targetId,
            full_name: acc.full_name,
            recovery_sms: acc.recovery_sms
        };

        (acc.root_zips || []).forEach(z => rootFilesSet.add(z));
    });

    const filePaths = Array.from(rootFilesSet);

    // Ativar Tela de Espera Animada (igual ao Instagram/WhatsApp)
    setGoogleImportState('loading');

    try {
        const res = await fetch('/api/google/import', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                operation_id: opId,
                phase_id: phaseId,
                file_paths: filePaths,
                mapping: mapping
            })
        });

        let result;
        const cType = res.headers.get('content-type') || '';
        if (cType.includes('application/json')) {
            result = await res.json();
        } else {
            const rawText = await res.text();
            throw new Error(rawText || `Erro no servidor (Código HTTP ${res.status})`);
        }

        if (!res.ok) {
            throw new Error(result.detail || result.message || `Falha na importação (HTTP ${res.status})`);
        }

        if (result.status === 'success') {
            const pb = document.getElementById('google-import-progress-bar');
            if (pb) pb.style.width = '100%';

            // Preencher resumo pericial de sucesso
            const targetsCountEl = document.getElementById('google-success-targets-count');
            const emailsCountEl = document.getElementById('google-success-emails-count');
            const devicesCountEl = document.getElementById('google-success-devices-count');
            const locationsCountEl = document.getElementById('google-success-locations-count');
            const ipsCountEl = document.getElementById('google-success-ips-count');

            if (targetsCountEl) targetsCountEl.innerText = result.imported_targets || 0;
            if (emailsCountEl) emailsCountEl.innerText = (result.total_emails || 0).toLocaleString();
            if (devicesCountEl) devicesCountEl.innerText = (result.total_devices || 0).toLocaleString();
            if (locationsCountEl) locationsCountEl.innerText = (result.total_locations || 0).toLocaleString();
            if (ipsCountEl) ipsCountEl.innerText = `${(result.total_ips || 0).toLocaleString()} registros`;

            // Ativar Tela de Sucesso
            setGoogleImportState('success');

            // Atualizar lista de alvos no topo da aplicação
            if (typeof loadTargets === 'function') {
                loadTargets(opId, phaseId);
            }
        } else {
            setGoogleImportState('form');
            alert(`Erro na importação: ${result.detail || 'Falha desconhecida'}`);
        }
    } catch (err) {
        setGoogleImportState('form');
        console.error("Erro ao executar importação do Google:", err);
        alert(`Erro na importação: ${err.message}`);
    }
}

// ==================== 7. GOOGLE CHROME: NAVEGAÇÃO & FAVORITOS ====================

function switchChromeSubView(view) {
    googleChromeCurrentSubView = view;
    const btnHist = document.getElementById('btn-chrome-sub-history');
    const btnBm = document.getElementById('btn-chrome-sub-bookmarks');
    const panelHist = document.getElementById('google-chrome-history-panel');
    const panelBm = document.getElementById('google-chrome-bookmarks-panel');
    const pag = document.getElementById('google-chrome-pagination');

    if (view === 'history') {
        if (btnHist) btnHist.className = 'px-2.5 py-1 rounded-md bg-white dark:bg-slate-800 text-blue-600 dark:text-cyan-400 shadow-xs';
        if (btnBm) btnBm.className = 'px-2.5 py-1 rounded-md text-slate-500 hover:text-slate-700 dark:hover:text-slate-300';
        if (panelHist) panelHist.classList.remove('hidden');
        if (panelBm) panelBm.classList.add('hidden');
        if (pag) pag.classList.remove('hidden');
        loadGoogleChromeHistory();
    } else {
        if (btnBm) btnBm.className = 'px-2.5 py-1 rounded-md bg-white dark:bg-slate-800 text-blue-600 dark:text-cyan-400 shadow-xs';
        if (btnHist) btnHist.className = 'px-2.5 py-1 rounded-md text-slate-500 hover:text-slate-700 dark:hover:text-slate-300';
        if (panelHist) panelHist.classList.add('hidden');
        if (panelBm) panelBm.classList.remove('hidden');
        if (pag) pag.classList.add('hidden');
        loadGoogleChromeBookmarks();
    }
}

function handleGoogleChromeSearch(event) {
    clearTimeout(googleChromeSearchTimer);
    googleChromeSearchTimer = setTimeout(() => {
        const input = document.getElementById('google-chrome-search');
        googleChromeSearch = input ? input.value.trim() : '';
        googleChromePage = 1;
        loadGoogleChromeHistory();
    }, 300);
}

function changeGoogleChromePage(delta) {
    googleChromePage += delta;
    if (googleChromePage < 1) googleChromePage = 1;
    loadGoogleChromeHistory();
}

async function loadGoogleChromeHistory() {
    if (!googleCurrentAccount) return;
    const body = document.getElementById('google-chrome-history-body');
    if (!body) return;

    body.innerHTML = `<tr><td colspan="4" class="p-8 text-center text-slate-400"><i data-lucide="loader" class="w-5 h-5 animate-spin mx-auto mb-2 text-blue-500"></i>Carregando histórico do Chrome...</td></tr>`;
    if (window.lucide) lucide.createIcons();

    try {
        let url = `/api/google/chrome/history?google_target_id=${googleCurrentAccount.id}&page=${googleChromePage}&limit=50`;
        if (googleChromeSearch) url += `&query=${encodeURIComponent(googleChromeSearch)}`;

        const res = await fetch(url);
        const data = await res.json();
        const items = data.history || [];
        const total = data.total || 0;

        const badge = document.getElementById('google-chrome-total-badge');
        if (badge) badge.innerText = `${total.toLocaleString()} páginas`;

        const bHeader = document.getElementById('google-badge-chrome');
        if (bHeader) {
            bHeader.innerText = total.toLocaleString();
            if (total > 0) bHeader.classList.remove('hidden');
            else bHeader.classList.add('hidden');
        }

        const pageInfo = document.getElementById('google-chrome-page-info');
        const maxPages = Math.ceil(total / 50) || 1;
        if (pageInfo) pageInfo.innerText = `Página ${googleChromePage} de ${maxPages} (${total.toLocaleString()} registros)`;

        const btnPrev = document.getElementById('btn-google-chrome-prev');
        const btnNext = document.getElementById('btn-google-chrome-next');
        if (btnPrev) btnPrev.disabled = (googleChromePage <= 1);
        if (btnNext) btnNext.disabled = (googleChromePage >= maxPages);

        if (items.length === 0) {
            body.innerHTML = `<tr><td colspan="4" class="p-8 text-center text-slate-400">Nenhum registro de navegação localizado no histórico deste alvo.</td></tr>`;
            return;
        }

        body.innerHTML = items.map(h => {
            const cleanTitle = escapeHtml(h.title || h.url);
            const cleanUrl = escapeHtml(h.url);
            const shortUrl = h.url.length > 75 ? escapeHtml(h.url.substring(0, 75)) + '...' : cleanUrl;
            const trans = escapeHtml(h.transition || 'LINK');

            return `
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                    <td class="py-2.5 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400 whitespace-nowrap">${h.visit_time_brt || h.visit_time_utc || '---'}</td>
                    <td class="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-100 max-w-xs break-words">${cleanTitle}</td>
                    <td class="py-2.5 px-3">
                        <a href="${cleanUrl}" target="_blank" rel="noopener noreferrer" class="text-blue-600 dark:text-cyan-400 hover:underline inline-flex items-center space-x-1 break-all" title="${cleanUrl}">
                            <span>${shortUrl}</span>
                            <i data-lucide="external-link" class="w-3 h-3 flex-shrink-0"></i>
                        </a>
                    </td>
                    <td class="py-2.5 px-3 text-center">
                        <span class="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 uppercase">${trans}</span>
                    </td>
                </tr>
            `;
        }).join('');

        if (window.lucide) lucide.createIcons();

    } catch (err) {
        console.error("Erro ao carregar histórico do Chrome:", err);
        body.innerHTML = `<tr><td colspan="4" class="p-6 text-center text-rose-500 font-semibold">Erro ao carregar histórico de navegação.</td></tr>`;
    }
}

async function loadGoogleChromeBookmarks() {
    if (!googleCurrentAccount) return;
    const container = document.getElementById('google-chrome-bookmarks-container');
    if (!container) return;

    container.innerHTML = `<div class="p-6 text-center text-slate-400"><i data-lucide="loader" class="w-5 h-5 animate-spin mx-auto mb-2 text-blue-500"></i>Carregando favoritos do Chrome...</div>`;
    if (window.lucide) lucide.createIcons();

    try {
        const res = await fetch(`/api/google/chrome/bookmarks?google_target_id=${googleCurrentAccount.id}`);
        const bookmarks = await res.json();

        if (!bookmarks || bookmarks.length === 0) {
            container.innerHTML = `<div class="p-8 text-center text-slate-400">Nenhum favorito (bookmark) localizado nos pacotes deste alvo.</div>`;
            return;
        }

        container.innerHTML = bookmarks.map(bm => {
            const cleanTitle = escapeHtml(bm.title);
            const cleanUrl = escapeHtml(bm.url);
            const cleanFolder = escapeHtml(bm.folder || 'Favoritos');
            return `
                <div class="py-2 flex items-center justify-between">
                    <div class="space-y-0.5">
                        <div class="flex items-center space-x-2">
                            <span class="px-1.5 py-0.2 rounded text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">${cleanFolder}</span>
                            <span class="font-bold text-slate-800 dark:text-slate-100 text-xs">${cleanTitle}</span>
                        </div>
                        <a href="${cleanUrl}" target="_blank" rel="noopener noreferrer" class="text-xs text-blue-600 dark:text-cyan-400 hover:underline flex items-center space-x-1">
                            <span>${cleanUrl}</span>
                            <i data-lucide="external-link" class="w-3 h-3"></i>
                        </a>
                    </div>
                    <span class="text-[10px] font-mono text-slate-400 whitespace-nowrap">${bm.date_added_brt || ''}</span>
                </div>
            `;
        }).join('');

        if (window.lucide) lucide.createIcons();

    } catch (err) {
        console.error("Erro ao carregar favoritos do Chrome:", err);
        container.innerHTML = `<div class="p-6 text-center text-rose-500 font-semibold">Erro ao carregar favoritos.</div>`;
    }
}

// ==================== 8. MINHA ATIVIDADE: PESQUISAS & ÁUDIOS DE VOZ ====================

function handleGoogleActivitySearch(event) {
    clearTimeout(googleActivitySearchTimer);
    googleActivitySearchTimer = setTimeout(() => {
        const input = document.getElementById('google-activity-search');
        googleActivitySearch = input ? input.value.trim() : '';
        googleActivityPage = 1;
        loadGoogleActivities();
    }, 300);
}

function changeGoogleActivityProduct(prod) {
    googleActivityProduct = prod;
    googleActivityPage = 1;
    loadGoogleActivities();
}

function toggleGoogleActivityAudioOnly(event) {
    googleActivityAudioOnly = event.target.checked;
    googleActivityPage = 1;
    loadGoogleActivities();
}

function changeGoogleActivitiesPage(delta) {
    googleActivityPage += delta;
    if (googleActivityPage < 1) googleActivityPage = 1;
    loadGoogleActivities();
}

async function loadGoogleActivities() {
    if (!googleCurrentAccount) return;
    const body = document.getElementById('google-activities-body');
    if (!body) return;

    body.innerHTML = `<tr><td colspan="4" class="p-8 text-center text-slate-400"><i data-lucide="loader" class="w-5 h-5 animate-spin mx-auto mb-2 text-rose-500"></i>Carregando atividades e pesquisas...</td></tr>`;
    if (window.lucide) lucide.createIcons();

    try {
        let url = `/api/google/activities?google_target_id=${googleCurrentAccount.id}&page=${googleActivityPage}&limit=50`;
        if (googleActivityProduct) url += `&product=${encodeURIComponent(googleActivityProduct)}`;
        if (googleActivityAudioOnly) url += `&has_audio=true`;
        if (googleActivitySearch) url += `&query=${encodeURIComponent(googleActivitySearch)}`;

        const res = await fetch(url);
        const data = await res.json();
        const items = data.activities || [];
        const total = data.total || 0;
        const totalAudio = data.total_audio || 0;
        const products = data.products || [];

        const prodSelect = document.getElementById('google-activity-product-select');
        if (prodSelect && prodSelect.options.length <= 1 && products.length > 0) {
            products.forEach(p => {
                const opt = document.createElement('option');
                opt.value = p;
                opt.innerText = p;
                prodSelect.appendChild(opt);
            });
            prodSelect.value = googleActivityProduct;
        }

        const totalBadge = document.getElementById('google-activities-total-badge');
        if (totalBadge) totalBadge.innerText = `${total.toLocaleString()} registros`;

        const audioBadge = document.getElementById('google-activities-audio-badge');
        const audioCount = document.getElementById('google-activities-audio-count');
        if (audioBadge && audioCount) {
            audioCount.innerText = `${totalAudio.toLocaleString()} áudios de voz`;
            if (totalAudio > 0) audioBadge.classList.remove('hidden');
            else audioBadge.classList.add('hidden');
        }

        const bHeader = document.getElementById('google-badge-activities');
        if (bHeader) {
            bHeader.innerText = total.toLocaleString();
            if (total > 0) bHeader.classList.remove('hidden');
            else bHeader.classList.add('hidden');
        }

        const pageInfo = document.getElementById('google-activities-page-info');
        const maxPages = Math.ceil(total / 50) || 1;
        if (pageInfo) pageInfo.innerText = `Página ${googleActivityPage} de ${maxPages} (${total.toLocaleString()} registros)`;

        const btnPrev = document.getElementById('btn-google-act-prev');
        const btnNext = document.getElementById('btn-google-act-next');
        if (btnPrev) btnPrev.disabled = (googleActivityPage <= 1);
        if (btnNext) btnNext.disabled = (googleActivityPage >= maxPages);

        if (items.length === 0) {
            body.innerHTML = `<tr><td colspan="4" class="p-8 text-center text-slate-400">Nenhuma pesquisa ou atividade localizada com os filtros atuais.</td></tr>`;
            return;
        }

        body.innerHTML = items.map(act => {
            const cleanAction = escapeHtml(act.action_text);
            const cleanUrl = act.target_url ? escapeHtml(act.target_url) : '';
            const prod = act.product || 'Search';

            let prodBadgeColor = 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20';
            if (prod.includes('Lens')) prodBadgeColor = 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20';
            else if (prod.includes('Image')) prodBadgeColor = 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20';
            else if (prod.includes('Discover')) prodBadgeColor = 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20';
            else if (prod.includes('YouTube')) prodBadgeColor = 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20';

            let audioPlayerHtml = '<span class="text-slate-400 text-[10px]">Sem áudio</span>';
            if (act.has_audio && act.audio_file) {
                const audioUrl = `/api/media/${act.audio_file}`;
                audioPlayerHtml = `
                    <div class="flex flex-col items-center space-y-1">
                        <span class="inline-flex items-center space-x-1 text-[9px] font-bold text-rose-600 dark:text-rose-400">
                            <span>🎙️ Gravação de Voz</span>
                        </span>
                        <audio controls class="h-7 w-56 rounded bg-slate-100 dark:bg-slate-800" preload="none" src="${audioUrl}">
                            Seu navegador não suporta áudio HTML5.
                        </audio>
                    </div>
                `;
            }

            return `
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                    <td class="py-2.5 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400 whitespace-nowrap">${act.timestamp_brt || act.timestamp_utc || '---'}</td>
                    <td class="py-2.5 px-3 whitespace-nowrap">
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold border ${prodBadgeColor}">${escapeHtml(prod)}</span>
                    </td>
                    <td class="py-2.5 px-3">
                        <div class="space-y-0.5">
                            <span class="font-bold text-slate-800 dark:text-slate-100">${cleanAction}</span>
                            ${cleanUrl ? `
                                <div>
                                    <a href="${cleanUrl}" target="_blank" rel="noopener noreferrer" class="text-[11px] text-blue-600 dark:text-cyan-400 hover:underline inline-flex items-center space-x-1">
                                        <span>Abrir resultado pesquisado</span>
                                        <i data-lucide="external-link" class="w-3 h-3"></i>
                                    </a>
                                </div>
                            ` : ''}
                        </div>
                    </td>
                    <td class="py-2.5 px-3 text-center">
                        ${audioPlayerHtml}
                    </td>
                </tr>
            `;
        }).join('');

        if (window.lucide) lucide.createIcons();

    } catch (err) {
        console.error("Erro ao carregar atividades do Google:", err);
        body.innerHTML = `<tr><td colspan="4" class="p-6 text-center text-rose-500 font-semibold">Erro ao carregar atividades e pesquisas.</td></tr>`;
    }
}

// ==================== 8. GOOGLE DRIVE (ARQUIVOS EM NUVEM) ====================

let googleDrivePage = 1;
let googleDriveCategory = '';
let googleDriveSearch = '';
let googleDriveTrashOnly = false;
let googleDriveSearchTimeout = null;

function changeGoogleDriveCategory(cat) {
    googleDriveCategory = cat;
    googleDrivePage = 1;
    loadGoogleDriveFiles();
}

function toggleGoogleDriveTrashOnly(e) {
    googleDriveTrashOnly = e.target.checked;
    googleDrivePage = 1;
    loadGoogleDriveFiles();
}

function handleGoogleDriveSearch(e) {
    if (googleDriveSearchTimeout) clearTimeout(googleDriveSearchTimeout);
    googleDriveSearchTimeout = setTimeout(() => {
        googleDriveSearch = e.target.value.trim();
        googleDrivePage = 1;
        loadGoogleDriveFiles();
    }, 350);
}

function changeGoogleDrivePage(delta) {
    googleDrivePage += delta;
    if (googleDrivePage < 1) googleDrivePage = 1;
    loadGoogleDriveFiles();
}

async function loadGoogleDriveFiles() {
    if (!googleCurrentAccount) return;

    const body = document.getElementById('google-drive-body');
    if (!body) return;

    body.innerHTML = `<tr><td colspan="5" class="text-center py-10 text-slate-400"><i data-lucide="loader-2" class="w-6 h-6 animate-spin mx-auto mb-2 text-amber-500"></i>Indexando arquivos periciais do Google Drive...</td></tr>`;
    if (window.lucide) lucide.createIcons();

    try {
        let url = `/api/google/drive?google_target_id=${googleCurrentAccount.id}&page=${googleDrivePage}&limit=50`;
        if (googleDriveCategory) url += `&file_category=${encodeURIComponent(googleDriveCategory)}`;
        if (googleDriveTrashOnly) url += `&only_trashed=true`;
        if (googleDriveSearch) url += `&search=${encodeURIComponent(googleDriveSearch)}`;

        const res = await fetch(url);
        const data = await res.json();

        // Atualizar KPIs
        const kpiTotal = document.getElementById('google-drive-kpi-total');
        if (kpiTotal) kpiTotal.innerText = (data.total_all || 0).toLocaleString();

        const kpiSize = document.getElementById('google-drive-kpi-size');
        if (kpiSize) kpiSize.innerText = `${data.total_size_formatted || '0 B'} em nuvem`;

        const kpiDocs = document.getElementById('google-drive-kpi-docs');
        if (kpiDocs) kpiDocs.innerText = (data.total_docs || 0).toLocaleString();

        const kpiImages = document.getElementById('google-drive-kpi-images');
        if (kpiImages) kpiImages.innerText = (data.total_images || 0).toLocaleString();

        const kpiTrashed = document.getElementById('google-drive-kpi-trashed');
        if (kpiTrashed) kpiTrashed.innerText = (data.total_trashed || 0).toLocaleString();

        const filteredBadge = document.getElementById('google-drive-filtered-badge');
        if (filteredBadge) filteredBadge.innerText = `${data.total || 0} arquivos`;

        // Paginação
        const totalPages = Math.ceil((data.total || 0) / 50) || 1;
        const pageInfo = document.getElementById('google-drive-page-info');
        if (pageInfo) pageInfo.innerText = `Página ${data.page || 1} de ${totalPages} (${data.total || 0} arquivos)`;

        const btnPrev = document.getElementById('btn-google-drive-prev');
        if (btnPrev) btnPrev.disabled = (data.page <= 1);

        const btnNext = document.getElementById('btn-google-drive-next');
        if (btnNext) btnNext.disabled = (data.page >= totalPages);

        if (!data.files || data.files.length === 0) {
            body.innerHTML = `<tr><td colspan="5" class="p-8 text-center text-slate-400">Nenhum arquivo do Google Drive localizado para este filtro.</td></tr>`;
            return;
        }

        body.innerHTML = data.files.map(f => {
            const name = escapeHtml(f.name || 'Arquivo sem nome');
            const mime = f.mime_type || '';
            const size = f.size_formatted || '0 B';
            const uploadIp = f.upload_ip ? escapeHtml(f.upload_ip) : '';
            const ownerName = escapeHtml(f.owner_name || '');
            const ownerEmail = escapeHtml(f.owner_email || '');
            const sha256 = f.sha256 || '';
            const shortSha = sha256 ? `${sha256.substring(0, 8)}...${sha256.substring(sha256.length - 6)}` : '';
            const actions = escapeHtml(f.actions_summary || '');

            // Ícone do arquivo
            let iconName = 'file';
            let iconColor = 'text-slate-400';
            const lowerName = (f.name || '').toLowerCase();

            if (mime.includes('pdf') || lowerName.endsWith('.pdf')) {
                iconName = 'file-text';
                iconColor = 'text-rose-500';
            } else if (mime.startsWith('image/') || lowerName.match(/\.(jpg|jpeg|png|webp|gif)$/)) {
                iconName = 'image';
                iconColor = 'text-purple-500';
            } else if (mime.includes('sheet') || lowerName.match(/\.(xls|xlsx|csv)$/)) {
                iconName = 'table';
                iconColor = 'text-emerald-500';
            } else if (mime.includes('document') || mime.includes('kix') || lowerName.match(/\.(doc|docx|odt|txt)$/)) {
                iconName = 'file-text';
                iconColor = 'text-blue-500';
            } else if (mime.startsWith('video/') || lowerName.match(/\.(mp4|mov|avi)$/)) {
                iconName = 'film';
                iconColor = 'text-cyan-500';
            } else if (mime.startsWith('audio/') || lowerName.match(/\.(mp3|wav|m4a)$/)) {
                iconName = 'mic';
                iconColor = 'text-amber-500';
            } else if (mime.includes('zip') || mime.includes('compressed') || lowerName.match(/\.(zip|rar|7z)$/)) {
                iconName = 'archive';
                iconColor = 'text-orange-500';
            }

            // Badges especiais
            let badgeHtml = '';
            if (f.is_trashed) {
                badgeHtml += `<span class="px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-100 dark:bg-rose-900/60 text-rose-700 dark:text-rose-300">Lixeira</span> `;
            }
            if (f.is_cloud_only) {
                badgeHtml += `<span class="px-1.5 py-0.5 rounded text-[9px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">Documento Nuvem</span> `;
            }

            // IP Forense
            let ipHtml = '<span class="text-slate-400 text-[11px]">—</span>';
            if (uploadIp) {
                ipHtml = `
                    <div class="flex items-center space-x-1">
                        <span class="px-2 py-0.5 rounded font-mono font-bold text-[11px] bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800">
                            ${uploadIp}
                        </span>
                    </div>
                `;
            }

            // Ações / Download
            let actionBtnHtml = '';
            if (f.file_path) {
                const fileUrl = `/api/media/${f.file_path}`;
                actionBtnHtml = `
                    <div class="flex items-center justify-center space-x-1.5">
                        <a href="${fileUrl}" target="_blank" rel="noopener noreferrer" class="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-[11px] font-semibold flex items-center space-x-1 transition" title="Abrir arquivo preservado">
                            <i data-lucide="eye" class="w-3 h-3 text-blue-500"></i>
                            <span>Ver</span>
                        </a>
                        <a href="${fileUrl}" download="${name}" class="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-[11px] font-semibold flex items-center space-x-1 transition" title="Baixar arquivo original">
                            <i data-lucide="download" class="w-3 h-3 text-emerald-500"></i>
                            <span>Baixar</span>
                        </a>
                    </div>
                `;
            } else {
                actionBtnHtml = `<span class="text-[10px] text-slate-400 font-semibold italic">Nativo Google Nuvem</span>`;
            }

            // Hash Forense
            let hashHtml = '';
            if (sha256) {
                hashHtml = `
                    <div class="mt-1 flex items-center justify-center space-x-1">
                        <span class="font-mono text-[9px] text-slate-400" title="${sha256}">SHA256: ${shortSha}</span>
                        <button onclick="navigator.clipboard.writeText('${sha256}'); alert('Hash SHA-256 copiado!');" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5" title="Copiar SHA-256 completo">
                            <i data-lucide="copy" class="w-2.5 h-2.5"></i>
                        </button>
                    </div>
                `;
            }

            return `
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                    <td class="py-2.5 px-3">
                        <div class="flex items-start space-x-2.5">
                            <div class="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 flex-shrink-0 mt-0.5">
                                <i data-lucide="${iconName}" class="w-4 h-4 ${iconColor}"></i>
                            </div>
                            <div class="min-w-0">
                                <div class="font-semibold text-slate-800 dark:text-slate-100 break-words flex items-center flex-wrap gap-1">
                                    <span>${name}</span>
                                    ${badgeHtml}
                                </div>
                                <div class="text-[10px] text-slate-400 mt-0.5 flex items-center flex-wrap gap-2">
                                    <span>Tipo: ${escapeHtml(mime || 'Não identificado')}</span>
                                    ${ownerName ? `<span>Dono: ${ownerName}</span>` : ''}
                                    ${actions ? `<span class="italic text-slate-500 font-sans">Ações: ${actions}</span>` : ''}
                                </div>
                            </div>
                        </div>
                    </td>
                    <td class="py-2.5 px-3 whitespace-nowrap">
                        <span class="font-mono font-semibold text-slate-700 dark:text-slate-300 text-[11px]">${size}</span>
                    </td>
                    <td class="py-2.5 px-3 whitespace-nowrap text-[11px]">
                        <div class="font-mono text-slate-700 dark:text-slate-300">${f.creation_date_brt || f.creation_date_utc || '---'}</div>
                        ${f.modified_date_brt ? `<div class="font-mono text-[10px] text-slate-400">Mod: ${f.modified_date_brt}</div>` : ''}
                    </td>
                    <td class="py-2.5 px-3 whitespace-nowrap">
                        ${ipHtml}
                    </td>
                    <td class="py-2.5 px-3 text-center">
                        ${actionBtnHtml}
                        ${hashHtml}
                    </td>
                </tr>
            `;
        }).join('');

        if (window.lucide) lucide.createIcons();

    } catch (err) {
        console.error("Erro ao carregar arquivos do Drive:", err);
        body.innerHTML = `<tr><td colspan="5" class="p-6 text-center text-rose-500 font-semibold">Erro ao carregar arquivos do Google Drive.</td></tr>`;
    }
}

// ==================== 9. AUDITORIA DA LINHA DO TEMPO (TIMELINE SETTINGS) ====================

async function loadTimelineSettings() {
    if (!googleCurrentAccount) return;

    const card = document.getElementById('google-timeline-card');
    const list = document.getElementById('google-timeline-devices-list');
    const badge = document.getElementById('google-timeline-summary-badge');
    if (!card || !list) return;

    try {
        const res = await fetch(`/api/google/timeline/settings?google_target_id=${googleCurrentAccount.id}`);
        const devices = await res.json();

        if (!devices || devices.length === 0) {
            card.classList.add('hidden');
            return;
        }

        card.classList.remove('hidden');
        if (badge) badge.innerText = `${devices.length} aparelhos auditados`;

        list.innerHTML = devices.map(d => {
            const name = escapeHtml(d.device_pretty_name || 'Dispositivo Android');
            const platform = escapeHtml(d.platform_type || 'ANDROID');
            const created = d.device_creation_time_brt || d.device_creation_time_utc || 'Data desconhecida';
            const changeTime = d.setting_change_time_brt || d.setting_change_time_utc || '';
            const source = escapeHtml(d.setting_change_source || '');
            const isEnabled = d.reporting_enabled === 1;

            return `
                <div class="p-2.5 rounded-lg border ${isEnabled ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800' : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'} flex flex-col justify-between space-y-2">
                    <div>
                        <div class="flex items-center justify-between">
                            <span class="font-bold text-xs text-slate-800 dark:text-slate-100 flex items-center space-x-1.5">
                                <i data-lucide="smartphone" class="w-3.5 h-3.5 ${isEnabled ? 'text-emerald-500' : 'text-slate-400'}"></i>
                                <span>${name}</span>
                            </span>
                            <span class="px-2 py-0.5 rounded text-[9px] font-bold ${isEnabled ? 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300' : 'bg-rose-100 dark:bg-rose-900/60 text-rose-700 dark:text-rose-300'}">
                                ${isEnabled ? 'Rastreamento ATIVO ✅' : 'Rastreamento DESATIVADO ⚠️'}
                            </span>
                        </div>
                        <div class="text-[10px] text-slate-400 mt-1 space-y-0.5 font-mono">
                            <div>Plataforma: ${platform}</div>
                            <div>Vinculado em: ${created}</div>
                        </div>
                    </div>
                    ${changeTime ? `
                        <div class="text-[9px] text-slate-500 pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
                            Última alteração: <span class="font-mono font-semibold">${changeTime}</span> (${source})
                        </div>
                    ` : ''}
                </div>
            `;
        }).join('');

        if (window.lucide) lucide.createIcons();

    } catch (err) {
        console.error("Erro ao carregar Timeline settings:", err);
    }
}



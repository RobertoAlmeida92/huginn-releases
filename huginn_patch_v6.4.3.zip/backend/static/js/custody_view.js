/**
 * custody_view.js
 * Módulo de Cadeia de Custódia & Auditoria de Integridade Forense (SHA-256 / MD5)
 * MetaAnalise - Forensic Intelligence Suite
 */

let custodyFilesData = [];
let custodyAuditResults = {}; // Map de custodyId -> resultado de auditoria

/**
 * Carrega a visão da Cadeia de Custódia com base nos seletores ativos
 */
async function loadCustodyView(operationId = null, phaseId = null, targetId = null) {
    const effectiveOpId = operationId || window.currentOpId;
    if (!effectiveOpId) {
        renderCustodyEmpty("Selecione uma operação para visualizar a cadeia de custódia.");
        return;
    }

    const tbody = document.getElementById('custody-table-body');
    if (tbody) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center py-8 text-slate-400 text-xs">
                    <div class="flex flex-col items-center justify-center space-y-2">
                        <i data-lucide="loader-2" class="w-6 h-6 animate-spin text-indigo-500"></i>
                        <span>Carregando registros forenses de custódia...</span>
                    </div>
                </td>
            </tr>
        `;
        if (window.lucide) lucide.createIcons();
    }

    try {
        let url = `/api/custody?operation_id=${effectiveOpId}`;
        if (phaseId) url += `&phase_id=${phaseId}`;
        if (targetId) url += `&target_id=${targetId}`;

        const res = await fetch(url);
        const data = await res.json();
        custodyFilesData = Array.isArray(data) ? data : [];

        // Atualizar KPI Cards
        updateCustodyKpis();

        // Renderizar Tabela
        renderCustodyTable(custodyFilesData);

    } catch (err) {
        console.error("Erro ao carregar cadeia de custódia:", err);
        renderCustodyEmpty("Erro ao carregar dados da custódia do servidor.");
    }
}

/**
 * Atualiza os contadores e KPI cards de integridade
 */
function updateCustodyKpis() {
    const totalElem = document.getElementById('custody-kpi-total');
    const statusElem = document.getElementById('custody-kpi-status');
    const badgeCountElem = document.getElementById('badge-custody-count');

    const total = custodyFilesData.length;
    if (totalElem) totalElem.innerText = total.toLocaleString();
    if (badgeCountElem) badgeCountElem.innerText = total.toLocaleString();

    let verifiedCount = 0;
    let corruptedCount = 0;
    let missingCount = 0;

    Object.values(custodyAuditResults).forEach(r => {
        if (r.status === 'valid') verifiedCount++;
        else if (r.status === 'corrupted') corruptedCount++;
        else if (r.status === 'missing') missingCount++;
    });

    if (statusElem) {
        if (total === 0) {
            statusElem.innerHTML = `<span class="text-slate-400 font-medium">Nenhum arquivo</span>`;
        } else if (corruptedCount > 0) {
            statusElem.innerHTML = `<span class="text-red-500 font-bold flex items-center space-x-1"><i data-lucide="alert-triangle" class="w-3.5 h-3.5 inline"></i><span>${corruptedCount} Arquivo(s) Corrompido(s)</span></span>`;
        } else if (missingCount > 0) {
            statusElem.innerHTML = `<span class="text-amber-500 font-bold flex items-center space-x-1"><i data-lucide="alert-circle" class="w-3.5 h-3.5 inline"></i><span>${missingCount} Arquivo(s) Ausente(s)</span></span>`;
        } else if (verifiedCount === total) {
            statusElem.innerHTML = `<span class="text-emerald-500 font-bold flex items-center space-x-1"><i data-lucide="shield-check" class="w-3.5 h-3.5 inline"></i><span>100% Autêntico e Íntegro</span></span>`;
        } else {
            statusElem.innerHTML = `<span class="text-blue-500 font-bold flex items-center space-x-1"><i data-lucide="clock" class="w-3.5 h-3.5 inline"></i><span>${verifiedCount}/${total} Auditados</span></span>`;
        }
    }
}

/**
 * Renderiza a tabela pericial de arquivos de custódia
 */
function renderCustodyTable(files) {
    const tbody = document.getElementById('custody-table-body');
    if (!tbody) return;

    if (!files || files.length === 0) {
        renderCustodyEmpty("Nenhuma evidência ou arquivo registrado na custódia desta operação.");
        return;
    }

    let html = '';
    files.forEach(f => {
        const audit = custodyAuditResults[f.id];
        const statusBadge = getCustodyStatusBadge(f, audit);
        const formattedSize = formatFileSize(f.file_size);
        const platformBadge = f.platform === 'whatsapp'
            ? `<span class="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 font-bold text-[10px] flex items-center space-x-1"><i data-lucide="message-circle" class="w-3 h-3"></i><span>WhatsApp</span></span>`
            : `<span class="px-2 py-0.5 rounded-md bg-pink-500/10 text-pink-600 dark:text-pink-400 border border-pink-500/20 font-bold text-[10px] flex items-center space-x-1"><i data-lucide="instagram" class="w-3 h-3"></i><span>Instagram</span></span>`;

        const targetLabel = f.target_name || f.target_identifier || `Alvo #${f.target_id}`;
        const hashDisplay = f.sha256_hash || 'N/A';
        const hashShort = hashDisplay.length > 20 ? `${hashDisplay.substring(0, 10)}...${hashDisplay.substring(hashDisplay.length - 10)}` : hashDisplay;

        html += `
            <tr class="hover:bg-slate-50/80 dark:hover:bg-slate-900/40 transition">
                <!-- 1. Status de Integridade -->
                <td class="py-3 px-3">
                    ${statusBadge}
                </td>

                <!-- 2. Arquivo & Plataforma -->
                <td class="py-3 px-3">
                    <div class="flex items-center space-x-2">
                        <div class="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center flex-shrink-0 font-bold">
                            <i data-lucide="file-archive" class="w-4 h-4"></i>
                        </div>
                        <div class="min-w-0">
                            <span class="font-bold text-xs text-slate-900 dark:text-white block truncate max-w-[200px]" title="${escapeHtml(f.file_name)}">${escapeHtml(f.file_name)}</span>
                            <div class="flex items-center space-x-2 mt-0.5">
                                ${platformBadge}
                                <span class="text-[10px] text-slate-400 font-mono">${formattedSize}</span>
                            </div>
                        </div>
                    </div>
                </td>

                <!-- 3. Alvo Vinculado -->
                <td class="py-3 px-3">
                    <span class="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-xs border border-slate-200 dark:border-slate-700 inline-block max-w-[150px] truncate" title="${escapeHtml(targetLabel)}">
                        ${escapeHtml(targetLabel)}
                    </span>
                </td>

                <!-- 4. Fase / Operação -->
                <td class="py-3 px-3">
                    <span class="text-xs text-slate-600 dark:text-slate-400 font-medium block truncate max-w-[140px]" title="${escapeHtml(f.phase_name || 'Fase 1')}">${escapeHtml(f.phase_name || 'Fase 1')}</span>
                    <span class="text-[10px] text-slate-400 block truncate max-w-[140px]">${escapeHtml(f.operation_name || '')}</span>
                </td>

                <!-- 5. Hash Calculado na Ingestão -->
                <td class="py-3 px-3">
                    <div class="space-y-1 max-w-[240px]">
                        <div class="flex items-center space-x-1.5 bg-slate-100 dark:bg-slate-950 px-2 py-1 rounded-md border border-slate-200 dark:border-slate-800">
                            <span class="font-mono text-[10px] text-slate-700 dark:text-slate-300 truncate select-all" title="${escapeHtml(hashDisplay)}">${escapeHtml(hashDisplay)}</span>
                            <button onclick="copyHashToClipboard('${escapeHtml(hashDisplay)}', 'btn-cp-${f.id}')" id="btn-cp-${f.id}" title="Copiar Hash SHA-256 completo" class="text-slate-400 hover:text-indigo-600 dark:hover:text-cyan-400 transition flex-shrink-0">
                                <i data-lucide="copy" class="w-3.5 h-3.5"></i>
                            </button>
                        </div>
                        <div class="text-[9px] text-slate-400 font-mono">Recepção: ${f.imported_at || '---'}</div>
                    </div>
                </td>

                <!-- 6. Hash Declarado (Portal Meta / LERS) -->
                <td class="py-3 px-3">
                    ${f.declared_hash ? `
                        <div class="space-y-1 max-w-[240px]">
                            <div class="flex items-center justify-between">
                                ${(f.declared_hash.trim().toLowerCase() === f.sha256_hash.trim().toLowerCase())
                                    ? `<span class="px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 text-[9px] font-bold flex items-center space-x-1"><i data-lucide="shield-check" class="w-3 h-3 text-emerald-500"></i><span>100% Match (Autêntico)</span></span>`
                                    : `<span class="px-1.5 py-0.5 rounded bg-red-500/15 text-red-700 dark:text-red-300 border border-red-500/30 text-[9px] font-bold flex items-center space-x-1 animate-pulse"><i data-lucide="alert-triangle" class="w-3 h-3 text-red-500"></i><span>Divergente</span></span>`
                                }
                                <button onclick="promptUpdateDeclaredHash(${f.id}, '${escapeHtml(f.declared_hash)}')" title="Editar Hash Declarado" class="text-slate-400 hover:text-blue-500 p-0.5 transition">
                                    <i data-lucide="edit-3" class="w-3 h-3"></i>
                                </button>
                            </div>
                            <div class="font-mono text-[10px] text-slate-600 dark:text-slate-400 truncate bg-slate-50 dark:bg-slate-950/60 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-800 select-all" title="${escapeHtml(f.declared_hash)}">
                                ${escapeHtml(f.declared_hash)}
                            </div>
                        </div>
                    ` : `
                        <button onclick="promptUpdateDeclaredHash(${f.id}, '')" class="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800/80 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-cyan-400 border border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-400 font-medium text-[10px] flex items-center space-x-1 transition">
                            <i data-lucide="plus-circle" class="w-3 h-3 text-indigo-500"></i>
                            <span>+ Informar Hash Declarado</span>
                        </button>
                    `}
                </td>

                <!-- 7. Ações de Auditoria e Download -->
                <td class="py-3 px-3 text-right whitespace-nowrap">
                    <div class="flex items-center justify-end space-x-1.5">
                        <button onclick="verifyCustodyItem(${f.id})" id="btn-audit-${f.id}" title="Auditar / Recalcular Hash em Tempo Real" class="px-2 py-1 rounded bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-cyan-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 font-bold text-[11px] flex items-center space-x-1 border border-indigo-200 dark:border-indigo-800 transition">
                            <i data-lucide="zap" class="w-3 h-3 text-indigo-500 dark:text-cyan-400"></i>
                            <span>Auditar</span>
                        </button>
                        <a href="/api/custody/${f.id}/download" download="${escapeHtml(f.file_name)}" title="Baixar Arquivo Original Bruto" class="p-1 rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition">
                            <i data-lucide="download" class="w-3.5 h-3.5"></i>
                        </a>
                    </div>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
    if (window.lucide) lucide.createIcons();
}

/**
 * Retorna o badge de status com base na auditoria
 */
function getCustodyStatusBadge(file, audit) {
    if (!audit) {
        if (file.file_exists === false) {
            return `<span class="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20 font-bold text-[10px] flex items-center space-x-1 w-fit"><i data-lucide="alert-triangle" class="w-3 h-3"></i><span>Ausente</span></span>`;
        }
        return `<span class="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-300 dark:border-slate-700 font-semibold text-[10px] flex items-center space-x-1 w-fit"><i data-lucide="shield" class="w-3 h-3 text-slate-400"></i><span>Preservado</span></span>`;
    }

    if (audit.status === 'valid') {
        return `<span class="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 font-bold text-[10px] flex items-center space-x-1 w-fit shadow-xs"><i data-lucide="check-circle" class="w-3 h-3 text-emerald-500"></i><span>100% Íntegro</span></span>`;
    } else if (audit.status === 'corrupted') {
        return `<span class="px-2 py-0.5 rounded-full bg-red-500/15 text-red-700 dark:text-red-300 border border-red-500/30 font-bold text-[10px] flex items-center space-x-1 w-fit shadow-xs animate-pulse"><i data-lucide="x-circle" class="w-3 h-3 text-red-500"></i><span>Adulterado</span></span>`;
    } else {
        return `<span class="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30 font-bold text-[10px] flex items-center space-x-1 w-fit"><i data-lucide="alert-triangle" class="w-3 h-3 text-amber-500"></i><span>Não Encontrado</span></span>`;
    }
}

/**
 * Renderiza estado vazio na tabela
 */
function renderCustodyEmpty(message) {
    const tbody = document.getElementById('custody-table-body');
    if (!tbody) return;

    tbody.innerHTML = `
        <tr>
            <td colspan="7" class="text-center py-12 text-slate-400 text-xs">
                <div class="flex flex-col items-center justify-center space-y-2">
                    <i data-lucide="shield-alert" class="w-8 h-8 text-slate-300 dark:text-slate-600"></i>
                    <span class="font-medium">${escapeHtml(message)}</span>
                </div>
            </td>
        </tr>
    `;
    if (window.lucide) lucide.createIcons();
    updateCustodyKpis();
}

/**
 * Audita um arquivo de custódia individual
 */
async function verifyCustodyItem(custodyId) {
    const btn = document.getElementById(`btn-audit-${custodyId}`);
    if (btn) {
        btn.innerHTML = `<i data-lucide="loader-2" class="w-3 h-3 animate-spin text-indigo-500"></i><span>Auditando...</span>`;
        if (window.lucide) lucide.createIcons();
    }

    try {
        const res = await fetch(`/api/custody/${custodyId}/verify`, { method: 'POST' });
        const result = await res.json();
        custodyAuditResults[custodyId] = result;

        renderCustodyTable(custodyFilesData);
        updateCustodyKpis();

        if (result.status === 'valid') {
            showToastSuccess(`✅ Evidência #${custodyId} verificada: 100% autêntica e íntegra.`);
        } else if (result.status === 'corrupted') {
            alert(`⚠️ ALERTA FORENSE:\nO arquivo #${custodyId} foi modificado ou corrompido!\nHash Original: ${result.expected_sha256}\nHash Atual: ${result.current_sha256}`);
        } else {
            alert(`⚠️ O arquivo físico da evidência #${custodyId} não foi encontrado no disco de custódia.`);
        }

    } catch (err) {
        console.error("Erro ao auditar custódia:", err);
        alert("Erro ao conectar com o servidor para auditoria.");
        if (btn) {
            btn.innerHTML = `<i data-lucide="zap" class="w-3 h-3 text-indigo-500"></i><span>Auditar</span>`;
            if (window.lucide) lucide.createIcons();
        }
    }
}

/**
 * Audita todas as evidências da operação em lote
 */
async function verifyAllCustodyItems() {
    const opId = window.currentOpId;
    if (!opId) return alert("Selecione uma operação para auditar.");

    const btnAll = document.getElementById('btn-verify-all-custody');
    if (btnAll) {
        btnAll.disabled = true;
        btnAll.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>Auditando Hashes em Disco...</span>`;
        if (window.lucide) lucide.createIcons();
    }

    try {
        const res = await fetch('/api/custody/verify-all', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                operation_id: opId,
                phase_id: window.currentPhaseId || null,
                target_id: window.currentTargetId || null
            })
        });

        const data = await res.json();
        if (Array.isArray(data.results)) {
            data.results.forEach(r => {
                custodyAuditResults[r.id] = r;
            });
        }

        renderCustodyTable(custodyFilesData);
        updateCustodyKpis();

        if (data.all_valid) {
            showToastSuccess(`🛡️ Auditoria Concluída com Sucesso: Todas as ${data.valid_count} evidências estão 100% íntegras e autênticas!`);
        } else if (data.corrupted_count > 0) {
            alert(`⚠️ ALERTA FORENSE:\n${data.corrupted_count} arquivo(s) apresentam divergência de Hash!\nVerifique a lista para detalhes.`);
        } else if (data.missing_count > 0) {
            alert(`⚠️ ATENÇÃO:\n${data.missing_count} arquivo(s) físicos não foram encontrados na pasta de custódia.`);
        }

    } catch (err) {
        console.error("Erro na auditoria em lote:", err);
        alert("Erro ao realizar auditoria completa.");
    } finally {
        if (btnAll) {
            btnAll.disabled = false;
            btnAll.innerHTML = `<i data-lucide="zap" class="w-3.5 h-3.5 fill-white"></i><span>Auditar Todas as Evidências</span>`;
            if (window.lucide) lucide.createIcons();
        }
    }
}

/**
 * Atualiza o Hash Declarado no Portal Oficial ou no Ofício Judicial com validação e recálculo
 */
async function promptUpdateDeclaredHash(custodyId, currentVal = '') {
    const input = prompt("Informe o Hash SHA-256 declarado no Portal Oficial ou no Ofício Judicial:", currentVal || '');
    if (input === null) return; // Cancelado pelo perito

    const cleanHash = input.trim();
    try {
        const res = await fetch(`/api/custody/${custodyId}/declared-hash`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ declared_hash: cleanHash || null })
        });
        const data = await res.json();
        if (res.ok) {
            showToastSuccess("Hash declarado atualizado e validado!");
            await loadCustodyView();
        } else {
            alert(data.detail || "Erro ao atualizar hash declarado.");
        }
    } catch (e) {
        console.error("Erro ao atualizar hash declarado:", e);
        alert("Falha na conexão com o servidor.");
    }
}

/**
 * Copia o Hash para a área de transferência com feedback visual
 */
function copyHashToClipboard(text, btnId) {
    if (!text || text === 'N/A') return;
    navigator.clipboard.writeText(text).then(() => {
        const btn = document.getElementById(btnId);
        if (btn) {
            const orig = btn.innerHTML;
            btn.innerHTML = `<i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i>`;
            if (window.lucide) lucide.createIcons();
            setTimeout(() => {
                btn.innerHTML = orig;
                if (window.lucide) lucide.createIcons();
            }, 1500);
        }
    }).catch(err => {
        console.error("Erro ao copiar hash:", err);
    });
}

/**
 * Abre o Modal do Termo Oficial de Custódia pronto para impressão
 */
function openCustodyReportModal() {
    const modal = document.getElementById('modal-custody-report');
    if (!modal) return;

    const opName = document.getElementById('op-select') ? document.getElementById('op-select').selectedOptions[0]?.text : 'Operação';
    const dateNow = new Date().toLocaleString('pt-BR');

    const opElem = document.getElementById('report-op-name');
    if (opElem) opElem.innerText = opName;
    const dateElem = document.getElementById('report-generated-date');
    if (dateElem) dateElem.innerText = dateNow;

    const container = document.getElementById('report-evidence-rows');
    if (container) {
        if (!custodyFilesData || custodyFilesData.length === 0) {
            container.innerHTML = `<tr><td colspan="6" class="py-4 text-center text-slate-400">Nenhuma evidência registrada nesta operação.</td></tr>`;
        } else {
            container.innerHTML = custodyFilesData.map((f, i) => {
                const audit = custodyAuditResults[f.id];
                const declaredClean = (f.declared_hash || '').trim().toLowerCase();
                const calculatedClean = (f.sha256_hash || '').trim().toLowerCase();

                let matchStatus = '';
                if (declaredClean) {
                    if (declaredClean === calculatedClean) {
                        matchStatus = '<span class="text-emerald-600 dark:text-emerald-400 font-bold text-[10px]">✅ 100% Coincidente (Autêntico)</span>';
                    } else {
                        matchStatus = '<span class="text-red-600 dark:text-red-400 font-bold text-[10px]">❌ Divergente</span>';
                    }
                } else {
                    matchStatus = audit && audit.status === 'valid'
                        ? '<span class="text-emerald-600 dark:text-emerald-400 font-medium text-[10px]">✅ Íntegro em Disco</span>'
                        : '<span class="text-slate-400 text-[10px]">Preservado (Pendente)</span>';
                }

                return `
                    <tr class="border-b border-slate-200 dark:border-slate-800 text-[11px] print:border-slate-300">
                        <td class="py-2 px-2 font-mono font-bold">${i + 1}</td>
                        <td class="py-2 px-2 font-bold max-w-[180px] truncate" title="${escapeHtml(f.file_name)}">${escapeHtml(f.file_name)}</td>
                        <td class="py-2 px-2">${escapeHtml(f.target_name || f.target_identifier || 'Alvo')}</td>
                        <td class="py-2 px-2 font-mono text-[9px] break-all select-all font-semibold text-slate-900 dark:text-white">${escapeHtml(f.sha256_hash)}</td>
                        <td class="py-2 px-2 font-mono text-[9px] break-all text-slate-600 dark:text-slate-400 select-all">${f.declared_hash ? escapeHtml(f.declared_hash) : '<span class="italic text-slate-400">Não informado</span>'}</td>
                        <td class="py-2 px-2 whitespace-nowrap">${matchStatus}</td>
                    </tr>
                `;
            }).join('');
        }
    }

    // Sincronizar inputs de analistas com os rótulos do bloco de assinatura
    const cedenteInput = document.getElementById('custody-analyst-cedente-name');
    if (cedenteInput) {
        cedenteInput.oninput = (e) => {
            const lbl = document.getElementById('custody-sig-cedente-label');
            if (lbl) lbl.innerText = e.target.value.trim() || 'Analista Cedente (Transmitente)';
        };
    }
    const receptorInput = document.getElementById('custody-analyst-receptor-name');
    if (receptorInput) {
        receptorInput.oninput = (e) => {
            const lbl = document.getElementById('custody-sig-receptor-label');
            if (lbl) lbl.innerText = e.target.value.trim() || 'Analista Receptor (Destinatário)';
        };
    }

    modal.classList.remove('hidden');
    if (window.lucide) lucide.createIcons();
}

/**
 * Fecha o Modal do Termo de Custódia
 */
function closeCustodyReportModal() {
    const modal = document.getElementById('modal-custody-report');
    if (modal) modal.classList.add('hidden');
}

/**
 * Dispara impressão do Termo Pericial
 */
function printCustodyReport() {
    window.print();
}

/**
 * Exibe notificação temporária tipo Toast
 */
function showToastSuccess(msg) {
    const toast = document.createElement('div');
    toast.className = 'fixed bottom-5 right-5 z-50 bg-slate-900 text-white dark:bg-white dark:text-slate-900 px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center space-x-2 text-xs font-semibold animate-bounce';
    toast.innerHTML = `<i data-lucide="check-circle" class="w-4 h-4 text-emerald-400"></i><span>${escapeHtml(msg)}</span>`;
    document.body.appendChild(toast);
    if (window.lucide) lucide.createIcons();
    setTimeout(() => { toast.remove(); }, 3500);
}

/**
 * Utilitário de formatação de tamanho de arquivo
 */
function formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

let networkInstance = null;
let networkPhysicsEnabled = true;

async function loadGraphView(operationId, phaseId = null, targetId = null) {
    if (!operationId) return;

    const graphContainer = document.getElementById('network-graph');
    const loadingElem = document.getElementById('graph-loading');
    loadingElem.classList.remove('hidden');

    try {
        let url = `/api/graph?operation_id=${operationId}&max_nodes=150`;
        if (phaseId) url += `&phase_id=${phaseId}`;
        if (targetId) url += `&target_id=${targetId}`;

        const res = await fetch(url);
        const graphData = await res.json();

        const nodes = new vis.DataSet(graphData.nodes || []);
        const edges = new vis.DataSet(graphData.edges || []);

        const isDark = document.documentElement.classList.contains('dark');
        const fontColor = isDark ? '#f8fafc' : '#0f172a';

        const data = { nodes, edges };
        const options = {
            nodes: {
                borderWidth: 2,
                font: {
                    color: fontColor,
                    size: 11,
                    face: 'Inter, sans-serif'
                },
                scaling: {
                    min: 10,
                    max: 40
                }
            },
            edges: {
                smooth: {
                    type: 'continuous'
                },
                width: 1.2
            },
            physics: {
                stabilization: false,
                barnesHut: {
                    gravitationalConstant: -3000,
                    springConstant: 0.04,
                    springLength: 95
                }
            },
            interaction: {
                hover: true,
                tooltipDelay: 100,
                navigationButtons: false,
                keyboard: false
            }
        };

        if (networkInstance) {
            networkInstance.destroy();
        }

        networkInstance = new vis.Network(graphContainer, data, options);
        loadingElem.classList.add('hidden');

    } catch (err) {
        console.error("Erro ao carregar grafo de vínculos:", err);
        loadingElem.classList.add('hidden');
    }
}

function fitGraph() {
    if (networkInstance) {
        networkInstance.fit({ animation: true });
    }
}

function toggleGraphPhysics() {
    if (!networkInstance) return;
    networkPhysicsEnabled = !networkPhysicsEnabled;
    networkInstance.setOptions({ physics: { enabled: networkPhysicsEnabled } });
    document.getElementById('btn-physics').innerText = networkPhysicsEnabled ? 'Pausar Física' : 'Ativar Física';
}

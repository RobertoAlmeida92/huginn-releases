let currentTimelinePlatform = 'all';

async function loadTimelineView(operationId, phaseId = null, targetId = null) {
    if (!operationId) return;

    const container = document.getElementById('timeline-container');
    try {
        let url = `/api/timeline?operation_id=${operationId}`;
        if (phaseId) url += `&phase_id=${phaseId}`;
        if (targetId) url += `&target_id=${targetId}`;
        if (currentTimelinePlatform !== 'all') url += `&platform=${currentTimelinePlatform}`;

        const res = await fetch(url);
        const events = await res.json();

        if (events.length === 0) {
            container.innerHTML = `<p class="text-xs text-slate-500">Nenhum evento registrado nesta linha do tempo.</p>`;
            return;
        }

        let html = '';
        events.forEach(e => {
            const isIg = e.platform === 'instagram';
            const badgeColor = isIg ? 'bg-pink-500/20 text-pink-400 border-pink-500/30' : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
            const iconBg = isIg ? 'bg-pink-500' : 'bg-emerald-500';

            html += `
                <div class="relative flex items-start space-x-4">
                    <div class="w-4 h-4 rounded-full ${iconBg} border-2 border-slate-900 absolute -left-[23px] top-1.5 ring-4 ring-slate-950"></div>
                    <div class="flex-1 bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
                        <div class="flex items-center justify-between">
                            <span class="font-bold text-xs text-slate-200">${escapeHtml(e.title)}</span>
                            <span class="text-[11px] font-mono text-slate-400">${e.timestamp_brt || e.timestamp_utc}</span>
                        </div>
                        <p class="text-xs text-slate-400">${escapeHtml(e.description)}</p>
                        <div class="pt-1 flex items-center space-x-2">
                            <span class="px-2 py-0.5 rounded text-[10px] font-semibold border ${badgeColor}">
                                ${e.platform.toUpperCase()}
                            </span>
                            <span class="text-[10px] text-slate-500 font-mono">Evento: ${e.event_type}</span>
                        </div>
                    </div>
                </div>
            `;
        });
        container.innerHTML = html;

    } catch (err) {
        console.error("Erro ao carregar linha do tempo:", err);
    }
}

function filterTimeline(platform) {
    currentTimelinePlatform = platform;
    document.getElementById('btn-tl-all').className = platform === 'all' ? "px-3 py-1.5 rounded-lg bg-amber-600 text-white font-medium" : "px-3 py-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-200";
    document.getElementById('btn-tl-ig').className = platform === 'instagram' ? "px-3 py-1.5 rounded-lg bg-pink-600 text-white font-medium" : "px-3 py-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-200";
    document.getElementById('btn-tl-wa').className = platform === 'whatsapp' ? "px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-medium" : "px-3 py-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-200";

    if (window.currentOpId) {
        loadTimelineView(window.currentOpId, window.currentPhaseId, window.currentTargetId);
    }
}

async function loadCustodyView(operationId, phaseId = null) {
    if (!operationId) return;

    const tbody = document.getElementById('custody-table-body');
    try {
        const res = await fetch(`/api/operations/${operationId}`);
        const opData = await res.json();
        let files = opData.custody_files || [];
        if (phaseId) {
            files = files.filter(f => f.phase_id === phaseId);
        }

        if (files.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center py-6 text-slate-500">Nenhum arquivo registrado na cadeia de custódia.</td></tr>`;
            return;
        }

        let html = '';
        files.forEach(f => {
            const sizeKb = (f.file_size / 1024).toFixed(1);
            html += `
                <tr class="table-row-hover transition">
                    <td class="py-3 px-4 font-semibold text-slate-200">${escapeHtml(f.file_name)}</td>
                    <td class="py-3 px-4 uppercase text-cyan-400 text-[11px] font-bold">${f.platform}</td>
                    <td class="py-3 px-4 text-slate-400 font-mono">${sizeKb} KB</td>
                    <td class="py-3 px-4 text-slate-300 font-mono text-[11px] select-all">${f.sha256_hash}</td>
                    <td class="py-3 px-4 text-slate-400 text-[11px]">${f.imported_at}</td>
                </tr>
            `;
        });
        tbody.innerHTML = html;
    } catch (err) {
        console.error("Erro ao carregar cadeia de custódia:", err);
    }
}

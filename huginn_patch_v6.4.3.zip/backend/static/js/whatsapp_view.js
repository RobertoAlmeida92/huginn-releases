// ==========================================
// MÓDULO FORENSE DO WHATSAPP (Meta / LERS)
// ==========================================

let waCurrentOpId = null;
let waCurrentPhaseId = null;
let waCurrentTargetId = null;
let waActiveSubTab = 'overview';

// Estado de Grupos
let waGroupsData = [];
let waGroupRoleFilter = 'all';

// Estado de Contatos
let waContactsPage = 1;
let waContactsLimit = 50;
let waContactsSearchTimer = null;

// Estado de Conexões
let waConnPage = 1;
let waConnLimit = 50;
let waConnIpVersion = 'all';

// Carregador Principal do Módulo WhatsApp
async function loadWhatsAppView(operationId, phaseId = null, targetId = null) {
    if (!operationId) return;

    waCurrentOpId = operationId;
    waCurrentPhaseId = phaseId;
    waCurrentTargetId = targetId;

    const emptyElem = document.getElementById('whatsapp-empty');
    const contentElem = document.getElementById('whatsapp-content');

    try {
        let url = `/api/whatsapp?operation_id=${operationId}`;
        if (phaseId) url += `&phase_id=${phaseId}`;
        if (targetId) url += `&target_id=${targetId}`;

        const res = await fetch(url);
        const data = await res.json();

        if (!data.target) {
            emptyElem.classList.remove('hidden');
            contentElem.classList.add('hidden');
            const badge = document.getElementById('badge-wa-count');
            if (badge) badge.innerText = '0';
            return;
        }

        emptyElem.classList.add('hidden');
        contentElem.classList.remove('hidden');

        const t = data.target;
        const stats = data.stats || {};

        // 1. Identificação do Alvo
        const phoneFormatted = formatPhoneNumber(t.phone_number);
        const nameDisplay = t.business_name || t.push_name || t.name_or_alias || phoneFormatted;
        
        document.getElementById('wa-target-name').innerText = nameDisplay;
        document.getElementById('wa-target-phone').innerText = phoneFormatted;
        document.getElementById('wa-ticket-badge').innerText = `Ticket: ${t.internal_ticket || '---'}`;
        document.getElementById('wa-logical-badge').innerText = `ID Meta: ${t.logical_id || '---'}`;

        // Avatar
        const avatarContainer = document.getElementById('wa-avatar-container');
        if (t.profile_pic_path) {
            avatarContainer.innerHTML = `<img src="/media/whatsapp/${waCurrentOpId}/${t.target_id}/${t.profile_pic_path}" class="w-full h-full object-cover" onerror="this.parentElement.innerHTML='<i data-lucide=\\'user\\' class=\\'w-7 h-7\\'></i>'; lucide.createIcons();" alt="Foto WhatsApp">`;
        } else {
            avatarContainer.innerHTML = `<i data-lucide="user" class="w-7 h-7"></i>`;
        }

        // Tipo de Conta Badge
        const accType = t.account_type || (t.business_name ? 'WhatsApp Business' : 'WhatsApp User');
        document.getElementById('wa-account-type').innerText = accType;

        // Dossiê Cadastral
        document.getElementById('wa-email').innerText = t.email || 'Não informado';
        document.getElementById('wa-created-brt').innerText = t.account_created_brt || t.account_created_utc || 'Não informado';
        document.getElementById('wa-registration-ip').innerText = t.registration_ip || '---';

        // Recado / Status
        const statusBox = document.getElementById('wa-status-box');
        const statusText = document.getElementById('wa-status-text');
        if (t.status_text && t.status_text !== 'None') {
            statusText.innerText = `"${t.status_text}"`;
            statusBox.classList.remove('hidden');
        } else {
            statusBox.classList.add('hidden');
        }

        // Informações Comerciais (SMB)
        document.getElementById('wa-biz-name').innerText = t.business_name || 'Não cadastrado';
        document.getElementById('wa-biz-email').innerText = t.business_email || '---';
        document.getElementById('wa-biz-address').innerText = t.business_address || '---';
        const webEl = document.getElementById('wa-biz-website');
        if (t.business_website) {
            webEl.innerText = t.business_website;
            webEl.href = t.business_website.startsWith('http') ? t.business_website : `https://${t.business_website}`;
            webEl.target = '_blank';
        } else {
            webEl.innerText = '---';
            webEl.removeAttribute('href');
        }
        document.getElementById('wa-date-range').innerText = t.date_range || '---';
        document.getElementById('wa-report-generated').innerText = t.report_generated_utc || '---';

        // KPIs
        document.getElementById('wa-kpi-groups').innerText = (stats.groups_count || 0).toLocaleString();
        document.getElementById('wa-kpi-contacts').innerText = (stats.contacts_count || 0).toLocaleString();
        document.getElementById('wa-kpi-devices').innerText = (stats.devices_count || 0).toLocaleString();
        document.getElementById('wa-kpi-connections').innerText = (stats.connections_count || 0).toLocaleString();

        // Badges do Header das Sub-abas
        document.getElementById('wa-badge-groups').innerText = (stats.groups_count || 0).toLocaleString();
        document.getElementById('wa-badge-contacts').innerText = (stats.contacts_count || 0).toLocaleString();
        document.getElementById('wa-badge-connections').innerText = (stats.connections_count || 0).toLocaleString();
        const badgeDev = document.getElementById('wa-badge-devices');
        if (badgeDev) badgeDev.innerText = (stats.devices_count || 0).toLocaleString();
        const devCountLabel = document.getElementById('wa-devices-count-label');
        if (devCountLabel) devCountLabel.innerText = `${(stats.devices_count || 0).toLocaleString()} aparelhos/sessões`;

        const badgeTotal = document.getElementById('badge-wa-count');
        if (badgeTotal) {
            const totalItems = (stats.groups_count || 0) + (stats.contacts_count || 0) + (stats.connections_count || 0) + (stats.devices_count || 0);
            badgeTotal.innerText = totalItems.toLocaleString();
        }

        // Renderizar Pills de Alvos WhatsApp
        renderWaTargetPills(data.available_targets || [], data.target.target_id);

        // Renderizar Aparelhos
        renderWaDevices(data.devices || []);

        // Atualizar sub-aba ativa
        if (waActiveSubTab === 'groups') loadWaGroups();
        else if (waActiveSubTab === 'contacts') loadWaContacts();
        else if (waActiveSubTab === 'connections') loadWaConnections();
        else if (waActiveSubTab === 'devices') loadWaDevices();
        else if (waActiveSubTab === 'cdr') loadWaCdrData();

        // Carregar contador de bilhetagem para a badge
        loadWaCdrBadgeCount();

        if (window.lucide) {
            const waEl = document.getElementById('view-whatsapp');
            if (waEl) lucide.createIcons({ root: waEl });
        }

    } catch (err) {
        console.error("Erro ao carregar dados do WhatsApp:", err);
    }
}

async function loadWaCdrBadgeCount() {
    if (!waCurrentOpId) return;
    try {
        let url = `/api/whatsapp/cdr?operation_id=${waCurrentOpId}`;
        if (waCurrentPhaseId) url += `&phase_id=${waCurrentPhaseId}`;
        if (waCurrentTargetId) url += `&target_id=${waCurrentTargetId}`;
        const res = await fetch(url);
        const data = await res.json();
        const badge = document.getElementById('wa-badge-cdr');
        if (badge && data.stats) {
            badge.innerText = (data.stats.total_messages || 0).toLocaleString();
        }
    } catch (e) {
        console.error("Erro ao atualizar badge de CDR:", e);
    }
}

function renderWaTargetPills(availableTargets, selectedTargetId) {
    const pillsBar = document.getElementById('wa-target-pills-bar');
    if (!pillsBar) return;

    if (!availableTargets || availableTargets.length <= 1) {
        pillsBar.classList.add('hidden');
        pillsBar.innerHTML = '';
        return;
    }

    pillsBar.classList.remove('hidden');
    let html = `
        <span class="text-[11px] font-bold text-slate-500 dark:text-slate-400 mr-1 flex items-center space-x-1">
            <i data-lucide="users" class="w-3.5 h-3.5 text-emerald-500"></i>
            <span>Alvos WhatsApp:</span>
        </span>
    `;

    const isAll = !waCurrentTargetId;
    html += `
        <button onclick="selectWaTargetFromPill(null)" class="px-2.5 py-1 text-xs font-semibold rounded-lg transition ${isAll ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 text-slate-700'}">
            Todos (${availableTargets.length})
        </button>
    `;

    availableTargets.forEach(at => {
        const isSelected = (waCurrentTargetId === at.target_id) || (!waCurrentTargetId && selectedTargetId === at.target_id);
        const name = at.business_name || at.push_name || at.name_or_alias || formatPhoneNumber(at.phone_number);
        const phone = formatPhoneNumber(at.phone_number);
        html += `
            <button onclick="selectWaTargetFromPill(${at.target_id})" class="px-2.5 py-1 text-xs font-semibold rounded-lg transition flex items-center space-x-1.5 ${isSelected ? 'bg-emerald-600 text-white shadow-sm' : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 text-slate-700'}">
                <span>${escapeHtml(name)}</span>
                <span class="font-mono text-[10px] opacity-75">(${phone})</span>
            </button>
        `;
    });

    pillsBar.innerHTML = html;
    lucide.createIcons();
}

function selectWaTargetFromPill(targetId) {
    waCurrentTargetId = targetId;
    loadWhatsAppView(waCurrentOpId, waCurrentPhaseId, targetId);
}

// Troca de Sub-abas
function switchWaSubTab(tabName) {
    waActiveSubTab = tabName;

    // Atualizar botões
    const subTabs = ['overview', 'groups', 'contacts', 'connections', 'devices', 'cdr'];
    subTabs.forEach(t => {
        const btn = document.getElementById(`wa-tab-${t}`);
        if (!btn) return;
        if (t === tabName) {
            btn.className = "wa-subtab-btn active flex-shrink-0 whitespace-nowrap h-7 px-2.5 rounded-md bg-emerald-600 text-white font-semibold text-[11px] border border-emerald-600 shadow-2xs flex items-center space-x-1.5 transition";
        } else {
            btn.className = "wa-subtab-btn flex-shrink-0 whitespace-nowrap h-7 px-2.5 rounded-md bg-slate-100/70 hover:bg-slate-200/70 text-slate-700 dark:bg-slate-950/50 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:bg-slate-800/70 border border-slate-200/80 dark:border-slate-800/80 font-semibold text-[11px] flex items-center space-x-1.5 transition";
        }
    });

    // Alternar visibilidade das sub-views
    document.querySelectorAll('.wa-subview').forEach(view => view.classList.add('hidden'));
    const activeView = document.getElementById(`wa-view-${tabName}`);
    if (activeView) activeView.classList.remove('hidden');

    if (tabName === 'groups') loadWaGroups();
    else if (tabName === 'contacts') {
        loadWaContacts();
        checkWaWebSessionStatus();
    }
    else if (tabName === 'connections') loadWaConnections();
    else if (tabName === 'devices') loadWaDevices();
    else if (tabName === 'cdr') loadWaCdrData();
}

// ----------------------------------------------------
// 1. CARREGAR E RENDERIZAR DISPOSITIVOS
// ----------------------------------------------------
async function loadWaDevices() {
    if (!waCurrentOpId) return;

    const container = document.getElementById('wa-devices-container');
    if (!container) return;
    container.innerHTML = `<p class="text-xs text-slate-400 col-span-3 text-center py-8">Carregando aparelhos e sessões...</p>`;

    try {
        let url = `/api/whatsapp/devices?operation_id=${waCurrentOpId}`;
        if (waCurrentPhaseId) url += `&phase_id=${waCurrentPhaseId}`;
        if (waCurrentTargetId) url += `&target_id=${waCurrentTargetId}`;

        const res = await fetch(url);
        const data = await res.json();
        const devices = data.devices || [];

        const devCountLabel = document.getElementById('wa-devices-count-label');
        if (devCountLabel) devCountLabel.innerText = `${devices.length.toLocaleString()} aparelhos/sessões`;
        const badgeDev = document.getElementById('wa-badge-devices');
        if (badgeDev) badgeDev.innerText = devices.length.toLocaleString();

        renderWaDevices(devices);
    } catch (err) {
        console.error("Erro ao carregar dispositivos do WhatsApp:", err);
        container.innerHTML = `<p class="text-xs text-rose-400 col-span-3 text-center py-8">Erro ao carregar aparelhos.</p>`;
    }
}

function renderWaDevices(devices) {
    const container = document.getElementById('wa-devices-container');
    if (!container) return;

    if (!devices || devices.length === 0) {
        container.innerHTML = `<p class="text-xs text-slate-400 col-span-3 text-center py-8">Nenhum aparelho ou sessão web registrada.</p>`;
        return;
    }

    let html = '';
    devices.forEach(d => {
        const isWeb = (d.device_type && d.device_type.toLowerCase().includes('web')) || (d.device_model && d.device_model.toLowerCase().includes('desktop'));
        const iconName = isWeb ? 'monitor' : 'smartphone';
        const modelName = d.device_model || (isWeb ? 'WhatsApp Web / Desktop' : 'Dispositivo Móvel');
        const mfg = d.device_manufacturer && d.device_manufacturer !== 'Device Model' ? `${d.device_manufacturer} ` : '';
        const title = `${mfg}${modelName}`.trim();
        const statusClass = d.status === 'ONLINE' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-slate-700/40 text-slate-400 border-slate-700';

        html += `
            <div class="bg-slate-50 dark:bg-slate-950/60 p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2 flex flex-col justify-between">
                <div class="flex items-start justify-between">
                    <div class="flex items-center space-x-2.5">
                        <div class="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-600 dark:text-purple-400">
                            <i data-lucide="${iconName}" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <span class="font-bold text-xs text-slate-800 dark:text-slate-200 block truncate max-w-[170px]">${escapeHtml(title)}</span>
                            <span class="text-[10px] text-slate-500 font-mono">ID: ${d.device_id || '0'} | ${d.device_type || 'App'}</span>
                        </div>
                    </div>
                    <span class="px-1.5 py-0.2 rounded text-[9px] font-bold border ${statusClass}">${d.status || 'OFFLINE'}</span>
                </div>

                <div class="pt-2 border-t border-slate-200/60 dark:border-slate-800/60 space-y-1 text-[11px]">
                    ${d.os_version ? `<div class="flex justify-between text-slate-500"><span class="text-[10px]">SO / Build:</span><span class="font-mono text-slate-700 dark:text-slate-300">${escapeHtml(d.os_version)}</span></div>` : ''}
                    ${d.app_version ? `<div class="flex justify-between text-slate-500"><span class="text-[10px]">Versão WhatsApp:</span><span class="font-mono text-slate-700 dark:text-slate-300 truncate max-w-[150px]">${escapeHtml(d.app_version)}</span></div>` : ''}
                    ${d.service_start_brt ? `<div class="flex justify-between text-slate-500"><span class="text-[10px]">Ativação:</span><span class="font-mono text-slate-700 dark:text-slate-300">${d.service_start_brt}</span></div>` : ''}
                    ${d.last_seen_brt ? `<div class="flex justify-between text-slate-500"><span class="text-[10px]">Último Acesso:</span><span class="font-mono text-slate-700 dark:text-slate-300">${d.last_seen_brt}</span></div>` : ''}
                    ${d.last_ip ? `<div class="flex justify-between text-slate-500"><span class="text-[10px]">Último IP:</span><span class="font-mono text-cyan-500 font-bold">${d.last_ip}</span></div>` : ''}
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

// ----------------------------------------------------
// 2. GRUPOS DE WHATSAPP
// ----------------------------------------------------
async function loadWaGroups() {
    if (!waCurrentOpId) return;

    const grid = document.getElementById('wa-groups-grid');
    grid.innerHTML = `<p class="text-xs text-slate-400 col-span-3 text-center py-8">Carregando grupos...</p>`;

    try {
        let url = `/api/whatsapp/groups?operation_id=${waCurrentOpId}`;
        if (waCurrentPhaseId) url += `&phase_id=${waCurrentPhaseId}`;
        if (waCurrentTargetId) url += `&target_id=${waCurrentTargetId}`;
        if (waGroupRoleFilter !== 'all') url += `&role=${waGroupRoleFilter}`;

        const search = (document.getElementById('wa-groups-search')?.value || '').trim();
        if (search) url += `&search=${encodeURIComponent(search)}`;

        const res = await fetch(url);
        const data = await res.json();
        waGroupsData = data.groups || [];

        renderWaGroups(waGroupsData);
    } catch (err) {
        console.error("Erro ao carregar grupos do WhatsApp:", err);
        grid.innerHTML = `<p class="text-xs text-rose-400 col-span-3 text-center py-8">Erro ao carregar grupos.</p>`;
    }
}

function renderWaGroups(groups) {
    const grid = document.getElementById('wa-groups-grid');
    if (!grid) return;

    if (!groups || groups.length === 0) {
        grid.innerHTML = `<p class="text-xs text-slate-400 col-span-3 text-center py-8">Nenhum grupo encontrado com os filtros selecionados.</p>`;
        return;
    }

    let html = '';
    groups.forEach(g => {
        const isOwned = g.role === 'owned';
        const roleBadge = isOwned 
            ? `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-500 border border-amber-500/30 inline-flex items-center space-x-1">👑 <span>Criador/Dono</span></span>`
            : `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 inline-flex items-center space-x-1">👥 <span>Participante</span></span>`;

        let picHtml = `
            <div class="relative w-10 h-10 rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-400 flex-shrink-0 shadow-2xs">
                <i data-lucide="users" class="w-5 h-5"></i>
                ${g.profile_pic_path ? `<img src="/media/whatsapp/${waCurrentOpId}/${g.target_id}/${g.profile_pic_path}" class="absolute inset-0 w-full h-full object-cover" onerror="this.remove()" alt="Foto do Grupo">` : ''}
            </div>
        `;

        html += `
            <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm flex flex-col justify-between space-y-3">
                <div class="flex items-start space-x-3">
                    ${picHtml}
                    <div class="flex-1 min-w-0">
                        <div class="flex items-start justify-between gap-1">
                            <h4 class="font-bold text-xs text-slate-900 dark:text-white truncate" title="${escapeHtml(g.subject || 'Grupo sem Título')}">${escapeHtml(g.subject || 'Grupo sem Título')}</h4>
                        </div>
                        <p class="text-[10px] text-slate-500 font-mono truncate mt-0.5">${g.group_jid}</p>
                    </div>
                </div>

                <div class="flex items-center justify-between">
                    ${roleBadge}
                    <span class="text-xs font-bold text-slate-700 dark:text-slate-300 font-mono bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">${g.total_participants} membros</span>
                </div>

                ${g.description ? `
                    <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 text-[11px] text-slate-600 dark:text-slate-400 line-clamp-3 italic">
                        "${escapeHtml(g.description)}"
                    </div>
                ` : ''}

                <div class="pt-2 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center text-[10px] text-slate-400">
                    <span>Criado em:</span>
                    <span class="font-mono text-slate-700 dark:text-slate-300">${g.created_at_brt || g.created_at_utc || 'Não informado'}</span>
                </div>
            </div>
        `;
    });

    grid.innerHTML = html;
    if (window.lucide) lucide.createIcons({ root: grid });
}

function filterWaGroups() {
    loadWaGroups();
}

function setWaGroupRoleFilter(role) {
    waGroupRoleFilter = role;
    ['all', 'owned', 'participating'].forEach(r => {
        const btn = document.getElementById(`btn-wa-grp-${r === 'participating' ? 'part' : r}`);
        if (btn) {
            if (r === role) {
                btn.className = 'px-2.5 py-1 text-xs font-semibold rounded-lg bg-emerald-600 text-white';
            } else {
                btn.className = 'px-2.5 py-1 text-xs font-semibold rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800';
            }
        }
    });
    loadWaGroups();
}

// ----------------------------------------------------
// 3. AGENDA DE CONTATOS
// ----------------------------------------------------
// 3. AGENDA DE CONTATOS
// ----------------------------------------------------
let waContactsFilterType = 'all';

function debounceWaContactsSearch() {
    clearTimeout(waContactsSearchTimer);
    waContactsSearchTimer = setTimeout(() => {
        waContactsPage = 1;
        loadWaContacts();
    }, 300);
}

function setWaContactsFilter(filterType) {
    waContactsFilterType = filterType;
    waContactsPage = 1;

    // Atualizar estilo visual dos botões de filtro
    const btnAll = document.getElementById('btn-wa-contacts-all');
    const btnSym = document.getElementById('btn-wa-contacts-sym');
    const btnAsym = document.getElementById('btn-wa-contacts-asym');

    const activeClasses = 'px-2.5 py-1 text-xs font-semibold rounded-lg bg-emerald-600 text-white shadow-2xs transition';
    const inactiveClasses = 'px-2.5 py-1 text-xs font-semibold rounded-lg bg-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition';

    if (btnAll) btnAll.className = (filterType === 'all') ? activeClasses : inactiveClasses;
    if (btnSym) btnSym.className = (filterType === 'symmetric') ? activeClasses : inactiveClasses;
    if (btnAsym) btnAsym.className = (filterType === 'asymmetric') ? activeClasses : inactiveClasses;

    loadWaContacts();
}

async function loadWaContacts() {
    if (!waCurrentOpId) return;

    const tbody = document.getElementById('wa-contacts-body');
    tbody.innerHTML = `<tr><td colspan="5" class="text-center py-8 text-slate-400">Carregando contatos sincronizados...</td></tr>`;

    try {
        let url = `/api/whatsapp/contacts?operation_id=${waCurrentOpId}&page=${waContactsPage}&limit=${waContactsLimit}&filter_type=${waContactsFilterType}`;
        if (waCurrentPhaseId) url += `&phase_id=${waCurrentPhaseId}`;
        if (waCurrentTargetId) url += `&target_id=${waCurrentTargetId}`;

        const search = (document.getElementById('wa-contacts-search')?.value || '').trim();
        if (search) url += `&search=${encodeURIComponent(search)}`;

        const res = await fetch(url);
        const data = await res.json();
        const contacts = data.contacts || [];
        const total = data.total || 0;
        const stats = data.stats || {};

        // Atualizar contadores nos botões de filtro
        const cAll = document.getElementById('wa-contacts-count-all');
        const cSym = document.getElementById('wa-contacts-count-sym');
        const cAsym = document.getElementById('wa-contacts-count-asym');
        if (cAll) cAll.innerText = (stats.all ?? total).toLocaleString();
        if (cSym) cSym.innerText = (stats.symmetric ?? 0).toLocaleString();
        if (cAsym) cAsym.innerText = (stats.asymmetric ?? 0).toLocaleString();

        const totalLabel = document.getElementById('wa-contacts-total-label');
        if (totalLabel) {
            let labelSuffix = 'contatos';
            if (waContactsFilterType === 'symmetric') labelSuffix = 'contatos mútuos (simétricos)';
            else if (waContactsFilterType === 'asymmetric') labelSuffix = 'contatos unilaterais (assimétricos)';
            totalLabel.innerText = `${total.toLocaleString()} ${labelSuffix}`;
        }

        if (contacts.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center py-8 text-slate-400">Nenhum contato encontrado com os filtros atuais.</td></tr>`;
            return;
        }

        let html = '';
        const offset = (waContactsPage - 1) * waContactsLimit;
        contacts.forEach((c, idx) => {
            const formatted = formatPhoneNumber(c.phone_number);
            const isSym = Boolean(c.is_symmetric);
            const symmetryBadge = isSym
                ? `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25 inline-flex items-center space-x-1" title="Vínculo Mútuo: Ambos os usuários têm o contato salvo em suas respectivas agendas">
                     <span>🤝</span>
                     <span>Mútuo (Simétrico)</span>
                   </span>`
                : `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-300 dark:border-slate-700/80 inline-flex items-center space-x-1" title="Vínculo Unilateral: Apenas o alvo investigado salvou este contato em sua agenda">
                     <span>👤</span>
                     <span>Unilateral (Salvo pelo Alvo)</span>
                   </span>`;

            const picHtml = c.profile_pic_path
                ? `<div class="w-9 h-9 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center flex-shrink-0 cursor-pointer shadow-2xs hover:scale-110 transition duration-150" onclick="openMediaViewer('/media/avatars/${c.profile_pic_path}', 'image', 'Foto de Perfil - ${formatted}')" title="Clique para ampliar a foto de perfil">
                     <img src="/media/avatars/${c.profile_pic_path}" alt="${formatted}" class="w-full h-full object-cover" onerror="this.onerror=null; this.parentElement.innerHTML='<i data-lucide=\\'user\\' class=\\'w-4 h-4 text-slate-400\\'></i>'; if (window.lucide) lucide.createIcons();">
                   </div>`
                : `<div class="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60 flex items-center justify-center text-slate-400 flex-shrink-0" title="Sem foto de perfil capturada">
                     <i data-lucide="user" class="w-4 h-4"></i>
                   </div>`;

            html += `
                <tr class="table-row-hover transition">
                    <td class="py-2.5 px-4 text-slate-500 font-mono text-[11px]">${offset + idx + 1}</td>
                    <td class="py-2 px-4">
                        ${picHtml}
                    </td>
                    <td class="py-2.5 px-4 font-bold text-slate-900 dark:text-slate-100 font-mono text-xs">
                        <div class="flex items-center space-x-2">
                            <span>${formatted}</span>
                            <a href="https://wa.me/${c.phone_number.replace(/[^0-9]/g, '')}" target="_blank" rel="noopener noreferrer" class="text-emerald-500 hover:text-emerald-600 opacity-60 hover:opacity-100 transition" title="Abrir conversa no WhatsApp Web">
                                <i data-lucide="external-link" class="w-3 h-3"></i>
                            </a>
                        </div>
                    </td>
                    <td class="py-2.5 px-4">
                        ${symmetryBadge}
                    </td>
                    <td class="py-2.5 px-4 text-right">
                        <button onclick="copyToClipboard('${c.phone_number}')" class="px-2.5 py-1 text-[11px] font-medium rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 inline-flex items-center space-x-1 transition shadow-2xs cursor-pointer" title="Copiar Número">
                            <i data-lucide="copy" class="w-3 h-3"></i>
                            <span>Copiar</span>
                        </button>
                    </td>
                </tr>
            `;
        });
        tbody.innerHTML = html;

        // Paginação
        const totalPages = Math.ceil(total / waContactsLimit) || 1;
        document.getElementById('wa-contacts-page-info').innerText = `Página ${waContactsPage} de ${totalPages} (${total.toLocaleString()} contatos)`;
        document.getElementById('btn-wa-contacts-prev').disabled = (waContactsPage <= 1);
        if (window.lucide) {
            const cEl = document.getElementById('wa-view-contacts');
            if (cEl) lucide.createIcons({ root: cEl });
        }

    } catch (err) {
        console.error("Erro ao carregar contatos do WhatsApp:", err);
        tbody.innerHTML = `<tr><td colspan="5" class="text-center py-8 text-rose-400">Erro ao carregar contatos.</td></tr>`;
    }
}

function changeWaContactsPage(delta) {
    waContactsPage += delta;
    if (waContactsPage < 1) waContactsPage = 1;
    loadWaContacts();
}

// ----------------------------------------------------
// 4. INTELIGÊNCIA DE IPS & CONEXÕES
// ----------------------------------------------------
async function loadWaConnections() {
    if (!waCurrentOpId) return;

    const tbody = document.getElementById('wa-connections-body');
    tbody.innerHTML = `<tr><td colspan="4" class="text-center py-8 text-slate-400">Carregando logs de conexão...</td></tr>`;

    try {
        let url = `/api/whatsapp/connections?operation_id=${waCurrentOpId}&page=${waConnPage}&limit=${waConnLimit}&ip_version=${waConnIpVersion}`;
        if (waCurrentPhaseId) url += `&phase_id=${waCurrentPhaseId}`;
        if (waCurrentTargetId) url += `&target_id=${waCurrentTargetId}`;

        const res = await fetch(url);
        const data = await res.json();
        const stats = data.stats || {};
        const rankedIps = data.ranked_ips || [];
        const timeline = data.timeline || [];
        const total = data.total || 0;

        // 1. Atualizar KPIs
        document.getElementById('wa-conn-total').innerText = (stats.total_connections || 0).toLocaleString();
        document.getElementById('wa-conn-unique').innerText = (stats.unique_ips_count || 0).toLocaleString();
        document.getElementById('wa-conn-top-ip').innerText = stats.top_ip || '---';
        document.getElementById('wa-conn-top-isp').innerText = `${stats.top_ip_isp || '---'} (${stats.top_ip_percent || 0}% dos acessos)`;
        document.getElementById('wa-conn-range-first').innerText = stats.first_activity_brt || '---';
        document.getElementById('wa-conn-range-last').innerText = `até ${stats.last_activity_brt || '---'}`;

        // 2. Renderizar Ranking de Top IPs
        renderWaRankedIps(rankedIps, stats.total_connections || 1);

        // 3. Renderizar Tabela da Linha do Tempo
        document.getElementById('wa-conn-timeline-count').innerText = `${total.toLocaleString()} conexões`;
        if (timeline.length === 0) {
            tbody.innerHTML = `<tr><td colspan="4" class="text-center py-8 text-slate-400">Nenhum registro de conexão encontrado.</td></tr>`;
            return;
        }

        let html = '';
        timeline.forEach(c => {
            html += `
                <tr class="table-row-hover transition">
                    <td class="py-2.5 px-4 text-slate-900 dark:text-slate-200 font-bold text-xs">${c.timestamp_brt || '---'}</td>
                    <td class="py-2.5 px-4 text-slate-500 font-mono text-[11px]">${c.timestamp_utc}</td>
                    <td class="py-2.5 px-4 font-mono font-bold text-cyan-600 dark:text-cyan-400 text-xs">${c.source_ip}</td>
                    <td class="py-2.5 px-4">
                        <span class="px-2 py-0.5 rounded text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 uppercase">
                            ${c.event_type || 'CONEXÃO'}
                        </span>
                    </td>
                </tr>
            `;
        });
        tbody.innerHTML = html;

        // Paginação
        const totalPages = Math.ceil(total / waConnLimit) || 1;
        document.getElementById('wa-conn-page-info').innerText = `Página ${waConnPage} de ${totalPages} (${total.toLocaleString()} conexões)`;
        document.getElementById('btn-wa-conn-prev').disabled = (waConnPage <= 1);
        document.getElementById('btn-wa-conn-next').disabled = (waConnPage >= totalPages);

    } catch (err) {
        console.error("Erro ao carregar conexões do WhatsApp:", err);
        tbody.innerHTML = `<tr><td colspan="4" class="text-center py-8 text-rose-400">Erro ao carregar registros.</td></tr>`;
    }
}

function renderWaRankedIps(rankedIps, totalConns) {
    const container = document.getElementById('wa-ranked-ips-container');
    if (!container) return;

    if (!rankedIps || rankedIps.length === 0) {
        container.innerHTML = `<p class="text-xs text-slate-400 py-4 text-center">Nenhum IP classificado.</p>`;
        return;
    }

    let html = '';
    rankedIps.forEach((r, idx) => {
        const pct = r.percentage || 0;
        html += `
            <div class="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1.5">
                <div class="flex items-center justify-between text-xs">
                    <div class="flex items-center space-x-2">
                        <span class="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center font-mono text-[10px] font-bold text-slate-600 dark:text-slate-300">${idx + 1}</span>
                        <span class="font-mono font-bold text-cyan-600 dark:text-cyan-400">${r.ip_address}</span>
                        <span class="text-[11px] text-slate-500 dark:text-slate-400 font-medium">(${escapeHtml(r.isp)})</span>
                    </div>
                    <div class="flex items-center space-x-2 font-mono text-xs">
                        <span class="font-bold text-slate-900 dark:text-slate-100">${r.count.toLocaleString()} conexões</span>
                        <span class="text-emerald-500 font-bold">(${pct}%)</span>
                    </div>
                </div>
                <div class="w-full bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div class="bg-gradient-to-r from-emerald-500 to-cyan-500 h-full rounded-full" style="width: ${Math.max(pct, 2)}%"></div>
                </div>
                <div class="flex justify-between items-center text-[10px] text-slate-400">
                    <span>Primeiro: ${r.first_seen_brt || '---'} | Último: ${r.last_seen_brt || '---'}</span>
                    ${r.whois_url ? `<a href="${r.whois_url}" target="_blank" class="text-blue-500 hover:underline">Consultar WHOIS →</a>` : ''}
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

function setWaIpVersionFilter(version) {
    waConnIpVersion = version;
    waConnPage = 1;
    ['all', 'ipv4', 'ipv6'].forEach(v => {
        const btnId = `btn-wa-ip-${v === 'ipv4' ? 'v4' : (v === 'ipv6' ? 'v6' : 'all')}`;
        const btn = document.getElementById(btnId);
        if (btn) {
            if (v === version) {
                btn.className = 'px-2 py-0.5 text-[10px] font-semibold rounded bg-emerald-600 text-white';
            } else {
                btn.className = 'px-2 py-0.5 text-[10px] font-semibold rounded text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800';
            }
        }
    });
    loadWaConnections();
}

function changeWaConnPage(delta) {
    waConnPage += delta;
    if (waConnPage < 1) waConnPage = 1;
    loadWaConnections();
}

// ----------------------------------------------------
// UTILITÁRIOS
// ----------------------------------------------------
function formatPhoneNumber(phone) {
    if (!phone) return 'Telefone não informado';
    let clean = phone.replace(/\D/g, '');
    if (clean.startsWith('55') && clean.length >= 12) {
        const ddi = clean.substring(0, 2);
        const ddd = clean.substring(2, 4);
        const num = clean.substring(4);
        if (num.length === 9) {
            return `+${ddi} (${ddd}) ${num.substring(0, 5)}-${num.substring(5)}`;
        } else if (num.length === 8) {
            return `+${ddi} (${ddd}) ${num.substring(0, 4)}-${num.substring(4)}`;
        }
    }
    return phone.startsWith('+') ? phone : `+${phone}`;
}

// ====================================================
// CONTROLADOR DE BILHETAGEM & CDRs DO WHATSAPP
// ====================================================

let waCdrCurrentSubView = 'interlocutors';
let waCdrBatchFile = '';
let waCdrIsolatedContact = '';
let waCdrMediaTypeFilter = '';
let waCdrDirectionFilter = '';
let waCdrSearchQuery = '';
let waCdrPage = 1;
let waCdrLimit = 50;
let waCdrDataCache = null;
let waCdrMapInstance = null;

async function loadWaCdrData() {
    if (!waCurrentOpId) return;

    try {
        let url = `/api/whatsapp/cdr?operation_id=${waCurrentOpId}`;
        if (waCurrentPhaseId) url += `&phase_id=${waCurrentPhaseId}`;
        if (waCurrentTargetId) url += `&target_id=${waCurrentTargetId}`;
        if (waCdrBatchFile) url += `&batch_file=${encodeURIComponent(waCdrBatchFile)}`;

        const res = await fetch(url);
        const data = await res.json();
        waCdrDataCache = data;

        const stats = data.stats || {};
        const mediaBreakdown = stats.media_breakdown || {};
        const callsStats = stats.calls_stats || {};

        // 1. Atualizar KPI Cards
        document.getElementById('wa-cdr-kpi-total-msgs').innerText = (stats.total_messages || 0).toLocaleString();
        
        const voiceCnt = (mediaBreakdown['voice'] || 0) + (mediaBreakdown['audio'] || 0);
        const imgVidCnt = (mediaBreakdown['image'] || 0) + (mediaBreakdown['video'] || 0);
        const textCnt = mediaBreakdown['text'] || 0;
        document.getElementById('wa-cdr-kpi-msgs-sub').innerText = `${textCnt.toLocaleString()} textos • ${voiceCnt.toLocaleString()} áudios • ${imgVidCnt.toLocaleString()} mídias`;

        document.getElementById('wa-cdr-kpi-total-calls').innerText = (stats.total_calls || 0).toLocaleString();
        document.getElementById('wa-cdr-kpi-calls-sub').innerText = `${(callsStats.accepted || 0).toLocaleString()} atendidas • ${(callsStats.rejected || 0).toLocaleString()} recusadas • ${(callsStats.missed || 0).toLocaleString()} perdidas`;

        document.getElementById('wa-cdr-kpi-unique-contacts').innerText = (stats.unique_contacts_count || 0).toLocaleString();
        const topInter = (data.interlocutors && data.interlocutors.length > 0) ? data.interlocutors[0] : null;
        if (topInter) {
            document.getElementById('wa-cdr-kpi-top-contact').innerText = `Principal: ${formatPhoneNumber(topInter.contact_phone)} (${topInter.total_msgs.toLocaleString()} msgs)`;
        } else {
            document.getElementById('wa-cdr-kpi-top-contact').innerText = `Principal: ---`;
        }

        const batchesCnt = data.total_batches_count || 0;
        document.getElementById('wa-cdr-kpi-batches-count').innerText = `${batchesCnt} lote(s) diário(s) Meta`;
        if (stats.first_activity_brt && stats.first_activity_brt !== '---') {
            document.getElementById('wa-cdr-kpi-period').innerText = `${stats.first_activity_brt.split(' ')[0]} a ${stats.last_activity_brt.split(' ')[0]}`;
        } else {
            document.getElementById('wa-cdr-kpi-period').innerText = '---';
        }

        // Atualizar badges dos contadores de mídia
        const voiceBadge = document.getElementById('cnt-cdr-voice');
        if (voiceBadge) voiceBadge.innerText = voiceCnt.toLocaleString();
        const imgBadge = document.getElementById('cnt-cdr-image');
        if (imgBadge) imgBadge.innerText = (mediaBreakdown['image'] || 0).toLocaleString();
        const vidBadge = document.getElementById('cnt-cdr-video');
        if (vidBadge) vidBadge.innerText = (mediaBreakdown['video'] || 0).toLocaleString();
        const txtBadge = document.getElementById('cnt-cdr-text');
        if (txtBadge) txtBadge.innerText = textCnt.toLocaleString();
        const locBadge = document.getElementById('cnt-cdr-location');
        if (locBadge) locBadge.innerText = (mediaBreakdown['location'] || 0).toLocaleString();

        // 2. Atualizar Dropdown de Lotes Diários
        renderWaCdrBatchDropdown(data.daily_batches || []);

        // 3. Renderizar Sub-visão Ativa
        if (waCdrCurrentSubView === 'interlocutors') {
            renderWaCdrInterlocutors(data.interlocutors || []);
        } else if (waCdrCurrentSubView === 'timeline') {
            loadWaCdrMessages();
        } else if (waCdrCurrentSubView === 'calls') {
            renderWaCdrCalls(data.calls || []);
        } else if (waCdrCurrentSubView === 'map') {
            renderWaCdrMap(data.geo_points || []);
        }
        if (window.lucide) {
            const cdrEl = document.getElementById('wa-view-cdr');
            if (cdrEl) lucide.createIcons({ root: cdrEl });
        }

    } catch (e) {
        console.error("Erro ao carregar inteligência CDR do WhatsApp:", e);
    }
}

function formatShortDateRange(rawRange) {
    if (!rawRange) return '';
    const matches = rawRange.match(/\d{4}-\d{2}-\d{2}/g);
    if (matches && matches.length >= 2) {
        const d1 = matches[0].split('-');
        const d2 = matches[1].split('-');
        if (d1.length === 3 && d2.length === 3) {
            return `${d1[2]}/${d1[1]} a ${d2[2]}/${d2[1]}`;
        }
    } else if (matches && matches.length === 1) {
        const d = matches[0].split('-');
        return `${d[2]}/${d[1]}`;
    }
    return '';
}

function renderWaCdrBatchDropdown(batches) {
    const select = document.getElementById('wa-cdr-batch-select');
    if (!select) return;

    const currentVal = waCdrBatchFile;
    const totalMsgs = batches.reduce((acc, b) => acc + (b.messages_count || 0), 0);
    let html = `<option value="">📅 Todos os Lotes (${batches.length} dias • ${totalMsgs.toLocaleString()} msgs)</option>`;
    batches.forEach((b, idx) => {
        const isSel = (b.batch_file_name === currentVal) ? 'selected' : '';
        const shortDate = formatShortDateRange(b.batch_day_date);
        const dateStr = shortDate ? ` (${shortDate})` : '';
        html += `<option value="${escapeHtml(b.batch_file_name)}" ${isSel}>Lote ${idx + 1}${dateStr} • ${b.messages_count.toLocaleString()} msgs</option>`;
    });
    select.innerHTML = html;
}

function onWaCdrBatchChange() {
    const select = document.getElementById('wa-cdr-batch-select');
    if (select) {
        waCdrBatchFile = select.value;
        waCdrPage = 1;
        loadWaCdrData();
    }
}

function switchWaCdrView(viewName) {
    waCdrCurrentSubView = viewName;

    // Atualizar botões
    ['interlocutors', 'timeline', 'calls', 'map'].forEach(v => {
        const btn = document.getElementById(`wa-cdr-btn-${v}`);
        const container = document.getElementById(`wa-cdr-view-${v}`);
        if (btn) {
            if (v === viewName) {
                btn.className = 'px-2.5 py-1 rounded-md font-bold bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-xs transition flex items-center space-x-1.5';
            } else {
                btn.className = 'px-2.5 py-1 rounded-md font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition flex items-center space-x-1.5';
            }
        }
        if (container) {
            if (v === viewName) {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
            }
        }
    });

    if (viewName === 'interlocutors') {
        if (waCdrDataCache) renderWaCdrInterlocutors(waCdrDataCache.interlocutors || []);
    } else if (viewName === 'timeline') {
        loadWaCdrMessages();
    } else if (viewName === 'calls') {
        if (waCdrDataCache) renderWaCdrCalls(waCdrDataCache.calls || []);
    } else if (viewName === 'map') {
        if (waCdrDataCache) renderWaCdrMap(waCdrDataCache.geo_points || []);
    }

    if (window.lucide) {
        const cdrEl = document.getElementById('wa-view-cdr');
        if (cdrEl) lucide.createIcons({ root: cdrEl });
    }
}

function renderWaCdrInterlocutors(interlocutors) {
    const tbody = document.getElementById('wa-cdr-interlocutors-body');
    if (!tbody) return;

    if (!interlocutors || interlocutors.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" class="text-center py-8 text-slate-400">Nenhum interlocutor registrado neste período.</td></tr>`;
        return;
    }

    const maxMsgs = interlocutors[0]?.total_msgs || 1;
    let html = '';

    interlocutors.forEach((ir, idx) => {
        const phoneFormatted = formatPhoneNumber(ir.contact_phone);
        const total = ir.total_msgs || 0;
        const sent = ir.sent_by_target || 0;
        const rec = ir.received_from_contact || 0;
        const audios = ir.audio_count || 0;
        const medias = ir.media_count || 0;
        const calls = ir.calls_count || 0;
        const pctBar = Math.max(Math.round((total / maxMsgs) * 100), 3);

        html += `
            <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                <td class="py-2.5 px-4">
                    <div class="flex items-center space-x-2.5">
                        <span class="w-5 h-5 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-mono text-[10px] font-bold text-slate-600 dark:text-slate-400">${idx + 1}</span>
                        <div>
                            <span class="font-bold text-slate-900 dark:text-white font-mono block">${escapeHtml(phoneFormatted)}</span>
                            <span class="text-[10px] text-slate-400 font-mono">${escapeHtml(ir.contact_phone)}</span>
                        </div>
                    </div>
                </td>
                <td class="py-2.5 px-4">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono">${escapeHtml(ir.region_label || 'Brasil')}</span>
                </td>
                <td class="py-2.5 px-4">
                    <div class="space-y-1">
                        <div class="flex items-center justify-between text-xs font-mono font-bold">
                            <span class="text-pink-600 dark:text-pink-400">${total.toLocaleString()}</span>
                            <span class="text-[10px] text-slate-400">${pctBar}%</span>
                        </div>
                        <div class="w-28 bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div class="bg-gradient-to-r from-pink-500 to-purple-500 h-full rounded-full" style="width: ${pctBar}%"></div>
                        </div>
                    </div>
                </td>
                <td class="py-2.5 px-4 font-mono text-[11px]">
                    <span class="text-emerald-600 dark:text-emerald-400 font-bold" title="Enviadas pelo Alvo">↑ ${sent.toLocaleString()}</span>
                    <span class="text-slate-300 dark:text-slate-700 mx-1">|</span>
                    <span class="text-blue-600 dark:text-cyan-400 font-bold" title="Recebidas pelo Alvo">↓ ${rec.toLocaleString()}</span>
                </td>
                <td class="py-2.5 px-4 font-mono text-[11px]">
                    <span class="text-amber-600 dark:text-amber-400" title="Áudios Gravados">🎙️ ${audios}</span>
                    <span class="text-slate-300 dark:text-slate-700 mx-1">•</span>
                    <span class="text-purple-600 dark:text-purple-400" title="Fotos e Vídeos">🖼️ ${medias}</span>
                </td>
                <td class="py-2.5 px-4 font-mono text-[11px]">
                    ${calls > 0 ? `<span class="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 font-bold">📞 ${calls} chamada(s)</span>` : `<span class="text-slate-400">0</span>`}
                </td>
                <td class="py-2.5 px-4 text-[11px] font-mono text-slate-500 dark:text-slate-400 whitespace-nowrap">
                    ${escapeHtml(ir.last_seen || '---')}
                </td>
                <td class="py-2.5 px-4 text-right">
                    <button onclick="isolateWaCdrContact('${escapeHtml(ir.contact_phone)}')" class="px-2.5 py-1 rounded bg-pink-50 hover:bg-pink-100 dark:bg-pink-950/40 dark:hover:bg-pink-900/60 text-pink-700 dark:text-pink-300 font-bold text-[10px] transition inline-flex items-center space-x-1">
                        <i data-lucide="message-square" class="w-3 h-3"></i>
                        <span>Isolar Conversa</span>
                    </button>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
}

async function loadWaCdrMessages() {
    if (!waCurrentOpId) return;

    const tbody = document.getElementById('wa-cdr-messages-body');
    if (!tbody) return;
    tbody.innerHTML = `<tr><td colspan="7" class="text-center py-8 text-slate-400 font-sans">Filtrando e carregando mensagens da bilhetagem...</td></tr>`;

    try {
        let url = `/api/whatsapp/cdr/messages?operation_id=${waCurrentOpId}&page=${waCdrPage}&limit=${waCdrLimit}`;
        if (waCurrentPhaseId) url += `&phase_id=${waCurrentPhaseId}`;
        if (waCurrentTargetId) url += `&target_id=${waCurrentTargetId}`;
        if (waCdrBatchFile) url += `&batch_file=${encodeURIComponent(waCdrBatchFile)}`;
        if (waCdrIsolatedContact) url += `&interlocutor=${encodeURIComponent(waCdrIsolatedContact)}`;
        if (waCdrMediaTypeFilter) url += `&media_type=${encodeURIComponent(waCdrMediaTypeFilter)}`;
        if (waCdrDirectionFilter) url += `&direction=${encodeURIComponent(waCdrDirectionFilter)}`;
        if (waCdrSearchQuery) url += `&search=${encodeURIComponent(waCdrSearchQuery)}`;

        const res = await fetch(url);
        const data = await res.json();
        const msgs = data.messages || [];
        const total = data.total || 0;

        // Paginação
        const totalPages = Math.ceil(total / waCdrLimit) || 1;
        document.getElementById('wa-cdr-page-info').innerText = `Página ${waCdrPage} de ${totalPages} (${total.toLocaleString()} mensagens encontradas)`;
        document.getElementById('btn-wa-cdr-prev').disabled = (waCdrPage <= 1);
        document.getElementById('btn-wa-cdr-next').disabled = (waCdrPage >= totalPages);

        if (msgs.length === 0) {
            tbody.innerHTML = `<tr><td colspan="7" class="text-center py-8 text-slate-400 font-sans">Nenhuma mensagem encontrada para os filtros selecionados.</td></tr>`;
            return;
        }

        let html = '';
        msgs.forEach(m => {
            const isTarget = (m.is_target_sender === 1);
            const dirBadge = isTarget 
                ? `<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25 inline-flex items-center gap-1">↑ Enviada pelo Alvo</span>`
                : `<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-cyan-400 border border-blue-500/25 inline-flex items-center gap-1">↓ Recebida pelo Alvo</span>`;

            const flowHtml = isTarget
                ? `<div class="flex items-center flex-nowrap whitespace-nowrap gap-1.5 font-mono text-[11px] leading-tight">
                       <span class="inline-flex items-center gap-1 font-bold text-slate-900 dark:text-white bg-amber-500/10 dark:bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.5 rounded-md flex-shrink-0" title="Contato do Alvo Investigado">
                           <span>🎯</span>
                           <span>${formatPhoneNumber(m.sender)}</span>
                           <span class="text-[9px] font-bold uppercase text-amber-600 dark:text-amber-400">Alvo</span>
                       </span>
                       <span class="text-emerald-500 font-bold text-xs select-none px-0.5 flex-shrink-0" title="Sentido: Enviada pelo Alvo">➔</span>
                       <span class="inline-flex items-center gap-1 text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 px-1.5 py-0.5 rounded-md flex-shrink-0" title="Interlocutor">
                           <span>👤</span>
                           <span>${formatPhoneNumber(m.recipients)}</span>
                       </span>
                   </div>`
                : `<div class="flex items-center flex-nowrap whitespace-nowrap gap-1.5 font-mono text-[11px] leading-tight">
                       <span class="inline-flex items-center gap-1 text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 px-1.5 py-0.5 rounded-md flex-shrink-0" title="Interlocutor Remetente">
                           <span>👤</span>
                           <span>${formatPhoneNumber(m.sender)}</span>
                       </span>
                       <span class="text-blue-500 dark:text-cyan-400 font-bold text-xs select-none px-0.5 flex-shrink-0" title="Sentido: Recebida pelo Alvo">➔</span>
                       <span class="inline-flex items-center gap-1 font-bold text-slate-900 dark:text-white bg-amber-500/10 dark:bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.5 rounded-md flex-shrink-0" title="Contato do Alvo Investigado">
                           <span>🎯</span>
                           <span>${formatPhoneNumber(m.recipients)}</span>
                           <span class="text-[9px] font-bold uppercase text-amber-600 dark:text-amber-400">Alvo</span>
                       </span>
                   </div>`;

            // Mídia Badge
            const mediaIcons = {
                'voice': '🎙️ Áudio Gravado',
                'audio': '🎵 Áudio Encaminhado',
                'image': '🖼️ Imagem',
                'video': '🎥 Vídeo',
                'text': '💬 Texto',
                'sticker': '🎭 Figurinha',
                'reaction': '👍 Reação',
                'location': '📍 Localização',
                'vcard': '📇 Contato vCard',
                'document': '📁 Documento'
            };
            const mediaLabel = mediaIcons[m.msg_type] || `📦 ${m.msg_type}`;

            // IP & Provedor
            const ipInfo = m.ip_info || {};
            const cleanIp = m.clean_ip || '---';
            const port = m.sender_port ? `:${m.sender_port}` : '';
            const ispLabel = ipInfo.isp ? `<span class="text-[10px] text-slate-500 font-sans block truncate max-w-[180px]">${escapeHtml(ipInfo.isp)}</span>` : '';
            const mobileBadge = ipInfo.is_mobile ? `<span class="px-1 py-0.2 rounded text-[9px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-sans">📱 Móvel</span>` : '';

            // Formatação de Tamanho
            const sizeStr = m.msg_size ? `${(m.msg_size / 1024).toFixed(1)} KB` : '---';

            html += `
                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition text-xs">
                    <td class="py-2.5 px-4 font-mono text-[11px] whitespace-nowrap">
                        <span class="font-bold text-slate-800 dark:text-slate-200 block">${escapeHtml(m.timestamp_brt || '---')}</span>
                        <span class="text-[10px] text-slate-400 block">${escapeHtml(m.timestamp_utc || '')}</span>
                    </td>
                    <td class="py-2.5 px-4 whitespace-nowrap">
                        <div class="space-y-1.5">
                            ${dirBadge}
                            ${flowHtml}
                        </div>
                    </td>
                    <td class="py-2.5 px-4">
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">${mediaLabel}</span>
                    </td>
                    <td class="py-2.5 px-4">
                        <div class="space-y-0.5 font-mono text-[11px]">
                            <div class="flex items-center space-x-1">
                                <span class="font-bold text-blue-600 dark:text-cyan-400">${cleanIp}</span>
                                <span class="text-slate-400 text-[10px]">${port}</span>
                                ${mobileBadge}
                            </div>
                            ${ispLabel}
                        </div>
                    </td>
                    <td class="py-2.5 px-4">
                        <span class="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 uppercase font-mono">${escapeHtml(m.sender_device || '---')}</span>
                    </td>
                    <td class="py-2.5 px-4 font-mono text-[10px] text-slate-400 truncate max-w-[140px]" title="${escapeHtml(m.message_id)}">
                        ${escapeHtml(m.message_id)}
                    </td>
                    <td class="py-2.5 px-4 text-right font-mono text-[11px] text-slate-500">
                        ${sizeStr}
                    </td>
                </tr>
            `;
        });

        tbody.innerHTML = html;
        lucide.createIcons();

    } catch (err) {
        console.error("Erro ao carregar mensagens da bilhetagem:", err);
        tbody.innerHTML = `<tr><td colspan="7" class="text-center py-8 text-rose-400 font-sans">Erro ao carregar mensagens.</td></tr>`;
    }
}

function renderWaCdrCalls(calls) {
    const tbody = document.getElementById('wa-cdr-calls-body');
    if (!tbody) return;

    if (!calls || calls.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="text-center py-8 text-slate-400 font-sans">Nenhuma chamada registrada neste período.</td></tr>`;
        return;
    }

    let html = '';
    calls.forEach(c => {
        const isTarget = (c.is_target_creator === 1);
        const dirBadge = isTarget
            ? `<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25 inline-flex items-center gap-1">🟢 Originada pelo Alvo</span>`
            : `<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-cyan-400 border border-blue-500/25 inline-flex items-center gap-1">🔵 Recebida pelo Alvo</span>`;

        const flowHtml = isTarget
            ? `<div class="flex items-center flex-nowrap whitespace-nowrap gap-1.5 font-mono text-[11px] leading-tight">
                   <span class="inline-flex items-center gap-1 font-bold text-slate-900 dark:text-white bg-amber-500/10 dark:bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.5 rounded-md flex-shrink-0" title="Contato do Alvo Investigado">
                       <span>🎯</span>
                       <span>${formatPhoneNumber(c.from_number)}</span>
                       <span class="text-[9px] font-bold uppercase text-amber-600 dark:text-amber-400">Alvo</span>
                   </span>
                   <span class="text-emerald-500 font-bold text-xs select-none px-0.5 flex-shrink-0" title="Sentido: Originada pelo Alvo">➔</span>
                   <span class="inline-flex items-center gap-1 text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 px-1.5 py-0.5 rounded-md flex-shrink-0" title="Interlocutor">
                       <span>👤</span>
                       <span>${formatPhoneNumber(c.to_number)}</span>
                   </span>
               </div>`
            : `<div class="flex items-center flex-nowrap whitespace-nowrap gap-1.5 font-mono text-[11px] leading-tight">
                   <span class="inline-flex items-center gap-1 text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 px-1.5 py-0.5 rounded-md flex-shrink-0" title="Interlocutor Remetente">
                       <span>👤</span>
                       <span>${formatPhoneNumber(c.from_number)}</span>
                   </span>
                   <span class="text-blue-500 dark:text-cyan-400 font-bold text-xs select-none px-0.5 flex-shrink-0" title="Sentido: Recebida pelo Alvo">➔</span>
                   <span class="inline-flex items-center gap-1 font-bold text-slate-900 dark:text-white bg-amber-500/10 dark:bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.5 rounded-md flex-shrink-0" title="Contato do Alvo Investigado">
                       <span>🎯</span>
                       <span>${formatPhoneNumber(c.to_number)}</span>
                       <span class="text-[9px] font-bold uppercase text-amber-600 dark:text-amber-400">Alvo</span>
                   </span>
               </div>`;
        
        let statusBadge = '';
        if (c.status === 'atendida') {
            statusBadge = `<span class="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 font-bold text-[10px]">✅ Atendida</span>`;
        } else if (c.status === 'recusada') {
            statusBadge = `<span class="px-2 py-0.5 rounded bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300 font-bold text-[10px]">📵 Recusada</span>`;
        } else {
            statusBadge = `<span class="px-2 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 font-bold text-[10px]">⏳ Não Atendida</span>`;
        }

        // Formatação de Duração
        let durStr = '0s';
        if (c.duration_seconds > 0) {
            const mins = Math.floor(c.duration_seconds / 60);
            const secs = c.duration_seconds % 60;
            durStr = `${mins.toString().padStart(2, '0')}m ${secs.toString().padStart(2, '0')}s`;
        }

        const mediaIcon = c.media_type === 'video' ? '🎥 Chamada de Vídeo' : '📞 Chamada de Áudio';

        html += `
            <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition text-xs">
                <td class="py-2.5 px-4 font-mono text-[11px] whitespace-nowrap">
                    <span class="font-bold text-slate-800 dark:text-slate-200 block">${escapeHtml(c.timestamp_brt || '---')}</span>
                </td>
                <td class="py-2.5 px-4 whitespace-nowrap">
                    <div class="space-y-1.5">
                        ${dirBadge}
                        ${flowHtml}
                    </div>
                </td>
                <td class="py-2.5 px-4">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">${mediaIcon}</span>
                </td>
                <td class="py-2.5 px-4">
                    ${statusBadge}
                </td>
                <td class="py-2.5 px-4 font-mono font-bold text-pink-600 dark:text-pink-400">
                    ${durStr}
                </td>
                <td class="py-2.5 px-4 font-mono text-[11px] text-blue-600 dark:text-cyan-400">
                    ${escapeHtml(c.clean_ip || '---')}${c.from_port ? `:${c.from_port}` : ''}
                </td>
                <td class="py-2.5 px-4 text-right font-mono text-[10px] text-slate-400 truncate max-w-[120px]" title="${escapeHtml(c.call_id)}">
                    ${escapeHtml(c.call_id)}
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
}

function renderWaCdrMap(geoPoints) {
    const mapCountEl = document.getElementById('wa-cdr-map-count');
    if (mapCountEl) {
        mapCountEl.innerText = `${geoPoints ? geoPoints.length : 0} pontos geográficos identificados`;
    }

    const mapContainer = document.getElementById('wa-cdr-leaflet-map');
    if (!mapContainer) return;

    if (typeof L === 'undefined') {
        console.warn("Leaflet não carregado.");
        return;
    }

    if (waCdrMapInstance) {
        waCdrMapInstance.remove();
        waCdrMapInstance = null;
    }

    // Centro inicial do Brasil
    waCdrMapInstance = L.map('wa-cdr-leaflet-map').setView([-14.235, -51.925], 4);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap'
    }).addTo(waCdrMapInstance);

    if (!geoPoints || geoPoints.length === 0) return;

    const bounds = [];
    geoPoints.forEach(pt => {
        if (pt.lat && pt.lon) {
            bounds.push([pt.lat, pt.lon]);
            const radius = Math.min(Math.max(pt.total_count * 2, 8), 25);
            
            const circle = L.circleMarker([pt.lat, pt.lon], {
                radius: radius,
                fillColor: '#ec4899',
                color: '#be185d',
                weight: 2,
                opacity: 1,
                fillOpacity: 0.7
            }).addTo(waCdrMapInstance);

            const popupContent = `
                <div class="font-sans text-xs space-y-1">
                    <b class="text-pink-600 text-sm">${escapeHtml(pt.city)} - ${escapeHtml(pt.region)}</b><br>
                    <span>IP: <code class="font-mono text-blue-600 font-bold">${escapeHtml(pt.clean_ip)}</code></span><br>
                    <span>Provedor: <b>${escapeHtml(pt.isp)}</b></span><br>
                    <span>Mensagens emitidas: <b class="text-pink-600">${pt.total_count}</b></span><br>
                    <span class="text-[10px] text-slate-500">Última atividade: ${escapeHtml(pt.last_seen || '---')}</span>
                </div>
            `;
            circle.bindPopup(popupContent);
        }
    });

    if (bounds.length > 0) {
        waCdrMapInstance.fitBounds(bounds, { padding: [40, 40] });
    }

    setTimeout(() => {
        if (waCdrMapInstance) waCdrMapInstance.invalidateSize();
    }, 200);
}

// Filtros e Interações de CDR
function setWaCdrMediaTypeFilter(type) {
    waCdrMediaTypeFilter = type;
    waCdrPage = 1;
    ['all', 'voice', 'image', 'video', 'text', 'location'].forEach(t => {
        const btn = document.getElementById(`btn-cdr-media-${t}`);
        if (btn) {
            if ((t === 'all' && !type) || (t === type)) {
                btn.className = 'px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px] shadow-2xs';
            } else {
                btn.className = 'px-2.5 py-1 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold text-[11px]';
            }
        }
    });
    loadWaCdrMessages();
}

function setWaCdrDirectionFilter(dir) {
    waCdrDirectionFilter = dir;
    waCdrPage = 1;
    ['all', 'sent', 'received'].forEach(d => {
        const btn = document.getElementById(`btn-cdr-dir-${d}`);
        if (btn) {
            if ((d === 'all' && !dir) || (d === dir)) {
                btn.className = 'px-2 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px] shadow-2xs';
            } else {
                btn.className = 'px-2 py-1 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] font-medium';
            }
        }
    });
    loadWaCdrMessages();
}

function isolateWaCdrContact(phone) {
    waCdrIsolatedContact = phone;
    waCdrPage = 1;
    
    // Atualizar badge de contato isolado
    const badge = document.getElementById('wa-cdr-isolated-contact-badge');
    const phoneEl = document.getElementById('wa-cdr-isolated-phone');
    if (badge && phoneEl) {
        phoneEl.innerText = formatPhoneNumber(phone);
        badge.classList.remove('hidden');
    }

    switchWaCdrView('timeline');
}

function clearWaCdrContactFilter() {
    waCdrIsolatedContact = '';
    waCdrPage = 1;
    const badge = document.getElementById('wa-cdr-isolated-contact-badge');
    if (badge) badge.classList.add('hidden');
    loadWaCdrMessages();
}

function handleWaCdrSearch(event) {
    waCdrSearchQuery = event.target.value.trim();
    waCdrPage = 1;
    if (event.key === 'Enter' || waCdrSearchQuery.length === 0 || waCdrSearchQuery.length >= 3) {
        if (waCdrCurrentSubView === 'timeline') {
            loadWaCdrMessages();
        } else if (waCdrCurrentSubView === 'interlocutors' && waCdrDataCache) {
            const filtered = (waCdrDataCache.interlocutors || []).filter(i => 
                i.contact_phone.includes(waCdrSearchQuery) || 
                (i.region_label && i.region_label.toLowerCase().includes(waCdrSearchQuery.toLowerCase()))
            );
            renderWaCdrInterlocutors(filtered);
        }
    }
}

function changeWaCdrPage(delta) {
    waCdrPage += delta;
    if (waCdrPage < 1) waCdrPage = 1;
    loadWaCdrMessages();
}

function exportWaCdrCsv() {
    if (!waCurrentOpId) return;
    let url = `/api/whatsapp/cdr/messages?operation_id=${waCurrentOpId}&limit=10000`;
    if (waCurrentPhaseId) url += `&phase_id=${waCurrentPhaseId}`;
    if (waCurrentTargetId) url += `&target_id=${waCurrentTargetId}`;
    if (waCdrBatchFile) url += `&batch_file=${encodeURIComponent(waCdrBatchFile)}`;
    
    fetch(url)
        .then(res => res.json())
        .then(data => {
            const msgs = data.messages || [];
            if (msgs.length === 0) {
                alert("Nenhuma mensagem disponível para exportação.");
                return;
            }
            let csv = "Data/Hora BRT,Data/Hora UTC,Sentido,Remetente,Destinatário,Tipo,IP Remetente,Porta,Aparelho,ID Mensagem,Tamanho Bytes\n";
            msgs.forEach(m => {
                const dir = m.is_target_sender === 1 ? "Enviada pelo Alvo" : "Recebida";
                csv += `"${m.timestamp_brt || ''}","${m.timestamp_utc || ''}","${dir}","${m.sender || ''}","${m.recipients || ''}","${m.msg_type || ''}","${m.clean_ip || ''}","${m.sender_port || ''}","${m.sender_device || ''}","${m.message_id || ''}","${m.msg_size || 0}"\n`;
            });
            const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = `Bilhetagem_WhatsApp_Op${waCurrentOpId}.csv`;
            link.click();
        })
        .catch(err => {
            console.error("Erro ao exportar CSV de bilhetagem:", err);
            alert("Erro ao exportar CSV.");
        });
}

// ====================================================
// 5. INTEGRAÇÃO WHATSAPP WEB & SINCRONIZAÇÃO DE FOTOS
// ====================================================
let waQrPollInterval = null;
let waAvatarSyncPollInterval = null;

async function checkWaWebSessionStatus() {
    try {
        const res = await fetch('/api/whatsapp/web/status');
        const data = await res.json();
        
        const dot = document.getElementById('wa-web-status-dot');
        const text = document.getElementById('wa-web-status-text');
        const logoutBtn = document.getElementById('btn-wa-logout');

        if (data.is_logged_in) {
            if (dot) {
                dot.className = "w-2 h-2 rounded-full bg-emerald-500 animate-pulse";
            }
            if (text) text.innerText = "WhatsApp Web: Conectado";
            if (logoutBtn) logoutBtn.classList.remove('hidden');
        } else {
            if (dot) {
                dot.className = "w-2 h-2 rounded-full bg-slate-400";
            }
            if (text) text.innerText = "WhatsApp Web: Desconectado";
            if (logoutBtn) logoutBtn.classList.add('hidden');
        }
        return data.is_logged_in;
    } catch (e) {
        console.warn("Não foi possível verificar status do WhatsApp Web:", e);
        return false;
    }
}

async function openWaQrModal() {
    const modal = document.getElementById('modal-wpp-qr');
    if (!modal) return;
    modal.classList.remove('hidden');

    const loading = document.getElementById('wa-qr-loading');
    const loadingText = document.getElementById('wa-qr-loading-text');
    const qrImg = document.getElementById('wa-qr-img');
    const successBox = document.getElementById('wa-qr-success');
    const logoutBtn = document.getElementById('btn-wa-logout');

    if (loading) loading.classList.remove('hidden');
    if (loadingText) loadingText.innerText = "Iniciando sessão do WhatsApp Web...";
    if (qrImg) qrImg.classList.add('hidden');
    if (successBox) successBox.classList.add('hidden');

    if (window.lucide) {
        lucide.createIcons({ root: modal });
    }

    // Checar se já está conectado
    const isConnected = await checkWaWebSessionStatus();
    if (isConnected) {
        if (loading) loading.classList.add('hidden');
        if (qrImg) qrImg.classList.add('hidden');
        if (successBox) successBox.classList.remove('hidden');
        if (logoutBtn) logoutBtn.classList.remove('hidden');
        return;
    }

    // Buscar QR Code e iniciar polling
    await fetchWaQrCode();

    if (waQrPollInterval) clearInterval(waQrPollInterval);
    waQrPollInterval = setInterval(async () => {
        const loggedIn = await checkWaWebSessionStatus();
        if (loggedIn) {
            clearInterval(waQrPollInterval);
            waQrPollInterval = null;
            if (loading) loading.classList.add('hidden');
            if (qrImg) qrImg.classList.add('hidden');
            if (successBox) successBox.classList.remove('hidden');
            if (logoutBtn) logoutBtn.classList.remove('hidden');
        }
    }, 3000);
}

function closeWaQrModal() {
    const modal = document.getElementById('modal-wpp-qr');
    if (modal) modal.classList.add('hidden');
    if (waQrPollInterval) {
        clearInterval(waQrPollInterval);
        waQrPollInterval = null;
    }
    checkWaWebSessionStatus();
}

async function fetchWaQrCode() {
    const loading = document.getElementById('wa-qr-loading');
    const loadingText = document.getElementById('wa-qr-loading-text');
    const qrImg = document.getElementById('wa-qr-img');
    const successBox = document.getElementById('wa-qr-success');

    if (loading) loading.classList.remove('hidden');
    if (loadingText) loadingText.innerText = "Gerando QR Code...";
    if (qrImg) qrImg.classList.add('hidden');

    try {
        const res = await fetch('/api/whatsapp/web/qr');
        const data = await res.json();

        if (data.is_logged_in) {
            if (loading) loading.classList.add('hidden');
            if (qrImg) qrImg.classList.add('hidden');
            if (successBox) successBox.classList.remove('hidden');
            checkWaWebSessionStatus();
            return;
        }

        const qrSrc = data.qr_code || (data.qr_code_base64 ? ('data:image/png;base64,' + data.qr_code_base64) : null);
        if (qrSrc) {
            if (qrImg) {
                qrImg.src = qrSrc;
                qrImg.classList.remove('hidden');
            }
            if (loading) loading.classList.add('hidden');
        } else {
            if (loadingText) loadingText.innerText = data.message || data.detail || "Aguardando geração do QR Code...";
        }
    } catch (e) {
        console.error("Erro ao buscar QR Code do WhatsApp Web:", e);
        if (loadingText) loadingText.innerText = "Erro ao carregar QR Code. Clique em Atualizar.";
    }
}

async function refreshWaQrCode() {
    await fetchWaQrCode();
}

async function logoutWaSession() {
    if (!confirm("Deseja realmente desconectar o WhatsApp Web do robô?")) return;
    try {
        await fetch('/api/whatsapp/web/logout', { method: 'POST' });
        await checkWaWebSessionStatus();
        openWaQrModal();
    } catch (e) {
        console.error("Erro ao desconectar WhatsApp Web:", e);
    }
}

async function startWaAvatarSync() {
    if (!waCurrentOpId) {
        alert("Nenhuma operação selecionada.");
        return;
    }

    // 1. Checar se está conectado
    const isConnected = await checkWaWebSessionStatus();
    if (!isConnected) {
        openWaQrModal();
        return;
    }

    // 2. Disparar sincronização
    const container = document.getElementById('wa-avatar-sync-bar-container');
    const statusMsg = document.getElementById('wa-avatar-sync-status-msg');
    const percentEl = document.getElementById('wa-avatar-sync-percent');
    const barEl = document.getElementById('wa-avatar-sync-bar');

    if (container) container.classList.remove('hidden');
    if (percentEl) percentEl.innerText = '0%';
    if (barEl) barEl.style.width = '0%';
    if (statusMsg) statusMsg.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i> Iniciando sincronização de fotos dos contatos...`;
    if (window.lucide) lucide.createIcons({ root: container });

    try {
        const res = await fetch('/api/whatsapp/avatars/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                operation_id: waCurrentOpId,
                target_id: waCurrentTargetId || null
            })
        });
        const data = await res.json();
        if (!res.ok) {
            alert(data.detail || "Erro ao iniciar sincronização.");
            if (container) container.classList.add('hidden');
            return;
        }

        startWaAvatarSyncPolling();
    } catch (e) {
        console.error("Erro ao disparar sincronização de fotos:", e);
        alert("Falha de conexão com o backend ao iniciar sincronização.");
        if (container) container.classList.add('hidden');
    }
}

function startWaAvatarSyncPolling() {
    if (waAvatarSyncPollInterval) clearInterval(waAvatarSyncPollInterval);

    const container = document.getElementById('wa-avatar-sync-bar-container');
    const statusMsg = document.getElementById('wa-avatar-sync-status-msg');
    const percentEl = document.getElementById('wa-avatar-sync-percent');
    const barEl = document.getElementById('wa-avatar-sync-bar');

    waAvatarSyncPollInterval = setInterval(async () => {
        try {
            const res = await fetch('/api/whatsapp/avatars/status');
            const data = await res.json();

            const pct = data.progress_pct || 0;
            if (percentEl) percentEl.innerText = `${pct}%`;
            if (barEl) barEl.style.width = `${pct}%`;

            if (data.is_running) {
                const cur = data.processed || 0;
                const tot = data.total || 0;
                const phone = data.current_phone ? ` (${formatPhoneNumber(data.current_phone)})` : '';
                const found = data.found || 0;
                if (statusMsg) {
                    statusMsg.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i> Sincronizando contato ${cur} de ${tot}${phone} • ${found} fotos obtidas`;
                    if (window.lucide) lucide.createIcons({ root: statusMsg });
                }
            } else {
                // Finalizado ou parado
                clearInterval(waAvatarSyncPollInterval);
                waAvatarSyncPollInterval = null;

                if (data.error) {
                    if (statusMsg) statusMsg.innerHTML = `<span class="text-rose-500">Erro na sincronização: ${data.error}</span>`;
                } else {
                    const found = data.found || 0;
                    if (statusMsg) statusMsg.innerHTML = `<i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-emerald-500 inline mr-1"></i> Sincronização concluída! ${found} fotos de perfil salvas com sucesso.`;
                    if (percentEl) percentEl.innerText = `100%`;
                    if (barEl) barEl.style.width = `100%`;
                    if (window.lucide) lucide.createIcons({ root: container });

                    // Recarregar tabela de contatos para exibir as novas fotos
                    loadWaContacts();

                    // Ocultar barra após 5 segundos
                    setTimeout(() => {
                        if (container) container.classList.add('hidden');
                    }, 5000);
                }
            }
        } catch (e) {
            console.error("Erro no polling de sincronização de fotos:", e);
        }
    }, 1500);
}


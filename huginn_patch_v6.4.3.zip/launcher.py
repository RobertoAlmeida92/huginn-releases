import os
import sys
import time
import socket
import threading
import subprocess
import webbrowser
import uvicorn

# Proteção robusta contra falhas de escrita caso executado sem console (console=False)
if sys.stdout is None:
    try:
        sys.stdout = open(os.devnull, 'w', encoding='utf-8')
    except Exception:
        class _FullNullStream:
            def write(self, s): pass
            def flush(self): pass
            def isatty(self): return False
            encoding = 'utf-8'
        sys.stdout = _FullNullStream()

if sys.stderr is None:
    try:
        sys.stderr = open(os.devnull, 'w', encoding='utf-8')
    except Exception:
        class _FullNullStream:
            def write(self, s): pass
            def flush(self): pass
            def isatty(self): return False
            encoding = 'utf-8'
        sys.stderr = _FullNullStream()

# Adiciona o diretorio base ao sys.path para importacoes
if getattr(sys, 'frozen', False):
    app_base = os.path.dirname(sys.executable)
    if hasattr(sys, '_MEIPASS'):
        sys.path.insert(0, sys._MEIPASS)
else:
    app_base = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, app_base)

def is_port_available(port: int) -> bool:
    # 1. Tentar conectar: se responder, significa que outro programa esta escutando na porta
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.2)
            if s.connect_ex(('127.0.0.1', port)) == 0:
                return False
    except Exception:
        pass

    # 2. Tentar bind em todas as interfaces
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('0.0.0.0', port))
            return True
    except OSError:
        return False

def find_available_port(start_port: int = 8000, max_attempts: int = 20) -> int:
    for p in range(start_port, start_port + max_attempts):
        if is_port_available(p):
            return p
    return start_port

def wait_for_server(port: int, timeout: float = 25.0) -> bool:
    """Aguarda ativamente até que o servidor FastAPI/Uvicorn esteja escutando na porta especificada."""
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.2)
                if s.connect_ex(('127.0.0.1', port)) == 0:
                    return True
        except Exception:
            pass
        time.sleep(0.2)
    return False

def open_desktop_window(port: int):
    """
    Abre o Huginn em uma Janela Própria de Aplicativo (Desktop Window),
    eliminando abas, barra de endereços (URL) e cache persistente do navegador comum.
    """
    # Só abre a janela após o servidor estar respondendo com sucesso
    if not wait_for_server(port, timeout=25.0):
        return

    url = f'http://127.0.0.1:{port}'
    app_profile = os.path.join(os.environ.get('TEMP', os.path.expanduser('~')), 'huginn_app_profile')

    # 1. Tentar abrir em Janela Própria de Aplicativo (Edge ou Chrome no modo --app)
    edge_paths = [
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%LocalAppData%\Microsoft\Edge\Application\msedge.exe"),
    ]
    chrome_paths = [
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
    ]

    for browser_exe in edge_paths + chrome_paths:
        if os.path.exists(browser_exe):
            try:
                subprocess.Popen([
                    browser_exe,
                    f"--app={url}",
                    f"--user-data-dir={app_profile}",
                    "--no-first-run",
                    "--no-default-browser-check",
                    "--window-size=1440,900",
                    "--start-maximized"
                ])
                return
            except Exception:
                pass

    # 2. Fallback caso não localize os binários Chromium
    try:
        webbrowser.open(url)
    except Exception:
        pass

def check_existing_instance(port: int = 8000) -> bool:
    """Se uma instância do Huginn já estiver ativa e respondendo, apenas reabre a janela e evita duplicar processos."""
    import urllib.request
    try:
        req = urllib.request.Request(f'http://127.0.0.1:{port}/api/system/check-update', headers={'User-Agent': 'HuginnLauncher'})
        with urllib.request.urlopen(req, timeout=0.8) as resp:
            if resp.status == 200:
                open_desktop_window(port)
                return True
    except Exception:
        pass
    return False

if __name__ == '__main__':
    # Se já existir uma instância saudável em execução, foca/reabre a janela e encerra
    if check_existing_instance(8000):
        sys.exit(0)

    from backend.config import UPLOAD_DIR, MEDIA_BASE_DIR, DB_PATH
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs(MEDIA_BASE_DIR, exist_ok=True)

    port = find_available_port(start_port=8000)

    print('='*65)
    print('   HUGINN — Plataforma de Inteligência & Análise Telemática')
    print('   Servidor ativo e disponível!')
    if port != 8000:
        print(f'   [AVISO] Porta 8000 ocupada por outra aplicacao.')
        print(f'   [*] Redirecionado automaticamente para a porta livre: {port}')
    print(f'   -> Acesso Local:  http://127.0.0.1:{port}')
    print(f'   -> Banco de dados: {DB_PATH}')
    print('   Pressione Ctrl+C na janela para encerrar.')
    print('='*65)

    # Abre a janela própria de aplicativo automaticamente
    threading.Thread(target=open_desktop_window, args=(port,), daemon=True).start()

    from backend.main import app
    try:
        uvicorn.run(app, host='0.0.0.0', port=port, log_config=None)
    except Exception as e:
        err_log = os.path.join(os.environ.get('TEMP', '.'), 'huginn_fatal_error.log')
        try:
            with open(err_log, 'w', encoding='utf-8') as f:
                import traceback
                f.write(traceback.format_exc())
        except Exception:
            pass

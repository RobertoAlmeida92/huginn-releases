import os
import re
import shutil
import json
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Query, BackgroundTasks, Request
from fastapi.responses import FileResponse, StreamingResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend.database import init_db, get_db_connection
from backend.config import STATIC_DIR, UPLOAD_DIR, MEDIA_BASE_DIR, AVATAR_DIR, CUSTODY_DIR
from backend.services.operation_service import OperationService
from backend.services.link_analysis import LinkAnalysisService
from backend.services.export_service import ExportService
from backend.services.ip_service import IpService
from backend.services.avatar_service import (
    fetch_and_cache_avatar,
    batch_sync_avatars,
    get_avatar_sync_status,
    get_all_cached_avatars_map,
    get_cached_avatar_url,
    get_pending_avatars_count
)

init_db()

app = FastAPI(
    title="HUGINN - Intelligence Platform",
    description="Plataforma de Inteligência e Análise Telemática de Quebras Judiciais",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from backend.services.license_service import LicenseService

@app.middleware("http")
async def license_lockdown_middleware(request: Request, call_next):
    # Rotas sempre liberadas para navegação e reativação da licença
    path = request.url.path
    if (
        path == "/"
        or path.startswith("/static")
        or path == "/favicon.ico"
        or path.startswith("/api/license")
        or path.startswith("/api/system")
    ):
        return await call_next(request)

    # Bloqueio de dados forenses e mídias se a licença não estiver ativa
    if path.startswith("/api/") or path.startswith("/media"):
        if not LicenseService.is_license_active():
            return JSONResponse(
                status_code=403,
                content={"detail": "Acesso bloqueado: Licença de avaliação expirada ou inválida. Insira uma nova chave para liberar o cofre de dados."}
            )

    return await call_next(request)

os.makedirs(STATIC_DIR, exist_ok=True)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

os.makedirs(MEDIA_BASE_DIR, exist_ok=True)
os.makedirs(AVATAR_DIR, exist_ok=True)

app.mount("/media/avatars", StaticFiles(directory=AVATAR_DIR), name="media_avatars")
app.mount("/api/media/avatars", StaticFiles(directory=AVATAR_DIR), name="api_media_avatars")

@app.get("/favicon.ico", include_in_schema=False)
def favicon():
    fav_svg = os.path.join(STATIC_DIR, "img", "favicon.svg")
    if os.path.exists(fav_svg):
        return FileResponse(fav_svg, media_type="image/svg+xml")
    fav_ico = os.path.join(STATIC_DIR, "favicon.ico")
    if os.path.exists(fav_ico):
        return FileResponse(fav_ico, media_type="image/x-icon")
    return Response(status_code=204)

# ==================== ROTAS DE LICENCIAMENTO DE TESTE ====================

class LicenseActivationPayload(BaseModel):
    key: str

@app.get("/api/license/status")
def get_license_status():
    return LicenseService.get_license_status()

@app.post("/api/license/activate")
def activate_license(payload: LicenseActivationPayload):
    res = LicenseService.activate_license(payload.key)
    if res.get("status") == "error":
        raise HTTPException(status_code=400, detail=res.get("message"))
    return res

@app.post("/api/license/self-destruct")
def self_destruct():
    return LicenseService.execute_self_destruction()

# ==================== ROTAS DE ATUALIZAÇÃO SEGURA (HUGINN AUTO-UPDATE) ====================

from backend.services.update_service import UpdateService

class ApplyUpdatePayload(BaseModel):
    download_url: str
    sha256: str
    signature: str

@app.get("/api/system/version")
def get_system_version():
    return {
        "app_name": "Huginn Forensics",
        "version": UpdateService.get_current_version()
    }

@app.get("/api/system/check-update")
def check_for_system_updates():
    return UpdateService.check_for_updates()

@app.post("/api/system/apply-update")
def apply_system_update(payload: ApplyUpdatePayload):
    res = UpdateService.apply_update_from_url(
        download_url=payload.download_url,
        expected_sha=payload.sha256,
        expected_sig=payload.signature
    )
    if not res.get("success"):
        raise HTTPException(status_code=400, detail=res.get("message"))
    return res

@app.get("/media/{file_path:path}")
@app.get("/api/media/{file_path:path}")
def serve_media(file_path: str):
    # 1. Checar se é um avatar diretamente
    if file_path.startswith("avatars/"):
        avatar_name = file_path.replace("avatars/", "", 1)
        full_avatar = os.path.join(AVATAR_DIR, avatar_name)
        if os.path.exists(full_avatar) and os.path.isfile(full_avatar):
            return FileResponse(full_avatar)

    # 2. Caminho direto solicitado em MEDIA_BASE_DIR
    full_path = os.path.join(MEDIA_BASE_DIR, file_path)
    if os.path.exists(full_path) and os.path.isfile(full_path):
        return FileResponse(full_path)
    
    # 3. Busca recursiva pelo nome do arquivo em mídias e avatares
    filename = os.path.basename(file_path)
    for base in [AVATAR_DIR, MEDIA_BASE_DIR]:
        if os.path.exists(base):
            for root, _, files in os.walk(base):
                if filename in files:
                    found = os.path.join(root, filename)
                    if os.path.isfile(found) and os.path.getsize(found) > 100:
                        return FileResponse(found)

    # 4. Auto-download sob demanda para avatares se ainda não estiver em disco
    if file_path.startswith("avatars/") or filename.startswith("ig_"):
        if filename.startswith("ig_") and filename.endswith(".jpg"):
            ident = filename[3:-4]
            try:
                cached_url = fetch_and_cache_avatar(username=ident, identifier=ident)
                if cached_url:
                    rel_name = cached_url.replace("/media/avatars/", "", 1).split("?")[0]
                    target_file = os.path.join(AVATAR_DIR, rel_name)
                    if os.path.exists(target_file) and os.path.isfile(target_file):
                        return FileResponse(target_file)
                    direct_file = os.path.join(AVATAR_DIR, filename)
                    if os.path.exists(direct_file) and os.path.isfile(direct_file):
                        return FileResponse(direct_file)
            except Exception as e:
                logger.debug(f"Auto-fetch sob demanda falhou para {ident}: {e}")
                
    # 5. Fallback inteligente: buscar nos pacotes ZIP da custódia e auto-extrair
    if os.path.exists(CUSTODY_DIR):
        import zipfile
        for c_file in os.listdir(CUSTODY_DIR):
            c_path = os.path.join(CUSTODY_DIR, c_file)
            if zipfile.is_zipfile(c_path):
                try:
                    with zipfile.ZipFile(c_path, 'r') as z:
                        for z_item in z.namelist():
                            if os.path.basename(z_item) == filename and not z_item.endswith('/'):
                                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                                with z.open(z_item) as src, open(full_path, 'wb') as dst:
                                    shutil.copyfileobj(src, dst)
                                if os.path.exists(full_path):
                                    return FileResponse(full_path)
                except Exception:
                    pass

    raise HTTPException(status_code=404, detail="Arquivo de mídia não encontrado")

@app.get("/")
def serve_index():
    index_file = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file)
    return {"message": "HUGINN API ativa."}

# ==================== ROTAS DE OPERAÇÕES ====================

class OperationCreateRequest(BaseModel):
    name: str
    police_unit: Optional[str] = ""
    court_docket: Optional[str] = ""
    description: Optional[str] = ""
    initial_phase_name: Optional[str] = "Fase 1 - Preservação e Quebra Inicial"
    initial_phase_court_order: Optional[str] = ""
    initial_phase_date_range: Optional[str] = ""

class OperationUpdateRequest(BaseModel):
    name: str
    police_unit: Optional[str] = ""
    court_docket: Optional[str] = ""
    description: Optional[str] = ""

@app.get("/api/operations")
def list_operations():
    return OperationService.list_operations()

@app.post("/api/operations")
def create_operation(req: OperationCreateRequest):
    return OperationService.create_operation(
        name=req.name,
        police_unit=req.police_unit or "",
        court_docket=req.court_docket or "",
        description=req.description or "",
        initial_phase_name=req.initial_phase_name or "Fase 1 - Preservação e Quebra Inicial",
        initial_phase_court_order=req.initial_phase_court_order or "",
        initial_phase_date_range=req.initial_phase_date_range or ""
    )

@app.get("/api/operations/{operation_id}")
def get_operation(operation_id: int):
    op = OperationService.get_operation(operation_id)
    if not op:
        raise HTTPException(status_code=404, detail="Operação não encontrada.")
    return op

@app.put("/api/operations/{operation_id}")
def update_operation(operation_id: int, req: OperationUpdateRequest):
    OperationService.update_operation(
        operation_id=operation_id,
        name=req.name,
        police_unit=req.police_unit or "",
        court_docket=req.court_docket or "",
        description=req.description or ""
    )
    return {"status": "updated", "operation_id": operation_id}

@app.delete("/api/operations/{operation_id}")
def delete_operation(operation_id: int):
    OperationService.delete_operation(operation_id)
    return {"status": "deleted", "operation_id": operation_id}

# ==================== ROTAS DE FASES ====================

class PhaseCreateRequest(BaseModel):
    name: str
    court_order: Optional[str] = ""
    date_range: Optional[str] = ""
    description: Optional[str] = ""

class PhaseUpdateRequest(BaseModel):
    name: str
    court_order: Optional[str] = ""
    date_range: Optional[str] = ""
    description: Optional[str] = ""

@app.get("/api/operations/{operation_id}/phases")
def list_phases(operation_id: int):
    return OperationService.list_phases(operation_id)

@app.get("/api/phases/{phase_id}")
def get_phase(phase_id: int):
    ph = OperationService.get_phase(phase_id)
    if not ph:
        raise HTTPException(status_code=404, detail="Fase não encontrada.")
    return ph

@app.post("/api/operations/{operation_id}/phases")
def create_phase(operation_id: int, req: PhaseCreateRequest):
    return OperationService.create_phase(operation_id, req.name, req.court_order or "", req.date_range or "", req.description or "")

@app.put("/api/phases/{phase_id}")
def update_phase(phase_id: int, req: PhaseUpdateRequest):
    OperationService.update_phase(
        phase_id=phase_id,
        name=req.name,
        court_order=req.court_order or "",
        date_range=req.date_range or "",
        description=req.description or ""
    )
    return {"status": "updated", "phase_id": phase_id}

@app.delete("/api/phases/{phase_id}")
def delete_phase(phase_id: int):
    OperationService.delete_phase(phase_id)
    return {"status": "deleted", "phase_id": phase_id}

# ==================== ROTAS DE ALVOS ====================

class TargetCreateRequest(BaseModel):
    name_or_alias: str
    main_identifier: str
    platform: Optional[str] = "both"
    cpf_cnpj: Optional[str] = ""
    notes: Optional[str] = ""
    phase_id: Optional[int] = None

class TargetUpdateRequest(BaseModel):
    name_or_alias: Optional[str] = None
    notes: Optional[str] = None
    main_identifier: Optional[str] = None

class MergeTargetsRequest(BaseModel):
    operation_id: int
    source_target_id: int
    destination_target_id: int

class InspectLocalRequest(BaseModel):
    local_path: str
    operation_id: Optional[int] = None

@app.get("/api/operations/{operation_id}/targets")
def list_targets(operation_id: int, phase_id: Optional[int] = None):
    return OperationService.list_targets(operation_id, phase_id)

@app.post("/api/operations/{operation_id}/targets")
def create_target(operation_id: int, req: TargetCreateRequest):
    return OperationService.create_target(
        operation_id, req.name_or_alias, req.main_identifier,
        req.platform or "both", req.cpf_cnpj or "", req.notes or "",
        phase_id_to_bind=req.phase_id
    )

@app.put("/api/targets/{target_id}")
def update_target(target_id: int, req: TargetUpdateRequest):
    try:
        updated = OperationService.update_target(target_id, req.name_or_alias, req.notes, req.main_identifier)
        return {"status": "success", "target": updated}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/targets/merge")
def merge_targets(req: MergeTargetsRequest):
    try:
        res = OperationService.merge_targets(req.operation_id, req.source_target_id, req.destination_target_id)
        return res
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/api/targets/{target_id}")
def delete_target(target_id: int):
    OperationService.delete_target(target_id)
    return {"status": "deleted", "target_id": target_id}

class TargetBindRequest(BaseModel):
    target_id: int
    notes: Optional[str] = ""

@app.post("/api/phases/{phase_id}/bind-target")
def bind_target_to_phase(phase_id: int, req: TargetBindRequest):
    pt_id = OperationService.bind_target_to_phase(phase_id, req.target_id, req.notes or "")
    return {"status": "bound", "phase_target_id": pt_id}

# ==================== ROTAS DE IMPORTAÇÃO & PRÉ-SCANNER ====================

def cleanup_tmp_inspect(target_filename: Optional[str] = None):
    """
    Remove arquivos temporários de quarentena/inspeção da pasta uploads/tmp_inspect.
    Se target_filename for passado, remove os temporários daquele arquivo específico.
    Se for None, limpa toda a pasta de quarentena.
    """
    tmp_inspect_dir = os.path.join(UPLOAD_DIR, "tmp_inspect")
    if not os.path.exists(tmp_inspect_dir):
        return
    try:
        if target_filename:
            clean_name = os.path.basename(target_filename)
            candidates = [
                os.path.join(tmp_inspect_dir, f"inspect_{clean_name}"),
                os.path.join(tmp_inspect_dir, clean_name)
            ]
            for cand in candidates:
                if os.path.exists(cand):
                    try:
                        os.remove(cand)
                        print(f"[CLEANUP] Arquivo temporário de inspeção removido: {cand}")
                    except Exception as e:
                        print(f"[CLEANUP] Erro ao remover {cand}: {e}")
        else:
            for item in os.listdir(tmp_inspect_dir):
                item_path = os.path.join(tmp_inspect_dir, item)
                try:
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path, ignore_errors=True)
                except Exception as e:
                    print(f"[CLEANUP] Erro ao limpar item {item_path}: {e}")
            print("[CLEANUP] Pasta de quarentena temporária uploads/tmp_inspect limpa com sucesso.")
    except Exception as e:
        print(f"[CLEANUP] Erro geral ao limpar tmp_inspect: {e}")

@app.on_event("startup")
def on_startup_cleanup():
    cleanup_tmp_inspect()

@app.post("/api/import/cleanup-tmp")
def cleanup_temp_inspect_endpoint():
    cleanup_tmp_inspect()
    return {"status": "success", "message": "Pasta temporária de inspeção limpa com sucesso."}

@app.post("/api/import/inspect")
def inspect_import_local(req: InspectLocalRequest):
    if not os.path.exists(req.local_path):
        raise HTTPException(status_code=400, detail="Arquivo local não encontrado.")
    try:
        return OperationService.inspect_evidence(req.local_path, req.operation_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Erro ao inspecionar arquivo: {str(e)}")

@app.post("/api/import/inspect-upload")
async def inspect_import_upload(
    file: UploadFile = File(...),
    operation_id: Optional[int] = Form(None)
):
    tmp_inspect_dir = os.path.join(UPLOAD_DIR, "tmp_inspect")
    os.makedirs(tmp_inspect_dir, exist_ok=True)
    tmp_path = os.path.join(tmp_inspect_dir, f"inspect_{os.path.basename(file.filename)}")

    with open(tmp_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    try:
        result = OperationService.inspect_evidence(tmp_path, operation_id)
        result["temp_file_path"] = tmp_path
        return result
    except Exception as e:
        cleanup_tmp_inspect(file.filename)
        raise HTTPException(status_code=400, detail=f"Erro ao inspecionar arquivo: {str(e)}")

@app.post("/api/import/upload")
async def import_upload(
    operation_id: int = Form(...),
    phase_id: int = Form(...),
    target_id: Optional[int] = Form(None),
    target_name: Optional[str] = Form(None),
    platform: Optional[str] = Form(None),
    declared_hash: Optional[str] = Form(None),
    file: UploadFile = File(...)
):
    try:
        # Garantir existência automática de todas as pastas de upload
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        os.makedirs(os.path.join(UPLOAD_DIR, "media"), exist_ok=True)
        os.makedirs(os.path.join(UPLOAD_DIR, "avatars"), exist_ok=True)
        os.makedirs(os.path.join(UPLOAD_DIR, "custody"), exist_ok=True)

        # Preservar estritamente o nome original do arquivo enviado na pasta de custódia
        clean_filename = os.path.basename(file.filename)
        file_path = os.path.join(CUSTODY_DIR, clean_filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        result = OperationService.import_evidence(
            operation_id=operation_id,
            phase_id=phase_id,
            target_id=target_id,
            file_path=file_path,
            platform_hint=platform,
            declared_hash=declared_hash
        )

        # Se o perito digitou um nome customizado para o novo alvo
        if target_name and target_name.strip() and result.get("target_id"):
            OperationService.update_target(result["target_id"], name_or_alias=target_name.strip())
            result["target_name"] = target_name.strip()

        # Limpar arquivo temporário de prévia correspondente imediatamente após ingestão
        cleanup_tmp_inspect(file.filename)

        return result
    except Exception as e:
        cleanup_tmp_inspect(file.filename)
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Erro ao processar arquivo: {str(e)}")

class LocalImportRequest(BaseModel):
    operation_id: int
    phase_id: int
    target_id: Optional[int] = None
    target_name: Optional[str] = None
    local_path: str
    platform: Optional[str] = None
    declared_hash: Optional[str] = None

@app.post("/api/import/local")
def import_local(req: LocalImportRequest):
    if not os.path.exists(req.local_path):
        raise HTTPException(status_code=400, detail="Arquivo local não encontrado.")
    
    try:
        result = OperationService.import_evidence(
            operation_id=req.operation_id,
            phase_id=req.phase_id,
            target_id=req.target_id,
            file_path=req.local_path,
            platform_hint=req.platform,
            declared_hash=req.declared_hash
        )

        # Se o perito digitou um nome customizado para o novo alvo
        if req.target_name and req.target_name.strip() and result.get("target_id"):
            OperationService.update_target(result["target_id"], name_or_alias=req.target_name.strip())
            result["target_name"] = req.target_name.strip()

        # Limpar arquivo temporário de prévia se houver
        cleanup_tmp_inspect(req.local_path)

        return result
    except Exception as e:
        cleanup_tmp_inspect(req.local_path)
        raise e

# ==================== CADEIA DE CUSTÓDIA & AUDITORIA DE HASH ====================

@app.get("/api/custody")
def get_custody_list(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None
):
    return OperationService.get_custody_files(operation_id, phase_id, target_id)

@app.post("/api/custody/{custody_id}/verify")
def verify_custody(custody_id: int):
    return OperationService.verify_custody_file(custody_id)

class UpdateDeclaredHashRequest(BaseModel):
    declared_hash: Optional[str] = None

@app.put("/api/custody/{custody_id}/declared-hash")
@app.put("/api/custody/{custody_id}/declared_hash")
def update_custody_declared_hash(custody_id: int, req: UpdateDeclaredHashRequest):
    return OperationService.update_declared_hash(custody_id, req.declared_hash)

class VerifyAllCustodyRequest(BaseModel):
    operation_id: int
    phase_id: Optional[int] = None
    target_id: Optional[int] = None

@app.post("/api/custody/verify-all")
def verify_all_custody(req: VerifyAllCustodyRequest):
    return OperationService.verify_all_operation_custody(
        operation_id=req.operation_id,
        phase_id=req.phase_id,
        target_id=req.target_id
    )

@app.get("/api/custody/{custody_id}/download")
def download_custody_file(custody_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM custody_files WHERE id = ?", (custody_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Evidência não encontrada.")
    
    file_path = row["file_path"] or os.path.join(CUSTODY_DIR, row["file_name"])
    if not os.path.exists(file_path):
        fallback = os.path.join(CUSTODY_DIR, row["file_name"])
        if os.path.exists(fallback):
            file_path = fallback
        else:
            raise HTTPException(status_code=404, detail="Arquivo físico de custódia não encontrado no disco.")
    
    return FileResponse(
        path=file_path,
        filename=row["file_name"],
        media_type="application/octet-stream"
    )

# ==================== ROTAS INSTAGRAM ====================

@app.get("/api/instagram")
def get_instagram_data(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    account_uid: Optional[str] = None,
    search: Optional[str] = None,
    page: int = 1,
    limit: int = 50,
    rel_type: Optional[str] = None
):
    page = int(page) if not hasattr(page, 'default') else 1
    limit = int(limit) if not hasattr(limit, 'default') else 50
    conn = get_db_connection()
    cursor = conn.cursor()

    target_phase_filter = phase_id if phase_id is not None else -1

    if target_id:
        # 1. ALVO ESPECÍFICO
        q_target = """
            SELECT
                t.id as target_id,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.vanity_name IS NOT NULL AND it.vanity_name != 'unknown' THEN it.vanity_name END),
                    MAX(CASE WHEN it.vanity_name IS NOT NULL AND it.vanity_name != 'unknown' THEN it.vanity_name END),
                    t.main_identifier
                ) as vanity_name,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.full_name IS NOT NULL AND it.full_name != '' THEN it.full_name END),
                    MAX(CASE WHEN it.full_name IS NOT NULL AND it.full_name != '' THEN it.full_name END),
                    t.name_or_alias
                ) as full_name,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.email IS NOT NULL AND it.email != '' THEN it.email END),
                    MAX(CASE WHEN it.email IS NOT NULL AND it.email != '' THEN it.email END),
                    t.email
                ) as email,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.phone IS NOT NULL AND it.phone != '' THEN it.phone END),
                    MAX(CASE WHEN it.phone IS NOT NULL AND it.phone != '' THEN it.phone END),
                    t.phone
                ) as phone,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.registration_date_utc IS NOT NULL THEN it.registration_date_utc END),
                    MAX(CASE WHEN it.registration_date_utc IS NOT NULL THEN it.registration_date_utc END)
                ) as registration_date_utc,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.registration_date_brt IS NOT NULL THEN it.registration_date_brt END),
                    MAX(CASE WHEN it.registration_date_brt IS NOT NULL THEN it.registration_date_brt END)
                ) as registration_date_brt,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.registration_ip IS NOT NULL THEN it.registration_ip END),
                    MAX(CASE WHEN it.registration_ip IS NOT NULL THEN it.registration_ip END)
                ) as registration_ip,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.threads_registration_date_utc IS NOT NULL THEN it.threads_registration_date_utc END),
                    MAX(CASE WHEN it.threads_registration_date_utc IS NOT NULL THEN it.threads_registration_date_utc END)
                ) as threads_registration_date_utc,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.threads_registration_date_brt IS NOT NULL THEN it.threads_registration_date_brt END),
                    MAX(CASE WHEN it.threads_registration_date_brt IS NOT NULL THEN it.threads_registration_date_brt END)
                ) as threads_registration_date_brt,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.internal_ticket IS NOT NULL THEN it.internal_ticket END),
                    MAX(CASE WHEN it.internal_ticket IS NOT NULL THEN it.internal_ticket END)
                ) as internal_ticket,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.date_range IS NOT NULL THEN it.date_range END),
                    MAX(CASE WHEN it.date_range IS NOT NULL THEN it.date_range END)
                ) as date_range,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.report_generated_utc IS NOT NULL THEN it.report_generated_utc END),
                    MAX(CASE WHEN it.report_generated_utc IS NOT NULL THEN it.report_generated_utc END)
                ) as report_generated_utc,
                COALESCE(
                    MAX(CASE WHEN it.phase_id = ? AND it.target_uid IS NOT NULL THEN it.target_uid END),
                    MAX(it.target_uid)
                ) as target_uid,
                t.name_or_alias,
                t.main_identifier as registered_id
            FROM targets t
            LEFT JOIN instagram_targets it ON it.target_id = t.id
            WHERE t.operation_id = ? AND t.id = ?
            GROUP BY t.id
            LIMIT 1
        """
        p_target = [
            target_phase_filter, target_phase_filter, target_phase_filter, target_phase_filter,
            target_phase_filter, target_phase_filter, target_phase_filter, target_phase_filter,
            target_phase_filter, target_phase_filter, target_phase_filter, target_phase_filter,
            target_phase_filter, operation_id, target_id
        ]
        cursor.execute(q_target, p_target)
        target_row = cursor.fetchone()
        target = dict(target_row) if target_row else None
        if not target:
            conn.close()
            return {"target": None, "relationships": [], "total": 0, "page": page, "limit": limit, "stats": {}}

        # Buscar todas as contas/fakes vinculadas ao alvo
        q_acc = """
            SELECT it.*,
                   (SELECT COUNT(DISTINCT thread_id) FROM messages WHERE target_id = it.target_id AND (sender_id = it.target_uid OR sender_username = it.vanity_name)) as dm_threads_count,
                   (SELECT COUNT(*) FROM messages WHERE target_id = it.target_id AND (sender_id = it.target_uid OR sender_username = it.vanity_name)) as messages_count
            FROM instagram_targets it
            WHERE it.target_id = ?
        """
        p_acc = [target_id]
        if phase_id:
            q_acc += " AND it.phase_id = ?"
            p_acc.append(phase_id)
        q_acc += " ORDER BY it.id ASC"
        cursor.execute(q_acc, p_acc)
        acc_rows = [dict(r) for r in cursor.fetchall()]
        target["accounts"] = acc_rows

        # Se account_uid foi especificado, priorizar dados ESTRITOS daquela conta específica no cabeçalho
        if account_uid and acc_rows:
            selected_acc = next((a for a in acc_rows if str(a["target_uid"]) == str(account_uid) or a["vanity_name"] == account_uid), None)
            if selected_acc:
                target["selected_account_uid"] = selected_acc["target_uid"]
                target["vanity_name"] = selected_acc.get("vanity_name")
                target["full_name"] = selected_acc.get("full_name")
                target["email"] = selected_acc.get("email")
                target["phone"] = selected_acc.get("phone")
                target["registration_ip"] = selected_acc.get("registration_ip")
                target["registration_date_utc"] = selected_acc.get("registration_date_utc")
                target["registration_date_brt"] = selected_acc.get("registration_date_brt")
                target["threads_registration_date_utc"] = selected_acc.get("threads_registration_date_utc")
                target["threads_registration_date_brt"] = selected_acc.get("threads_registration_date_brt")
                target["internal_ticket"] = selected_acc.get("internal_ticket")
                target["date_range"] = selected_acc.get("date_range")
                target["report_generated_utc"] = selected_acc.get("report_generated_utc")
                target["target_uid"] = selected_acc.get("target_uid")
        elif acc_rows:
            # Em visão geral do alvo, agregar dados cadastrais de todas as contas vinculadas
            emails = []
            phones = []
            ips = []
            for a in acc_rows:
                if a.get("email") and a["email"] not in emails:
                    emails.append(a["email"])
                if a.get("phone") and a["phone"] not in phones:
                    phones.append(a["phone"])
                if a.get("registration_ip") and a["registration_ip"] not in ips:
                    ips.append(a["registration_ip"])
            if emails:
                target["email"] = " • ".join(emails)
            if phones:
                target["phone"] = " • ".join(phones)
            if ips:
                target["registration_ip"] = ", ".join(ips)

        # Stats do alvo individual (filtrado por account_uid se selecionado)
        q_stats = "SELECT rel_type, COUNT(*) as count FROM instagram_relationships WHERE target_id = ?"
        p_stats = [target_id]
        if phase_id:
            q_stats += " AND phase_id = ?"
            p_stats.append(phase_id)
        if account_uid:
            q_stats += " AND (target_uid = ? OR target_uid IS NULL)"
            p_stats.append(account_uid)
        q_stats += " GROUP BY rel_type"
        cursor.execute(q_stats, p_stats)
        stats = {r["rel_type"]: r["count"] for r in cursor.fetchall()}

        # DMs, IPs e Mídias do alvo
        q_dm = "SELECT COUNT(DISTINCT thread_id), COUNT(*) FROM messages WHERE target_id = ? AND platform = 'instagram'"
        p_dm = [target_id]
        if phase_id:
            q_dm += " AND phase_id = ?"
            p_dm.append(phase_id)
        if account_uid:
            q_dm += " AND (sender_id = ? OR participants LIKE ?)"
            p_dm.extend([account_uid, f"%{account_uid}%"])
        cursor.execute(q_dm, p_dm)
        dm_threads, dm_total = cursor.fetchone()
        stats["dm_threads"] = dm_threads
        stats["dm_total"] = dm_total

        q_ip = "SELECT COUNT(*) FROM instagram_connections WHERE target_id = ?"
        p_ip = [target_id]
        if phase_id:
            q_ip += " AND phase_id = ?"
            p_ip.append(phase_id)
        if account_uid:
            q_ip += " AND (target_uid = ? OR target_uid IS NULL)"
            p_ip.append(account_uid)
        cursor.execute(q_ip, p_ip)
        stats["ip_connections"] = cursor.fetchone()[0]

        q_media = "SELECT COUNT(*) FROM messages WHERE target_id = ? AND platform = 'instagram' AND media_path IS NOT NULL AND media_path != ''"
        p_media = [target_id]
        if phase_id:
            q_media += " AND phase_id = ?"
            p_media.append(phase_id)
        if account_uid:
            q_media += " AND (sender_id = ? OR participants LIKE ?)"
            p_media.extend([account_uid, f"%{account_uid}%"])
        cursor.execute(q_media, p_media)
        stats["media_count"] = cursor.fetchone()[0]

        q_devices = "SELECT COUNT(*) FROM instagram_devices WHERE target_id = ?"
        p_devices = [target_id]
        if phase_id:
            q_devices += " AND phase_id = ?"
            p_devices.append(phase_id)
        if account_uid:
            q_devices += " AND (target_uid = ? OR target_uid IS NULL)"
            p_devices.append(account_uid)
        cursor.execute(q_devices, p_devices)
        stats["devices_count"] = cursor.fetchone()[0]

        # Query de relacionamentos do alvo
        query = "SELECT r.*, t.name_or_alias as target_name, t.main_identifier as target_identifier FROM instagram_relationships r JOIN targets t ON r.target_id = t.id WHERE r.target_id = ?"
        params = [target_id]
        if phase_id:
            query += " AND r.phase_id = ?"
            params.append(phase_id)
        if account_uid:
            query += " AND (r.target_uid = ? OR r.target_uid IS NULL)"
            params.append(account_uid)

    else:
        # 2. TODOS OS ALVOS (VISÃO CONSOLIDADA COM SOMA TOTAL)
        # Buscar lista de alvos da operação/fase
        if phase_id:
            cursor.execute("SELECT t.id, t.name_or_alias, t.main_identifier FROM targets t JOIN target_phases tp ON tp.target_id = t.id WHERE t.operation_id = ? AND tp.phase_id = ?", (operation_id, phase_id))
        else:
            cursor.execute("SELECT t.id, t.name_or_alias, t.main_identifier FROM targets t WHERE t.operation_id = ?", (operation_id,))
        
        all_targets = [dict(r) for r in cursor.fetchall()]
        target_count = len(all_targets)

        if target_count == 0:
            conn.close()
            return {"target": None, "relationships": [], "total": 0, "page": page, "limit": limit, "stats": {}}

        # Estatísticas Consolidadas (SOMA de todos os alvos)
        q_stats = """
            SELECT r.rel_type, COUNT(*) as count
            FROM instagram_relationships r
            JOIN targets t ON r.target_id = t.id
            WHERE t.operation_id = ?
        """
        p_stats = [operation_id]
        if phase_id:
            q_stats += " AND r.phase_id = ?"
            p_stats.append(phase_id)
        q_stats += " GROUP BY r.rel_type"
        cursor.execute(q_stats, p_stats)
        stats = {r["rel_type"]: r["count"] for r in cursor.fetchall()}

        # DMs Consolidadas
        q_dm = "SELECT COUNT(DISTINCT thread_id), COUNT(*) FROM messages WHERE operation_id = ? AND platform = 'instagram'"
        p_dm = [operation_id]
        if phase_id:
            q_dm += " AND phase_id = ?"
            p_dm.append(phase_id)
        cursor.execute(q_dm, p_dm)
        dm_threads, dm_total = cursor.fetchone()
        stats["dm_threads"] = dm_threads
        stats["dm_total"] = dm_total

        # IPs Consolidados
        q_ip = """
            SELECT COUNT(*)
            FROM instagram_connections c
            JOIN targets t ON c.target_id = t.id
            WHERE t.operation_id = ?
        """
        p_ip = [operation_id]
        if phase_id:
            q_ip += " AND c.phase_id = ?"
            p_ip.append(phase_id)
        cursor.execute(q_ip, p_ip)
        stats["ip_connections"] = cursor.fetchone()[0]

        # Mídias Consolidadas
        q_media = "SELECT COUNT(*) FROM messages WHERE operation_id = ? AND platform = 'instagram' AND media_path IS NOT NULL AND media_path != ''"
        p_media = [operation_id]
        if phase_id:
            q_media += " AND phase_id = ?"
            p_media.append(phase_id)
        cursor.execute(q_media, p_media)
        stats["media_count"] = cursor.fetchone()[0]

        # Dispositivos Consolidados
        q_devices = """
            SELECT COUNT(*)
            FROM instagram_devices d
            JOIN targets t ON d.target_id = t.id
            WHERE t.operation_id = ?
        """
        p_devices = [operation_id]
        if phase_id:
            q_devices += " AND d.phase_id = ?"
            p_devices.append(phase_id)
        cursor.execute(q_devices, p_devices)
        stats["devices_count"] = cursor.fetchone()[0]

        # Objeto de Alvo Consolidado
        target = {
            "target_id": None,
            "is_consolidated": True,
            "target_count": target_count,
            "vanity_name": f"{target_count} Alvos Investigados",
            "full_name": f"Visão Consolidada ({target_count} perfis)",
            "registered_id": "Todos os Alvos",
            "email": f"{target_count} investigados cadastrados",
            "phone": "Dados consolidados",
            "registration_ip": f"{stats['ip_connections']} conexões catalogadas",
            "registration_date_brt": "Consolidado Geral",
            "registration_date_utc": None,
            "threads_registration_date_brt": "---",
            "internal_ticket": "Todos os autos",
            "date_range": "Período global da investigação",
            "report_generated_utc": "Automático",
            "target_uid": f"{target_count} perfis"
        }

        # Query de relacionamentos de TODOS os alvos
        query = """
            SELECT r.*, t.name_or_alias as target_name, t.main_identifier as target_identifier
            FROM instagram_relationships r
            JOIN targets t ON r.target_id = t.id
            WHERE t.operation_id = ?
        """
        params = [operation_id]
        if phase_id:
            query += " AND r.phase_id = ?"
            params.append(phase_id)

    # Filtros adicionais de busca e tipo de vínculo
    if rel_type and rel_type != 'all':
        query += " AND r.rel_type = ?"
        params.append(rel_type)
    if search:
        query += " AND (r.username LIKE ? OR r.uid LIKE ? OR r.display_name LIKE ?)"
        s = f"%{search}%"
        params.extend([s, s, s])

    count_query = f"SELECT COUNT(*) FROM ({query})"
    cursor.execute(count_query, params)
    total_count = cursor.fetchone()[0]
    offset = (page - 1) * limit
    paginated_query = f"{query} ORDER BY r.id ASC LIMIT ? OFFSET ?"
    cursor.execute(paginated_query, params + [limit, offset])
    relationships = [dict(r) for r in cursor.fetchall()]

    cursor.execute("""
        SELECT t.id, t.name_or_alias, t.main_identifier, it.vanity_name, it.target_uid
        FROM targets t
        LEFT JOIN instagram_targets it ON it.target_id = t.id
        WHERE t.operation_id = ?
    """, (operation_id,))
    op_targets = [dict(t) for t in cursor.fetchall()]

    conn.close()
    return {
        "target": target,
        "operation_targets": op_targets,
        "is_consolidated": target.get("is_consolidated", False),
        "stats": stats,
        "relationships": relationships,
        "total": total_count,
        "page": page,
        "limit": limit
    }

# ==================== ROTAS DE INTELIGÊNCIA DE IPS ====================

@app.get("/api/instagram/connections")
def get_instagram_connections(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    account_uid: Optional[str] = None
):
    return IpService.get_ip_intelligence(operation_id, phase_id, target_id, account_uid)

@app.post("/api/instagram/ips/identify-all")
def identify_all_target_ips(
    operation_id: int = Query(...),
    phase_id: Optional[int] = Query(None),
    target_id: Optional[int] = Query(None),
    account_uid: Optional[str] = Query(None)
):
    intel = IpService.get_ip_intelligence(operation_id, phase_id, target_id, account_uid)
    unique_ips = [r["ip_address"] for r in intel.get("ranked_ips", [])]
    IpService.batch_enrich_ips(unique_ips)
    return IpService.get_ip_intelligence(operation_id, phase_id, target_id, account_uid)

@app.get("/api/ip/lookup")
def lookup_single_ip(ip: str):
    return IpService.enrich_ip(ip, force_refresh=True)

@app.get("/api/instagram/media")
def get_instagram_media(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    account_uid: Optional[str] = None,
    thread_id: Optional[str] = None,
    media_type: Optional[str] = None,
    search: Optional[str] = None,
    order: Optional[str] = "desc",
    page: int = 1,
    limit: int = 40
):
    page = int(page) if not hasattr(page, 'default') else 1
    limit = int(limit) if not hasattr(limit, 'default') else 40

    conn = get_db_connection()
    cursor = conn.cursor()

    base_where = "WHERE m.operation_id = ? AND m.platform = 'instagram' AND m.media_path IS NOT NULL AND m.media_path != ''"
    base_params = [operation_id]

    if target_id:
        base_where += " AND m.target_id = ?"
        base_params.append(target_id)
    if phase_id:
        base_where += " AND m.phase_id = ?"
        base_params.append(phase_id)
    if account_uid:
        base_where += " AND (m.sender_id = ? OR m.participants LIKE ?)"
        base_params.extend([account_uid, f"%{account_uid}%"])
    if thread_id:
        base_where += " AND m.thread_id = ?"
        base_params.append(thread_id)
    if search:
        base_where += " AND (m.content LIKE ? OR m.transcription LIKE ? OR m.sender_username LIKE ? OR m.media_path LIKE ?)"
        s = f"%{search}%"
        base_params.extend([s, s, s, s])

    # Estatísticas de tipos de mídia (calculadas para TODO o escopo, sem serem zeradas pelo tipo selecionado)
    stats_query = f"""
        SELECT m.message_type, COUNT(*) as count
        FROM messages m
        {base_where}
        GROUP BY m.message_type
    """
    cursor.execute(stats_query, base_params)
    stats = {r["message_type"]: r["count"] for r in cursor.fetchall()}
    stats["total"] = sum(stats.values())

    # Filtro específico para a listagem da página atual
    filter_where = base_where
    filter_params = list(base_params)
    if media_type:
        filter_where += " AND m.message_type = ?"
        filter_params.append(media_type)

    # Contagem total para paginação
    count_query = f"SELECT COUNT(*) FROM messages m {filter_where}"
    cursor.execute(count_query, filter_params)
    total_count = cursor.fetchone()[0]

    # Ordenação por data (ascendente: mais antigo primeiro; descendente: mais recente primeiro)
    sort_dir = "ASC" if str(order).lower() == "asc" else "DESC"

    # Buscar itens
    query = f"""
        SELECT m.*, t.name_or_alias as target_name, t.main_identifier as target_identifier
        FROM messages m
        JOIN targets t ON m.target_id = t.id
        {filter_where}
        ORDER BY m.timestamp_utc {sort_dir}, m.id {sort_dir}
        LIMIT ? OFFSET ?
    """
    p_items = list(filter_params)
    p_items.extend([limit, (page - 1) * limit])

    cursor.execute(query, p_items)
    items = []
    for r in cursor.fetchall():
        d = dict(r)
        try:
            d["participants"] = json.loads(d["participants"]) if d["participants"] else []
        except Exception:
            d["participants"] = []
        items.append(d)

    conn.close()
    return {
        "media": items,
        "total": total_count,
        "page": page,
        "limit": limit,
        "stats": stats
    }

@app.get("/api/instagram/devices")
def get_instagram_devices(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    account_uid: Optional[str] = None,
    search: Optional[str] = None
):
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
        SELECT d.*, t.name_or_alias as target_name, t.main_identifier as target_identifier
        FROM instagram_devices d
        JOIN targets t ON d.target_id = t.id
        WHERE t.operation_id = ?
    """
    params = [operation_id]
    if target_id:
        query += " AND d.target_id = ?"
        params.append(target_id)
    if phase_id:
        query += " AND d.phase_id = ?"
        params.append(phase_id)
    if account_uid:
        query += " AND (d.target_uid = ? OR d.target_uid IS NULL)"
        params.append(account_uid)
    if search:
        s = f"%{search.strip()}%"
        query += " AND (d.device_id LIKE ? OR d.device_type LIKE ? OR d.associated_users LIKE ?)"
        params.extend([s, s, s])

    query += " ORDER BY d.id ASC"
    cursor.execute(query, params)
    devices = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return {
        "devices": devices,
        "total": len(devices),
        "is_consolidated": target_id is None
    }

@app.get("/api/instagram/threads")
def get_instagram_threads(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    account_uid: Optional[str] = None,
    search: Optional[str] = None,
    sort_by: Optional[str] = "recent",
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Buscar todos os alvos e seus perfis/fakes na operação para filtrar interlocutores
    cursor.execute("SELECT id, name_or_alias, main_identifier FROM targets WHERE operation_id = ?", (operation_id,))
    op_targets = [dict(t) for t in cursor.fetchall()]
    target_identifiers = set()
    target_map = {}
    for ot in op_targets:
        ident = (ot.get("main_identifier") or ot.get("name_or_alias") or "").strip()
        target_map[ot["id"]] = ident
        if ot.get("main_identifier"):
            target_identifiers.add(ot["main_identifier"].replace("@", "").lower().strip())
        if ot.get("name_or_alias"):
            target_identifiers.add(ot["name_or_alias"].replace("@", "").lower().strip())

    cursor.execute("SELECT it.vanity_name, it.target_uid FROM instagram_targets it JOIN targets t ON it.target_id = t.id WHERE t.operation_id = ?", (operation_id,))
    for it_row in cursor.fetchall():
        if it_row["vanity_name"]:
            target_identifiers.add(it_row["vanity_name"].replace("@", "").lower().strip())
        if it_row["target_uid"]:
            target_identifiers.add(str(it_row["target_uid"]).strip())

    where_clauses = ["operation_id = ?", "platform = 'instagram'"]
    params = [operation_id]
    if target_id:
        where_clauses.append("target_id = ?")
        params.append(target_id)
    if phase_id:
        where_clauses.append("phase_id = ?")
        params.append(phase_id)
    if account_uid:
        where_clauses.append("(sender_id = ? OR participants LIKE ?)")
        params.extend([account_uid, f"%{account_uid}%"])
    if start_date:
        where_clauses.append("timestamp_utc >= ?")
        params.append(f"{start_date} 00:00:00")
    if end_date:
        where_clauses.append("timestamp_utc <= ?")
        params.append(f"{end_date} 23:59:59")
    if search:
        search_clean = search.strip()
        raw_terms = [t.strip() for t in search_clean.replace(',', ' ').split() if len(t.strip()) >= 1]
        if raw_terms:
            sub_clauses = []
            for term in raw_terms:
                sub_clauses.append("(content LIKE ? OR participants LIKE ? OR sender_username LIKE ?)")
                s = f"%{term}%"
                params.extend([s, s, s])
            where_clauses.append(f"({' OR '.join(sub_clauses)})")
        else:
            where_clauses.append("(content LIKE ? OR participants LIKE ? OR sender_username LIKE ?)")
            s = f"%{search_clean}%"
            params.extend([s, s, s])

    where_sql = " AND ".join(where_clauses)
    order_sql = "ORDER BY agg.message_count DESC, agg.last_activity_utc DESC" if sort_by == "count" else "ORDER BY agg.last_activity_utc DESC"

    # Query com CTE para ranquear a última mensagem e agregar estatísticas
    query = f"""
        WITH ranked_messages AS (
            SELECT id, thread_id, target_id, participants, sender_username, timestamp_utc, timestamp_brt, message_type, content, media_path,
                   ROW_NUMBER() OVER (PARTITION BY thread_id ORDER BY timestamp_utc DESC, id DESC) as rn
            FROM messages
            WHERE {where_sql}
        )
        SELECT 
            agg.thread_id,
            rm.target_id,
            agg.participants,
            agg.distinct_senders,
            agg.message_count,
            agg.first_activity_utc,
            agg.last_activity_utc,
            agg.first_activity_brt,
            agg.last_activity_brt,
            rm.content as last_message_content,
            rm.message_type as last_message_type,
            rm.sender_username as last_message_sender,
            rm.media_path as last_message_media_path
        FROM (
            SELECT thread_id,
                   MAX(CASE WHEN participants IS NOT NULL AND participants != '[]' AND participants != 'null' THEN participants ELSE '' END) as participants,
                   GROUP_CONCAT(DISTINCT sender_username) as distinct_senders,
                   COUNT(*) as message_count,
                   MIN(timestamp_utc) as first_activity_utc,
                   MAX(timestamp_utc) as last_activity_utc,
                   MIN(timestamp_brt) as first_activity_brt,
                   MAX(timestamp_brt) as last_activity_brt
            FROM messages
            WHERE {where_sql}
            GROUP BY thread_id
        ) agg
        JOIN ranked_messages rm ON agg.thread_id = rm.thread_id AND rm.rn = 1
        {order_sql}
    """

    cursor.execute(query, params + params)
    threads = []
    for r in cursor.fetchall():
        th = dict(r)
        plist = []
        try:
            if th.get("participants"):
                plist = json.loads(th["participants"])
        except Exception:
            plist = []

        if not plist and th.get("distinct_senders"):
            plist = [s.strip() for s in th["distinct_senders"].split(",") if s.strip()]

        clean_p = list(dict.fromkeys([str(p).strip() for p in plist if p and str(p).strip()]))
        th["participants"] = clean_p
        th["target_identifier"] = target_map.get(th.get("target_id"), "")

        # Filtrar interlocutores excluindo os alvos e seus perfis fakes
        interlocutors = [p for p in clean_p if p.replace("@", "").lower().strip() not in target_identifiers]
        
        # Identificar se é grupo (2+ interlocutores ou 3+ participantes no total)
        th["is_group"] = len(interlocutors) >= 2 or len(clean_p) >= 3
        th["interlocutors"] = interlocutors if interlocutors else clean_p

        threads.append(th)

    conn.close()
    return threads

@app.get("/api/instagram/active-dates")
def get_instagram_active_dates(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    thread_id: Optional[str] = None
):
    conn = get_db_connection()
    cursor = conn.cursor()

    where = "WHERE operation_id = ? AND platform = 'instagram'"
    params = [operation_id]
    if target_id:
        where += " AND target_id = ?"
        params.append(target_id)
    if phase_id:
        where += " AND phase_id = ?"
        params.append(phase_id)
    if thread_id:
        where += " AND thread_id = ?"
        params.append(thread_id)

    q = f"""
        SELECT substr(timestamp_utc, 1, 10) as date_str, COUNT(*) as msg_count
        FROM messages
        {where}
        GROUP BY date_str
        ORDER BY date_str ASC
    """
    cursor.execute(q, params)
    rows = cursor.fetchall()
    dates = [r["date_str"] for r in rows if r["date_str"]]
    date_counts = {r["date_str"]: r["msg_count"] for r in rows if r["date_str"]}

    conn.close()
    return {
        "dates": dates,
        "date_counts": date_counts,
        "min_date": dates[0] if dates else None,
        "max_date": dates[-1] if dates else None,
        "total_days": len(dates)
    }

@app.get("/api/instagram/threads/{thread_id}/messages")
def get_thread_messages(
    operation_id: int,
    thread_id: str,
    target_id: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
):
    conn = get_db_connection()
    cursor = conn.cursor()
    q = """
        SELECT 
            m.*,
            (
                CASE 
                    WHEN it.target_uid IS NOT NULL AND TRIM(m.sender_id) = TRIM(it.target_uid) THEN 1
                    WHEN it.vanity_name IS NOT NULL AND LOWER(REPLACE(m.sender_username, '@', '')) = LOWER(REPLACE(it.vanity_name, '@', '')) THEN 1
                    WHEN t.main_identifier IS NOT NULL AND LOWER(REPLACE(m.sender_username, '@', '')) = LOWER(REPLACE(t.main_identifier, '@', '')) THEN 1
                    ELSE 0 
                END
            ) as is_target_sender,
            it.vanity_name as target_vanity,
            it.target_uid as target_account_uid,
            t.name_or_alias as target_display_name
        FROM messages m
        LEFT JOIN targets t ON m.target_id = t.id
        LEFT JOIN instagram_targets it ON m.target_id = it.target_id
        WHERE m.operation_id = ? AND m.platform = 'instagram' AND m.thread_id = ?
    """
    p = [operation_id, thread_id]
    if target_id:
        q += " AND m.target_id = ?"
        p.append(target_id)
    if start_date:
        q += " AND m.timestamp_utc >= ?"
        p.append(f"{start_date} 00:00:00")
    if end_date:
        q += " AND m.timestamp_utc <= ?"
        p.append(f"{end_date} 23:59:59")
    q += " ORDER BY m.timestamp_utc ASC"
    cursor.execute(q, p)
    messages = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return messages

# ==================== ROTAS DE TRANSCRIÇÃO DE ÁUDIO (WHISPER SMALL) ====================

@app.get("/api/whisper/status")
def get_whisper_status():
    """Retorna o status de instalação e progresso do download do modelo Whisper."""
    try:
        from backend.services.transcription_service import AudioTranscriptionService
        service = AudioTranscriptionService.get_instance()
        return {"success": True, "data": service.get_status()}
    except Exception as e:
        logger.error(f"Erro ao consultar status do Whisper: {e}")
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=500, content={"success": False, "detail": str(e)})

@app.post("/api/whisper/download")
def download_whisper_model():
    """Dispara o download seguro e assíncrono do modelo Whisper small em segundo plano."""
    try:
        from backend.services.transcription_service import AudioTranscriptionService
        service = AudioTranscriptionService.get_instance()
        result = service.start_download_async()
        return {"success": True, "data": result}
    except Exception as e:
        logger.error(f"Erro ao iniciar download do Whisper: {e}")
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=500, content={"success": False, "detail": str(e)})

class TranscriptionReviewRequest(BaseModel):
    transcription: str

@app.post("/api/messages/{message_id}/transcribe")
def transcribe_single_message(message_id: int, force: bool = False):
    """Executa a transcrição forense do áudio localmente via Whisper small."""
    try:
        from backend.services.transcription_service import AudioTranscriptionService
        service = AudioTranscriptionService.get_instance()
        result = service.transcribe_message(message_id, force=force)
        return {"success": True, "data": result}
    except Exception as e:
        logger.error(f"Erro ao transcrever mensagem {message_id}: {e}")
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=400, content={"success": False, "detail": str(e)})

@app.put("/api/messages/{message_id}/transcription")
def update_message_transcription(message_id: int, req: TranscriptionReviewRequest):
    """Salva a revisão pericial do texto da transcrição realizada pelo analista."""
    try:
        from backend.services.transcription_service import AudioTranscriptionService
        service = AudioTranscriptionService.get_instance()
        result = service.update_analyst_review(message_id, req.transcription)
        return {"success": True, "data": result}
    except Exception as e:
        logger.error(f"Erro ao atualizar transcrição {message_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/threads/{thread_id}/transcribe-all")
def transcribe_thread_all(thread_id: str, operation_id: int, limit: int = 50):
    """Transcreve em lote todos os áudios pendentes da conversa informada."""
    try:
        from backend.services.transcription_service import AudioTranscriptionService
        service = AudioTranscriptionService.get_instance()
        result = service.transcribe_thread_batch(thread_id, operation_id, limit=limit)
        return {"success": True, "data": result}
    except Exception as e:
        logger.error(f"Erro ao transcrever lote da thread {thread_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ==================== ROTAS DE AVATARES & FOTOS DE PERFIL (ONLINE / OFFLINE) ====================

class SingleAvatarRequest(BaseModel):
    username: str
    user_id: Optional[str] = None
    target_id: Optional[int] = None

class BatchAvatarRequest(BaseModel):
    operation_id: Optional[int] = None
    target_id: Optional[int] = None
    limit: Optional[int] = None

@app.get("/api/instagram/avatars/map")
def get_avatars_map(target_id: Optional[int] = None):
    """Retorna o mapeamento de todos os avatares já baixados e salvos localmente."""
    return get_all_cached_avatars_map(target_id)

@app.get("/api/instagram/avatars/status")
def get_avatars_status():
    """Retorna o status do progresso do download em lote."""
    return get_avatar_sync_status()

@app.get("/api/instagram/avatars/pending-count")
def get_pending_avatars(operation_id: Optional[int] = None, target_id: Optional[int] = None):
    """Retorna contagem de pendentes e já salvos."""
    return get_pending_avatars_count(operation_id, target_id)

@app.post("/api/instagram/avatars/sync")
def trigger_batch_avatar_sync(req: BatchAvatarRequest, background_tasks: BackgroundTasks):
    """Inicia a sincronização contínua de todos os perfis pendentes em segundo plano."""
    status = get_avatar_sync_status()
    if status.get("in_progress"):
        return {"status": "already_running", "progress": status}
    
    background_tasks.add_task(batch_sync_avatars, req.operation_id, req.target_id, req.limit)
    return {"status": "started"}

@app.post("/api/instagram/avatars/fetch-single")
def fetch_single_avatar(req: SingleAvatarRequest):
    """Busca sob demanda e baixa a foto de um único perfil."""
    url = fetch_and_cache_avatar(req.username, req.user_id, req.target_id)
    if url:
        return {"success": True, "avatar_url": url}
    return {"success": False, "message": "Foto não encontrada ou perfil privado"}

# ==================== ROTAS DE EVIDÊNCIAS & RELATÓRIO PERICIAL ====================

class EvidenceToggleRequest(BaseModel):
    operation_id: int
    message_id: int
    tag_label: Optional[str] = None
    tags: Optional[List[str]] = None
    analyst_notes: Optional[str] = ""
    is_included: bool

def parse_tag_labels(raw_label: Optional[str]) -> List[str]:
    if not raw_label:
        return ["Prova Chave"]
    raw_str = str(raw_label).strip()
    if raw_str.startswith("[") and raw_str.endswith("]"):
        try:
            parsed = json.loads(raw_str)
            if isinstance(parsed, list):
                clean = [str(t).strip() for t in parsed if str(t).strip()]
                return clean if clean else ["Prova Chave"]
        except Exception:
            pass
    if "," in raw_str:
        clean = [t.strip() for t in raw_str.split(",") if t.strip()]
        return clean if clean else ["Prova Chave"]
    return [raw_str]

@app.get("/api/evidence/tags")
def get_evidence_tags(operation_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT et.message_id, et.tag_label, et.analyst_notes, et.created_at, m.thread_id, m.platform
        FROM message_evidence_tags et
        LEFT JOIN messages m ON et.message_id = m.id
        WHERE et.operation_id = ?
    """, (operation_id,))
    rows = cursor.fetchall()
    result = {}
    for r in rows:
        tag_list = parse_tag_labels(r["tag_label"])
        result[str(r["message_id"])] = {
            "tag_label": ", ".join(tag_list),
            "tags": tag_list,
            "analyst_notes": r["analyst_notes"],
            "created_at": r["created_at"],
            "thread_id": r["thread_id"],
            "platform": r["platform"]
        }
    conn.close()
    return result

@app.get("/api/evidence/tags-summary")
def get_evidence_tags_summary(operation_id: int, phase_id: Optional[int] = None, target_id: Optional[int] = None):
    conn = get_db_connection()
    cursor = conn.cursor()
    q = """
        SELECT et.tag_label, m.platform
        FROM message_evidence_tags et
        JOIN messages m ON et.message_id = m.id
        WHERE et.operation_id = ?
    """
    p = [operation_id]
    if phase_id:
        q += " AND m.phase_id = ?"
        p.append(phase_id)
    if target_id:
        q += " AND m.target_id = ?"
        p.append(target_id)
    cursor.execute(q, p)
    rows = cursor.fetchall()
    tag_counts = {}
    total_msgs = len(rows)
    for r in rows:
        t_list = parse_tag_labels(r["tag_label"])
        for t in t_list:
            tag_counts[t] = tag_counts.get(t, 0) + 1
    conn.close()
    return {
        "total_evidence_messages": total_msgs,
        "tag_counts": tag_counts
    }

@app.post("/api/evidence/toggle")
def toggle_evidence_tag(req: EvidenceToggleRequest):
    conn = get_db_connection()
    cursor = conn.cursor()
    if req.is_included:
        tags_input = req.tags if req.tags is not None else ([req.tag_label] if req.tag_label else ["Prova Chave"])
        clean_tags = list(dict.fromkeys([str(t).strip() for t in tags_input if str(t).strip()]))
        if not clean_tags:
            clean_tags = ["Prova Chave"]
        stored_json = json.dumps(clean_tags, ensure_ascii=False)
        
        cursor.execute("""
            INSERT INTO message_evidence_tags (operation_id, message_id, tag_label, analyst_notes, created_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(operation_id, message_id)
            DO UPDATE SET tag_label = excluded.tag_label, analyst_notes = excluded.analyst_notes
        """, (req.operation_id, req.message_id, stored_json, req.analyst_notes or ""))
    else:
        cursor.execute("""
            DELETE FROM message_evidence_tags
            WHERE operation_id = ? AND message_id = ?
        """, (req.operation_id, req.message_id))
    conn.commit()
    conn.close()
    return {"status": "success", "message_id": req.message_id, "is_included": req.is_included}

@app.get("/api/evidence/report-data")
def get_evidence_report_data(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    filter_tags: Optional[str] = None
):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Operação
    cursor.execute("SELECT * FROM operations WHERE id = ?", (operation_id,))
    op_row = cursor.fetchone()
    operation = dict(op_row) if op_row else {}

    # Fase
    phase = None
    if phase_id:
        cursor.execute("SELECT * FROM phases WHERE id = ?", (phase_id,))
        p_row = cursor.fetchone()
        if p_row:
            phase = dict(p_row)

    # Alvo
    target = None
    if target_id:
        cursor.execute("SELECT * FROM targets WHERE id = ?", (target_id,))
        t_row = cursor.fetchone()
        if t_row:
            target = dict(t_row)
            cursor.execute("SELECT * FROM instagram_targets WHERE target_id = ?", (target_id,))
            ig_t = cursor.fetchone()
            if ig_t:
                target["instagram_profile"] = dict(ig_t)

    # Arquivos de Custódia
    custody_q = "SELECT * FROM custody_files WHERE operation_id = ?"
    custody_p = [operation_id]
    if phase_id:
        custody_q += " AND phase_id = ?"
        custody_p.append(phase_id)
    if target_id:
        custody_q += " AND target_id = ?"
        custody_p.append(target_id)
    cursor.execute(custody_q, custody_p)
    custody_files = [dict(r) for r in cursor.fetchall()]

    # Mensagens de Evidência Selecionadas
    ev_q = """
        SELECT m.*, t.name_or_alias as target_name, t.main_identifier as target_identifier,
               et.tag_label, et.analyst_notes, et.created_at as tagged_at
        FROM messages m
        JOIN message_evidence_tags et ON m.id = et.message_id
        JOIN targets t ON m.target_id = t.id
        WHERE et.operation_id = ?
    """
    ev_p = [operation_id]
    if phase_id:
        ev_q += " AND m.phase_id = ?"
        ev_p.append(phase_id)
    if target_id:
        ev_q += " AND m.target_id = ?"
        ev_p.append(target_id)
    ev_q += " ORDER BY m.thread_id ASC, m.timestamp_utc ASC"

    cursor.execute(ev_q, ev_p)
    raw_evidences = [dict(r) for r in cursor.fetchall()]

    # Processar tags de cada evidência e aplicar filtro se especificado
    selected_tags_set = set([t.strip().lower() for t in filter_tags.split(",") if t.strip()]) if filter_tags else None

    filtered_evidences = []
    for ev in raw_evidences:
        t_list = parse_tag_labels(ev.get("tag_label"))
        ev["tags"] = t_list
        ev["tag_display"] = ", ".join(t_list)

        if selected_tags_set is not None:
            msg_tags_lower = set([t.lower() for t in t_list])
            if not (msg_tags_lower & selected_tags_set):
                continue
        filtered_evidences.append(ev)

    # Agrupar por conversa / thread
    threads_map = {}
    for ev in filtered_evidences:
        th_id = ev["thread_id"]
        if th_id not in threads_map:
            try:
                parts = json.loads(ev["participants"]) if ev.get("participants") else []
            except Exception:
                parts = []
            threads_map[th_id] = {
                "thread_id": th_id,
                "participants": parts,
                "messages": []
            }
        threads_map[th_id]["messages"].append(ev)

    conn.close()
    return {
        "operation": operation,
        "phase": phase,
        "target": target,
        "custody_files": custody_files,
        "total_evidence_count": len(filtered_evidences),
        "threads": list(threads_map.values())
    }

# ==================== ROTAS DE ANOTAÇÕES & MARCADORES DE DMs ====================

class DmAnnotationReadRequest(BaseModel):
    operation_id: int
    platform: Optional[str] = "instagram"
    thread_id: str
    is_read: bool

class DmAnnotationStarRequest(BaseModel):
    operation_id: int
    platform: Optional[str] = "instagram"
    thread_id: str
    is_starred: bool

class DmAnnotationBookmarkRequest(BaseModel):
    operation_id: int
    platform: Optional[str] = "instagram"
    thread_id: str
    message_id: Optional[int] = None

@app.get("/api/dms/annotations")
def get_dm_annotations(operation_id: int, platform: Optional[str] = "instagram"):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT thread_id, is_read, is_starred, last_read_message_id, notes, updated_at
        FROM dm_thread_annotations
        WHERE operation_id = ? AND platform = ?
    """, (operation_id, platform or "instagram"))
    rows = cursor.fetchall()
    result = {}
    for r in rows:
        result[r["thread_id"]] = {
            "is_read": bool(r["is_read"]),
            "is_starred": bool(r["is_starred"]),
            "last_read_message_id": r["last_read_message_id"],
            "notes": r["notes"],
            "updated_at": r["updated_at"]
        }
    conn.close()
    return result

@app.post("/api/dms/annotations/toggle-read")
def toggle_dm_read(req: DmAnnotationReadRequest):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO dm_thread_annotations (operation_id, platform, thread_id, is_read, updated_at)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(operation_id, platform, thread_id)
        DO UPDATE SET is_read = excluded.is_read, updated_at = CURRENT_TIMESTAMP
    """, (req.operation_id, req.platform or "instagram", req.thread_id, 1 if req.is_read else 0))
    conn.commit()
    conn.close()
    return {"status": "success", "thread_id": req.thread_id, "is_read": req.is_read}

@app.post("/api/dms/annotations/toggle-star")
def toggle_dm_star(req: DmAnnotationStarRequest):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO dm_thread_annotations (operation_id, platform, thread_id, is_starred, updated_at)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(operation_id, platform, thread_id)
        DO UPDATE SET is_starred = excluded.is_starred, updated_at = CURRENT_TIMESTAMP
    """, (req.operation_id, req.platform or "instagram", req.thread_id, 1 if req.is_starred else 0))
    conn.commit()
    conn.close()
    return {"status": "success", "thread_id": req.thread_id, "is_starred": req.is_starred}

@app.post("/api/dms/annotations/set-bookmark")
def set_dm_bookmark(req: DmAnnotationBookmarkRequest):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO dm_thread_annotations (operation_id, platform, thread_id, last_read_message_id, is_read, updated_at)
        VALUES (?, ?, ?, ?, 1, CURRENT_TIMESTAMP)
        ON CONFLICT(operation_id, platform, thread_id)
        DO UPDATE SET last_read_message_id = excluded.last_read_message_id, updated_at = CURRENT_TIMESTAMP
    """, (req.operation_id, req.platform or "instagram", req.thread_id, req.message_id))
    conn.commit()

    cursor.execute("""
        SELECT updated_at FROM dm_thread_annotations
        WHERE operation_id = ? AND platform = ? AND thread_id = ?
    """, (req.operation_id, req.platform or "instagram", req.thread_id))
    row = cursor.fetchone()
    updated_at = row["updated_at"] if row else None
    conn.close()

    return {
        "status": "success",
        "thread_id": req.thread_id,
        "last_read_message_id": req.message_id,
        "updated_at": updated_at
    }

# ==================== ROTAS WHATSAPP ====================

@app.get("/api/whatsapp")
def get_whatsapp_data(operation_id: int, phase_id: Optional[int] = None, target_id: Optional[int] = None):
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Buscar todos os alvos que possuem dados de WhatsApp nesta operação
    cursor.execute("""
        SELECT DISTINCT wt.target_id, t.name_or_alias, t.main_identifier, wt.phone_number, wt.push_name, wt.business_name
        FROM whatsapp_targets wt
        JOIN targets t ON wt.target_id = t.id
        WHERE t.operation_id = ?
        ORDER BY wt.id DESC
    """, (operation_id,))
    available_targets = [dict(r) for r in cursor.fetchall()]

    if not available_targets:
        conn.close()
        return {
            "target": None,
            "available_targets": [],
            "stats": {"groups_count": 0, "contacts_count": 0, "devices_count": 0, "connections_count": 0},
            "devices": [],
            "groups": []
        }

    # 2. Determinar alvo selecionado
    selected_target = None
    if target_id and any(t["target_id"] == target_id for t in available_targets):
        cursor.execute("""
            SELECT wt.*, t.name_or_alias 
            FROM whatsapp_targets wt 
            JOIN targets t ON wt.target_id = t.id 
            WHERE wt.target_id = ?
            ORDER BY wt.id DESC LIMIT 1
        """, (target_id,))
        row = cursor.fetchone()
        if row:
            selected_target = dict(row)

    # Se nenhum target_id foi selecionado ou se o alvo selecionado só possui Instagram, usar o 1º WhatsApp disponível
    if not selected_target:
        first_tid = available_targets[0]["target_id"]
        cursor.execute("""
            SELECT wt.*, t.name_or_alias 
            FROM whatsapp_targets wt 
            JOIN targets t ON wt.target_id = t.id 
            WHERE wt.target_id = ?
            ORDER BY wt.id DESC LIMIT 1
        """, (first_tid,))
        row = cursor.fetchone()
        if row:
            selected_target = dict(row)

    if not selected_target:
        conn.close()
        return {
            "target": None,
            "available_targets": available_targets,
            "stats": {"groups_count": 0, "contacts_count": 0, "devices_count": 0, "connections_count": 0},
            "devices": [],
            "groups": []
        }

    sel_target_id = selected_target["target_id"]

    # 3. Contadores Forenses (KPIs)
    if target_id:
        cursor.execute("SELECT COUNT(*) FROM whatsapp_groups WHERE target_id = ?", (sel_target_id,))
        groups_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM whatsapp_contacts WHERE target_id = ?", (sel_target_id,))
        contacts_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM whatsapp_contacts WHERE target_id = ? AND is_symmetric = 1", (sel_target_id,))
        symmetric_contacts_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM whatsapp_contacts WHERE target_id = ? AND is_symmetric = 0", (sel_target_id,))
        asymmetric_contacts_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM whatsapp_devices WHERE target_id = ?", (sel_target_id,))
        devices_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM whatsapp_connections WHERE target_id = ?", (sel_target_id,))
        connections_count = cursor.fetchone()[0]
    else:
        cursor.execute("SELECT COUNT(*) FROM whatsapp_groups g JOIN targets t ON g.target_id = t.id WHERE t.operation_id = ?", (operation_id,))
        groups_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM whatsapp_contacts c JOIN targets t ON c.target_id = t.id WHERE t.operation_id = ?", (operation_id,))
        contacts_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM whatsapp_contacts c JOIN targets t ON c.target_id = t.id WHERE t.operation_id = ? AND c.is_symmetric = 1", (operation_id,))
        symmetric_contacts_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM whatsapp_contacts c JOIN targets t ON c.target_id = t.id WHERE t.operation_id = ? AND c.is_symmetric = 0", (operation_id,))
        asymmetric_contacts_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM whatsapp_devices d JOIN targets t ON d.target_id = t.id WHERE t.operation_id = ?", (operation_id,))
        devices_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM whatsapp_connections c JOIN targets t ON c.target_id = t.id WHERE t.operation_id = ?", (operation_id,))
        connections_count = cursor.fetchone()[0]

    # Dispositivos cadastrados
    cursor.execute("SELECT * FROM whatsapp_devices WHERE target_id = ? ORDER BY is_active DESC, id ASC", (sel_target_id,))
    devices = [dict(r) for r in cursor.fetchall()]

    # Grupos (amostra inicial)
    cursor.execute("SELECT * FROM whatsapp_groups WHERE target_id = ? ORDER BY total_participants DESC, id ASC LIMIT 10", (sel_target_id,))
    groups = [dict(r) for r in cursor.fetchall()]

    conn.close()
    return {
        "target": selected_target,
        "available_targets": available_targets,
        "is_consolidated": (target_id is None),
        "stats": {
            "groups_count": groups_count,
            "contacts_count": contacts_count,
            "symmetric_contacts_count": symmetric_contacts_count,
            "asymmetric_contacts_count": asymmetric_contacts_count,
            "devices_count": devices_count,
            "connections_count": connections_count
        },
        "devices": devices,
        "groups": groups
    }

@app.get("/api/whatsapp/groups")
def get_whatsapp_groups(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    role: Optional[str] = None,
    search: Optional[str] = None
):
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
        SELECT g.*, t.name_or_alias as target_name, t.main_identifier as target_identifier
        FROM whatsapp_groups g
        JOIN targets t ON g.target_id = t.id
        WHERE t.operation_id = ?
    """
    params = [operation_id]
    if target_id:
        query += " AND g.target_id = ?"
        params.append(target_id)
    if role:
        query += " AND g.role = ?"
        params.append(role)
    if search:
        s = f"%{search.strip()}%"
        query += " AND (g.subject LIKE ? OR g.group_jid LIKE ? OR g.description LIKE ?)"
        params.extend([s, s, s])

    query += " ORDER BY g.total_participants DESC, g.id ASC"
    cursor.execute(query, params)
    groups = [dict(r) for r in cursor.fetchall()]
    conn.close()

    return {"groups": groups, "total": len(groups)}

@app.get("/api/whatsapp/contacts")
def get_whatsapp_contacts(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    filter_type: Optional[str] = "all",
    search: Optional[str] = None,
    page: int = 1,
    limit: int = 50
):
    page = int(page) if not hasattr(page, 'default') else 1
    limit = int(limit) if not hasattr(limit, 'default') else 50

    conn = get_db_connection()
    cursor = conn.cursor()

    # Base raw (sem filtro de simetria) para contadores de aba
    raw_where = "WHERE t.operation_id = ?"
    raw_params = [operation_id]
    if target_id:
        raw_where += " AND c.target_id = ?"
        raw_params.append(target_id)

    cursor.execute(f"SELECT COUNT(*) FROM whatsapp_contacts c JOIN targets t ON c.target_id = t.id {raw_where}", raw_params)
    total_all = cursor.fetchone()[0]

    cursor.execute(f"SELECT COUNT(*) FROM whatsapp_contacts c JOIN targets t ON c.target_id = t.id {raw_where} AND c.is_symmetric = 1", raw_params)
    total_symmetric = cursor.fetchone()[0]

    cursor.execute(f"SELECT COUNT(*) FROM whatsapp_contacts c JOIN targets t ON c.target_id = t.id {raw_where} AND c.is_symmetric = 0", raw_params)
    total_asymmetric = cursor.fetchone()[0]

    # Cláusula de filtragem efetiva
    base_where = raw_where
    base_params = list(raw_params)

    if filter_type == "symmetric":
        base_where += " AND c.is_symmetric = 1"
    elif filter_type == "asymmetric":
        base_where += " AND c.is_symmetric = 0"

    if search:
        s = f"%{search.strip()}%"
        base_where += " AND (c.phone_number LIKE ? OR c.display_name LIKE ?)"
        base_params.extend([s, s])

    count_q = f"SELECT COUNT(*) FROM whatsapp_contacts c JOIN targets t ON c.target_id = t.id {base_where}"
    cursor.execute(count_q, base_params)
    total_filtered = cursor.fetchone()[0]

    query = f"""
        SELECT c.*, t.name_or_alias as target_name, t.main_identifier as target_identifier
        FROM whatsapp_contacts c
        JOIN targets t ON c.target_id = t.id
        {base_where}
        ORDER BY c.id ASC
        LIMIT ? OFFSET ?
    """
    p_items = list(base_params)
    p_items.extend([limit, (page - 1) * limit])
    cursor.execute(query, p_items)
    contacts = [dict(r) for r in cursor.fetchall()]
    conn.close()

    return {
        "contacts": contacts,
        "total": total_filtered,
        "stats": {
            "all": total_all,
            "symmetric": total_symmetric,
            "asymmetric": total_asymmetric
        },
        "page": page,
        "limit": limit
    }

class WhatsAppSyncRequest(BaseModel):
    operation_id: int
    target_id: Optional[int] = None

@app.get("/api/whatsapp/web/status")
def get_whatsapp_web_status():
    from backend.services.whatsapp_web_service import whatsapp_web_service
    return whatsapp_web_service.get_status()

@app.get("/api/whatsapp/web/qr")
def get_whatsapp_web_qr():
    from backend.services.whatsapp_web_service import whatsapp_web_service
    return whatsapp_web_service.get_qr_code()

@app.post("/api/whatsapp/web/logout")
def logout_whatsapp_web():
    from backend.services.whatsapp_web_service import whatsapp_web_service
    return whatsapp_web_service.logout()

@app.post("/api/whatsapp/avatars/sync")
def sync_whatsapp_avatars(req: WhatsAppSyncRequest):
    from backend.services.whatsapp_web_service import whatsapp_web_service
    return whatsapp_web_service.start_avatar_sync(req.operation_id, req.target_id)

@app.get("/api/whatsapp/avatars/status")
def get_whatsapp_avatars_status():
    from backend.services.whatsapp_web_service import whatsapp_web_service
    return whatsapp_web_service.get_status()["sync"]

@app.get("/api/whatsapp/devices")
def get_whatsapp_devices(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None
):
    conn = get_db_connection()
    cursor = conn.cursor()

    query = """
        SELECT d.*, t.name_or_alias as target_name, t.main_identifier as target_identifier
        FROM whatsapp_devices d
        JOIN targets t ON d.target_id = t.id
        WHERE t.operation_id = ?
    """
    params = [operation_id]
    if target_id:
        query += " AND d.target_id = ?"
        params.append(target_id)

    query += " ORDER BY d.is_active DESC, d.id ASC"
    cursor.execute(query, params)
    devices = [dict(r) for r in cursor.fetchall()]
    conn.close()

    return {"devices": devices, "total": len(devices)}

@app.get("/api/whatsapp/connections")
def get_whatsapp_connections(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    page: int = 1,
    limit: int = 50,
    ip_version: Optional[str] = "all",
    search: Optional[str] = None
):
    page = int(page) if not hasattr(page, 'default') else 1
    limit = int(limit) if not hasattr(limit, 'default') else 50

    conn = get_db_connection()
    cursor = conn.cursor()

    where = "WHERE t.operation_id = ?"
    params = [operation_id]
    if target_id:
        where += " AND c.target_id = ?"
        params.append(target_id)
    if ip_version == "ipv4":
        where += " AND c.source_ip NOT LIKE '%:%'"
    elif ip_version == "ipv6":
        where += " AND c.source_ip LIKE '%:%'"
    if search:
        s = f"%{search.strip()}%"
        where += " AND (c.source_ip LIKE ? OR c.timestamp_utc LIKE ?)"
        params.extend([s, s])

    # Contagem total
    count_q = f"SELECT COUNT(*) FROM whatsapp_connections c JOIN targets t ON c.target_id = t.id {where}"
    cursor.execute(count_q, params)
    total_conns = cursor.fetchone()[0]

    # Conexões paginadas
    query = f"""
        SELECT c.*, t.name_or_alias as target_name, t.main_identifier as target_identifier
        FROM whatsapp_connections c
        JOIN targets t ON c.target_id = t.id
        {where}
        ORDER BY c.timestamp_utc DESC
        LIMIT ? OFFSET ?
    """
    p_items = list(params)
    p_items.extend([limit, (page - 1) * limit])
    cursor.execute(query, p_items)
    timeline = [dict(r) for r in cursor.fetchall()]

    # Buscar Ranking dos top IPs
    rank_q = f"""
        SELECT c.source_ip as ip_address, COUNT(*) as count,
               MIN(c.timestamp_utc) as first_seen_utc, MAX(c.timestamp_utc) as last_seen_utc,
               MIN(c.timestamp_brt) as first_seen_brt, MAX(c.timestamp_brt) as last_seen_brt
        FROM whatsapp_connections c
        JOIN targets t ON c.target_id = t.id
        {where}
        GROUP BY c.source_ip
        ORDER BY count DESC
        LIMIT 20
    """
    cursor.execute(rank_q, params)
    ranked_rows = [dict(r) for r in cursor.fetchall()]

    # Contagem de IPs únicos
    cursor.execute(f"SELECT COUNT(DISTINCT c.source_ip) FROM whatsapp_connections c JOIN targets t ON c.target_id = t.id {where}", params)
    unique_ips_count = cursor.fetchone()[0]

    # Dados de registro
    reg_ip = None
    if target_id:
        cursor.execute("SELECT registration_ip FROM whatsapp_targets WHERE target_id = ? ORDER BY id DESC LIMIT 1", (target_id,))
        t_row = cursor.fetchone()
        if t_row:
            reg_ip = t_row["registration_ip"]

    conn.close()

    # Enriquecer top IPs com ISP da tabela de cache
    unique_ips_list = [r["ip_address"] for r in ranked_rows]
    cached_info = IpService.batch_enrich_ips(unique_ips_list)

    top_ip = "---"
    top_ip_count = 0
    top_ip_percent = 0
    top_ip_isp = "---"

    ranked_ips = []
    for r in ranked_rows:
        ip = r["ip_address"]
        cnt = r["count"]
        pct = round((cnt / total_conns) * 100, 1) if total_conns > 0 else 0
        info = cached_info.get(ip, {})

        if top_ip == "---":
            top_ip = ip
            top_ip_count = cnt
            top_ip_percent = pct
            top_ip_isp = info.get("isp", "---")

        ranked_ips.append({
            "ip_address": ip,
            "count": cnt,
            "percentage": pct,
            "isp": info.get("isp", "Pendente de consulta"),
            "location": f"{info.get('city', '')} - {info.get('region', '')}, {info.get('country', '')}".strip(" -,"),
            "first_seen_brt": r.get("first_seen_brt") or r.get("first_seen_utc"),
            "last_seen_brt": r.get("last_seen_brt") or r.get("last_seen_utc"),
            "is_brazil": info.get("is_brazil", 1),
            "whois_url": IpService.get_whois_url(ip, is_br=info.get("is_brazil", 1))
        })

    first_activity_brt = ranked_ips[0]["first_seen_brt"] if ranked_ips else "---"
    last_activity_brt = ranked_ips[0]["last_seen_brt"] if ranked_ips else "---"

    return {
        "stats": {
            "total_connections": total_conns,
            "unique_ips_count": unique_ips_count,
            "top_ip": top_ip,
            "top_ip_count": top_ip_count,
            "top_ip_percent": top_ip_percent,
            "top_ip_isp": top_ip_isp,
            "first_activity_brt": first_activity_brt,
            "last_activity_brt": last_activity_brt,
            "registration_ip": reg_ip or "---"
        },
        "ranked_ips": ranked_ips,
        "timeline": timeline,
        "total": total_conns,
        "page": page,
        "limit": limit
    }

# ==================== ROTAS DE BILHETAGEM & CDRs DO WHATSAPP ====================

@app.get("/api/whatsapp/cdr")
def get_whatsapp_cdr_intelligence(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    batch_file: Optional[str] = None
):
    conn = get_db_connection()
    cursor = conn.cursor()

    base_where = "WHERE m.operation_id = ?"
    params = [operation_id]
    if target_id:
        base_where += " AND m.target_id = ?"
        params.append(target_id)
    if phase_id:
        base_where += " AND m.phase_id = ?"
        params.append(phase_id)
    if batch_file:
        base_where += " AND m.batch_file_name = ?"
        params.append(batch_file)

    # 1. Estatísticas de Mensagens
    cursor.execute(f"SELECT COUNT(*) as total, MIN(m.timestamp_brt) as first_seen, MAX(m.timestamp_brt) as last_seen FROM whatsapp_cdr_messages m {base_where}", params)
    stat_row = cursor.fetchone()
    total_messages = stat_row["total"] if stat_row else 0
    first_activity_brt = stat_row["first_seen"] if (stat_row and stat_row["first_seen"]) else "---"
    last_activity_brt = stat_row["last_seen"] if (stat_row and stat_row["last_seen"]) else "---"

    # Tipos de Mídia
    cursor.execute(f"SELECT m.msg_type, COUNT(*) as count FROM whatsapp_cdr_messages m {base_where} GROUP BY m.msg_type", params)
    media_breakdown = {r["msg_type"]: r["count"] for r in cursor.fetchall()}

    # 2. Estatísticas de Chamadas
    calls_where = "WHERE c.operation_id = ?"
    c_params = [operation_id]
    if target_id:
        calls_where += " AND c.target_id = ?"
        c_params.append(target_id)
    if phase_id:
        calls_where += " AND c.phase_id = ?"
        c_params.append(phase_id)
    if batch_file:
        calls_where += " AND c.batch_file_name = ?"
        c_params.append(batch_file)

    cursor.execute(f"""
        SELECT COUNT(*) as total,
               SUM(CASE WHEN c.status = 'atendida' THEN 1 ELSE 0 END) as accepted,
               SUM(CASE WHEN c.status = 'recusada' THEN 1 ELSE 0 END) as rejected,
               SUM(CASE WHEN c.status = 'perdida' THEN 1 ELSE 0 END) as missed,
               SUM(c.duration_seconds) as total_duration
        FROM whatsapp_cdr_calls c
        {calls_where}
    """, c_params)
    c_stat = cursor.fetchone()
    total_calls = c_stat["total"] if c_stat else 0
    accepted_calls = c_stat["accepted"] if (c_stat and c_stat["accepted"]) else 0
    rejected_calls = c_stat["rejected"] if (c_stat and c_stat["rejected"]) else 0
    missed_calls = c_stat["missed"] if (c_stat and c_stat["missed"]) else 0
    total_duration = c_stat["total_duration"] if (c_stat and c_stat["total_duration"]) else 0

    # 3. Matriz de Interlocutores (Top Contatos)
    interlocutors_query = f"""
        SELECT 
            CASE WHEN m.is_target_sender = 1 THEN m.recipients ELSE m.sender END as contact_phone,
            COUNT(*) as total_msgs,
            SUM(CASE WHEN m.is_target_sender = 1 THEN 1 ELSE 0 END) as sent_by_target,
            SUM(CASE WHEN m.is_target_sender = 0 THEN 1 ELSE 0 END) as received_from_contact,
            SUM(CASE WHEN m.msg_type IN ('voice', 'audio') THEN 1 ELSE 0 END) as audio_count,
            SUM(CASE WHEN m.msg_type IN ('image', 'video') THEN 1 ELSE 0 END) as media_count,
            MIN(m.timestamp_brt) as first_seen,
            MAX(m.timestamp_brt) as last_seen
        FROM whatsapp_cdr_messages m
        {base_where}
        GROUP BY contact_phone
        ORDER BY total_msgs DESC
        LIMIT 100
    """
    cursor.execute(interlocutors_query, params)
    interlocutors_raw = [dict(r) for r in cursor.fetchall()]

    # Contagem de chamadas por interlocutor
    calls_by_contact = {}
    cursor.execute(f"""
        SELECT 
            CASE WHEN c.is_target_creator = 1 THEN c.to_number ELSE c.from_number END as contact_phone,
            COUNT(*) as call_count
        FROM whatsapp_cdr_calls c
        {calls_where}
        GROUP BY contact_phone
    """, c_params)
    for cr in cursor.fetchall():
        calls_by_contact[cr["contact_phone"]] = cr["call_count"]

    ddd_map = {
        "71": "Salvador/BA", "73": "Ilhéus/BA", "75": "Feira de Santana/BA", "77": "Vitória da Conquista/BA",
        "61": "Brasília/DF", "62": "Goiânia/GO", "81": "Recife/PE", "85": "Fortaleza/CE",
        "11": "São Paulo/SP", "19": "Campinas/SP", "21": "Rio de Janeiro/RJ", "31": "Belo Horizonte/MG",
        "41": "Curitiba/PR", "51": "Porto Alegre/RS", "91": "Belém/PA", "92": "Manaus/AM"
    }

    interlocutors = []
    for ir in interlocutors_raw:
        phone = ir["contact_phone"]
        ir["calls_count"] = calls_by_contact.get(phone, 0)
        clean_p = re.sub(r'\D', '', phone)
        ddd = ""
        region_label = "Brasil"
        if clean_p.startswith("55") and len(clean_p) >= 4:
            ddd = clean_p[2:4]
            region_label = ddd_map.get(ddd, f"DDD {ddd}")
        ir["ddd"] = ddd
        ir["region_label"] = region_label
        interlocutors.append(ir)

    # 4. Lista de Chamadas
    cursor.execute(f"""
        SELECT c.*, t.name_or_alias as target_name
        FROM whatsapp_cdr_calls c
        JOIN targets t ON c.target_id = t.id
        {calls_where}
        ORDER BY c.timestamp_utc DESC
        LIMIT 200
    """, c_params)
    calls_list = [dict(r) for r in cursor.fetchall()]

    # 5. Lotes Diários Importados
    cursor.execute(f"""
        SELECT m.batch_file_name, m.batch_day_date, COUNT(*) as messages_count,
               MIN(m.timestamp_brt) as first_brt, MAX(m.timestamp_brt) as last_brt
        FROM whatsapp_cdr_messages m
        {base_where}
        GROUP BY m.batch_file_name
        ORDER BY MIN(m.timestamp_utc) ASC
    """, params)
    daily_batches = [dict(r) for r in cursor.fetchall()]

    # 6. Geolocalização dos IPs de Envio
    cursor.execute(f"""
        SELECT m.clean_ip, COUNT(*) as total_count, MIN(m.timestamp_brt) as first_seen, MAX(m.timestamp_brt) as last_seen
        FROM whatsapp_cdr_messages m
        {base_where} AND m.clean_ip IS NOT NULL AND m.clean_ip != ''
        GROUP BY m.clean_ip
        ORDER BY total_count DESC
    """, params)
    ip_rows = [dict(r) for r in cursor.fetchall()]
    unique_ips_list = [r["clean_ip"] for r in ip_rows]
    cached_info = IpService.batch_enrich_ips(unique_ips_list) if unique_ips_list else {}

    geo_points = []
    for r in ip_rows:
        ip = r["clean_ip"]
        info = cached_info.get(ip, {})
        lat = info.get("lat")
        lon = info.get("lon")
        if lat and lon:
            geo_points.append({
                "clean_ip": ip,
                "lat": lat,
                "lon": lon,
                "city": info.get("city", "Não identificada"),
                "region": info.get("region", "---"),
                "country": info.get("country", "Brasil"),
                "isp": info.get("isp", "Não informado"),
                "is_mobile": info.get("is_mobile", 0),
                "is_proxy": info.get("is_proxy", 0),
                "is_hosting": info.get("is_hosting", 0),
                "total_count": r["total_count"],
                "first_seen": r["first_seen"],
                "last_seen": r["last_seen"]
            })

    conn.close()

    return {
        "stats": {
            "total_messages": total_messages,
            "total_calls": total_calls,
            "unique_contacts_count": len(interlocutors),
            "unique_ips_count": len(unique_ips_list),
            "first_activity_brt": first_activity_brt,
            "last_activity_brt": last_activity_brt,
            "media_breakdown": media_breakdown,
            "calls_stats": {
                "accepted": accepted_calls,
                "rejected": rejected_calls,
                "missed": missed_calls,
                "total_duration_sec": total_duration
            }
        },
        "interlocutors": interlocutors,
        "calls": calls_list,
        "daily_batches": daily_batches,
        "geo_points": geo_points,
        "total_batches_count": len(daily_batches)
    }

@app.get("/api/whatsapp/cdr/messages")
def get_whatsapp_cdr_messages(
    operation_id: int,
    phase_id: Optional[int] = None,
    target_id: Optional[int] = None,
    interlocutor: Optional[str] = None,
    media_type: Optional[str] = None,
    batch_file: Optional[str] = None,
    direction: Optional[str] = None,
    search: Optional[str] = None,
    page: int = 1,
    limit: int = 50
):
    page = int(page) if not hasattr(page, 'default') else 1
    limit = int(limit) if not hasattr(limit, 'default') else 50

    conn = get_db_connection()
    cursor = conn.cursor()

    where = "WHERE m.operation_id = ?"
    params = [operation_id]
    if target_id:
        where += " AND m.target_id = ?"
        params.append(target_id)
    if phase_id:
        where += " AND m.phase_id = ?"
        params.append(phase_id)
    if batch_file:
        where += " AND m.batch_file_name = ?"
        params.append(batch_file)
    if media_type:
        where += " AND m.msg_type = ?"
        params.append(media_type)
    if direction == "sent":
        where += " AND m.is_target_sender = 1"
    elif direction == "received":
        where += " AND m.is_target_sender = 0"
    if interlocutor:
        clean_inter = re.sub(r'\D', '', interlocutor)
        where += " AND (m.sender LIKE ? OR m.recipients LIKE ?)"
        params.extend([f"%{clean_inter}%", f"%{clean_inter}%"])
    if search:
        s = f"%{search.strip()}%"
        where += " AND (m.sender LIKE ? OR m.recipients LIKE ? OR m.clean_ip LIKE ? OR m.message_id LIKE ?)"
        params.extend([s, s, s, s])

    count_q = f"SELECT COUNT(*) FROM whatsapp_cdr_messages m {where}"
    cursor.execute(count_q, params)
    total = cursor.fetchone()[0]

    query = f"""
        SELECT m.*, t.name_or_alias as target_name
        FROM whatsapp_cdr_messages m
        JOIN targets t ON m.target_id = t.id
        {where}
        ORDER BY m.timestamp_utc DESC
        LIMIT ? OFFSET ?
    """
    p_items = list(params)
    p_items.extend([limit, (page - 1) * limit])

    cursor.execute(query, p_items)
    messages = [dict(r) for r in cursor.fetchall()]

    msg_ips = [m["clean_ip"] for m in messages if m["clean_ip"]]
    ip_cache = IpService.batch_enrich_ips(msg_ips) if msg_ips else {}
    for m in messages:
        if m["clean_ip"] and m["clean_ip"] in ip_cache:
            m["ip_info"] = ip_cache[m["clean_ip"]]

    conn.close()
    return {
        "messages": messages,
        "total": total,
        "page": page,
        "limit": limit
    }

# ==================== LINHA DO TEMPO & GRAFOS ====================

@app.get("/api/timeline")
def get_timeline(operation_id: int, phase_id: Optional[int] = None, target_id: Optional[int] = None, platform: Optional[str] = None):
    conn = get_db_connection()
    cursor = conn.cursor()

    query = "SELECT * FROM timeline_events WHERE operation_id = ?"
    params = [operation_id]
    if phase_id:
        query += " AND phase_id = ?"
        params.append(phase_id)
    if target_id:
        query += " AND target_id = ?"
        params.append(target_id)
    if platform:
        query += " AND platform = ?"
        params.append(platform)

    query += " ORDER BY timestamp_utc DESC LIMIT 300"
    cursor.execute(query, params)
    events = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return events

@app.get("/api/graph")
def get_graph(operation_id: int, phase_id: Optional[int] = None, target_id: Optional[int] = None, max_nodes: int = Query(150, ge=10, le=500)):
    return LinkAnalysisService.get_case_graph(operation_id, phase_id=phase_id, target_id=target_id, max_nodes=max_nodes)

# ==================== EXPORTAÇÃO EXCEL ====================

@app.get("/api/export/excel")
def export_excel(operation_id: int, phase_id: Optional[int] = None):
    op = OperationService.get_operation(operation_id)
    if not op:
        raise HTTPException(status_code=404, detail="Operação não encontrada.")
    
    excel_stream = ExportService.export_operation_to_excel(operation_id, phase_id=phase_id)
    filename = f"Relatorio_Forense_Op_{operation_id}_{op['name'].replace(' ', '_')}.xlsx"
    
    return StreamingResponse(
        excel_stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

# ==================== ROTAS DO MÓDULO GOOGLE LERS ====================

from backend.services.google_service import GoogleService

class GoogleScanPayload(BaseModel):
    operation_id: int
    folder_path: Optional[str] = None
    file_paths: Optional[List[str]] = None

class GoogleImportPayload(BaseModel):
    operation_id: int
    phase_id: int
    file_paths: List[str]
    mapping: Dict[str, Any]

@app.post("/api/google/scan")
def scan_google(payload: GoogleScanPayload):
    paths = payload.file_paths or []
    if payload.folder_path and os.path.exists(payload.folder_path):
        paths.extend([
            os.path.join(payload.folder_path, f) 
            for f in os.listdir(payload.folder_path) 
            if f.endswith('.zip')
        ])
    if not paths:
        raise HTTPException(status_code=400, detail="Nenhum arquivo ZIP do Google fornecido.")
    return GoogleService.scan_google_packages(paths, payload.operation_id)

@app.post("/api/google/import")
def import_google(payload: GoogleImportPayload):
    if not payload.file_paths:
        raise HTTPException(status_code=400, detail="Nenhum arquivo fornecido para importação.")
    try:
        return GoogleService.import_google_packages(
            payload.file_paths,
            payload.operation_id,
            payload.phase_id,
            payload.mapping
        )
    except RuntimeError as re:
        raise HTTPException(status_code=409, detail=str(re))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no processamento do Google LERS: {str(e)}")

@app.get("/api/google/targets")
def get_google_targets(operation_id: int, phase_id: Optional[int] = None, target_id: Optional[int] = None):
    return GoogleService.get_google_targets(operation_id, phase_id, target_id)

@app.get("/api/google/overview")
def get_google_overview(google_target_id: int):
    data = GoogleService.get_google_overview(google_target_id)
    if not data:
        raise HTTPException(status_code=404, detail="Conta Google não encontrada.")
    return data

@app.get("/api/google/devices")
def get_google_devices(google_target_id: int):
    return GoogleService.get_google_devices(google_target_id)

@app.get("/api/google/locations")
def get_google_locations(google_target_id: int):
    return GoogleService.get_google_locations(google_target_id)

@app.get("/api/google/emails")
def get_google_emails(
    google_target_id: int,
    folder: Optional[str] = None,
    search: Optional[str] = None,
    page: int = 1,
    limit: int = 50
):
    return GoogleService.get_google_emails(google_target_id, folder, search, page, limit)

@app.get("/api/google/emails/{email_id}")
def get_google_email_detail(email_id: int):
    data = GoogleService.get_google_email_detail(email_id)
    if not data:
        raise HTTPException(status_code=404, detail="E-mail não encontrado.")
    return data

@app.get("/api/google/ips")
def get_google_ips(google_target_id: int, page: int = 1, limit: int = 100):
    return GoogleService.get_google_ips(google_target_id, page, limit)

@app.get("/api/google/photos")
def get_google_photos(
    google_target_id: int,
    media_type: Optional[str] = None,
    has_gps: Optional[bool] = None,
    search: Optional[str] = None,
    order: Optional[str] = "desc",
    page: int = 1,
    limit: int = 30
):
    return GoogleService.get_google_photos(google_target_id, media_type, has_gps, search, order or "desc", page, limit)

@app.get("/api/google/photos/{photo_id}")
def get_google_photo_detail(photo_id: int):
    data = GoogleService.get_google_photo_detail(photo_id)
    if not data:
        raise HTTPException(status_code=404, detail="Foto ou mídia não encontrada.")
    return data

# ==================== GOOGLE CHROME: NAVEGAÇÃO & FAVORITOS ====================
@app.get("/api/google/chrome/history")
def get_google_chrome_history(
    google_target_id: int,
    query: Optional[str] = None,
    page: int = 1,
    limit: int = 50
):
    return GoogleService.get_chrome_history(google_target_id, query, page, limit)

@app.get("/api/google/chrome/bookmarks")
def get_google_chrome_bookmarks(google_target_id: int):
    return GoogleService.get_chrome_bookmarks(google_target_id)

# ==================== MINHA ATIVIDADE: PESQUISAS & ÁUDIOS DE VOZ ====================
@app.get("/api/google/activities")
def get_google_activities(
    google_target_id: int,
    product: Optional[str] = None,
    has_audio: Optional[bool] = None,
    query: Optional[str] = None,
    page: int = 1,
    limit: int = 50
):
    return GoogleService.get_activities(google_target_id, product, has_audio, query, page, limit)

# ==================== GOOGLE DRIVE: ARQUIVOS & NUVEM ====================
@app.get("/api/google/drive")
def get_google_drive_files(
    google_target_id: int,
    search: Optional[str] = None,
    file_category: Optional[str] = None,
    only_trashed: Optional[bool] = None,
    page: int = 1,
    limit: int = 50
):
    return GoogleService.get_drive_files(google_target_id, search, file_category, only_trashed, page, limit)

# ==================== TIMELINE: CONFIGURAÇÕES & HISTÓRICO DE DISPOSITIVOS ====================
@app.get("/api/google/timeline/settings")
def get_google_timeline_settings(google_target_id: int):
    return GoogleService.get_timeline_settings(google_target_id)



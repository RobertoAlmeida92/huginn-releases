let currentOpId = null;
let currentPhaseId = null;
let currentTargetId = null;
let currentActiveTab = 'instagram';

// Helper seguro de escape HTML
function escapeHtml(text) {
    if (!text) return '';
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

// Helper seguro de criação de ícones Lucide (com tolerância a ambiente offline)
function safeCreateIcons() {
    try {
        if (window.lucide && typeof window.lucide.createIcons === 'function') {
            window.lucide.createIcons();
        }
    } catch (e) {
        console.warn("Lucide createIcons warning:", e);
    }
}

// ==================== TEMA CLARO / ESCURO ====================
function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'dark';
    setTheme(savedTheme);
}

function setTheme(theme) {
    const html = document.documentElement;
    const iconContainer = document.getElementById('theme-icon-container') || document.getElementById('theme-toggle-btn');
    const label = document.getElementById('theme-toggle-label');

    if (theme === 'dark') {
        html.classList.add('dark');
        localStorage.setItem('theme', 'dark');
        if (iconContainer) {
            iconContainer.innerHTML = '<i data-lucide="sun" id="theme-icon" class="w-4 h-4 text-amber-400"></i>';
        }
        if (label) label.innerText = 'Dia';
    } else {
        html.classList.remove('dark');
        localStorage.setItem('theme', 'light');
        if (iconContainer) {
            iconContainer.innerHTML = '<i data-lucide="moon" id="theme-icon" class="w-4 h-4 text-indigo-600"></i>';
        }
        if (label) label.innerText = 'Noite';
    }
    safeCreateIcons();
    if (window.currentActiveTab === 'graph' && typeof loadGraphView === 'function' && window.currentOpId) {
        loadGraphView(window.currentOpId, window.currentPhaseId, window.currentTargetId);
    }
}

function toggleTheme() {
    const isDark = document.documentElement.classList.contains('dark');
    setTheme(isDark ? 'light' : 'dark');
}

// ==================== HELPER DE TOOLTIP (HOVER COMPLETO) ====================
function syncSelectTooltip(selectIdOrElem) {
    const sel = typeof selectIdOrElem === 'string' ? document.getElementById(selectIdOrElem) : selectIdOrElem;
    if (!sel) return;
    if (sel.selectedIndex >= 0) {
        const fullText = sel.options[sel.selectedIndex]?.text || '';
        sel.title = fullText;
        if (sel.parentElement && sel.parentElement.classList.contains('border')) {
            sel.parentElement.title = fullText;
        }
    }
}

// Formatação limpa do rótulo do alvo
function getCleanTargetLabel(target) {
    const name = (target.name_or_alias || '').trim();
    const ident = (target.main_identifier || '').trim();
    const linked = Array.isArray(target.linked_accounts) ? target.linked_accounts : [];

    let handlesStr = '';
    if (linked.length > 1) {
        handlesStr = linked.join(', ');
    } else if (linked.length === 1) {
        handlesStr = linked[0];
    } else {
        handlesStr = ident;
    }

    if (!name || name === ident || name === 'Alvo_Meta' || name.startsWith('Alvo_') || name.startsWith('Investigado (Alvo_')) {
        return handlesStr || name || 'Alvo Sem Identificador';
    }
    
    if (handlesStr) {
        return `${name} (${handlesStr})`;
    }
    return name;
}

// ==================== GESTÃO DE LICENÇA DE TESTE & AUTODESTRUIÇÃO ====================

let licenseSelfDestructTimer = null;

async function checkLicenseStatus() {
    try {
        const res = await fetch('/api/license/status');
        const data = await res.json();

        const badge = document.getElementById('license-status-badge');
        const badgeText = document.getElementById('license-status-text');

        if (data.active === true) {
            // Licença Válida
            if (badge && badgeText) {
                badge.classList.remove('hidden');
                badge.classList.add('flex');
                
                const timeText = data.days_remaining > 0 
                    ? `${data.days_remaining}d ${data.hours_remaining}h`
                    : `${data.hours_remaining}h ${data.minutes_remaining}m`;
                
                badgeText.innerText = `Teste: ${timeText}`;
                badge.title = `Licença Pericial Válida até ${data.expiry_brt} (${data.tester_name})`;
            }
            closeLicenseModal();
            return true;
        } else {
            // Licença Inválida, Expirada ou Relógio Adulterado
            if (badge) badge.classList.add('hidden');

            if (data.status === 'expired' || data.status === 'clock_tampered') {
                triggerSelfDestructModal(data.message || "Período de avaliação encerrado.");
                return false;
            } else {
                openLicenseModal(data.message);
                return false;
            }
        }
    } catch (err) {
        console.error("Erro ao verificar status da licença:", err);
        return false;
    }
}

function openLicenseModal(customMsg = null) {
    const modal = document.getElementById('modal-license-activation');
    if (!modal) return;
    if (customMsg) {
        const msgElem = document.getElementById('license-modal-msg');
        if (msgElem) msgElem.innerText = customMsg;
    }
    const errBox = document.getElementById('license-error-box');
    if (errBox) errBox.classList.add('hidden');
    modal.classList.remove('hidden');
    const input = document.getElementById('input-license-key');
    if (input) input.focus();
    lucide.createIcons();
}

function closeLicenseModal() {
    const modal = document.getElementById('modal-license-activation');
    if (modal) modal.classList.add('hidden');
}

async function submitLicenseActivation() {
    const input = document.getElementById('input-license-key');
    const key = (input ? input.value : '').trim();
    const errBox = document.getElementById('license-error-box');
    const btn = document.getElementById('btn-activate-license');

    if (!key) {
        if (errBox) {
            errBox.innerText = "Por favor, informe a chave de ativação.";
            errBox.classList.remove('hidden');
        }
        return;
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<i data-lucide="loader" class="w-3.5 h-3.5 animate-spin"></i><span>Validando chave...</span>`;
        lucide.createIcons();
    }

    try {
        const res = await fetch('/api/license/activate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key: key })
        });
        const data = await res.json();

        if (res.ok && data.status === 'success') {
            closeLicenseModal();
            alert(data.message);
            await checkLicenseStatus();
            await loadOperations();
        } else {
            if (errBox) {
                errBox.innerText = data.detail || data.message || "Chave de licença inválida.";
                errBox.classList.remove('hidden');
            }
        }
    } catch (err) {
        if (errBox) {
            errBox.innerText = "Erro ao conectar com o validador: " + err.message;
            errBox.classList.remove('hidden');
        }
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `<i data-lucide="key" class="w-3.5 h-3.5"></i><span>Ativar e Iniciar Testes</span>`;
            lucide.createIcons();
        }
    }
}

function triggerSelfDestructModal(reasonMsg) {
    const modal = document.getElementById('modal-license-expired');
    if (!modal) return;

    const reasonElem = document.getElementById('license-expired-reason');
    if (reasonElem) reasonElem.innerText = reasonMsg;

    const errBox = document.getElementById('lockdown-error-box');
    if (errBox) errBox.classList.add('hidden');

    modal.classList.remove('hidden');
    lucide.createIcons();

    const input = document.getElementById('input-lockdown-key');
    if (input) {
        input.value = '';
        input.focus();
    }
}

async function submitLockdownActivation() {
    const input = document.getElementById('input-lockdown-key');
    const errBox = document.getElementById('lockdown-error-box');
    const btn = document.getElementById('btn-activate-lockdown');
    const key = (input ? input.value : '').trim();

    if (!key) {
        if (errBox) {
            errBox.innerText = "Por favor, insira uma chave de licença válida.";
            errBox.classList.remove('hidden');
        }
        return;
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>Validando Assinatura...</span>`;
        lucide.createIcons();
    }

    try {
        const res = await fetch('/api/license/activate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key })
        });
        const data = await res.json();

        if (res.ok && data.status === 'success') {
            const modal = document.getElementById('modal-license-expired');
            if (modal) modal.classList.add('hidden');
            await checkLicenseStatus();
            await loadOperations();
        } else {
            if (errBox) {
                errBox.innerText = data.detail || data.message || "Chave de licença inválida ou expirada.";
                errBox.classList.remove('hidden');
            }
        }
    } catch (err) {
        if (errBox) {
            errBox.innerText = "Erro ao validar a licença: " + err.message;
            errBox.classList.remove('hidden');
        }
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `<i data-lucide="key" class="w-3.5 h-3.5"></i><span>Validar e Desbloquear Huginn</span>`;
            lucide.createIcons();
        }
    }
}

// ==================== SISTEMA DE ATUALIZAÇÃO SEGURA (HUGINN AUTO-UPDATE) ====================

const HUGINN_STATIC_VERSION = '6.4.2';
window._pendingUpdateData = null;

function compareVersions(v1, v2) {
    if (!v1 || !v2) return 0;
    const clean = v => String(v).replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0);
    const p1 = clean(v1);
    const p2 = clean(v2);
    for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
        const num1 = p1[i] || 0;
        const num2 = p2[i] || 0;
        if (num1 > num2) return 1;
        if (num1 < num2) return -1;
    }
    return 0;
}

function getEffectiveSystemVersion(backendVersion = '6.4.1') {
    const installedPatch = localStorage.getItem('huginn_installed_patch_version');
    let highest = backendVersion;
    if (installedPatch && compareVersions(installedPatch, highest) > 0) {
        highest = installedPatch;
    }
    if (compareVersions(HUGINN_STATIC_VERSION, highest) > 0) {
        highest = HUGINN_STATIC_VERSION;
    }
    return highest;
}

function updateVersionDisplays(version) {
    const v = String(version).startsWith('v') ? version : `v${version}`;
    const footerLbl = document.getElementById('footer-version-label');
    if (footerLbl) footerLbl.innerText = v;
    const badge = document.getElementById('modal-about-version-badge');
    if (badge) badge.innerText = v;
}

async function checkForSystemUpdates(manualTrigger = false) {
    try {
        const res = await fetch(`/api/system/check-update?_t=${Date.now()}`, {
            cache: 'no-store'
        });
        const data = await res.json();

        // Obtém a versão efetiva rodando no frontend (considerando patches aplicados e build estático)
        const effectiveVer = getEffectiveSystemVersion(data.current_version);
        updateVersionDisplays(effectiveVer);

        // Se a versão mais recente do release remoto for menor ou igual à versão ativa,
        // NÃO há update a ser aplicado. Grava no localStorage para blindar contra repetições.
        if (data.latest_version && compareVersions(data.latest_version, effectiveVer) <= 0) {
            localStorage.setItem('huginn_installed_patch_version', effectiveVer);
            window._pendingUpdateData = null;
            dismissUpdateBanner();
            if (manualTrigger) {
                const statusText = document.getElementById('about-update-status-text');
                if (statusText) statusText.innerText = `O Huginn está atualizado na versão ${effectiveVer}.`;
                alert(`✓ O Huginn já está na versão mais recente (${effectiveVer})!`);
            }
            return;
        }

        // Se houver update real disponível (latest_version > effectiveVer)
        if (data.success && data.has_update && data.latest_version && compareVersions(data.latest_version, effectiveVer) > 0) {
            window._pendingUpdateData = data;
            const banner = document.getElementById('banner-update-available');
            const verLabel = document.getElementById('update-version-label');
            const descLabel = document.getElementById('update-desc-label');

            if (banner) {
                if (verLabel) verLabel.innerText = `v${data.latest_version}`;
                if (descLabel && Array.isArray(data.changelog) && data.changelog.length > 0) {
                    descLabel.innerText = data.changelog.join(' • ');
                }
                banner.classList.remove('hidden');
                safeCreateIcons();
            }

            if (manualTrigger) {
                const statusText = document.getElementById('about-update-status-text');
                if (statusText) statusText.innerText = `Nova versão disponível: v${data.latest_version}`;
            }
        } else {
            window._pendingUpdateData = null;
            dismissUpdateBanner();
            if (manualTrigger) {
                const statusText = document.getElementById('about-update-status-text');
                if (statusText) statusText.innerText = `O Huginn está atualizado na versão ${effectiveVer}.`;
                alert(`✓ Nenhuma nova atualização encontrada. Versão ativa: ${effectiveVer}.`);
            }
        }
    } catch (e) {
        console.warn("Checagem de atualizações offline ou indisponível:", e);
        if (manualTrigger) {
            alert("Não foi possível conectar ao servidor de atualizações. Verifique sua conexão com a internet.");
        }
    }
}

function dismissUpdateBanner() {
    const banner = document.getElementById('banner-update-available');
    if (banner) banner.classList.add('hidden');
}

async function applySystemUpdateOnline() {
    if (!window._pendingUpdateData) return;

    const btn = document.getElementById('btn-apply-update');
    const update = window._pendingUpdateData;

    const confirmMsg = `Deseja instalar a atualização Huginn v${update.latest_version} agora?\nO pacote (~1 MB) será verificado com assinatura criptográfica SHA-256 e aplicado com segurança.`;
    if (!confirm(confirmMsg)) return;

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>Validando e Instalando...</span>`;
        safeCreateIcons();
    }

    try {
        const res = await fetch('/api/system/apply-update', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                download_url: update.download_url,
                sha256: update.sha256,
                signature: update.signature,
                version: update.latest_version
            })
        });
        const data = await res.json();

        if (res.ok && data.success) {
            localStorage.setItem('huginn_installed_patch_version', update.latest_version);
            window._pendingUpdateData = null;
            const banner = document.getElementById('banner-update-available');
            if (banner) banner.classList.add('hidden');
            alert("✓ " + data.message);
            setTimeout(() => location.reload(true), 1200);
        } else {
            alert("Falha na atualização de segurança: " + (data.detail || data.message || "Erro desconhecido."));
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = `<i data-lucide="download-cloud" class="w-3.5 h-3.5"></i><span>Tentar Novamente</span>`;
                safeCreateIcons();
            }
        }
    } catch (err) {
        alert("Erro ao aplicar a atualização: " + err.message);
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `<i data-lucide="download-cloud" class="w-3.5 h-3.5"></i><span>Tentar Novamente</span>`;
            safeCreateIcons();
        }
    }
}

// ==================== MODAL: SOBRE O SISTEMA ====================

function openAboutModal() {
    const modal = document.getElementById('modal-about-system');
    if (!modal) return;
    const effectiveVer = getEffectiveSystemVersion();
    updateVersionDisplays(effectiveVer);
    modal.classList.remove('hidden');
    safeCreateIcons();
}

function closeAboutModal() {
    const modal = document.getElementById('modal-about-system');
    if (modal) modal.classList.add('hidden');
}

async function checkUpdatesFromAboutModal() {
    const btn = document.getElementById('btn-check-updates-modal');
    const statusText = document.getElementById('about-update-status-text');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<i data-lucide="loader-2" class="w-3 h-3 animate-spin"></i><span>Checando...</span>`;
        safeCreateIcons();
    }
    if (statusText) statusText.innerText = "Consultando repositório de segurança...";

    await checkForSystemUpdates(true);

    if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<i data-lucide="refresh-cw" class="w-3 h-3"></i><span>Verificar Agora</span>`;
        safeCreateIcons();
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    try {
        initTheme();
    } catch (e) {
        console.warn("Erro ao inicializar tema:", e);
    }

    try {
        initDeviceGuideCard();
    } catch (e) {
        console.warn("Erro ao inicializar guia de dispositivos:", e);
    }

    safeCreateIcons();

    // Event listeners dos seletores em cascata (registrados imediatamente para nunca falharem)
    const opSelect = document.getElementById('op-select');
    if (opSelect) {
        opSelect.addEventListener('change', async (e) => {
            syncSelectTooltip(e.target);
            const opId = parseInt(e.target.value);
            if (opId) {
                invalidateTabContext();
                if (typeof resetDmChatPanel === 'function') resetDmChatPanel();
                await selectOperation(opId);
            }
        });
    }

    const phaseSelect = document.getElementById('phase-select');
    if (phaseSelect) {
        phaseSelect.addEventListener('change', async (e) => {
            syncSelectTooltip(e.target);
            const phaseVal = e.target.value;
            currentPhaseId = phaseVal ? parseInt(phaseVal) : null;
            invalidateTabContext();
            if (typeof resetDmChatPanel === 'function') resetDmChatPanel();
            await loadTargets(currentOpId, currentPhaseId);
            refreshActiveTab(true);
        });
    }

    const targetSelect = document.getElementById('target-select');
    if (targetSelect) {
        targetSelect.addEventListener('change', (e) => {
            syncSelectTooltip(e.target);
            const targetVal = e.target.value;
            currentTargetId = targetVal ? parseInt(targetVal) : null;
            updateTargetDeleteButtonState();
            invalidateTabContext();
            if (typeof resetDmChatPanel === 'function') resetDmChatPanel();
            refreshActiveTab(true);
        });
    }

    // Import modal listeners
    const importOpSelect = document.getElementById('import-op-select');
    if (importOpSelect) {
        importOpSelect.addEventListener('change', (e) => syncSelectTooltip(e.target));
    }
    const importPhaseSelect = document.getElementById('import-phase-select');
    if (importPhaseSelect) {
        importPhaseSelect.addEventListener('change', (e) => syncSelectTooltip(e.target));
    }
    const importTargetSelect = document.getElementById('import-target-select');
    if (importTargetSelect) {
        importTargetSelect.addEventListener('change', (e) => syncSelectTooltip(e.target));
    }

    // Validação de licença e carregamento de operações
    try {
        const isLicensed = await checkLicenseStatus();
        if (isLicensed) {
            await loadOperations();
        } else {
            if (opSelect) {
                opSelect.innerHTML = '<option value="">Cofre Bloqueado</option>';
                syncSelectTooltip(opSelect);
            }
        }
    } catch (e) {
        console.error("Erro na checagem de licença/operações:", e);
        if (opSelect) {
            opSelect.innerHTML = '<option value="">Sem Operações</option>';
            syncSelectTooltip(opSelect);
        }
    }

    setTimeout(checkForSystemUpdates, 1500);
});

function updateTargetDeleteButtonState() {
    const btnDel = document.getElementById('btn-delete-target');
    const btnEdit = document.getElementById('btn-edit-target');
    const btnMerge = document.getElementById('btn-merge-target');
    if (currentTargetId) {
        if (btnDel) btnDel.classList.remove('hidden');
        if (btnEdit) btnEdit.classList.remove('hidden');
        if (btnMerge) btnMerge.classList.remove('hidden');
    } else {
        if (btnDel) btnDel.classList.add('hidden');
        if (btnEdit) btnEdit.classList.add('hidden');
        if (btnMerge) btnMerge.classList.add('hidden');
    }
}

// ==================== GESTÃO DE OPERAÇÕES ====================

async function loadOperations() {
    const select = document.getElementById('op-select');
    try {
        const res = await fetch('/api/operations');
        if (!res.ok) {
            console.warn("Resposta não-OK ao buscar operações:", res.status);
            if (select) {
                select.innerHTML = '<option value="">Sem Operações</option>';
                syncSelectTooltip(select);
            }
            return;
        }
        const operations = await res.json();

        if (!Array.isArray(operations) || operations.length === 0) {
            if (select) {
                select.innerHTML = '<option value="">Nenhuma Operação</option>';
                syncSelectTooltip(select);
            }
            currentOpId = null;
            currentPhaseId = null;
            currentTargetId = null;
            window.currentOpId = null;
            window.currentPhaseId = null;
            window.currentTargetId = null;
            refreshActiveTab();
            return;
        }

        if (select) {
            select.innerHTML = operations.map(o => `<option value="${o.id}" title="${escapeHtml(o.name)}">${escapeHtml(o.name)}</option>`).join('');
            if (!currentOpId || !operations.some(o => o.id === currentOpId)) {
                currentOpId = operations[0].id;
            }
            select.value = currentOpId;
            syncSelectTooltip(select);
        }
        await selectOperation(currentOpId);
    } catch (err) {
        console.error("Erro ao carregar operações:", err);
        if (select) {
            select.innerHTML = '<option value="">Sem Operações</option>';
            syncSelectTooltip(select);
        }
    }
}

async function selectOperation(opId) {
    currentOpId = opId;
    window.currentOpId = opId;
    currentTargetId = null;
    window.currentTargetId = null;
    window.currentTargetVanity = '';
    window.currentTargetUid = '';
    window.operationTargetHandles = new Set();
    invalidateTabContext();
    if (typeof resetDmChatPanel === 'function') resetDmChatPanel();

    const opSelect = document.getElementById('op-select');
    if (opSelect) {
        opSelect.value = opId;
        syncSelectTooltip(opSelect);
    }

    try {
        const res = await fetch(`/api/operations/${opId}`);
        if (!res.ok) return;
        const opData = await res.json();

        // Carregar Fases no dropdown
        await loadPhases(opId);

        // Carregar Alvos no dropdown
        await loadTargets(opId, currentPhaseId);

        const statsHtml = `
            <div class="flex items-center space-x-1"><span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span><span>Fases: <b>${opData.phases ? opData.phases.length : 0}</b></span></div>
            <div class="flex items-center space-x-1"><span class="w-1.5 h-1.5 rounded-full bg-pink-500"></span><span>Alvos: <b>${opData.targets ? opData.targets.length : 0}</b></span></div>
            <div class="flex items-center space-x-1"><span class="w-1.5 h-1.5 rounded-full bg-indigo-400"></span><span>Arquivos: <b>${opData.custody_files ? opData.custody_files.length : 0}</b></span></div>
        `;
        const statsElem = document.getElementById('case-quick-stats');
        if (statsElem) statsElem.innerHTML = statsHtml;

        refreshActiveTab(true);
    } catch (err) {
        console.error("Erro ao selecionar operação:", err);
    }
}

// ==================== GESTÃO DE FASES ====================

async function loadPhases(opId) {
    const phaseSelect = document.getElementById('phase-select');
    if (!phaseSelect) return;
    try {
        const res = await fetch(`/api/operations/${opId}/phases`);
        if (!res.ok) {
            phaseSelect.innerHTML = '<option value="">Sem Fases</option>';
            currentPhaseId = null;
            syncSelectTooltip(phaseSelect);
            return;
        }
        const phases = await res.json();

        if (!Array.isArray(phases) || phases.length === 0) {
            phaseSelect.innerHTML = '<option value="">Sem Fases</option>';
            currentPhaseId = null;
            syncSelectTooltip(phaseSelect);
            return;
        }

        let options = '<option value="" title="Todas as Fases da Operação">Todas as Fases</option>';
        options += phases.map(p => `<option value="${p.id}" title="${escapeHtml(p.name)}">${escapeHtml(p.name)}</option>`).join('');
        phaseSelect.innerHTML = options;

        if (currentPhaseId && phases.some(p => p.id === currentPhaseId)) {
            phaseSelect.value = currentPhaseId;
        } else {
            phaseSelect.value = "";
            currentPhaseId = null;
        }
        syncSelectTooltip(phaseSelect);
    } catch (err) {
        console.error("Erro ao carregar fases:", err);
        phaseSelect.innerHTML = '<option value="">Todas as Fases</option>';
        syncSelectTooltip(phaseSelect);
    }
}

// ==================== GESTÃO DE ALVOS ====================

async function loadTargets(opId, phaseId = null, targetToSelect = null) {
    const targetSelect = document.getElementById('target-select');
    if (!targetSelect) return;
    try {
        const url = `/api/operations/${opId}/targets${phaseId ? '?phase_id=' + phaseId : ''}`;
        const res = await fetch(url);
        if (!res.ok) {
            targetSelect.innerHTML = '<option value="">Todos os Alvos (0)</option>';
            currentTargetId = null;
            window.currentTargetId = null;
            updateTargetDeleteButtonState();
            syncSelectTooltip(targetSelect);
            return;
        }
        const targets = await res.json();

        if (!Array.isArray(targets) || targets.length === 0) {
            targetSelect.innerHTML = '<option value="">Todos os Alvos (0)</option>';
            currentTargetId = null;
            window.currentTargetId = null;
            updateTargetDeleteButtonState();
            syncSelectTooltip(targetSelect);
            return;
        }

        let options = '<option value="" title="Todos os Alvos da Operação">Todos os Alvos (' + targets.length + ')</option>';
        options += targets.map(t => {
            const cleanLabel = getCleanTargetLabel(t);
            return `<option value="${t.id}" title="${escapeHtml(cleanLabel)}">${escapeHtml(cleanLabel)}</option>`;
        }).join('');
        targetSelect.innerHTML = options;

        const effectiveTargetId = targetToSelect !== null ? targetToSelect : currentTargetId;

        if (effectiveTargetId && targets.some(t => t.id === effectiveTargetId)) {
            targetSelect.value = effectiveTargetId;
            currentTargetId = effectiveTargetId;
            window.currentTargetId = effectiveTargetId;
        } else {
            targetSelect.value = "";
            currentTargetId = null;
            window.currentTargetId = null;
        }
        updateTargetDeleteButtonState();
        syncSelectTooltip(targetSelect);
    } catch (err) {
        console.error("Erro ao carregar alvos:", err);
        targetSelect.innerHTML = '<option value="">Todos os Alvos</option>';
        updateTargetDeleteButtonState();
        syncSelectTooltip(targetSelect);
    }
}

async function loadTargetsForNavigation(opId, phaseId = null, targetToSelect = null) {
    await loadTargets(opId, phaseId, targetToSelect);
    refreshActiveTab();
}

// ==================== REFRESH DE VIEWS OTIMIZADO ====================

let tabLoadedContext = {
    instagram: null,
    whatsapp: null,
    google: null,
    graph: null,
    timeline: null,
    custody: null
};

function invalidateTabContext(tabName = null) {
    if (tabName && tabLoadedContext.hasOwnProperty(tabName)) {
        tabLoadedContext[tabName] = null;
    } else {
        Object.keys(tabLoadedContext).forEach(k => { tabLoadedContext[k] = null; });
    }
}

function refreshActiveTab(force = false) {
    if (!currentOpId) return;

    window.currentOpId = currentOpId;
    window.currentPhaseId = currentPhaseId;
    window.currentTargetId = currentTargetId;

    const currentContextKey = `${currentOpId}_${currentPhaseId || 'all'}_${currentTargetId || 'all'}`;

    if (!force && tabLoadedContext[currentActiveTab] === currentContextKey) {
        // Tab já está carregada no DOM para este mesmo contexto; troca 100% instantânea (0ms)!
        return;
    }

    tabLoadedContext[currentActiveTab] = currentContextKey;

    if (currentActiveTab === 'instagram') {
        loadInstagramView(currentOpId, currentPhaseId, currentTargetId);
    } else if (currentActiveTab === 'whatsapp') {
        loadWhatsAppView(currentOpId, currentPhaseId, currentTargetId);
    } else if (currentActiveTab === 'google') {
        loadGoogleView(currentOpId, currentPhaseId, currentTargetId);
    } else if (currentActiveTab === 'graph') {
        loadGraphView(currentOpId, currentPhaseId, currentTargetId);
    } else if (currentActiveTab === 'timeline') {
        loadTimelineView(currentOpId, currentPhaseId, currentTargetId);
    } else if (currentActiveTab === 'custody') {
        loadCustodyView(currentOpId, currentPhaseId, currentTargetId);
    }
}

function switchTab(tabName) {
    currentActiveTab = tabName;

    const tabs = ['instagram', 'whatsapp', 'google', 'graph', 'timeline', 'custody'];
    tabs.forEach(t => {
        const btn = document.getElementById(`tab-${t}`);
        const view = document.getElementById(`view-${t}`);
        if (!btn || !view) return;
        if (t === tabName) {
            btn.classList.add('active');
            view.classList.remove('hidden');
        } else {
            btn.classList.remove('active');
            view.classList.add('hidden');
        }
    });

    // Troca instantânea: sem varredura global do DOM e sem re-fetch desnecessário
    refreshActiveTab(false);
}

// ==================== MODAIS ====================

// 1. Nova Operação (Opção 2 - com 1ª Fase Inclusa)
function openNewOpModal() {
    document.getElementById('new-op-name').value = '';
    document.getElementById('new-op-unit').value = '';
    document.getElementById('new-op-docket').value = '';
    document.getElementById('new-op-desc').value = '';
    document.getElementById('new-op-phase-name').value = 'Fase 1 - Preservação e Quebra Inicial';
    document.getElementById('new-op-phase-court-order').value = '';
    document.getElementById('new-op-phase-daterange').value = '';
    document.getElementById('modal-new-op').classList.remove('hidden');
    lucide.createIcons();
}
function closeNewOpModal() {
    document.getElementById('modal-new-op').classList.add('hidden');
}
async function submitNewOp() {
    const name = document.getElementById('new-op-name').value.trim();
    if (!name) return alert("Digite o nome da operação.");

    const unit = document.getElementById('new-op-unit').value.trim();
    const docket = document.getElementById('new-op-docket').value.trim();
    const desc = document.getElementById('new-op-desc').value.trim();
    const phaseName = document.getElementById('new-op-phase-name').value.trim() || 'Fase 1 - Preservação e Quebra Inicial';
    const phaseCourtOrder = document.getElementById('new-op-phase-court-order').value.trim();
    const phaseDateRange = document.getElementById('new-op-phase-daterange').value.trim();

    try {
        const res = await fetch('/api/operations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name,
                police_unit: unit,
                court_docket: docket,
                description: desc,
                initial_phase_name: phaseName,
                initial_phase_court_order: phaseCourtOrder,
                initial_phase_date_range: phaseDateRange
            })
        });
        const op = await res.json();
        closeNewOpModal();
        currentOpId = op.id;
        currentPhaseId = op.default_phase_id || null;
        currentTargetId = null;
        window.currentOpId = op.id;
        window.currentPhaseId = currentPhaseId;
        window.currentTargetId = null;
        window.currentTargetVanity = '';
        window.currentTargetUid = '';
        if (typeof resetDmChatPanel === 'function') resetDmChatPanel();

        await loadOperations();
    } catch (err) {
        alert("Erro ao criar operação: " + err.message);
    }
}

// 1B. Editar Operação
async function openEditOpModal() {
    if (!currentOpId) return alert("Selecione uma operação para editar.");

    try {
        const res = await fetch(`/api/operations/${currentOpId}`);
        const op = await res.json();
        document.getElementById('edit-op-name').value = op.name || '';
        document.getElementById('edit-op-unit').value = op.police_unit || '';
        document.getElementById('edit-op-docket').value = op.court_docket || '';
        document.getElementById('edit-op-desc').value = op.description || '';
        document.getElementById('modal-edit-op').classList.remove('hidden');
        lucide.createIcons();
    } catch (err) {
        alert("Erro ao carregar dados da operação: " + err.message);
    }
}
function closeEditOpModal() {
    document.getElementById('modal-edit-op').classList.add('hidden');
}
async function submitEditOp() {
    const name = document.getElementById('edit-op-name').value.trim();
    if (!name) return alert("O nome da operação não pode ficar vazio.");

    const unit = document.getElementById('edit-op-unit').value.trim();
    const docket = document.getElementById('edit-op-docket').value.trim();
    const desc = document.getElementById('edit-op-desc').value.trim();

    try {
        const res = await fetch(`/api/operations/${currentOpId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, police_unit: unit, court_docket: docket, description: desc })
        });
        if (res.ok) {
            closeEditOpModal();
            await loadOperations();
            await selectOperation(currentOpId);
        } else {
            alert("Erro ao salvar alterações da operação.");
        }
    } catch (err) {
        alert("Erro na requisição: " + err.message);
    }
}
// ==================== MODAL DE CONFIRMAÇÃO DE EXCLUSÃO CUSTOMIZADO ====================
let pendingDeleteAction = null;

function showCustomDeleteModal({ title, subtitle, message, details, confirmBtnText = "Excluir Definitivamente", onConfirm }) {
    document.getElementById('delete-modal-title').innerText = title || "Confirmar Exclusão";
    document.getElementById('delete-modal-subtitle').innerText = subtitle || "Esta ação é irreversível.";
    document.getElementById('delete-modal-message').innerHTML = message || "";
    document.getElementById('delete-modal-details').innerHTML = details || "";
    document.getElementById('btn-confirm-delete-text').innerText = confirmBtnText;

    pendingDeleteAction = onConfirm;

    const modal = document.getElementById('modal-confirm-delete');
    modal.classList.remove('hidden');

    const confirmBtn = document.getElementById('btn-confirm-delete-action');
    confirmBtn.onclick = async () => {
        if (pendingDeleteAction) {
            confirmBtn.disabled = true;
            try {
                await pendingDeleteAction();
            } finally {
                confirmBtn.disabled = false;
                closeDeleteModal();
            }
        }
    };
    lucide.createIcons();
}

function closeDeleteModal() {
    document.getElementById('modal-confirm-delete').classList.add('hidden');
    pendingDeleteAction = null;
}

function confirmDeleteOp() {
    if (!currentOpId) return;
    const opName = document.getElementById('edit-op-name').value || 'esta operação';
    
    showCustomDeleteModal({
        title: "Excluir Operação Completa",
        subtitle: "Inquérito e todo o seu histórico serão removidos",
        message: `Você está prestes a excluir a operação <b>"${escapeHtml(opName)}"</b>.`,
        details: `⚠️ <b>AVISO DE CUSTÓDIA:</b> Esta ação apagará permanentemente todas as fases, alvos, conversas, mídias, seguidores e registros de integridade SHA-256 vinculados a este inquérito.`,
        confirmBtnText: "Sim, Excluir Operação",
        onConfirm: async () => {
            const res = await fetch(`/api/operations/${currentOpId}`, { method: 'DELETE' });
            if (res.ok) {
                closeEditOpModal();
                currentOpId = null;
                currentPhaseId = null;
                currentTargetId = null;
                await loadOperations();
            } else {
                alert("Erro ao excluir operação.");
            }
        }
    });
}

// 2. Nova Fase
function openNewPhaseModal() {
    if (!currentOpId) return alert("Selecione uma operação primeiro.");
    document.getElementById('new-phase-name').value = '';
    document.getElementById('new-phase-court-order').value = '';
    document.getElementById('new-phase-daterange').value = '';
    document.getElementById('new-phase-desc').value = '';
    document.getElementById('modal-new-phase').classList.remove('hidden');
    lucide.createIcons();
}
function closeNewPhaseModal() {
    document.getElementById('modal-new-phase').classList.add('hidden');
}
async function submitNewPhase() {
    const name = document.getElementById('new-phase-name').value.trim();
    if (!name) return alert("Digite o nome da fase.");

    const courtOrder = document.getElementById('new-phase-court-order').value.trim();
    const dateRange = document.getElementById('new-phase-daterange').value.trim();
    const desc = document.getElementById('new-phase-desc').value.trim();

    try {
        const res = await fetch(`/api/operations/${currentOpId}/phases`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, court_order: courtOrder, date_range: dateRange, description: desc })
        });
        const p = await res.json();
        closeNewPhaseModal();
        currentPhaseId = p.id;
        await selectOperation(currentOpId);
    } catch (err) {
        alert("Erro ao criar fase: " + err.message);
    }
}

// 2B. Editar Fase
async function openEditPhaseModal() {
    if (!currentPhaseId) {
        return alert("Selecione uma fase específica no menu de fases para editar.");
    }

    try {
        const res = await fetch(`/api/phases/${currentPhaseId}`);
        const ph = await res.json();
        document.getElementById('edit-phase-name').value = ph.name || '';
        document.getElementById('edit-phase-court-order').value = ph.court_order_number || '';
        document.getElementById('edit-phase-daterange').value = ph.date_range || '';
        document.getElementById('edit-phase-desc').value = ph.description || '';
        document.getElementById('modal-edit-phase').classList.remove('hidden');
        lucide.createIcons();
    } catch (err) {
        alert("Erro ao carregar dados da fase: " + err.message);
    }
}
function closeEditPhaseModal() {
    document.getElementById('modal-edit-phase').classList.add('hidden');
}
async function submitEditPhase() {
    const name = document.getElementById('edit-phase-name').value.trim();
    if (!name) return alert("O nome da fase não pode ficar vazio.");

    const courtOrder = document.getElementById('edit-phase-court-order').value.trim();
    const dateRange = document.getElementById('edit-phase-daterange').value.trim();
    const desc = document.getElementById('edit-phase-desc').value.trim();

    try {
        const res = await fetch(`/api/phases/${currentPhaseId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, court_order: courtOrder, date_range: dateRange, description: desc })
        });
        if (res.ok) {
            closeEditPhaseModal();
            await loadPhases(currentOpId);
            refreshActiveTab();
        } else {
            alert("Erro ao salvar alterações da fase.");
        }
    } catch (err) {
        alert("Erro na requisição: " + err.message);
    }
}
function confirmDeletePhase() {
    if (!currentPhaseId) return;
    const phaseName = document.getElementById('edit-phase-name').value || 'esta fase';

    showCustomDeleteModal({
        title: "Excluir Fase da Investigação",
        subtitle: "Ordem judicial e relatórios vinculados serão removidos",
        message: `Você está prestes a excluir a fase <b>"${escapeHtml(phaseName)}"</b>.`,
        details: `⚠️ A operação principal continuará existindo, mas os relatórios e registros importados especificamente sob este mandado serão excluídos.`,
        confirmBtnText: "Sim, Excluir Fase",
        onConfirm: async () => {
            const res = await fetch(`/api/phases/${currentPhaseId}`, { method: 'DELETE' });
            if (res.ok) {
                closeEditPhaseModal();
                currentPhaseId = null;
                await loadPhases(currentOpId);
                await loadTargets(currentOpId, null);
                refreshActiveTab();
            } else {
                alert("Erro ao excluir fase.");
            }
        }
    });
}

// 3. Excluir Alvo Selecionado
function confirmDeleteTarget() {
    if (!currentTargetId) return alert("Selecione um alvo para excluir.");

    const sel = document.getElementById('target-select');
    const targetLabel = sel.options[sel.selectedIndex]?.text || 'este alvo';

    showCustomDeleteModal({
        title: "Excluir Alvo da Investigação",
        subtitle: "Perfil e vínculos do investigado serão removidos",
        message: `Você está prestes a excluir o investigado <b>"${escapeHtml(targetLabel)}"</b>.`,
        details: `⚠️ Os dados cadastrais, seguidores, conexões IP e histórico de mensagens deste perfil serão removidos da operação.`,
        confirmBtnText: "Sim, Excluir Alvo",
        onConfirm: async () => {
            const res = await fetch(`/api/targets/${currentTargetId}`, { method: 'DELETE' });
            if (res.ok) {
                currentTargetId = null;
                await loadTargets(currentOpId, currentPhaseId);
                refreshActiveTab();
            } else {
                alert("Erro ao excluir alvo.");
            }
        }
    });
}

// 3B. Novo Alvo / Vincular Alvo Manual
async function openNewTargetModal() {
    if (!currentOpId) return alert("Selecione uma operação primeiro.");
    document.getElementById('new-target-name').value = '';
    document.getElementById('new-target-identifier').value = '';
    document.getElementById('new-target-cpf').value = '';

    const bindContainer = document.getElementById('existing-target-container');
    const bindSelect = document.getElementById('bind-existing-target-select');

    if (currentPhaseId) {
        const res = await fetch(`/api/operations/${currentOpId}/targets`);
        const targets = await res.json();
        if (targets.length > 0) {
            bindContainer.classList.remove('hidden');
            bindSelect.innerHTML = targets.map(t => {
                const cleanLabel = getCleanTargetLabel(t);
                return `<option value="${t.id}" title="${escapeHtml(cleanLabel)}">${escapeHtml(cleanLabel)}</option>`;
            }).join('');
            syncSelectTooltip(bindSelect);
        } else {
            bindContainer.classList.add('hidden');
        }
    } else {
        bindContainer.classList.add('hidden');
    }

    document.getElementById('modal-new-target').classList.remove('hidden');
    lucide.createIcons();
}
function closeNewTargetModal() {
    document.getElementById('modal-new-target').classList.add('hidden');
}
async function submitNewTarget() {
    const name = document.getElementById('new-target-name').value.trim();
    const identifier = document.getElementById('new-target-identifier').value.trim();
    if (!name || !identifier) return alert("Informe o nome/alias e o identificador do alvo.");

    const platform = document.getElementById('new-target-platform').value;
    const cpf = document.getElementById('new-target-cpf').value.trim();

    try {
        const res = await fetch(`/api/operations/${currentOpId}/targets`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name_or_alias: name,
                main_identifier: identifier,
                platform: platform,
                cpf_cnpj: cpf,
                phase_id: currentPhaseId
            })
        });
        const t = await res.json();
        closeNewTargetModal();
        currentTargetId = t.id;
        await selectOperation(currentOpId);
    } catch (err) {
        alert("Erro ao cadastrar alvo: " + err.message);
    }
}
async function submitBindTarget() {
    const targetId = parseInt(document.getElementById('bind-existing-target-select').value);
    if (!targetId || !currentPhaseId) return alert("Selecione um alvo e uma fase.");

    try {
        await fetch(`/api/phases/${currentPhaseId}/bind-target`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ target_id: targetId })
        });
        closeNewTargetModal();
        currentTargetId = targetId;
        await selectOperation(currentOpId);
    } catch (err) {
        alert("Erro ao vincular alvo: " + err.message);
    }
}

// 4. Importar Evidência
let lastImportedContext = null;
let importLoadingInterval = null;

function setImportState(state) {
    const viewForm = document.getElementById('import-view-form');
    const viewLoading = document.getElementById('import-view-loading');
    const viewSuccess = document.getElementById('import-view-success');

    if (!viewForm || !viewLoading || !viewSuccess) return;

    if (state === 'form') {
        viewForm.classList.remove('hidden');
        viewLoading.classList.add('hidden');
        viewSuccess.classList.add('hidden');
        if (importLoadingInterval) clearInterval(importLoadingInterval);
    } else if (state === 'loading') {
        viewForm.classList.add('hidden');
        viewLoading.classList.remove('hidden');
        viewSuccess.classList.add('hidden');
        startImportLoadingAnimation();
    } else if (state === 'success') {
        viewForm.classList.add('hidden');
        viewLoading.classList.add('hidden');
        viewSuccess.classList.remove('hidden');
        if (importLoadingInterval) clearInterval(importLoadingInterval);
    }
    lucide.createIcons();
}

function startImportLoadingAnimation() {
    const progressBar = document.getElementById('import-progress-bar');
    const loadingMsg = document.getElementById('import-loading-msg');
    const stepSha = document.getElementById('step-sha256');
    const stepExtract = document.getElementById('step-extract');
    const stepDossier = document.getElementById('step-dossier');
    const stepDms = document.getElementById('step-dms');
    const stepFinish = document.getElementById('step-finish');

    let currentStep = 1;
    let progress = 15;

    // Resetar estilos
    progressBar.style.width = '15%';
    loadingMsg.innerText = 'Calculando integridade criptográfica SHA-256...';
    stepSha.className = 'flex items-center space-x-2 text-blue-600 dark:text-cyan-400 font-semibold';
    stepExtract.className = 'flex items-center space-x-2 text-slate-400';
    stepDossier.className = 'flex items-center space-x-2 text-slate-400';
    stepDms.className = 'flex items-center space-x-2 text-slate-400';
    stepFinish.className = 'flex items-center space-x-2 text-slate-400';

    if (importLoadingInterval) clearInterval(importLoadingInterval);

    importLoadingInterval = setInterval(() => {
        currentStep++;
        if (currentStep === 2) {
            progress = 35;
            progressBar.style.width = `${progress}%`;
            loadingMsg.innerText = 'Descompactando e auditando arquivos...';
            stepSha.className = 'flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-medium';
            stepSha.innerHTML = `<i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-500"></i><span>1. Validação e cálculo do Hash SHA-256</span>`;
            stepExtract.className = 'flex items-center space-x-2 text-blue-600 dark:text-cyan-400 font-semibold';
            stepExtract.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>2. Descompactação e auditoria da estrutura Meta</span>`;
        } else if (currentStep === 3) {
            progress = 60;
            progressBar.style.width = `${progress}%`;
            loadingMsg.innerText = 'Extraindo dossiê cadastral, e-mails e conexões IP...';
            stepExtract.className = 'flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-medium';
            stepExtract.innerHTML = `<i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-500"></i><span>2. Descompactação e auditoria da estrutura Meta</span>`;
            stepDossier.className = 'flex items-center space-x-2 text-blue-600 dark:text-cyan-400 font-semibold';
            stepDossier.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>3. Extração do Dossiê Cadastral, E-mails e IPs</span>`;
        } else if (currentStep === 4) {
            progress = 80;
            progressBar.style.width = `${progress}%`;
            loadingMsg.innerText = 'Indexando mensagens diretas (DMs), mídias e áudios...';
            stepDossier.className = 'flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-medium';
            stepDossier.innerHTML = `<i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-500"></i><span>3. Extração do Dossiê Cadastral, E-mails e IPs</span>`;
            stepDms.className = 'flex items-center space-x-2 text-blue-600 dark:text-cyan-400 font-semibold';
            stepDms.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>4. Indexação de DMs, Mensagens e Áudios</span>`;
        } else if (currentStep === 5) {
            progress = 92;
            progressBar.style.width = `${progress}%`;
            loadingMsg.innerText = 'Mapeando seguidores, conexões e gravando no banco...';
            stepDms.className = 'flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-medium';
            stepDms.innerHTML = `<i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-500"></i><span>4. Indexação de DMs, Mensagens e Áudios</span>`;
            stepFinish.className = 'flex items-center space-x-2 text-blue-600 dark:text-cyan-400 font-semibold';
            stepFinish.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>5. Mapeamento de Vínculos e Linha do Tempo</span>`;
        }
        lucide.createIcons();
    }, 1400);
}

// ==================== GESTÃO AVANÇADA DE ALVOS (EDIÇÃO & MESCLAGEM) ====================

let currentEditingTarget = null;

async function openEditTargetModal() {
    if (!currentTargetId) {
        return alert("Selecione um alvo para editar.");
    }
    const opId = currentOpId || parseInt(document.getElementById('op-select').value);
    const res = await fetch(`/api/operations/${opId}/targets`);
    const targets = await res.json();
    const t = targets.find(item => item.id === currentTargetId);
    if (!t) return alert("Alvo não encontrado.");

    currentEditingTarget = t;
    document.getElementById('edit-target-name').value = t.name_or_alias || '';
    document.getElementById('edit-target-identifier').value = t.main_identifier || '';
    document.getElementById('edit-target-notes').value = t.notes || '';

    document.getElementById('modal-edit-target').classList.remove('hidden');
    lucide.createIcons();
}

function closeEditTargetModal() {
    document.getElementById('modal-edit-target').classList.add('hidden');
    currentEditingTarget = null;
}

async function submitEditTarget() {
    if (!currentTargetId) return;
    const name = document.getElementById('edit-target-name').value.trim();
    const identifier = document.getElementById('edit-target-identifier').value.trim();
    const notes = document.getElementById('edit-target-notes').value.trim();

    if (!name && !identifier) {
        return alert("Informe pelo menos um nome ou identificador para o alvo.");
    }

    try {
        const res = await fetch(`/api/targets/${currentTargetId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name_or_alias: name,
                main_identifier: identifier,
                notes: notes
            })
        });

        if (!res.ok) {
            const err = await res.json();
            throw new Error(err.detail || "Erro ao atualizar alvo.");
        }

        closeEditTargetModal();
        // Recarregar alvos mantendo a seleção ativa
        const opId = currentOpId || parseInt(document.getElementById('op-select').value);
        const phaseVal = document.getElementById('phase-select')?.value;
        const phaseId = currentPhaseId !== null ? currentPhaseId : (phaseVal ? parseInt(phaseVal) : null);
        await loadTargetsForNavigation(opId, phaseId, currentTargetId);
    } catch (e) {
        alert("Erro: " + e.message);
    }
}

let mergeTargetsList = [];

async function openMergeTargetsModal() {
    const opId = currentOpId || parseInt(document.getElementById('op-select').value);
    if (!opId) return alert("Selecione uma operação.");

    const res = await fetch(`/api/operations/${opId}/targets`);
    mergeTargetsList = await res.json();

    if (mergeTargetsList.length < 2) {
        return alert("São necessários pelo menos 2 alvos na operação para realizar uma mesclagem.");
    }

    const srcSelect = document.getElementById('merge-source-select');
    const destSelect = document.getElementById('merge-dest-select');

    srcSelect.innerHTML = mergeTargetsList.map(t => `<option value="${t.id}">${escapeHtml(getCleanTargetLabel(t))}</option>`).join('');
    
    // Se tiver alvo ativo, colocar ele como origem
    if (currentTargetId && mergeTargetsList.some(t => t.id === currentTargetId)) {
        srcSelect.value = currentTargetId;
    } else {
        srcSelect.value = mergeTargetsList[0].id;
    }

    onMergeSelectChange();
    document.getElementById('modal-merge-targets').classList.remove('hidden');
    lucide.createIcons();
}

function closeMergeTargetsModal() {
    document.getElementById('modal-merge-targets').classList.add('hidden');
}

function onMergeSelectChange() {
    const srcId = parseInt(document.getElementById('merge-source-select').value);
    const destSelect = document.getElementById('merge-dest-select');
    
    // Destino deve ser todos os alvos exceto a origem
    const availableDest = mergeTargetsList.filter(t => t.id !== srcId);
    destSelect.innerHTML = availableDest.map(t => `<option value="${t.id}">${escapeHtml(getCleanTargetLabel(t))}</option>`).join('');
    if (availableDest.length > 0) {
        destSelect.value = availableDest[0].id;
    }
}

async function submitMergeTargets() {
    const opId = currentOpId || parseInt(document.getElementById('op-select').value);
    const srcId = parseInt(document.getElementById('merge-source-select').value);
    const destId = parseInt(document.getElementById('merge-dest-select').value);

    if (!srcId || !destId || srcId === destId) {
        return alert("Selecione um alvo de origem e um alvo de destino distintos.");
    }

    const srcLabel = document.getElementById('merge-source-select').selectedOptions[0]?.text || 'Alvo Origem';
    const destLabel = document.getElementById('merge-dest-select').selectedOptions[0]?.text || 'Alvo Destino';

    if (!confirm(`Tem certeza que deseja mesclar o alvo '${srcLabel}' no alvo principal '${destLabel}'?\n\nTodas as mensagens, mídias, IPs e grupos serão unificados e o cadastro de origem será excluído.`)) {
        return;
    }

    try {
        const res = await fetch('/api/targets/merge', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                operation_id: opId,
                source_target_id: srcId,
                destination_target_id: destId
            })
        });

        const data = await res.json();
        if (!res.ok) {
            throw new Error(data.detail || "Erro ao mesclar alvos.");
        }

        alert(data.message || "Alvos mesclados com sucesso!");
        closeMergeTargetsModal();

        // Recarregar alvos com destino selecionado
        const phaseVal = document.getElementById('phase-select')?.value;
        const phaseId = currentPhaseId !== null ? currentPhaseId : (phaseVal ? parseInt(phaseVal) : null);
        await loadTargetsForNavigation(opId, phaseId, destId);
    } catch (e) {
        alert("Erro: " + e.message);
    }
}

// ==================== ASSISTENTE DE IMPORTAÇÃO (PRÉ-SCANNER & WIZARD) ====================

let inspectedEvidenceData = null;

function setImportStep(step) {
    const s1 = document.getElementById('import-step-1');
    const s2 = document.getElementById('import-step-2');
    if (step === 1) {
        if (s1) s1.classList.remove('hidden');
        if (s2) s2.classList.add('hidden');
    } else if (step === 2) {
        if (s1) s1.classList.add('hidden');
        if (s2) s2.classList.remove('hidden');
    }
    lucide.createIcons();
}

async function openImportModal(defaultPlatform = 'instagram') {
    if (defaultPlatform === 'google') {
        openGoogleImportModal();
        return;
    }
    setImportState('form');
    setImportStep(1);
    inspectedEvidenceData = null;

    const opSelect = document.getElementById('import-op-select');
    const resOps = await fetch('/api/operations');
    const operations = await resOps.json();

    if (operations.length === 0) {
        return alert("Crie pelo menos uma operação antes de importar evidências.");
    }

    opSelect.innerHTML = operations.map(o => `<option value="${o.id}" title="${escapeHtml(o.name)}">${escapeHtml(o.name)}</option>`).join('');

    if (currentOpId && operations.some(o => o.id === currentOpId)) {
        opSelect.value = currentOpId;
    } else {
        opSelect.value = operations[0].id;
    }
    syncSelectTooltip(opSelect);

    await onImportOpChange(opSelect.value);

    document.getElementById('file-upload-input').value = '';
    document.getElementById('import-local-path').value = '';
    const declHashInput = document.getElementById('import-declared-hash');
    if (declHashInput) declHashInput.value = '';

    document.getElementById('modal-import').classList.remove('hidden');
    lucide.createIcons();
}

async function onImportOpChange(opVal) {
    const opId = parseInt(opVal);
    const phaseSelect = document.getElementById('import-phase-select');
    if (!phaseSelect || isNaN(opId)) return;

    try {
        const resP = await fetch(`/api/operations/${opId}/phases`);
        const phases = await resP.json();

        if (phases.length === 0) {
            phaseSelect.innerHTML = '<option value="">Sem fases cadastradas</option>';
            syncSelectTooltip(phaseSelect);
            return;
        }

        phaseSelect.innerHTML = phases.map(p => `<option value="${p.id}" title="${escapeHtml(p.name)}">${escapeHtml(p.name)}</option>`).join('');

        if (currentPhaseId && phases.some(p => p.id === currentPhaseId)) {
            phaseSelect.value = currentPhaseId;
        } else {
            phaseSelect.value = phases[0].id;
        }
        syncSelectTooltip(phaseSelect);
    } catch (err) {
        console.error("Erro ao carregar fases para importação:", err);
    }
}

async function onImportPhaseChange(phaseVal, opId = null) {
    const phaseSelect = document.getElementById('import-phase-select');
    if (phaseSelect) syncSelectTooltip(phaseSelect);
}

let inspectedEvidenceFiles = [];

function formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

function onFileSelectedForInspect() {
    const fileInput = document.getElementById('file-upload-input');
    const summaryBox = document.getElementById('file-upload-multi-summary');
    
    if (fileInput && fileInput.files.length > 0) {
        document.getElementById('import-local-path').value = '';
        const rawFiles = Array.from(fileInput.files);
        inspectedEvidenceFiles = rawFiles.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
        
        const totalBytes = inspectedEvidenceFiles.reduce((acc, f) => acc + f.size, 0);
        
        if (summaryBox) {
            summaryBox.classList.remove('hidden');
            if (inspectedEvidenceFiles.length === 1) {
                summaryBox.innerHTML = `
                    <i data-lucide="file-archive" class="w-4 h-4 text-blue-500 flex-shrink-0"></i>
                    <span class="truncate"><b>1 arquivo ZIP selecionado:</b> ${escapeHtml(inspectedEvidenceFiles[0].name)} (${formatFileSize(inspectedEvidenceFiles[0].size)})</span>
                `;
            } else {
                const namesPreview = inspectedEvidenceFiles.slice(0, 3).map(f => escapeHtml(f.name)).join(', ');
                const extra = inspectedEvidenceFiles.length > 3 ? ` (+ ${inspectedEvidenceFiles.length - 3} outros)` : '';
                summaryBox.innerHTML = `
                    <i data-lucide="layers" class="w-4 h-4 text-blue-500 flex-shrink-0"></i>
                    <span class="truncate"><b>${inspectedEvidenceFiles.length} arquivos ZIP em lote (${formatFileSize(totalBytes)}):</b> ${namesPreview}${extra}</span>
                `;
            }
            lucide.createIcons();
        }
    } else {
        inspectedEvidenceFiles = [];
        if (summaryBox) summaryBox.classList.add('hidden');
    }
}

async function startFileInspect() {
    const opId = parseInt(document.getElementById('import-op-select').value);
    const fileInput = document.getElementById('file-upload-input');
    const localPath = document.getElementById('import-local-path').value.trim();

    if (!localPath && (!fileInput.files || fileInput.files.length === 0)) {
        return alert("Selecione um ou mais arquivos ZIP para upload ou informe o caminho local.");
    }

    if (fileInput.files && fileInput.files.length > 0) {
        const rawFiles = Array.from(fileInput.files);
        for (const f of rawFiles) {
            if (!f.name.toLowerCase().endsWith('.zip')) {
                return alert(`O arquivo "${f.name}" não é um arquivo ZIP válido. Selecione exclusivamente arquivos .zip.`);
            }
        }
        inspectedEvidenceFiles = rawFiles.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
    }

    const btnInspect = document.getElementById('btn-inspect-file');
    const origBtnHtml = btnInspect.innerHTML;
    btnInspect.disabled = true;
    btnInspect.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>Analisando...</span>`;
    lucide.createIcons();

    try {
        let inspectRes;
        if (localPath) {
            inspectRes = await fetch('/api/import/inspect', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ local_path: localPath, operation_id: opId })
            });
        } else {
            const formData = new FormData();
            formData.append('operation_id', opId);
            formData.append('file', inspectedEvidenceFiles[0]);
            inspectRes = await fetch('/api/import/inspect-upload', {
                method: 'POST',
                body: formData
            });
        }

        const data = await inspectRes.json();
        if (!inspectRes.ok) {
            throw new Error(data.detail || "Erro ao analisar o arquivo.");
        }

        inspectedEvidenceData = data;

        // Preencher Passo 2 (Confirmação)
        const pBadge = document.getElementById('inspect-platform-badge');
        if (pBadge) {
            if (data.platform === 'whatsapp') {
                pBadge.className = "px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300";
                pBadge.innerText = "💬 WhatsApp";
            } else {
                pBadge.className = "px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-pink-100 text-pink-800 dark:bg-pink-950/80 dark:text-pink-300";
                pBadge.innerText = "📸 Instagram";
            }
        }

        const nameElem = document.getElementById('inspect-name');
        const idElem = document.getElementById('inspect-identifier');
        const fileElem = document.getElementById('inspect-file-name');
        const emailTicketElem = document.getElementById('inspect-email-ticket');
        const multiZipBanner = document.getElementById('inspect-multi-zip-banner');
        const multiZipText = document.getElementById('inspect-multi-zip-text');

        if (nameElem) nameElem.innerText = data.detected_name || data.suggested_name || 'Não identificado';
        if (idElem) idElem.innerText = data.detected_identifier || '---';
        
        if (inspectedEvidenceFiles.length > 1) {
            if (fileElem) fileElem.innerText = `${inspectedEvidenceFiles.length} arquivos ZIP selecionados`;
            if (multiZipBanner) multiZipBanner.classList.remove('hidden');
            if (multiZipText) multiZipText.innerText = `Foram detectados ${inspectedEvidenceFiles.length} lotes compactados. Todos serão processados em sequência e vinculados ao mesmo Alvo nesta Fase.`;
        } else {
            if (fileElem) fileElem.innerText = data.file_name || 'arquivo.zip';
            if (multiZipBanner) multiZipBanner.classList.add('hidden');
        }

        if (emailTicketElem) {
            let info = data.detected_email || '';
            if (data.internal_ticket && data.internal_ticket !== '---') {
                info += ` | Ticket: ${data.internal_ticket}`;
            }
            emailTicketElem.innerText = info || '---';
        }

        // Sugestão de Nome para Novo Alvo
        const customNameInput = document.getElementById('inspect-custom-target-name');
        if (customNameInput) {
            customNameInput.value = data.suggested_name || data.detected_name || data.detected_identifier || '';
        }

        // Preencher Dropdown de Alvos Existentes
        const existSelect = document.getElementById('inspect-existing-target-select');
        if (existSelect) {
            const targets = data.existing_targets || [];
            if (targets.length === 0) {
                existSelect.innerHTML = '<option value="">Nenhum alvo cadastrado</option>';
            } else {
                existSelect.innerHTML = targets.map(t => {
                    const label = getCleanTargetLabel(t);
                    return `<option value="${t.id}">${escapeHtml(label)}</option>`;
                }).join('');
            }
        }

        // Box de Sugestão Inteligente
        const sugBox = document.getElementById('inspect-suggestion-box');
        const sugTxt = document.getElementById('inspect-suggestion-text');
        const radioNew = document.querySelector('input[name="import-target-mode"][value="new"]');
        const radioBind = document.querySelector('input[name="import-target-mode"][value="bind"]');

        if (data.matching_suggestion && data.existing_targets?.length > 0) {
            if (sugBox) sugBox.classList.remove('hidden');
            if (sugTxt) sugTxt.innerText = `${data.matching_suggestion.match_reason} ➔ Vincular a '${data.matching_suggestion.target_name}'?`;
            if (existSelect) existSelect.value = data.matching_suggestion.target_id;
            if (radioBind) radioBind.checked = true;
        } else {
            if (sugBox) sugBox.classList.add('hidden');
            if (radioNew) radioNew.checked = true;
        }

        onTargetModeChange();
        setImportStep(2);
    } catch (e) {
        alert("Erro na análise: " + e.message);
    } finally {
        btnInspect.disabled = false;
        btnInspect.innerHTML = origBtnHtml;
        lucide.createIcons();
    }
}

function onTargetModeChange() {
    const mode = document.querySelector('input[name="import-target-mode"]:checked')?.value || 'new';
    const customNameInput = document.getElementById('inspect-custom-target-name');
    const existSelect = document.getElementById('inspect-existing-target-select');

    if (mode === 'new') {
        if (customNameInput) {
            customNameInput.disabled = false;
            customNameInput.focus();
        }
        if (existSelect) existSelect.disabled = true;
    } else {
        if (customNameInput) customNameInput.disabled = true;
        if (existSelect) existSelect.disabled = false;
    }
}

function closeImportModal() {
    document.getElementById('modal-import').classList.add('hidden');
    if (importLoadingInterval) clearInterval(importLoadingInterval);
    inspectedEvidenceFiles = [];
    // Limpar arquivos temporários de quarentena/inspeção do servidor
    fetch('/api/import/cleanup-tmp', { method: 'POST' }).catch(() => {});
}

async function submitConfirmedImport() {
    const opId = parseInt(document.getElementById('import-op-select').value);
    const phaseId = parseInt(document.getElementById('import-phase-select').value);
    const mode = document.querySelector('input[name="import-target-mode"]:checked')?.value || 'new';
    
    let targetId = null;
    let targetName = null;

    if (mode === 'bind') {
        const existSelect = document.getElementById('inspect-existing-target-select');
        targetId = existSelect.value ? parseInt(existSelect.value) : null;
        if (!targetId) return alert("Selecione um alvo existente para vincular a evidência.");
    } else {
        targetName = document.getElementById('inspect-custom-target-name').value.trim();
        if (!targetName) targetName = inspectedEvidenceData?.suggested_name || 'Novo Alvo';
    }

    const localPathInput = document.getElementById('import-local-path').value.trim();
    const declaredHash = document.getElementById('import-declared-hash') ? document.getElementById('import-declared-hash').value.trim() : '';
    const platform = inspectedEvidenceData?.platform || 'instagram';

    setImportState('loading');

    try {
        let result = {};
        
        if (localPathInput) {
            const res = await fetch('/api/import/local', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    operation_id: opId,
                    phase_id: phaseId,
                    target_id: targetId,
                    target_name: targetName,
                    local_path: localPathInput,
                    platform: platform,
                    declared_hash: declaredHash || null
                })
            });
            result = await res.json();
            if (!res.ok) throw new Error(result.detail || "Erro ao processar caminho local.");
        } else {
            const files = (inspectedEvidenceFiles && inspectedEvidenceFiles.length > 0) ? inspectedEvidenceFiles : [document.getElementById('file-upload-input').files[0]];
            
            if (files.length === 1) {
                const formData = new FormData();
                formData.append('operation_id', opId);
                formData.append('phase_id', phaseId);
                if (targetId) formData.append('target_id', targetId);
                if (targetName) formData.append('target_name', targetName);
                formData.append('platform', platform);
                if (declaredHash) formData.append('declared_hash', declaredHash);
                formData.append('file', files[0]);

                const res = await fetch('/api/import/upload', {
                    method: 'POST',
                    body: formData
                });
                result = await res.json();
                if (!res.ok) throw new Error(result.detail || "Erro ao processar arquivo.");
            } else {
                // Ingestão Sequencial em Fila para Múltiplos ZIPs
                // Se o analista selecionou manualmente vincular a um alvo pré-existente (mode === 'bind'),
                // todos os arquivos vão para aquele alvo.
                // Se deixou em 'new' (Auto-detectar / Criar Novo), cada arquivo identifica ou cria seu próprio alvo!
                const isExplicitBind = (mode === 'bind' && Boolean(targetId));
                let currentTargetId = isExplicitBind ? targetId : null;
                let totalMessages = 0;
                let totalCalls = 0;
                let totalIps = 0;
                let lastHash = '';
                let targetCreatedName = targetName;
                let targetIdentifier = '';
                const fileHashesList = [];
                const distinctTargetsMap = new Map();

                const progressBar = document.getElementById('import-progress-bar');
                const loadingMsg = document.getElementById('import-loading-msg');

                for (let i = 0; i < files.length; i++) {
                    const f = files[i];
                    const pct = Math.round(((i) / files.length) * 100);
                    if (progressBar) progressBar.style.width = `${Math.max(5, pct)}%`;
                    if (loadingMsg) loadingMsg.innerText = `Processando arquivo ${i + 1} de ${files.length}: ${f.name}...`;

                    const formData = new FormData();
                    formData.append('operation_id', opId);
                    formData.append('phase_id', phaseId);

                    // Só envia target_id se for vinculação manual explícita
                    if (isExplicitBind && currentTargetId) {
                        formData.append('target_id', currentTargetId);
                    }
                    if (isExplicitBind && targetCreatedName) {
                        formData.append('target_name', targetCreatedName);
                    }

                    formData.append('platform', platform);
                    if (i === 0 && declaredHash) formData.append('declared_hash', declaredHash);
                    formData.append('file', f);

                    const res = await fetch('/api/import/upload', {
                        method: 'POST',
                        body: formData
                    });
                    const subRes = await res.json();
                    if (!res.ok) {
                        throw new Error(`Falha no arquivo ${f.name}: ${subRes.detail || 'Erro no servidor'}`);
                    }

                    if (subRes.target_id) {
                        if (!currentTargetId) currentTargetId = subRes.target_id;
                        targetCreatedName = subRes.target_name || targetCreatedName;
                        targetIdentifier = subRes.target_identifier || targetIdentifier;

                        distinctTargetsMap.set(subRes.target_id, {
                            id: subRes.target_id,
                            name: subRes.target_name || `Alvo #${subRes.target_id}`,
                            identifier: subRes.target_identifier || ''
                        });
                    }

                    lastHash = subRes.sha256_hash || lastHash;

                    fileHashesList.push({
                        name: f.name,
                        hash: subRes.sha256_hash,
                        size: f.size
                    });

                    const sum = subRes.summary || {};
                    totalMessages += (sum.messages_count || 0);
                    totalCalls += (sum.calls_count || 0);
                    totalIps += (sum.ip_count || 0);
                }

                if (progressBar) progressBar.style.width = '100%';
                if (loadingMsg) loadingMsg.innerText = 'Finalizando consolidação dos lotes...';

                const targetList = Array.from(distinctTargetsMap.values());
                let finalTargetName = targetCreatedName;
                if (targetList.length > 1) {
                    finalTargetName = `${targetList.length} Alvos Identificados (${targetList.map(t => t.name).join(', ')})`;
                }

                result = {
                    status: 'success',
                    operation_id: opId,
                    phase_id: phaseId,
                    target_id: currentTargetId,
                    target_name: finalTargetName,
                    target_identifier: targetList.length > 1 ? `${targetList.length} alvos processados individualmente` : targetIdentifier,
                    file_name: `${files.length} arquivos ZIP processados`,
                    sha256_hash: lastHash,
                    file_hashes_list: fileHashesList,
                    declared_hash: declaredHash || null,
                    hash_match: declaredHash ? (lastHash.toLowerCase() === declaredHash.toLowerCase()) : null,
                    platform: platform,
                    distinct_targets: targetList,
                    summary: {
                        followers_count: 0,
                        following_count: 0,
                        ip_count: totalIps,
                        threads_count: 0,
                        messages_count: totalMessages,
                        calls_count: totalCalls
                    }
                };
            }
        }

        if (result.status === 'success') {
            // Guardar contexto para navegação direta
            lastImportedContext = {
                opId: opId,
                phaseId: phaseId,
                targetId: result.target_id,
                platform: platform
            };

            // Preencher resumo de sucesso e lista de hashes
            const hashElem = document.getElementById('import-success-hash');
            const hashTitle = document.getElementById('import-success-hash-title');
            const hashCount = document.getElementById('import-success-hash-count');
            const singleHashBox = document.getElementById('import-success-single-hash-container');
            const multiHashBox = document.getElementById('import-success-multi-hash-container');

            if (result.file_hashes_list && result.file_hashes_list.length > 1) {
                if (hashTitle) hashTitle.innerText = "Hashes Criptográficos SHA-256 (Cadeia de Custódia)";
                if (hashCount) {
                    hashCount.innerText = `${result.file_hashes_list.length} arquivos auditados`;
                    hashCount.classList.remove('hidden');
                }
                if (singleHashBox) singleHashBox.classList.add('hidden');
                if (multiHashBox) {
                    multiHashBox.classList.remove('hidden');
                    multiHashBox.innerHTML = result.file_hashes_list.map((item, idx) => `
                        <div class="p-1.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[10px] space-y-0.5 font-mono">
                            <div class="flex items-center justify-between text-slate-700 dark:text-slate-300 font-sans font-bold">
                                <span class="truncate">📦 Lote ${idx + 1}: ${escapeHtml(item.name)}</span>
                                <span class="text-slate-400 font-normal text-[9px]">${formatFileSize(item.size)}</span>
                            </div>
                            <div class="text-blue-600 dark:text-cyan-400 break-all select-all font-mono">${item.hash}</div>
                        </div>
                    `).join('');
                }
            } else {
                if (hashTitle) hashTitle.innerText = "Hash Criptográfico SHA-256 Calculado (Ingestão)";
                if (hashCount) hashCount.classList.add('hidden');
                if (singleHashBox) singleHashBox.classList.remove('hidden');
                if (multiHashBox) multiHashBox.classList.add('hidden');
                if (hashElem) hashElem.innerText = result.sha256_hash || 'Hash registrado com sucesso';
            }
            const targetElem = document.getElementById('import-success-target');
            const relElem = document.getElementById('import-success-rel');
            const dmsElem = document.getElementById('import-success-dms');
            const ipsElem = document.getElementById('import-success-ips');
            const matchBox = document.getElementById('import-success-hash-match-box');

            if (hashElem) hashElem.innerText = result.sha256_hash || 'Hash registrado com sucesso';
            
            // Diagnóstico Pericial de Origem
            if (matchBox) {
                if (result.hash_match === true) {
                    matchBox.className = "p-3 rounded-xl border bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs space-y-1";
                    matchBox.innerHTML = `
                        <div class="flex items-center space-x-2 font-bold text-emerald-700 dark:text-emerald-300">
                            <i data-lucide="shield-check" class="w-4 h-4 text-emerald-500"></i>
                            <span>Autenticidade de Origem Confirmada (100% Match)</span>
                        </div>
                        <p class="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">O Hash do arquivo baixado coincide perfeitamente com o Hash declarado pelo portal Meta LERS / Provedor.</p>
                        <div class="font-mono text-[10px] text-emerald-700 dark:text-emerald-300 pt-0.5 truncate select-all">Portal: ${escapeHtml(result.declared_hash)}</div>
                    `;
                } else if (result.hash_match === false) {
                    matchBox.className = "p-3 rounded-xl border bg-red-50 dark:bg-red-950/30 border-red-300 dark:border-red-800 text-red-800 dark:text-red-200 text-xs space-y-1 animate-pulse";
                    matchBox.innerHTML = `
                        <div class="flex items-center space-x-2 font-bold text-red-700 dark:text-red-300">
                            <i data-lucide="alert-triangle" class="w-4 h-4 text-red-500"></i>
                            <span>Alerta: Divergência de Hash!</span>
                        </div>
                        <p class="text-[11px] text-red-600 dark:text-red-400 font-medium">O Hash do arquivo baixado NÃO coincide com o Hash informado pelo portal. O arquivo pode ter sido corrompido durante o download.</p>
                        <div class="font-mono text-[10px] text-red-700 dark:text-red-300 pt-0.5">Informado: ${escapeHtml(result.declared_hash || '')}</div>
                    `;
                } else {
                    matchBox.className = "p-3 rounded-xl border bg-slate-50 dark:bg-slate-950/60 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 text-xs space-y-1";
                    matchBox.innerHTML = `
                        <div class="flex items-center space-x-2 font-bold text-slate-800 dark:text-slate-200">
                            <i data-lucide="shield" class="w-4 h-4 text-indigo-500"></i>
                            <span>Integridade Local Registrada</span>
                        </div>
                        <p class="text-[11px] text-slate-500 dark:text-slate-400">Hash criptográfico gerado e vinculado à cadeia de custódia. Você pode informar o Hash do portal posteriormente no painel de Custódia.</p>
                    `;
                }
            }
            
            let targetLabel = result.target_name || 'Investigado';
            if (result.target_identifier) {
                targetLabel += ` (${result.target_identifier})`;
            }
            if (targetElem) targetElem.innerText = targetLabel;

            const s = result.summary || {};
            if (platform === 'whatsapp') {
                if (relElem) relElem.innerText = `Bilhetagem & CDRs (Interceptação Telefônica)`;
                if (dmsElem) dmsElem.innerText = `${(s.messages_count || 0).toLocaleString()} mensagens interceptadas • ${(s.calls_count || 0).toLocaleString()} chamadas`;
                if (ipsElem) ipsElem.innerText = `${(s.ip_count || 0).toLocaleString()} conexões de IP registradas`;
            } else {
                const totalRel = (s.followers_count || 0) + (s.following_count || 0);
                if (relElem) relElem.innerText = `${totalRel.toLocaleString()} vínculos (${s.followers_count || 0} seg. / ${s.following_count || 0} seguidos)`;
                const totalMsgs = s.messages_count || 0;
                if (dmsElem) dmsElem.innerText = `${s.threads_count || 0} conversas (${totalMsgs.toLocaleString()} mensagens)`;
                if (ipsElem) ipsElem.innerText = `${s.ip_count || 0} conexões registradas`;
            }

            // Mudar para o estado de sucesso
            setImportState('success');
            lucide.createIcons();

        } else {
            setImportState('form');
            alert("Erro no processamento da evidência: " + (result.detail || "Falha ao processar arquivo."));
        }
    } catch (err) {
        setImportState('form');
        alert("Erro na requisição: " + err.message);
    }
}

async function goToImportedTarget() {
    if (!lastImportedContext) {
        closeImportModal();
        return;
    }

    const { opId, phaseId, targetId, platform } = lastImportedContext;
    closeImportModal();

    currentOpId = opId;
    currentPhaseId = phaseId;
    currentTargetId = targetId;

    await loadOperations();
    await selectOperation(currentOpId);
    if (platform === 'whatsapp') {
        switchTab('whatsapp');
        setTimeout(() => {
            if (typeof switchWaSubTab === 'function') switchWaSubTab('cdr');
        }, 150);
    } else {
        switchTab(platform || 'instagram');
    }
}

function exportToExcel() {
    if (!currentOpId) return alert("Selecione uma operação para exportar.");
    const url = `/api/export/excel?operation_id=${currentOpId}${currentPhaseId ? '&phase_id=' + currentPhaseId : ''}`;
    window.location.href = url;
}

/**
 * Alterna a visualização do Card Guia Pericial de Dispositivos (Minimizar / Expandir)
 */
function toggleDeviceGuideCard() {
    const body = document.getElementById('guide-devices-body');
    const subtitle = document.getElementById('guide-devices-subtitle');
    const textToggle = document.getElementById('text-toggle-guide-devices');
    const iconToggle = document.getElementById('icon-toggle-guide-devices');
    if (!body) return;

    const isHidden = body.classList.contains('hidden');
    if (isHidden) {
        body.classList.remove('hidden');
        if (subtitle) subtitle.classList.add('hidden');
        if (textToggle) textToggle.innerText = 'Minimizar';
        if (iconToggle) iconToggle.setAttribute('data-lucide', 'chevron-up');
        localStorage.setItem('meta_analise_device_guide_collapsed', 'false');
    } else {
        body.classList.add('hidden');
        if (subtitle) subtitle.classList.remove('hidden');
        if (textToggle) textToggle.innerText = 'Expandir';
        if (iconToggle) iconToggle.setAttribute('data-lucide', 'chevron-down');
        localStorage.setItem('meta_analise_device_guide_collapsed', 'true');
    }
    if (window.lucide) lucide.createIcons();
}

function initDeviceGuideCard() {
    if (localStorage.getItem('meta_analise_device_guide_collapsed') === 'true') {
        const body = document.getElementById('guide-devices-body');
        const subtitle = document.getElementById('guide-devices-subtitle');
        const textToggle = document.getElementById('text-toggle-guide-devices');
        const iconToggle = document.getElementById('icon-toggle-guide-devices');
        if (body) body.classList.add('hidden');
        if (subtitle) subtitle.classList.remove('hidden');
        if (textToggle) textToggle.innerText = 'Expandir';
        if (iconToggle) iconToggle.setAttribute('data-lucide', 'chevron-down');
    }
}

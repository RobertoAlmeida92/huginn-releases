import socket
import uvicorn
import webbrowser
import threading
import time
import sys
import os

def is_port_available(port: int) -> bool:
    # 1. Tentar conectar: se responder, significa que outro programa está escutando na porta
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.2)
            if s.connect_ex(('127.0.0.1', port)) == 0:
                return False
    except Exception:
        pass

    # 2. Tentar bind em todas as interfaces
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('0.0.0.0', port))
            return True
    except OSError:
        return False

def find_available_port(start_port: int = 8000, max_attempts: int = 20) -> int:
    for p in range(start_port, start_port + max_attempts):
        if is_port_available(p):
            return p
    return start_port

import subprocess

def open_desktop_window(port: int):
    time.sleep(1.2)
    url = f"http://127.0.0.1:{port}"
    print(f"\n[HUGINN] Abrindo Janela Própria de Aplicativo em: {url}")

    # 1. Modo Janela Própria de Aplicativo (Edge ou Chrome no modo --app)
    # Abre uma janela de desktop limpa, sem barra de endereços e sem abas
    edge_paths = [
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%LocalAppData%\Microsoft\Edge\Application\msedge.exe"),
    ]
    chrome_paths = [
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
    ]

    for browser_exe in edge_paths + chrome_paths:
        if os.path.exists(browser_exe):
            try:
                subprocess.Popen([
                    browser_exe,
                    f"--app={url}",
                    "--window-size=1440,900",
                    "--start-maximized"
                ])
                print("   [*] Janela Desktop iniciada com sucesso (modo nativo)!")
                return
            except Exception:
                pass

    # 2. Fallback convencional se não houver Edge/Chrome
    webbrowser.open(url)

def main():
    print("=" * 65)
    print("  HUGINN — PLATAFORMA DE INTELIGÊNCIA & ANÁLISE TELEMÁTICA")
    print("  Digital Investigation & Police Intelligence System")
    print("=" * 65)

    port = find_available_port(start_port=8000)
    if port != 8000:
        print(f"[!] AVISO: A porta 8000 está ocupada por outra aplicação.")
        print(f"[*] Redirecionando automaticamente para a porta livre: {port}")
    else:
        print(f"[*] Iniciando servidor local offline na porta {port}...")

    # Thread para abrir a janela própria de aplicativo automaticamente
    threading.Thread(target=open_desktop_window, args=(port,), daemon=True).start()

    # Executar servidor FastAPI
    uvicorn.run(
        "backend.main:app",
        host="127.0.0.1",
        port=port,
        log_level="info",
        reload=False
    )

if __name__ == "__main__":
    main()

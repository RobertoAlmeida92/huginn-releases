import os
import sys
import time
import socket
import threading
import subprocess
import webbrowser
import uvicorn

# Adiciona o diretorio base ao sys.path para importacoes
if getattr(sys, 'frozen', False):
    app_base = os.path.dirname(sys.executable)
    if hasattr(sys, '_MEIPASS'):
        sys.path.insert(0, sys._MEIPASS)
else:
    app_base = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, app_base)

def is_port_available(port: int) -> bool:
    # 1. Tentar conectar: se responder, significa que outro programa esta escutando na porta
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.2)
            if s.connect_ex(('127.0.0.1', port)) == 0:
                return False
    except Exception:
        pass

    # 2. Tentar bind em todas as interfaces
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('0.0.0.0', port))
            return True
    except OSError:
        return False

def find_available_port(start_port: int = 8000, max_attempts: int = 20) -> int:
    for p in range(start_port, start_port + max_attempts):
        if is_port_available(p):
            return p
    return start_port

def open_desktop_window(port: int):
    """
    Abre o Huginn em uma Janela Própria de Aplicativo (Desktop Window),
    eliminando abas, barra de endereços (URL) e cache persistente do navegador comum.
    """
    time.sleep(1.2)
    url = f'http://127.0.0.1:{port}'

    # 1. Tentar abrir em Janela Própria de Aplicativo (Edge ou Chrome no modo --app)
    edge_paths = [
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%LocalAppData%\Microsoft\Edge\Application\msedge.exe"),
    ]
    chrome_paths = [
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
    ]

    for browser_exe in edge_paths + chrome_paths:
        if os.path.exists(browser_exe):
            try:
                subprocess.Popen([
                    browser_exe,
                    f"--app={url}",
                    "--window-size=1440,900",
                    "--start-maximized"
                ])
                print("   [*] Janela Própria de Aplicativo iniciada com sucesso!")
                return
            except Exception:
                pass

    # 2. Fallback caso não localize os binários Chromium
    try:
        webbrowser.open(url)
    except Exception as e:
        print('Erro ao abrir janela do aplicativo:', e)

if __name__ == '__main__':
    from backend.config import UPLOAD_DIR, MEDIA_BASE_DIR, DB_PATH
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs(MEDIA_BASE_DIR, exist_ok=True)

    port = find_available_port(start_port=8000)

    print('='*65)
    print('   HUGINN — Plataforma de Inteligência & Análise Telemática')
    print('   Servidor ativo e disponível!')
    if port != 8000:
        print(f'   [AVISO] Porta 8000 ocupada por outra aplicacao.')
        print(f'   [*] Redirecionado automaticamente para a porta livre: {port}')
    print(f'   -> Acesso Local:  http://127.0.0.1:{port}')
    print(f'   -> Banco de dados: {DB_PATH}')
    print('   Pressione Ctrl+C na janela para encerrar.')
    print('='*65)

    # Abre a janela própria de aplicativo automaticamente
    threading.Thread(target=open_desktop_window, args=(port,), daemon=True).start()

    from backend.main import app
    uvicorn.run(app, host='0.0.0.0', port=port, log_level='info')

let currentIgPage = 1;
let currentIgLimit = 50;
let currentIgRelFilter = 'follower';
let currentIgSearch = '';
let currentActiveIgSubTab = 'overview';
let currentSelectedThreadId = null;
let currentSelectedParticipant = null;
let currentSelectedAccountUid = null;
let currentDmAccountFilterUid = null;
let dmAnnotations = {};
let evidenceTagsMap = {};
let currentDmFilter = 'all'; // 'all', 'unread', 'read', 'starred'
let currentDmSort = 'recent'; // 'recent', 'count', 'alphabetical'
let currentDmStartDate = '';
let currentDmEndDate = '';
let cachedDmThreads = [];
let cachedAvatarsMap = {};
let avatarSyncInterval = null;

// ==================== HELPER DE LINK DO INSTAGRAM & UID ====================
function getIgProfileUrl(username) {
    if (!username) return '#';
    const clean = username.replace(/^@/, '').trim();
    if (!clean || clean === '---' || clean === 'não_informado' || clean === 'alvo') return '#';
    return `https://www.instagram.com/${encodeURIComponent(clean)}/`;
}

function getIgUidUrl(uid) {
    if (!uid) return '#';
    const clean = String(uid).trim();
    if (!clean || clean === '---' || clean === 'N/A') return '#';
    return `https://www.instagram.com/uid/${encodeURIComponent(clean)}`;
}

// Cores determinísticas e atraentes para iniciais
function getAvatarColorPair(str) {
    const palette = [
        { bg: 'bg-indigo-500/15', text: 'text-indigo-600 dark:text-indigo-400', border: 'border-indigo-500/30' },
        { bg: 'bg-purple-500/15', text: 'text-purple-600 dark:text-purple-400', border: 'border-purple-500/30' },
        { bg: 'bg-pink-500/15', text: 'text-pink-600 dark:text-pink-400', border: 'border-pink-500/30' },
        { bg: 'bg-emerald-500/15', text: 'text-emerald-600 dark:text-emerald-400', border: 'border-emerald-500/30' },
        { bg: 'bg-cyan-500/15', text: 'text-cyan-600 dark:text-cyan-400', border: 'border-cyan-500/30' },
        { bg: 'bg-amber-500/15', text: 'text-amber-600 dark:text-amber-400', border: 'border-amber-500/30' },
        { bg: 'bg-rose-500/15', text: 'text-rose-600 dark:text-rose-400', border: 'border-rose-500/30' },
        { bg: 'bg-teal-500/15', text: 'text-teal-600 dark:text-teal-400', border: 'border-teal-500/30' }
    ];
    let hash = 0;
    const s = String(str || 'user');
    for (let i = 0; i < s.length; i++) {
        hash = s.charCodeAt(i) + ((hash << 5) - hash);
    }
    const idx = Math.abs(hash) % palette.length;
    return palette[idx];
}

function formatChatDayHeader(dateStr) {
    if (!dateStr) return '';
    let d = null;
    if (dateStr.includes('/')) {
        const rawDate = dateStr.split(' ')[0];
        const parts = rawDate.split('/');
        if (parts.length === 3) {
            d = new Date(parseInt(parts[2], 10), parseInt(parts[1], 10) - 1, parseInt(parts[0], 10));
        }
    } else if (dateStr.includes('-')) {
        const rawDate = dateStr.split(' ')[0];
        const parts = rawDate.split('-');
        if (parts.length === 3) {
            d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
        }
    }

    if (!d || isNaN(d.getTime())) return dateStr.split(' ')[0];

    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    const isToday = d.toDateString() === today.toDateString();
    const isYesterday = d.toDateString() === yesterday.toDateString();

    if (isToday) return 'Hoje';
    if (isYesterday) return 'Ontem';

    const day = String(d.getDate()).padStart(2, '0');
    const months = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    const month = months[d.getMonth()];
    const year = d.getFullYear();

    const weekDays = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
    const weekDay = weekDays[d.getDay()];

    return `${weekDay}, ${day} de ${month} de ${year}`;
}

function getAvatarInitials(nameOrHandle) {
    if (!nameOrHandle) return 'IG';
    const clean = nameOrHandle.replace(/^@/, '').trim();
    if (clean.length <= 2) return clean.toUpperCase();
    const parts = clean.split(/[._\s-]+/).filter(Boolean);
    if (parts.length >= 2) {
        return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return clean.slice(0, 2).toUpperCase();
}

function getCachedAvatarSrc(userOrId) {
    if (!userOrId) return null;
    const clean = String(userOrId).replace(/^@/, '').toLowerCase().trim();
    return cachedAvatarsMap[clean] || null;
}

function renderAvatarHtml(username, userId = null, sizeClass = 'w-8 h-8', textSize = 'text-xs') {
    const cleanUser = (username || '').replace(/^@/, '').trim();
    const cleanId = userId ? String(userId).trim() : '';
    const avatarUrl = getCachedAvatarSrc(cleanUser) || getCachedAvatarSrc(cleanId);
    const initials = getAvatarInitials(cleanUser || cleanId || 'U');
    const color = getAvatarColorPair(cleanUser || cleanId || 'U');

    if (avatarUrl) {
        return `
            <div data-avatar-slot="true" data-avatar-user="${escapeHtml(cleanUser)}" data-avatar-id="${escapeHtml(cleanId)}" class="${sizeClass} rounded-full overflow-hidden flex-shrink-0 shadow-xs border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 flex items-center justify-center cursor-pointer hover:opacity-90 hover:scale-105 transition" onclick="event.stopPropagation(); openAvatarInViewer('${avatarUrl}', '${escapeHtml(cleanUser || cleanId)}')" title="Clique para ampliar a foto do perfil em alta resolução (@${escapeHtml(cleanUser || cleanId)})">
                <img src="${avatarUrl}" alt="${escapeHtml(cleanUser)}" class="w-full h-full object-cover pointer-events-none" onerror="this.parentElement.innerHTML='<div class=\\'w-full h-full flex items-center justify-center font-bold ${color.bg} ${color.text} ${textSize}\\'>${initials}</div>'">
            </div>
        `;
    }

    return `
        <div data-avatar-slot="true" data-avatar-user="${escapeHtml(cleanUser)}" data-avatar-id="${escapeHtml(cleanId)}" class="${sizeClass} rounded-full flex-shrink-0 shadow-xs border ${color.border} ${color.bg} flex items-center justify-center font-bold ${color.text} ${textSize}" title="${escapeHtml(cleanUser || cleanId)}">
            ${initials}
        </div>
    `;
}

/**
 * Abre a foto de perfil em alta resolução no visualizador forense (Lightbox)
 * com suporte a Super Zoom (2500%), Presets (2x..25x), Rotação 90° (tecla R) e Pan.
 */
function openAvatarInViewer(imgSrc, username = '') {
    if (!imgSrc || imgSrc.includes('data:image/svg')) return;
    const cleanSrc = imgSrc.split('?')[0];
    const cleanHandle = username ? username.replace(/^@/, '').trim() : '';
    const title = cleanHandle ? `Foto de Perfil: @${cleanHandle}` : 'Foto de Perfil em Alta Resolução';
    openMediaViewer(cleanSrc, 'image', title, [{ url: cleanSrc, type: 'image', sender: title }]);
}

function openTargetAvatarZoom() {
    const img = document.getElementById('ig-target-avatar-img');
    if (img && img.src && !img.classList.contains('hidden')) {
        openAvatarInViewer(img.src, window.currentTargetVanity || 'Alvo Investigado');
    }
}

function openHeaderAvatarZoom() {
    const img = document.getElementById('dm-header-avatar-img');
    if (img && img.src && !img.classList.contains('hidden')) {
        openAvatarInViewer(img.src, window.currentSelectedInterlocutor || 'Perfil');
    }
}

/**
 * Atualiza todos os avatares visíveis na interface instantaneamente sem recarregar a página
 */
function updateVisibleAvatarsInDom() {
    // 1. Atualizar todos os slots de avatares nas mensagens e itens visíveis
    document.querySelectorAll('[data-avatar-slot="true"]').forEach(el => {
        const u = el.getAttribute('data-avatar-user');
        const uid = el.getAttribute('data-avatar-id');
        const src = getCachedAvatarSrc(u) || getCachedAvatarSrc(uid);
        if (src) {
            el.classList.add('cursor-pointer', 'hover:opacity-90', 'hover:scale-105', 'transition');
            el.onclick = (e) => { e.stopPropagation(); openAvatarInViewer(src, u || uid); };
            el.title = `Clique para ampliar a foto do perfil em alta resolução (@${u || uid})`;
            const existingImg = el.querySelector('img');
            if (existingImg) {
                if (!existingImg.src.includes(src)) {
                    existingImg.src = src;
                }
            } else {
                el.className = el.className.replace(/bg-[a-z0-9\/-]+/g, '').replace(/border-[a-z0-9\/-]+/g, '');
                el.classList.add('overflow-hidden', 'bg-slate-100', 'dark:bg-slate-800', 'border', 'border-slate-200', 'dark:border-slate-700');
                el.innerHTML = `<img src="${src}" class="w-full h-full object-cover pointer-events-none" alt="avatar">`;
            }
        }
    });

    // 2. Atualizar avatar do cabeçalho da DM aberta
    if (window.currentSelectedInterlocutor) {
        const hImg = document.getElementById('dm-header-avatar-img');
        const hFb = document.getElementById('dm-header-avatar-fallback');
        const src = getCachedAvatarSrc(window.currentSelectedInterlocutor);
        if (src && hImg && hFb) {
            hImg.src = src;
            hImg.classList.remove('hidden');
            hFb.classList.add('hidden');
        }
    }

    // 3. Atualizar avatar do alvo no topo
    if (window.currentTargetVanity || window.currentTargetUid) {
        const tImg = document.getElementById('ig-target-avatar-img');
        const tFb = document.getElementById('ig-target-avatar-fallback');
        const src = getCachedAvatarSrc(window.currentTargetVanity) || getCachedAvatarSrc(window.currentTargetUid);
        if (src && tImg && tFb) {
            tImg.src = `${src}?t=${Date.now()}`;
            tImg.classList.remove('hidden');
            tFb.classList.add('hidden');
        }
    }
}

// ==================== VELOCIDADE GLOBAL E REPRODUÇÃO CONTÍNUA DE ÁUDIO ====================

window.globalAudioPlaybackRate = parseFloat(localStorage.getItem('meta_analise_audio_speed') || '1.0');
if (isNaN(window.globalAudioPlaybackRate) || window.globalAudioPlaybackRate <= 0) {
    window.globalAudioPlaybackRate = 1.0;
}

function getGlobalAudioSpeedLabel() {
    const s = window.globalAudioPlaybackRate || 1.0;
    if (Math.abs(s - 1.0) < 0.01) return '1.0x';
    if (Math.abs(s - 1.25) < 0.01) return '1.25x';
    if (Math.abs(s - 1.5) < 0.01) return '1.5x';
    if (Math.abs(s - 2.0) < 0.01) return '2.0x';
    return `${s}x`;
}

function setGlobalAudioSpeed(newSpeed) {
    const speed = parseFloat(newSpeed) || 1.0;
    window.globalAudioPlaybackRate = speed;
    try {
        localStorage.setItem('meta_analise_audio_speed', String(speed));
    } catch (e) {}

    // 1. Atualiza a velocidade de reprodução de todos os elementos <audio> no DOM
    const allAudios = document.querySelectorAll('audio');
    allAudios.forEach(a => {
        try {
            a.playbackRate = speed;
        } catch (e) {}
    });

    // 2. Atualiza o texto de todos os botões de velocidade visíveis
    const label = getGlobalAudioSpeedLabel();
    const speedButtons = document.querySelectorAll('.btn-audio-speed');
    speedButtons.forEach(btn => {
        const span = btn.querySelector('span');
        if (span) {
            span.innerText = label;
        } else {
            btn.innerText = label;
        }
    });
}

function cycleGlobalAudioSpeed(btn) {
    const speeds = [1.0, 1.25, 1.5, 2.0];
    const current = window.globalAudioPlaybackRate || 1.0;
    let nextIdx = 0;
    for (let i = 0; i < speeds.length; i++) {
        if (Math.abs(speeds[i] - current) < 0.05) {
            nextIdx = (i + 1) % speeds.length;
            break;
        }
    }
    const newSpeed = speeds[nextIdx];
    setGlobalAudioSpeed(newSpeed);
}

function toggleAudioSpeed(audioId, btn) {
    cycleGlobalAudioSpeed(btn);
}

// ==================== EFEITO SONORO FORENSE DE TRANSIÇÃO (AUTOPLAY) ====================
function playAutoplayTransitionSound() {
    try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        if (!window._forensicAudioCtx) {
            window._forensicAudioCtx = new AudioCtx();
        }
        const ctx = window._forensicAudioCtx;
        if (ctx.state === 'suspended') {
            ctx.resume();
        }

        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        // Opção 1: Gota Minimalista (Pop Suave) - Rápido, orgânico e sem fadiga auditiva
        // Frequência sobe suavemente de 800Hz para 1300Hz em 50ms, com decaimento exponencial de 70ms e volume sutil (0.07)
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(1300, now + 0.05);

        gain.gain.setValueAtTime(0.07, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + 0.07);
    } catch (e) {
        console.warn("[MetaAnalise Audio] Falha ao sintetizar som de transição:", e);
    }
}
window.playAutoplayTransitionSound = playAutoplayTransitionSound;

function attachChatContinuousAudio() {
    const chatContainer = document.getElementById('dm-messages-container');
    if (!chatContainer) return;
    const audios = Array.from(chatContainer.querySelectorAll('audio'));

    audios.forEach((audio) => {
        try {
            audio.playbackRate = window.globalAudioPlaybackRate || 1.0;
        } catch (e) {}

        audio.onplay = () => {
            // Pausa outros áudios para nunca sobrepor reproduções
            document.querySelectorAll('audio').forEach(other => {
                if (other !== audio && !other.paused) {
                    other.pause();
                }
            });

            // Aplica a taxa de velocidade global
            try {
                audio.playbackRate = window.globalAudioPlaybackRate || 1.0;
            } catch (e) {}

            // Destaca a mensagem do chat que está tocando
            document.querySelectorAll('#dm-messages-container .audio-playing-highlight').forEach(el => {
                el.classList.remove('audio-playing-highlight');
            });
            const msgRow = audio.closest('.group\\/msg') || audio.closest('[id^="msg-"]') || audio.parentElement;
            if (msgRow) {
                msgRow.classList.add('audio-playing-highlight');
            }
        };

        audio.onpause = () => {
            const msgRow = audio.closest('.group\\/msg') || audio.closest('[id^="msg-"]') || audio.parentElement;
            if (msgRow && audio.paused && !audio.ended) {
                msgRow.classList.remove('audio-playing-highlight');
            }
        };

        audio.onended = () => {
            const msgRow = audio.closest('[id^="msg-"]');
            if (msgRow) {
                msgRow.classList.remove('audio-playing-highlight');
            }

            if (!msgRow) return;

            // Busca todas as linhas de mensagens cronológicas no container do chat
            const allMsgRows = Array.from(chatContainer.querySelectorAll('[id^="msg-"]'));
            const currentIdx = allMsgRows.indexOf(msgRow);

            // Verifica se existe uma mensagem imediatamente subsequente
            if (currentIdx !== -1 && currentIdx + 1 < allMsgRows.length) {
                const nextMsgRow = allMsgRows[currentIdx + 1];
                const nextAudio = nextMsgRow.querySelector('audio');

                // Toca o próximo APENAS se a mensagem seguinte imediata for áudio!
                if (nextAudio) {
                    nextMsgRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    try {
                        nextAudio.playbackRate = window.globalAudioPlaybackRate || 1.0;
                    } catch (e) {}

                    // Efeito sonoro de transição rápida e sutil (Opção 1: Gota Minimalista)
                    playAutoplayTransitionSound();

                    setTimeout(() => {
                        nextAudio.play().catch(err => console.warn("Autoplay bloqueado pelo navegador:", err));
                    }, 280);
                } else {
                    // Se a próxima mensagem for texto, foto, vídeo, etc., PARA imediatamente
                    console.log("[Audio Chat] A próxima mensagem não é áudio. Reprodução sequencial pausada.");
                }
            }
        };
    });
}

function attachGalleryContinuousAudio() {
    const grid = document.getElementById('ig-media-grid');
    if (!grid) return;
    const audios = Array.from(grid.querySelectorAll('audio'));

    audios.forEach((audio) => {
        try {
            audio.playbackRate = window.globalAudioPlaybackRate || 1.0;
        } catch (e) {}

        audio.onplay = () => {
            document.querySelectorAll('audio').forEach(other => {
                if (other !== audio && !other.paused) {
                    other.pause();
                }
            });

            try {
                audio.playbackRate = window.globalAudioPlaybackRate || 1.0;
            } catch (e) {}

            document.querySelectorAll('#ig-media-grid .audio-playing-highlight').forEach(el => {
                el.classList.remove('audio-playing-highlight');
            });
            const card = audio.closest('.group\\/mcard, div.bg-white, div.dark\\:bg-slate-900') || audio.parentElement;
            if (card) {
                card.classList.add('audio-playing-highlight');
            }
        };

        audio.onpause = () => {
            const card = audio.closest('.group\\/mcard, div.bg-white, div.dark\\:bg-slate-900') || audio.parentElement;
            if (card && audio.paused && !audio.ended) {
                card.classList.remove('audio-playing-highlight');
            }
        };

        audio.onended = () => {
            const card = audio.closest('.group\\/mcard, div.bg-white, div.dark\\:bg-slate-900') || audio.parentElement;
            if (card) {
                card.classList.remove('audio-playing-highlight');
            }

            const currentAudios = Array.from(grid.querySelectorAll('audio'));
            const currentIdx = currentAudios.indexOf(audio);
            if (currentIdx !== -1 && currentIdx + 1 < currentAudios.length) {
                const nextAudio = currentAudios[currentIdx + 1];
                const nextCard = nextAudio.closest('.group\\/mcard, div.bg-white, div.dark\\:bg-slate-900') || nextAudio.parentElement;
                if (nextCard) {
                    nextCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                try {
                    nextAudio.playbackRate = window.globalAudioPlaybackRate || 1.0;
                } catch (e) {}

                // Efeito sonoro de transição rápida e sutil (Opção 1: Gota Minimalista)
                playAutoplayTransitionSound();

                setTimeout(() => {
                    nextAudio.play().catch(err => console.warn("Autoplay bloqueado pelo navegador:", err));
                }, 280);
            }
        };
    });
}

async function loadCachedAvatarsMap() {
    try {
        let url = '/api/instagram/avatars/map';
        if (window.currentTargetId) {
            url += `?target_id=${window.currentTargetId}`;
        }
        const res = await fetch(url);
        if (res.ok) {
            cachedAvatarsMap = await res.json();
        }
    } catch (e) {
        console.warn("Erro ao carregar mapa de avatares:", e);
    }
}

let currentDmSearchQuery = '';

function highlightSearchTerms(htmlText, query) {
    if (!htmlText || !query) return htmlText;
    const terms = query.replace(/[,;]/g, ' ').split(/\s+/).map(t => t.trim()).filter(t => t.length >= 1);
    if (terms.length === 0) return htmlText;

    let result = htmlText;
    terms.forEach(term => {
        const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(`(?<!<[^>]*)(${escaped})(?![^<]*>)`, 'gi');
        result = result.replace(regex, '<mark class="bg-amber-300 dark:bg-amber-500/40 text-slate-900 dark:text-white px-0.5 rounded font-bold shadow-2xs">$1</mark>');
    });
    return result;
}

function formatMessageContentWithLinks(rawContent, isTarget = false) {
    if (!rawContent) return '';

    // 0. Limpeza de metadados residuais Author/Sent/Body se houver
    if (rawContent.includes('Author |') || rawContent.includes('Body |')) {
        const bodyMatch = rawContent.match(/Body\s*\|\s*(.*)/i);
        if (bodyMatch) {
            rawContent = bodyMatch[1].trim();
        } else {
            rawContent = rawContent.replace(/Author\s*\|.*?\|\s*Sent\s*\|.*?(?:\|\s*)?/gi, '').trim();
        }
    }

    // 1. Detecção de Chamada de Áudio / Vídeo
    if (rawContent.startsWith('📞') || rawContent.startsWith('🎥') || rawContent.includes('Call Record')) {
        const isMissed = rawContent.includes('Perdida') || /Missed\s*\|\s*true/i.test(rawContent);
        const isVideo = rawContent.startsWith('🎥') || /video/i.test(rawContent);
        const iconName = isVideo ? 'video' : (isMissed ? 'phone-missed' : 'phone-call');
        const badgeColor = isMissed
            ? (isTarget ? 'bg-red-500/30 text-white border-red-300/40' : 'bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/25')
            : (isTarget ? 'bg-emerald-500/30 text-white border-emerald-300/40' : 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/25');

        return `
            <div class="flex items-center space-x-2 py-1.5 px-2.5 rounded-xl border ${badgeColor} font-semibold text-xs my-1 shadow-2xs">
                <i data-lucide="${iconName}" class="w-4 h-4 flex-shrink-0"></i>
                <span>${escapeHtml(rawContent)}</span>
            </div>
        `;
    }

    // 2. Detecção de Registro de Evento, Figurinha ou Reação
    if (rawContent.startsWith('ℹ️') || rawContent.startsWith('🏷️') || rawContent.startsWith('❤️')) {
        return `
            <div class="flex items-center space-x-1.5 py-1 px-2 rounded-lg ${isTarget ? 'bg-white/10 text-pink-100' : 'bg-slate-100 dark:bg-slate-900/60 text-slate-600 dark:text-slate-400'} text-[11px] font-medium my-0.5 border ${isTarget ? 'border-white/15' : 'border-slate-200 dark:border-slate-800'}">
                <span>${escapeHtml(rawContent)}</span>
            </div>
        `;
    }

    if (rawContent.includes('[Mídia / Anexo temporário expirado]') || rawContent.includes('Anexo temporário expirado')) {
        return `
            <div class="flex items-center space-x-1.5 py-1 px-2 rounded-lg ${isTarget ? 'bg-white/10 text-pink-100' : 'bg-slate-100 dark:bg-slate-900/60 text-slate-600 dark:text-slate-400'} text-[11px] italic font-medium my-0.5 border ${isTarget ? 'border-white/15' : 'border-slate-200 dark:border-slate-800'}">
                <i data-lucide="clock" class="w-3.5 h-3.5 text-amber-500 flex-shrink-0"></i>
                <span>Mídia / Anexo temporário expirado</span>
            </div>
        `;
    }

    // 3. Detecção visual de anexo / compartilhamento do Instagram
    if (rawContent.toLowerCase().includes('sent an attachment') || rawContent.startsWith('📎') || rawContent.startsWith('🔗')) {
        let cleanTxt = rawContent.replace(/^[📎🔗\uFFFD\?]+\s*/, '').replace(/[\uFFFD]/g, '').trim();
        const storyMatch = cleanTxt.match(/(https?:\/\/(?:www\.)?instagram\.com\/stories\/([a-zA-Z0-9_.-]+)\/?[^\s<]*)/i);
        const postMatch = cleanTxt.match(/(https?:\/\/(?:www\.)?instagram\.com\/p\/([a-zA-Z0-9_-]+)\/?[^\s<]*)/i);
        const reelMatch = cleanTxt.match(/(https?:\/\/(?:www\.)?instagram\.com\/reel\/([a-zA-Z0-9_-]+)\/?[^\s<]*)/i);

        let extraLinkHtml = '';
        if (storyMatch) {
            cleanTxt = cleanTxt.replace(storyMatch[1], '').trim();
            extraLinkHtml = `<a href="${storyMatch[1]}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center space-x-1.5 font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/25 px-2.5 py-1 rounded-lg text-xs transition shadow-xs mt-1" title="Abrir Story Compartilhado"><i data-lucide="sparkles" class="w-3.5 h-3.5"></i><span>Story de @${storyMatch[2]} ↗</span></a>`;
        } else if (postMatch) {
            cleanTxt = cleanTxt.replace(postMatch[1], '').trim();
            extraLinkHtml = `<a href="${postMatch[1]}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center space-x-1.5 font-bold text-purple-600 dark:text-purple-400 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/25 px-2.5 py-1 rounded-lg text-xs transition shadow-xs mt-1" title="Abrir Publicação Compartilhada"><i data-lucide="camera" class="w-3.5 h-3.5"></i><span>Post Instagram (${postMatch[2]}) ↗</span></a>`;
        } else if (reelMatch) {
            cleanTxt = cleanTxt.replace(reelMatch[1], '').trim();
            extraLinkHtml = `<a href="${reelMatch[1]}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center space-x-1.5 font-bold text-pink-600 dark:text-pink-400 bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/25 px-2.5 py-1 rounded-lg text-xs transition shadow-xs mt-1" title="Abrir Reel Compartilhado"><i data-lucide="video" class="w-3.5 h-3.5"></i><span>Reel Instagram (${reelMatch[2]}) ↗</span></a>`;
        } else {
            const genericUrlMatch = cleanTxt.match(/(https?:\/\/[^\s<]+)/i);
            if (genericUrlMatch) {
                cleanTxt = cleanTxt.replace(genericUrlMatch[1], '').trim();
                extraLinkHtml = `<a href="${genericUrlMatch[1]}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center space-x-1.5 font-bold text-cyan-600 dark:text-cyan-400 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/25 px-2.5 py-1 rounded-lg text-xs transition shadow-xs mt-1 break-all" title="Abrir link compartilhado"><i data-lucide="external-link" class="w-3.5 h-3.5"></i><span>Abrir Link ↗</span></a>`;
            }
        }

        cleanTxt = cleanTxt.replace(/[\uFFFD]/g, '').trim();

        return `
            <div class="space-y-1 my-0.5">
                <div class="inline-flex items-center space-x-2 px-2.5 py-1.5 rounded-xl ${isTarget ? 'bg-white/10 text-white border-white/20' : 'bg-slate-500/10 dark:bg-slate-800/60 border-slate-300/40 dark:border-slate-700/60 text-slate-700 dark:text-slate-300'} border text-xs font-medium shadow-2xs">
                    <i data-lucide="paperclip" class="w-3.5 h-3.5 text-pink-500 flex-shrink-0"></i>
                    <span class="italic">${escapeHtml(cleanTxt || 'Anexo / Conteúdo Compartilhado')}</span>
                </div>
                ${extraLinkHtml ? `<div>${extraLinkHtml}</div>` : ''}
            </div>
        `;
    }

    // 4. Mensagens de texto gerais com detecção de links
    let text = escapeHtml(rawContent);

    // 4A. Instagram Reels
    text = text.replace(/(https?:\/\/(?:www\.)?instagram\.com\/reel\/([a-zA-Z0-9_-]+)\/?[^\s<]*)/gi, (match, url, code) => {
        return `<a href="${url}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center space-x-1 font-bold text-pink-600 dark:text-pink-400 bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/20 px-2 py-0.5 rounded my-0.5 transition" title="Abrir Reel no Instagram"><span>🎬 Reel (${code}) ↗</span></a>`;
    });

    // 4B. Instagram Posts
    text = text.replace(/(https?:\/\/(?:www\.)?instagram\.com\/p\/([a-zA-Z0-9_-]+)\/?[^\s<]*)/gi, (match, url, code) => {
        return `<a href="${url}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center space-x-1 font-bold text-purple-600 dark:text-purple-400 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/20 px-2 py-0.5 rounded my-0.5 transition" title="Abrir Publicação no Instagram"><span>📸 Post (${code}) ↗</span></a>`;
    });

    // 4C. Instagram Stories
    text = text.replace(/(https?:\/\/(?:www\.)?instagram\.com\/stories\/([a-zA-Z0-9_.-]+)\/?[^\s<]*)/gi, (match, url, user) => {
        return `<a href="${url}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center space-x-1 font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 px-2 py-0.5 rounded my-0.5 transition" title="Abrir Story"><span>✨ Story de @${user} ↗</span></a>`;
    });

    // 4D. Links Gerais (http / https)
    text = text.replace(/(https?:\/\/[^\s<]+)/gi, (url) => {
        if (url.includes('class="')) return url;
        return `<a href="${url}" target="_blank" rel="noopener noreferrer" class="text-blue-600 dark:text-cyan-400 hover:underline break-all inline-flex items-center space-x-0.5 font-semibold"><span>${url}</span><i data-lucide="external-link" class="w-2.5 h-2.5 inline-block opacity-70"></i></a>`;
    });

    if (currentDmSearchQuery) {
        text = highlightSearchTerms(text, currentDmSearchQuery);
    }

    return `<div class="text-xs leading-relaxed break-words pt-0.5">${text}</div>`;
}

// ==================== CARREGAMENTO GERAL DA VIEW ====================
async function loadInstagramView(operationId, phaseId = null, targetId = null) {
    const emptyElem = document.getElementById('instagram-empty');
    const contentElem = document.getElementById('instagram-content');

    if (!operationId) {
        if (emptyElem) emptyElem.classList.remove('hidden');
        if (contentElem) contentElem.classList.add('hidden');
        document.getElementById('badge-ig-count').innerText = '0';
        document.getElementById('badge-ig-dm-count').innerText = '0';
        const badgeMediaElem = document.getElementById('badge-ig-media-count');
        if (badgeMediaElem) badgeMediaElem.innerText = '0';
        document.getElementById('badge-ig-ip-count').innerText = '0';
        const badgeDevElem = document.getElementById('badge-ig-devices-count');
        if (badgeDevElem) badgeDevElem.innerText = '0';
        resetDmChatPanel();
        cachedDmThreads = [];
        renderFilteredDmThreads();
        return;
    }

    try {
        let url = `/api/instagram?operation_id=${operationId}&page=${currentIgPage}&limit=${currentIgLimit}&rel_type=${currentIgRelFilter}&search=${encodeURIComponent(currentIgSearch)}`;
        if (phaseId) url += `&phase_id=${phaseId}`;
        if (targetId) url += `&target_id=${targetId}`;

        const res = await fetch(url);
        const data = await res.json();

        if (!data.target) {
            if (emptyElem) emptyElem.classList.remove('hidden');
            if (contentElem) contentElem.classList.add('hidden');
            document.getElementById('badge-ig-count').innerText = '0';
            document.getElementById('badge-ig-dm-count').innerText = '0';
            const badgeMediaElem = document.getElementById('badge-ig-media-count');
            if (badgeMediaElem) badgeMediaElem.innerText = '0';
            document.getElementById('badge-ig-ip-count').innerText = '0';
            const badgeDevElem = document.getElementById('badge-ig-devices-count');
            if (badgeDevElem) badgeDevElem.innerText = '0';

            const statFollowers = document.getElementById('stat-followers');
            if (statFollowers) statFollowers.innerText = '0';
            const statFollowing = document.getElementById('stat-following');
            if (statFollowing) statFollowing.innerText = '0';
            const statThreadsFollowers = document.getElementById('stat-threads-followers');
            if (statThreadsFollowers) statThreadsFollowers.innerText = '0';
            const statThreadsFollowing = document.getElementById('stat-threads-following');
            if (statThreadsFollowing) statThreadsFollowing.innerText = '0';

            resetDmChatPanel();
            cachedDmThreads = [];
            renderFilteredDmThreads();
            return;
        }

        emptyElem.classList.add('hidden');
        contentElem.classList.remove('hidden');

        // Preencher Dossiê Cadastral com Alta Nitidez
        const t = data.target;
        const profileLink = document.getElementById('ig-link-profile');
        const profileUidLink = document.getElementById('ig-link-profile-uid');
        const targetAvatarImg = document.getElementById('ig-target-avatar-img');
        const targetAvatarFallback = document.getElementById('ig-target-avatar-fallback');

        // Armazenar alvos da operação para isolamento perfeito de interlocutores
        window.operationTargetHandles = new Set();
        window.operationTargetUids = new Set();
        if (Array.isArray(data.operation_targets)) {
            data.operation_targets.forEach(ot => {
                if (ot.vanity_name) window.operationTargetHandles.add(ot.vanity_name.replace(/^@/, '').toLowerCase().trim());
                if (ot.main_identifier) window.operationTargetHandles.add(ot.main_identifier.replace(/^@/, '').toLowerCase().trim());
                if (ot.name_or_alias) window.operationTargetHandles.add(ot.name_or_alias.replace(/^@/, '').toLowerCase().trim());
                if (ot.target_uid) window.operationTargetUids.add(String(ot.target_uid).trim());
            });
        }

        await loadCachedAvatarsMap();

        const btnFetchAvatar = document.getElementById('btn-fetch-target-avatar');
        const vanityLink = document.getElementById('ig-vanity-link');
        const uidBadgeLink = document.getElementById('ig-uid-link');
        const bioElem = document.getElementById('ig-bio');

        if (t.is_consolidated) {
            window.currentTargetVanity = '';
            window.currentTargetUid = '';
            
            // 1. Título e subtítulo limpos
            document.getElementById('ig-fullname').innerText = `Visão Consolidada da Operação`;
            
            const count = t.target_count || 0;
            const countLabel = count === 1 ? '1 investigado catalogado' : `${count} investigados catalogados`;
            if (vanityLink) {
                vanityLink.href = '#';
                vanityLink.className = "text-xs font-medium text-slate-600 dark:text-slate-300 pointer-events-none flex items-center space-x-1";
            }
            document.getElementById('ig-vanity').innerHTML = `<span class="flex items-center space-x-1 font-semibold text-slate-700 dark:text-slate-200"><i data-lucide="users" class="w-3.5 h-3.5 text-pink-500 inline-block mr-1"></i>${countLabel}</span>`;
            
            // 2. Badge do canto direito: [ 📊 Panorama Geral ]
            if (uidBadgeLink) {
                uidBadgeLink.href = '#';
                uidBadgeLink.className = "text-[10px] font-sans px-2.5 py-1 rounded-full bg-blue-500/10 text-blue-700 dark:text-cyan-300 border border-blue-500/30 flex items-center space-x-1.5 font-bold shadow-xs pointer-events-none select-none";
                uidBadgeLink.innerHTML = `<i data-lucide="layout-dashboard" class="w-3.5 h-3.5 text-blue-500 dark:text-cyan-400"></i><span>Panorama Geral</span>`;
                uidBadgeLink.classList.remove('hidden');
            }

            // 3. Card Informativo no lugar da Bio
            if (bioElem) {
                bioElem.innerHTML = `<span class="text-slate-600 dark:text-slate-300 not-italic flex items-center space-x-1.5"><i data-lucide="info" class="w-3.5 h-3.5 text-pink-500 flex-shrink-0"></i><span>Exibindo dados agregados, vínculos cruzados e histórico unificado de todos os alvos da operação.</span></span>`;
            }

            // 4. Avatar de grupo / Ocultar botão de buscar foto online
            if (btnFetchAvatar) btnFetchAvatar.classList.add('hidden');
            if (targetAvatarImg) targetAvatarImg.classList.add('hidden');
            if (targetAvatarFallback) {
                targetAvatarFallback.innerHTML = `<i data-lucide="users" class="w-6 h-6 text-pink-600 dark:text-pink-400"></i>`;
                targetAvatarFallback.classList.remove('hidden');
            }

            document.getElementById('ig-email').innerHTML = `<span class="font-mono text-slate-800 dark:text-slate-200 text-[11px] font-medium">${count} investigado(s) catalogado(s)</span>`;
            document.getElementById('ig-phone').innerHTML = `<span class="font-mono text-slate-800 dark:text-slate-200 text-[11px] font-medium">Dados consolidados</span>`;
            document.getElementById('ig-ip').innerText = t.registration_ip || 'Múltiplos IPs';
            document.getElementById('ig-regdate').innerText = 'Panorama Geral';

        } else {
            const rawHandle = t.vanity_name || t.main_identifier || '';
            const cleanHandle = rawHandle.replace(/^@/, '').trim();
            window.currentTargetVanity = cleanHandle;
            window.currentTargetUid = t.target_uid || '';

            document.getElementById('ig-fullname').innerText = t.full_name || t.name_or_alias || 'Nome não identificado';
            document.getElementById('ig-email').innerHTML = formatEmailDisplay(t.email);
            document.getElementById('ig-phone').innerHTML = formatPhoneDisplay(t.phone);
            document.getElementById('ig-ip').innerText = t.registration_ip || 'Não disponível';
            document.getElementById('ig-regdate').innerText = t.registration_date_brt || t.registration_date_utc || 'Não informada';
            
            // Link direto no próprio @username
            if (vanityLink) {
                if (cleanHandle) {
                    vanityLink.href = getIgProfileUrl(cleanHandle);
                    vanityLink.className = "text-xs font-mono text-pink-600 dark:text-pink-400 hover:underline font-bold flex items-center space-x-1 transition group";
                } else {
                    vanityLink.href = '#';
                    vanityLink.className = "text-xs font-mono text-pink-600 dark:text-pink-400 font-bold flex items-center space-x-1 pointer-events-none opacity-60";
                }
            }
            document.getElementById('ig-vanity').innerText = cleanHandle ? `@${cleanHandle}` : (t.registered_id || '@não_informado');

            // Link permanente por ID Meta no Badge superior
            if (uidBadgeLink) {
                if (t.target_uid && t.target_uid !== 'N/A' && t.target_uid !== '---') {
                    uidBadgeLink.href = getIgUidUrl(t.target_uid);
                    uidBadgeLink.className = "text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/10 text-purple-700 dark:text-purple-300 border border-purple-500/30 hover:bg-purple-500/20 flex items-center space-x-1 transition font-bold shadow-xs";
                    uidBadgeLink.innerHTML = `<i data-lucide="fingerprint" class="w-3 h-3 text-purple-500"></i><span id="ig-uid">UID: ${escapeHtml(t.target_uid)}</span><i data-lucide="external-link" class="w-2.5 h-2.5 opacity-70"></i>`;
                    uidBadgeLink.classList.remove('hidden');
                } else {
                    uidBadgeLink.classList.add('hidden');
                }
            }

            // Bio padrão do Alvo
            if (bioElem) {
                bioElem.innerText = t.bio || 'Sem biografia disponível.';
                bioElem.className = 'text-xs text-slate-600 dark:text-slate-400 mt-3 italic bg-slate-50 dark:bg-slate-950/60 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800';
            }

            // Foto de perfil do Alvo (Cache Local)
            if (btnFetchAvatar) btnFetchAvatar.classList.remove('hidden');
            if (targetAvatarFallback) {
                targetAvatarFallback.innerHTML = `<i data-lucide="instagram" class="w-6 h-6"></i>`;
            }

            const targetAvatarUrl = getCachedAvatarSrc(cleanHandle) || getCachedAvatarSrc(t.target_uid);
            if (targetAvatarUrl && targetAvatarImg && targetAvatarFallback) {
                targetAvatarImg.src = `${targetAvatarUrl}?t=${Date.now()}`;
                targetAvatarImg.classList.remove('hidden');
                targetAvatarFallback.classList.add('hidden');
            } else if (targetAvatarImg && targetAvatarFallback) {
                targetAvatarImg.classList.add('hidden');
                targetAvatarFallback.classList.remove('hidden');

                // Busca imediata e automática do alvo (somente se possuir ID numérico)
                if (t.target_uid && String(t.target_uid).trim() !== '' && String(t.target_uid).trim() !== 'N/A' && String(t.target_uid).trim() !== '---') {
                    setTimeout(() => fetchTargetAvatarOnline(true), 100);
                }
            }
        }

        document.getElementById('ig-ticket-badge').innerText = `Ticket: ${t.internal_ticket || 'N/A'}`;
        document.getElementById('ig-daterange').innerText = t.date_range || 'Não especificado';
        document.getElementById('ig-generated').innerText = t.report_generated_utc || 'Não informado';
        document.getElementById('ig-threads-reg').innerText = t.threads_registration_date_brt || t.threads_registration_date_utc || 'Não ativado';

        // Estatísticas Rápidas
        const s = data.stats || {};
        document.getElementById('stat-followers').innerText = (s.follower || 0).toLocaleString();
        document.getElementById('stat-following').innerText = (s.following || 0).toLocaleString();
        document.getElementById('stat-threads-followers').innerText = (s.threads_follower || 0).toLocaleString();
        document.getElementById('stat-threads-following').innerText = (s.threads_following || 0).toLocaleString();

        const totalIgRel = (s.follower || 0) + (s.following || 0) + (s.threads_follower || 0) + (s.threads_following || 0);
        document.getElementById('badge-ig-count').innerText = totalIgRel.toLocaleString();

        document.getElementById('badge-ig-dm-count').innerText = (s.dm_threads || 0).toLocaleString();
        const badgeMediaElem = document.getElementById('badge-ig-media-count');
        if (badgeMediaElem) badgeMediaElem.innerText = (s.media_count || 0).toLocaleString();
        document.getElementById('badge-ig-ip-count').innerText = (s.ip_connections || 0).toLocaleString();
        const badgeDevElem = document.getElementById('badge-ig-devices-count');
        if (badgeDevElem) badgeDevElem.innerText = (s.devices_count || 0).toLocaleString();

        // Renderizar Tabela de Relacionamentos
        renderIgTable(data);

        if (window.lucide) {
            const ovEl = document.getElementById('ig-subview-overview');
            if (ovEl) lucide.createIcons({ root: ovEl });
        }

        // Se sub-aba DMs, Mídias, Conexões ou Dispositivos estiver ativa, carregar com o accountUid ativo
        if (currentActiveIgSubTab === 'dms') {
            loadDmThreads(operationId, phaseId, targetId, '', currentSelectedAccountUid);
        } else if (currentActiveIgSubTab === 'media') {
            loadIgMediaGallery(operationId, phaseId, targetId, currentSelectedAccountUid);
        } else if (currentActiveIgSubTab === 'connections') {
            loadIgConnections(operationId, phaseId, targetId, currentSelectedAccountUid);
        } else if (currentActiveIgSubTab === 'devices') {
            loadIgDevices(operationId, phaseId, targetId, '', currentSelectedAccountUid);
        }

    } catch (err) {
        console.error("Erro ao carregar dados do Instagram:", err);
    }
}

function switchIgSubTab(subTabName) {
    currentActiveIgSubTab = subTabName;

    const subTabs = ['overview', 'dms', 'media', 'connections', 'devices'];
    subTabs.forEach(t => {
        const btn = document.getElementById(`subtab-ig-${t}`);
        const view = document.getElementById(`ig-subview-${t}`);
        if (!btn || !view) return;
        if (t === subTabName) {
            btn.className = "ig-subtab-btn active flex-shrink-0 whitespace-nowrap h-7 px-2.5 rounded-md bg-pink-600 text-white font-semibold text-[11px] border border-pink-600 shadow-2xs flex items-center space-x-1.5 transition";
            view.classList.remove('hidden');
        } else {
            btn.className = "ig-subtab-btn flex-shrink-0 whitespace-nowrap h-7 px-2.5 rounded-md bg-slate-100/70 hover:bg-slate-200/70 text-slate-700 dark:bg-slate-950/50 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:bg-slate-800/70 border border-slate-200/80 dark:border-slate-800/80 font-semibold text-[11px] flex items-center space-x-1.5 transition";
            view.classList.add('hidden');
        }
    });

    if (window.currentOpId) {
        if (subTabName === 'dms') {
            loadDmThreads(window.currentOpId, window.currentPhaseId, window.currentTargetId, '', currentSelectedAccountUid);
        } else if (subTabName === 'media') {
            loadIgMediaGallery(window.currentOpId, window.currentPhaseId, window.currentTargetId, currentSelectedAccountUid);
        } else if (subTabName === 'connections') {
            loadIgConnections(window.currentOpId, window.currentPhaseId, window.currentTargetId, currentSelectedAccountUid);
        } else if (subTabName === 'devices') {
            loadIgDevices(window.currentOpId, window.currentPhaseId, window.currentTargetId, '', currentSelectedAccountUid);
        }
    }
}

function resetDmChatPanel() {
    currentSelectedThreadId = null;
    currentSelectedParticipant = null;
    const headerTitle = document.getElementById('dm-current-participant');
    const headerThreadId = document.getElementById('dm-current-thread-id');
    const headerMsgCount = document.getElementById('dm-current-msg-count');
    const container = document.getElementById('dm-messages-container');
    const igLink = document.getElementById('dm-header-ig-link');
    const btnBookmark = document.getElementById('btn-jump-bookmark');
    const btnRead = document.getElementById('btn-toggle-read-status');
    const btnStar = document.getElementById('btn-toggle-star-status');
    const btnDateFilter = document.getElementById('btn-toggle-date-filter');

    if (headerTitle) headerTitle.innerText = "Selecione uma conversa";
    if (headerThreadId) headerThreadId.innerText = "Thread ID: ---";
    if (headerMsgCount) headerMsgCount.innerText = "0 msgs";
    if (igLink) igLink.classList.add('hidden');
    if (btnBookmark) btnBookmark.classList.add('hidden');
    if (btnRead) btnRead.classList.add('hidden');
    if (btnStar) btnStar.classList.add('hidden');
    if (btnDateFilter) btnDateFilter.classList.add('hidden');

    const drawerMediaCount = document.getElementById('drawer-media-count');
    if (drawerMediaCount) drawerMediaCount.innerText = "(0)";
    const drawerMembersCount = document.getElementById('drawer-members-count');
    if (drawerMembersCount) drawerMembersCount.innerText = "(0)";
    const badgeDetails = document.getElementById('dm-chat-details-badge');
    if (badgeDetails) badgeDetails.innerText = "";
    closeDmChatSearch();

    if (container) {
        container.innerHTML = `
            <div class="text-center py-20 text-slate-400 dark:text-slate-500 text-xs">
                <i data-lucide="messages-square" class="w-8 h-8 mx-auto text-slate-400 dark:text-slate-600 mb-2"></i>
                Clique em uma conversa à esquerda para ler o histórico de mensagens e reproduzir mídias.
            </div>
        `;
    }
    lucide.createIcons();
}

// ==================== MENSAGENS DIRETAS (DMs), ORDENAÇÃO & EVIDÊNCIAS ====================

async function loadDmAnnotations(operationId) {
    try {
        const res = await fetch(`/api/dms/annotations?operation_id=${operationId}&platform=instagram`);
        dmAnnotations = await res.json();
    } catch (err) {
        console.error("Erro ao carregar anotações de DMs:", err);
        dmAnnotations = {};
    }
}

async function loadEvidenceTags(operationId) {
    try {
        const res = await fetch(`/api/evidence/tags?operation_id=${operationId}`);
        evidenceTagsMap = await res.json();
        const count = Object.keys(evidenceTagsMap).length;
        const badge = document.getElementById('evidence-count-badge');
        if (badge) badge.innerText = count;
    } catch (err) {
        console.error("Erro ao carregar tags de evidências:", err);
        evidenceTagsMap = {};
    }
}

function switchTargetAccount(accountUid) {
    currentSelectedAccountUid = accountUid || null;
    currentDmAccountFilterUid = accountUid || null;
    if (window.currentOpId) {
        loadInstagramView(window.currentOpId, window.currentPhaseId, window.currentTargetId, currentSelectedAccountUid);
    }
}

function handleDmAccountFilterChange(accountUid) {
    currentDmAccountFilterUid = accountUid || null;
    currentSelectedAccountUid = accountUid || null;
    if (window.currentOpId) {
        loadDmThreads(window.currentOpId, window.currentPhaseId, window.currentTargetId, '', currentDmAccountFilterUid);
    }
}

let currentThreadsStartDate = '';
let currentThreadsEndDate = '';

async function loadDmThreads(opId, phaseId = null, targetId = null, search = '', accountUid = null) {
    const listElem = document.getElementById('dm-threads-list');
    const effectiveAccountUid = accountUid !== null ? accountUid : (currentDmAccountFilterUid || currentSelectedAccountUid);
    currentDmAccountFilterUid = effectiveAccountUid;

    try {
        await Promise.all([
            loadDmAnnotations(opId),
            loadEvidenceTags(opId)
        ]);

        // Atualizar seletor de contas fakes na barra lateral de DMs
        const dmAccContainer = document.getElementById('dm-account-filter-container');
        const dmAccSelect = document.getElementById('dm-account-select');
        const accounts = window.currentTargetAccounts || [];

        if (dmAccContainer && dmAccSelect) {
            if (accounts.length > 1 && targetId) {
                dmAccContainer.classList.remove('hidden');
                dmAccSelect.innerHTML = `
                    <option value="">Todos os Perfis do Alvo (${accounts.length})</option>
                    ${accounts.map(acc => {
                        const handle = (acc.vanity_name || acc.target_uid || 'perfil').replace(/^@/, '');
                        const isSel = String(acc.target_uid) === String(currentDmAccountFilterUid);
                        return `<option value="${escapeHtml(acc.target_uid)}" ${isSel ? 'selected' : ''}>@${escapeHtml(handle)} (${acc.messages_count || 0} msgs)</option>`;
                    }).join('')}
                `;
            } else {
                dmAccContainer.classList.add('hidden');
            }
        }

        let url = `/api/instagram/threads?operation_id=${opId}&sort_by=${currentDmSort}`;
        if (phaseId) url += `&phase_id=${phaseId}`;
        if (targetId) url += `&target_id=${targetId}`;
        if (currentDmAccountFilterUid) url += `&account_uid=${encodeURIComponent(currentDmAccountFilterUid)}`;
        if (currentThreadsStartDate) url += `&start_date=${encodeURIComponent(currentThreadsStartDate)}`;
        if (currentThreadsEndDate) url += `&end_date=${encodeURIComponent(currentThreadsEndDate)}`;
        if (search) url += `&search=${encodeURIComponent(search)}`;

        const res = await fetch(url);
        cachedDmThreads = await res.json();

        updateDmProgress();
        renderFilteredDmThreads();

        // Se uma thread estava aberta e não estamos em um salto programado, recarregar suas mensagens
        if (currentSelectedThreadId && !window.isJumpingToMessage) {
            const stillExists = cachedDmThreads.find(t => String(t.thread_id) === String(currentSelectedThreadId));
            if (stillExists) {
                await selectDmThread(stillExists.thread_id, currentSelectedParticipant, stillExists.message_count, false);
            }
        }
    } catch (err) {
        console.error("Erro ao carregar threads de DMs:", err);
    }
}

function handleDmSortChange(newSort) {
    currentDmSort = newSort;
    if (window.currentOpId) {
        loadDmThreads(window.currentOpId, window.currentPhaseId, window.currentTargetId);
    }
}

// ==================== CALENDÁRIO DUPLO FORENSE (2 MESES INDEPENDENTES) ====================
let threadsCalendarLeftYear = null;
let threadsCalendarLeftMonth = null;
let threadsCalendarRightYear = null;
let threadsCalendarRightMonth = null;
let threadsActiveDates = [];
let threadsDataMinDate = null;
let threadsDataMaxDate = null;
let threadsHoverDate = null;
let threadsCalendarSelectionStep = 0;

let chatCalendarLeftYear = null;
let chatCalendarLeftMonth = null;
let chatCalendarRightYear = null;
let chatCalendarRightMonth = null;
let chatActiveDates = [];
let chatDataMinDate = null;
let chatDataMaxDate = null;
let chatHoverDate = null;
let chatCalendarSelectionStep = 0;

function renderDualForensicCalendar({
    containerId,
    activeDates = [],
    dataMinDate = null,
    dataMaxDate = null,
    currentLeftYear,
    currentLeftMonth,
    currentRightYear,
    currentRightMonth,
    selectedStart = null,
    selectedEnd = null,
    hoverDate = null,
    selectionStep = 0,
    onLeftMonthNavigate,
    onRightMonthNavigate,
    onSelectDay,
    onHoverDay,
    onResetFullPeriod,
    onClear
}) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const monthNames = [
        "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    ];
    const activeSet = new Set(activeDates);

    // Calcular intervalo efetivo a destacar (suporte a preview com hover)
    let effectiveStart = null;
    let effectiveEnd = null;

    if (selectionStep === 1 && selectedStart && hoverDate) {
        effectiveStart = (selectedStart < hoverDate) ? selectedStart : hoverDate;
        effectiveEnd = (selectedStart < hoverDate) ? hoverDate : selectedStart;
    } else if (selectedStart && selectedEnd) {
        effectiveStart = (selectedStart < selectedEnd) ? selectedStart : selectedEnd;
        effectiveEnd = (selectedStart < selectedEnd) ? selectedEnd : selectedStart;
    }

    // Função interna para renderizar a grade de 1 mês com navegação independente
    function renderSingleMonth(year, month, isLeft) {
        const firstDayOfWeek = new Date(year, month, 1).getDay(); // 0 = Dom, 6 = Sáb
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        const navPrevClass = isLeft ? 'btn-cal-left-prev' : 'btn-cal-right-prev';
        const navNextClass = isLeft ? 'btn-cal-left-next' : 'btn-cal-right-next';

        let gridHtml = `
            <div class="flex-1 min-w-[240px]">
                <!-- Cabeçalho com Navegação Independente do Mês -->
                <div class="flex items-center justify-between px-1 mb-2">
                    <button type="button" class="${navPrevClass} p-1 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold transition flex items-center justify-center w-6 h-6">
                        ‹
                    </button>
                    <span class="font-bold text-xs text-slate-800 dark:text-slate-200">
                        ${monthNames[month]} ${year}
                    </span>
                    <button type="button" class="${navNextClass} p-1 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold transition flex items-center justify-center w-6 h-6">
                        ›
                    </button>
                </div>

                <div class="grid grid-cols-7 gap-y-1 text-center text-[10px] font-semibold text-slate-400 dark:text-slate-500 mb-1">
                    <div>D</div><div>S</div><div>T</div><div>Q</div><div>Q</div><div>S</div><div>S</div>
                </div>
                <div class="grid grid-cols-7 gap-y-1 text-center text-xs">
        `;

        for (let i = 0; i < firstDayOfWeek; i++) {
            gridHtml += `<div class="h-8"></div>`;
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const mStr = String(month + 1).padStart(2, '0');
            const dStr = String(day).padStart(2, '0');
            const dateKey = `${year}-${mStr}-${dStr}`;

            const colIndex = (firstDayOfWeek + day - 1) % 7;
            const hasData = activeSet.has(dateKey);

            const isBeforeMin = (dataMinDate && dateKey < dataMinDate);
            const isAfterMax = (dataMaxDate && dateKey > dataMaxDate);
            const isOutOfBounds = isBeforeMin || isAfterMax;

            if (isOutOfBounds) {
                const disabledClasses = 'relative z-10 w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-medium text-slate-300 dark:text-slate-700 opacity-20 cursor-not-allowed pointer-events-none select-none';
                gridHtml += `
                    <div class="relative flex items-center justify-center h-8 w-full cal-day-wrapper">
                        <button type="button" disabled class="cal-day-btn ${disabledClasses}">
                            ${day}
                        </button>
                    </div>
                `;
                continue;
            }

            const isStart = (effectiveStart && dateKey === effectiveStart);
            const isEnd = (effectiveEnd && dateKey === effectiveEnd);
            const isInMiddle = (effectiveStart && effectiveEnd && dateKey > effectiveStart && dateKey < effectiveEnd);
            const isSingle = (effectiveStart && effectiveEnd && effectiveStart === effectiveEnd && isStart);

            let trackHtml = '';
            let btnClasses = 'relative z-10 w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-medium transition cursor-pointer ';

            if (isSingle) {
                btnClasses += 'bg-blue-600 dark:bg-blue-500 text-white font-bold shadow-xs';
            } else if (isStart) {
                trackHtml = `<div class="absolute inset-y-1 left-1/2 right-0 bg-blue-100 dark:bg-blue-950/70 ${colIndex === 6 ? 'rounded-r-full' : ''}"></div>`;
                btnClasses += 'bg-blue-600 dark:bg-blue-500 text-white font-bold shadow-xs';
            } else if (isEnd) {
                trackHtml = `<div class="absolute inset-y-1 left-0 right-1/2 bg-blue-100 dark:bg-blue-950/70 ${colIndex === 0 ? 'rounded-l-full' : ''}"></div>`;
                btnClasses += (selectionStep === 1)
                    ? 'border-2 border-blue-600 text-blue-600 dark:text-blue-300 bg-white dark:bg-slate-900 font-bold shadow-xs'
                    : 'bg-blue-600 dark:bg-blue-500 text-white font-bold shadow-xs';
            } else if (isInMiddle) {
                trackHtml = `<div class="absolute inset-y-1 left-0 right-0 bg-blue-100 dark:bg-blue-950/70 ${colIndex === 0 ? 'rounded-l-full' : ''} ${colIndex === 6 ? 'rounded-r-full' : ''}"></div>`;
                btnClasses += 'text-blue-900 dark:text-blue-200 font-bold hover:bg-blue-200/50';
            } else if (hasData) {
                btnClasses += 'text-slate-800 dark:text-slate-100 font-bold hover:bg-slate-200 dark:hover:bg-slate-800';
            } else {
                btnClasses += 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300';
            }

            gridHtml += `
                <div class="relative flex items-center justify-center h-8 w-full cal-day-wrapper" data-date="${dateKey}">
                    ${trackHtml}
                    <button type="button" data-date="${dateKey}" class="cal-day-btn ${btnClasses}">
                        ${day}
                    </button>
                </div>
            `;
        }

        gridHtml += `
                </div>
            </div>
        `;
        return gridHtml;
    }

    // Cabeçalho Panorâmico dos Dados
    const minFmt = dataMinDate ? dataMinDate.split('-').reverse().join('/') : '---';
    const maxFmt = dataMaxDate ? dataMaxDate.split('-').reverse().join('/') : '---';

    let html = `
        <div class="space-y-3 select-none">
            <!-- Barra Superior Panorâmica com Período Total -->
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800/80 pb-2">
                <div class="flex items-center space-x-1.5">
                    <span class="text-xs font-bold text-slate-800 dark:text-slate-200">📅 Histórico dos Dados:</span>
                    <span class="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-md border border-blue-200 dark:border-blue-800">${minFmt} até ${maxFmt}</span>
                </div>
                <button type="button" class="btn-cal-close text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-bold text-xs p-1">
                    ✕
                </button>
            </div>

            <!-- Grade dos 2 Meses com Navegação Independente -->
            <div class="flex flex-col sm:flex-row gap-4 justify-between items-start">
                ${renderSingleMonth(currentLeftYear, currentLeftMonth, true)}
                <div class="hidden sm:block w-px bg-slate-200 dark:bg-slate-800 self-stretch my-1"></div>
                ${renderSingleMonth(currentRightYear, currentRightMonth, false)}
            </div>

            <!-- Rodapé com Intervalo e Ações Rápidas -->
            <div class="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                <div class="text-slate-600 dark:text-slate-300 font-medium">
    `;

    if (effectiveStart && effectiveEnd) {
        const sFmt = effectiveStart.split('-').reverse().join('/');
        const eFmt = effectiveEnd.split('-').reverse().join('/');
        if (effectiveStart === effectiveEnd) {
            html += `📌 <span class="font-bold text-blue-600 dark:text-blue-400">Dia ${sFmt}</span>`;
        } else {
            html += `📌 <span class="font-bold text-blue-600 dark:text-blue-400">${sFmt} até ${eFmt}</span>`;
        }
    } else {
        html += `<span class="text-slate-400 dark:text-slate-500">Clique no dia inicial e arraste até o dia final</span>`;
    }

    html += `
                </div>
                <div class="flex items-center space-x-2">
                    <button type="button" class="btn-cal-reset-full px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 font-semibold transition text-[10px]">
                        Todo o Período
                    </button>
                    <button type="button" class="btn-cal-clear px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-red-500 hover:bg-slate-200 font-semibold transition text-[10px]">
                        Limpar
                    </button>
                </div>
            </div>
        </div>
    `;

    container.innerHTML = html;

    // Navegação independente esquerda
    container.querySelector('.btn-cal-left-prev')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (onLeftMonthNavigate) onLeftMonthNavigate(-1);
    });
    container.querySelector('.btn-cal-left-next')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (onLeftMonthNavigate) onLeftMonthNavigate(1);
    });

    // Navegação independente direita
    container.querySelector('.btn-cal-right-prev')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (onRightMonthNavigate) onRightMonthNavigate(-1);
    });
    container.querySelector('.btn-cal-right-next')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (onRightMonthNavigate) onRightMonthNavigate(1);
    });

    // Fechar
    container.querySelector('.btn-cal-close')?.addEventListener('click', (e) => {
        e.stopPropagation();
        container.classList.add('hidden');
    });

    // Resetar para todo o período
    container.querySelector('.btn-cal-reset-full')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (onResetFullPeriod) onResetFullPeriod();
    });

    // Limpar filtro
    container.querySelector('.btn-cal-clear')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (onClear) onClear();
    });

    // Clique nos dias
    container.querySelectorAll('.cal-day-btn, .cal-day-wrapper').forEach(el => {
        el.addEventListener('click', (e) => {
            e.stopPropagation();
            const dateStr = el.getAttribute('data-date');
            if (dateStr && onSelectDay) {
                onSelectDay(dateStr);
            }
        });

        // Hover dinâmico enquanto seleciona o 2º dia
        el.addEventListener('mouseenter', () => {
            if (selectionStep === 1) {
                const dateStr = el.getAttribute('data-date');
                if (dateStr && onHoverDay) {
                    onHoverDay(dateStr);
                }
            }
        });
    });
}

function positionCalendarPopover(popoverEl, triggerBtn, align = 'left') {
    if (!popoverEl || !triggerBtn) return;
    const rect = triggerBtn.getBoundingClientRect();
    popoverEl.style.position = 'fixed';
    popoverEl.style.top = `${Math.round(rect.bottom + 6)}px`;
    const popWidth = 580;
    
    let left = (align === 'right') ? (rect.right - popWidth) : rect.left;
    if (left + popWidth > window.innerWidth - 16) {
        left = window.innerWidth - popWidth - 16;
    }
    if (left < 16) left = 16;
    popoverEl.style.left = `${Math.round(left)}px`;
}

// ------------------- CALENDÁRIO DAS THREADS (ESQUERDA) -------------------
async function toggleThreadsCalendar() {
    const popover = document.getElementById('dm-threads-calendar-popover');
    const triggerBtn = document.getElementById('btn-toggle-threads-calendar');
    if (!popover) return;

    if (!popover.classList.contains('hidden')) {
        popover.classList.add('hidden');
        return;
    }

    document.getElementById('dm-chat-calendar-popover')?.classList.add('hidden');

    if (!threadsActiveDates || threadsActiveDates.length === 0) {
        try {
            let url = `/api/instagram/active-dates?operation_id=${window.currentOpId}`;
            if (window.currentTargetId) url += `&target_id=${window.currentTargetId}`;
            const res = await fetch(url);
            const data = await res.json();
            threadsActiveDates = data.dates || [];
            threadsDataMinDate = data.min_date || null;
            threadsDataMaxDate = data.max_date || null;

            if (threadsActiveDates.length > 0 && threadsCalendarLeftYear === null) {
                // Início (Mês Esquerdo): Mês da menor data
                const minParts = threadsDataMinDate.split('-');
                threadsCalendarLeftYear = parseInt(minParts[0]);
                threadsCalendarLeftMonth = parseInt(minParts[1]) - 1;

                // Fim (Mês Direito): Mês da maior data
                const maxParts = threadsDataMaxDate.split('-');
                threadsCalendarRightYear = parseInt(maxParts[0]);
                threadsCalendarRightMonth = parseInt(maxParts[1]) - 1;

                // Se ambos caírem no mesmo mês, o direito avança 1 mês
                if (threadsCalendarLeftYear === threadsCalendarRightYear && threadsCalendarLeftMonth === threadsCalendarRightMonth) {
                    threadsCalendarRightMonth += 1;
                    if (threadsCalendarRightMonth > 11) {
                        threadsCalendarRightMonth = 0;
                        threadsCalendarRightYear += 1;
                    }
                }
            }
        } catch (e) {
            console.error("Erro ao carregar datas ativas de threads:", e);
        }
    }

    if (threadsCalendarLeftYear === null) {
        const now = new Date();
        threadsCalendarLeftYear = now.getFullYear();
        threadsCalendarLeftMonth = now.getMonth();
        threadsCalendarRightYear = now.getFullYear();
        threadsCalendarRightMonth = now.getMonth() + 1;
        if (threadsCalendarRightMonth > 11) {
            threadsCalendarRightMonth = 0;
            threadsCalendarRightYear++;
        }
    }

    renderThreadsCalendarView();
    positionCalendarPopover(popover, triggerBtn, 'left');
    popover.classList.remove('hidden');
}

function renderThreadsCalendarView() {
    renderDualForensicCalendar({
        containerId: 'dm-threads-calendar-popover',
        activeDates: threadsActiveDates,
        dataMinDate: threadsDataMinDate,
        dataMaxDate: threadsDataMaxDate,
        currentLeftYear: threadsCalendarLeftYear,
        currentLeftMonth: threadsCalendarLeftMonth,
        currentRightYear: threadsCalendarRightYear,
        currentRightMonth: threadsCalendarRightMonth,
        selectedStart: currentThreadsStartDate,
        selectedEnd: currentThreadsEndDate,
        hoverDate: threadsHoverDate,
        selectionStep: threadsCalendarSelectionStep,
        onLeftMonthNavigate: (dir) => {
            let m = threadsCalendarLeftMonth + dir;
            let y = threadsCalendarLeftYear;
            if (m < 0) { m = 11; y--; }
            if (m > 11) { m = 0; y++; }
            threadsCalendarLeftYear = y;
            threadsCalendarLeftMonth = m;
            renderThreadsCalendarView();
        },
        onRightMonthNavigate: (dir) => {
            let m = threadsCalendarRightMonth + dir;
            let y = threadsCalendarRightYear;
            if (m < 0) { m = 11; y--; }
            if (m > 11) { m = 0; y++; }
            threadsCalendarRightYear = y;
            threadsCalendarRightMonth = m;
            renderThreadsCalendarView();
        },
        onSelectDay: (dateStr) => {
            if (threadsCalendarSelectionStep === 0) {
                currentThreadsStartDate = dateStr;
                currentThreadsEndDate = null;
                threadsHoverDate = dateStr;
                threadsCalendarSelectionStep = 1;
                renderThreadsCalendarView();
            } else {
                if (dateStr < currentThreadsStartDate) {
                    currentThreadsEndDate = currentThreadsStartDate;
                    currentThreadsStartDate = dateStr;
                } else {
                    currentThreadsEndDate = dateStr;
                }
                threadsCalendarSelectionStep = 0;
                threadsHoverDate = null;
                applyThreadsPeriodFilter();
            }
        },
        onHoverDay: (dateStr) => {
            if (threadsCalendarSelectionStep === 1 && threadsHoverDate !== dateStr) {
                threadsHoverDate = dateStr;
                renderThreadsCalendarView();
            }
        },
        onResetFullPeriod: () => {
            if (threadsDataMinDate && threadsDataMaxDate) {
                currentThreadsStartDate = threadsDataMinDate;
                currentThreadsEndDate = threadsDataMaxDate;
                threadsCalendarSelectionStep = 0;
                threadsHoverDate = null;
                applyThreadsPeriodFilter();
            }
        },
        onClear: () => {
            clearThreadsPeriodFilter();
        }
    });
}

function applyThreadsPeriodFilter() {
    document.getElementById('dm-threads-calendar-popover')?.classList.add('hidden');
    const badge = document.getElementById('dm-threads-period-badge');
    const badgeText = document.getElementById('dm-threads-period-text');
    const btnLabel = document.getElementById('btn-threads-calendar-label');

    if (currentThreadsStartDate && currentThreadsEndDate) {
        const s = currentThreadsStartDate.split('-').reverse().slice(0, 2).join('/');
        const e = currentThreadsEndDate.split('-').reverse().slice(0, 2).join('/');
        const label = (currentThreadsStartDate === currentThreadsEndDate) ? s : `${s} a ${e}`;
        if (badge) badge.classList.remove('hidden');
        if (badgeText) badgeText.innerText = `📅 ${label}`;
        if (btnLabel) btnLabel.innerText = label;
    }

    if (window.currentOpId) {
        loadDmThreads(window.currentOpId, window.currentPhaseId, window.currentTargetId);
    }
}

function clearThreadsPeriodFilter() {
    currentThreadsStartDate = '';
    currentThreadsEndDate = '';
    threadsHoverDate = null;
    threadsCalendarSelectionStep = 0;
    document.getElementById('dm-threads-calendar-popover')?.classList.add('hidden');
    document.getElementById('dm-threads-period-badge')?.classList.add('hidden');
    const btnLabel = document.getElementById('btn-threads-calendar-label');
    if (btnLabel) btnLabel.innerText = 'Período';

    if (window.currentOpId) {
        loadDmThreads(window.currentOpId, window.currentPhaseId, window.currentTargetId);
    }
}

// ------------------- CALENDÁRIO DO CHAT (DIREITA) -------------------
async function toggleChatCalendar() {
    const popover = document.getElementById('dm-chat-calendar-popover');
    const triggerBtn = document.getElementById('btn-toggle-date-filter');
    if (!popover) return;

    if (!popover.classList.contains('hidden')) {
        popover.classList.add('hidden');
        return;
    }

    document.getElementById('dm-threads-calendar-popover')?.classList.add('hidden');

    if (window.currentThreadMessages && window.currentThreadMessages.length > 0) {
        const dateSet = new Set();
        window.currentThreadMessages.forEach(m => {
            const raw = m.timestamp_utc || m.timestamp_brt;
            if (raw) {
                const ds = raw.substring(0, 10);
                if (ds.match(/^\d{4}-\d{2}-\d{2}$/)) dateSet.add(ds);
            }
        });
        chatActiveDates = Array.from(dateSet).sort();
        chatDataMinDate = chatActiveDates[0] || null;
        chatDataMaxDate = chatActiveDates[chatActiveDates.length - 1] || null;

        if (chatActiveDates.length > 0 && chatCalendarLeftYear === null) {
            const minParts = chatDataMinDate.split('-');
            chatCalendarLeftYear = parseInt(minParts[0]);
            chatCalendarLeftMonth = parseInt(minParts[1]) - 1;

            const maxParts = chatDataMaxDate.split('-');
            chatCalendarRightYear = parseInt(maxParts[0]);
            chatCalendarRightMonth = parseInt(maxParts[1]) - 1;

            if (chatCalendarLeftYear === chatCalendarRightYear && chatCalendarLeftMonth === chatCalendarRightMonth) {
                chatCalendarRightMonth += 1;
                if (chatCalendarRightMonth > 11) {
                    chatCalendarRightMonth = 0;
                    chatCalendarRightYear += 1;
                }
            }
        }
    }

    if (chatCalendarLeftYear === null) {
        const now = new Date();
        chatCalendarLeftYear = now.getFullYear();
        chatCalendarLeftMonth = now.getMonth();
        chatCalendarRightYear = now.getFullYear();
        chatCalendarRightMonth = now.getMonth() + 1;
        if (chatCalendarRightMonth > 11) {
            chatCalendarRightMonth = 0;
            chatCalendarRightYear++;
        }
    }

    renderChatCalendarView();
    positionCalendarPopover(popover, triggerBtn, 'right');
    popover.classList.remove('hidden');
}

function renderChatCalendarView() {
    renderDualForensicCalendar({
        containerId: 'dm-chat-calendar-popover',
        activeDates: chatActiveDates,
        dataMinDate: chatDataMinDate,
        dataMaxDate: chatDataMaxDate,
        currentLeftYear: chatCalendarLeftYear,
        currentLeftMonth: chatCalendarLeftMonth,
        currentRightYear: chatCalendarRightYear,
        currentRightMonth: chatCalendarRightMonth,
        selectedStart: currentDmStartDate,
        selectedEnd: currentDmEndDate,
        hoverDate: chatHoverDate,
        selectionStep: chatCalendarSelectionStep,
        onLeftMonthNavigate: (dir) => {
            let m = chatCalendarLeftMonth + dir;
            let y = chatCalendarLeftYear;
            if (m < 0) { m = 11; y--; }
            if (m > 11) { m = 0; y++; }
            chatCalendarLeftYear = y;
            chatCalendarLeftMonth = m;
            renderChatCalendarView();
        },
        onRightMonthNavigate: (dir) => {
            let m = chatCalendarRightMonth + dir;
            let y = chatCalendarRightYear;
            if (m < 0) { m = 11; y--; }
            if (m > 11) { m = 0; y++; }
            chatCalendarRightYear = y;
            chatCalendarRightMonth = m;
            renderChatCalendarView();
        },
        onSelectDay: (dateStr) => {
            if (chatCalendarSelectionStep === 0) {
                currentDmStartDate = dateStr;
                currentDmEndDate = null;
                chatHoverDate = dateStr;
                chatCalendarSelectionStep = 1;
                renderChatCalendarView();
            } else {
                if (dateStr < currentDmStartDate) {
                    currentDmEndDate = currentDmStartDate;
                    currentDmStartDate = dateStr;
                } else {
                    currentDmEndDate = dateStr;
                }
                chatCalendarSelectionStep = 0;
                chatHoverDate = null;
                applyChatPeriodFilter();
            }
        },
        onHoverDay: (dateStr) => {
            if (chatCalendarSelectionStep === 1 && chatHoverDate !== dateStr) {
                chatHoverDate = dateStr;
                renderChatCalendarView();
            }
        },
        onResetFullPeriod: () => {
            if (chatDataMinDate && chatDataMaxDate) {
                currentDmStartDate = chatDataMinDate;
                currentDmEndDate = chatDataMaxDate;
                chatCalendarSelectionStep = 0;
                chatHoverDate = null;
                applyChatPeriodFilter();
            }
        },
        onClear: () => {
            clearChatPeriodFilter();
        }
    });
}

function applyChatPeriodFilter() {
    document.getElementById('dm-chat-calendar-popover')?.classList.add('hidden');
    const badge = document.getElementById('dm-chat-period-badge');
    const badgeText = document.getElementById('dm-chat-period-text');
    const btnLabel = document.getElementById('btn-chat-calendar-label');

    if (currentDmStartDate && currentDmEndDate) {
        const s = currentDmStartDate.split('-').reverse().join('/');
        const e = currentDmEndDate.split('-').reverse().join('/');
        const text = (currentDmStartDate === currentDmEndDate)
            ? `📅 Filtrando mensagens do dia ${s}`
            : `📅 Filtrando mensagens de ${s} até ${e}`;
        if (badge) badge.classList.remove('hidden');
        if (badgeText) badgeText.innerText = text;
        if (btnLabel) btnLabel.innerText = (currentDmStartDate === currentDmEndDate) ? s.slice(0, 5) : `${s.slice(0, 5)} a ${e.slice(0, 5)}`;
    }

    if (currentSelectedThreadId) {
        selectDmThread(currentSelectedThreadId, currentSelectedParticipant, 0, false);
    }
}

function clearChatPeriodFilter() {
    currentDmStartDate = '';
    currentDmEndDate = '';
    chatHoverDate = null;
    chatCalendarSelectionStep = 0;
    document.getElementById('dm-chat-calendar-popover')?.classList.add('hidden');
    document.getElementById('dm-chat-period-badge')?.classList.add('hidden');
    const btnLabel = document.getElementById('btn-chat-calendar-label');
    if (btnLabel) btnLabel.innerText = 'Período';

    if (currentSelectedThreadId) {
        selectDmThread(currentSelectedThreadId, currentSelectedParticipant, 0, false);
    }
}

function updateDmProgress() {
    const total = cachedDmThreads.length;
    const txtEl = document.getElementById('dm-progress-text');
    const barEl = document.getElementById('dm-progress-bar');
    if (!txtEl || !barEl) return;

    if (total === 0) {
        txtEl.innerText = '0 / 0 (0%)';
        barEl.style.width = '0%';
        return;
    }

    let readCount = 0;
    cachedDmThreads.forEach(t => {
        if (dmAnnotations[t.thread_id]?.is_read) {
            readCount++;
        }
    });

    const percent = Math.round((readCount / total) * 100);
    txtEl.innerText = `${readCount} / ${total} lidas (${percent}%)`;
    barEl.style.width = `${percent}%`;
}

function getThreadEvidenceCount(threadId) {
    if (!evidenceTagsMap || !threadId) return 0;
    let count = 0;
    const tIdStr = String(threadId);
    Object.values(evidenceTagsMap).forEach(ev => {
        if (String(ev.thread_id) === tIdStr) {
            count++;
        }
    });
    return count;
}

function setDmFilter(filterType) {
    currentDmFilter = filterType;
    const filterBtns = {
        'all': 'dm-filter-all',
        'unread': 'dm-filter-unread',
        'read': 'dm-filter-read',
        'starred': 'dm-filter-starred',
        'groups': 'dm-filter-groups',
        'tagged': 'dm-filter-tagged',
        'bookmarked': 'dm-filter-bookmarked'
    };

    Object.keys(filterBtns).forEach(k => {
        const btn = document.getElementById(filterBtns[k]);
        if (!btn) return;
        const isSelected = (k === filterType);
        if (isSelected) {
            btn.className = (k === 'groups' || k === 'tagged' || k === 'bookmarked')
                ? "py-1 px-1 rounded-md bg-pink-600 text-white font-bold transition shadow-xs flex items-center justify-center space-x-1 truncate"
                : "py-1 px-1 rounded-md bg-pink-600 text-white font-bold transition shadow-xs text-center truncate flex items-center justify-center space-x-1";
        } else {
            btn.className = (k === 'groups' || k === 'tagged' || k === 'bookmarked')
                ? "py-1 px-1 rounded-md bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition shadow-xs font-semibold flex items-center justify-center space-x-1 truncate"
                : "py-1 px-1 rounded-md bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition shadow-xs text-center truncate flex items-center justify-center space-x-1";
        }
    });

    renderFilteredDmThreads();
    lucide.createIcons();
}

function formatDmParticipants(participants) {
    if (!participants) return '';
    if (Array.isArray(participants)) {
        const unique = Array.from(new Set(participants.map(p => String(p).trim()).filter(Boolean)));
        return unique.join(', ');
    }
    return String(participants);
}

function handleDmThreadClick(threadId) {
    if (!cachedDmThreads) return;
    const thread = cachedDmThreads.find(t => String(t.thread_id) === String(threadId));
    if (!thread) {
        selectDmThread(threadId, '', 0);
        return;
    }
    
    const rawList = Array.isArray(thread.participants) ? thread.participants : [];
    const participants = Array.from(new Set(rawList.map(p => String(p).trim()).filter(Boolean)));
    const currentTarget = (window.currentTargetVanity || '').replace(/^@/, '').toLowerCase();
    const interlocutors = participants.filter(p => {
        const clean = String(p).replace(/^@/, '').toLowerCase();
        return !currentTarget || (clean !== currentTarget && !clean.includes('071_benee') && !clean.includes('benee'));
    });
    const displayParticipant = (interlocutors.length > 0 ? interlocutors : participants).join(', ') || `Thread ${thread.thread_id}`;

    selectDmThread(thread.thread_id, displayParticipant, thread.message_count);
}

function renderFilteredDmThreads() {
    const listElem = document.getElementById('dm-threads-list');
    if (!cachedDmThreads || cachedDmThreads.length === 0) {
        listElem.innerHTML = `<p class="text-xs text-slate-500 p-4 text-center">Nenhuma conversa encontrada.</p>`;
        return;
    }

    const filtered = cachedDmThreads.filter(t => {
        const ann = dmAnnotations[t.thread_id] || {};
        if (currentDmFilter === 'unread') return !ann.is_read;
        if (currentDmFilter === 'read') return !!ann.is_read;
        if (currentDmFilter === 'starred') return !!ann.is_starred;
        if (currentDmFilter === 'groups') return !!t.is_group;
        if (currentDmFilter === 'tagged') return getThreadEvidenceCount(t.thread_id) > 0;
        if (currentDmFilter === 'bookmarked') return !!ann.last_read_message_id;
        return true;
    });

    if (filtered.length === 0) {
        listElem.innerHTML = `<p class="text-xs text-slate-400 dark:text-slate-500 p-4 text-center italic">Nenhuma conversa com este filtro.</p>`;
        return;
    }

    let html = '';
    filtered.forEach(th => {
        const rawList = Array.isArray(th.participants) ? th.participants : [];
        const participants = Array.from(new Set(rawList.map(p => String(p).trim()).filter(Boolean)));
        const isSelected = String(th.thread_id) === String(currentSelectedThreadId);
        const selectedClass = isSelected ? 'bg-pink-500/15 border-l-4 border-l-pink-600 dark:bg-pink-500/20 font-semibold shadow-2xs' : 'hover:bg-slate-100 dark:hover:bg-slate-900/60 border-l-4 border-l-transparent';
        
        // Filtrar o alvo da exibição para destacar apenas o(s) interlocutor(es)
        const currentTarget = (window.currentTargetVanity || '').replace(/^@/, '').toLowerCase().trim();
        const interlocutors = participants.filter(p => {
            const clean = String(p).replace(/^@/, '').toLowerCase().trim();
            if (currentTarget && clean === currentTarget) return false;
            if (window.operationTargetHandles && window.operationTargetHandles.has(clean)) return false;
            if (clean.includes('071_benee') || clean.includes('benee')) return false;
            return true;
        });
        
        let displayParticipant = (interlocutors.length > 0 ? interlocutors : participants).join(', ') || `Thread ${th.thread_id}`;
        const firstHandle = (interlocutors[0] || participants[0] || '').replace(/^@/, '');
        const threadAvatarHtml = renderAvatarHtml(firstHandle, null, 'w-10 h-10 min-w-[40px] max-w-[40px] h-[40px]', 'text-xs');

        const ann = dmAnnotations[th.thread_id] || {};
        const isRead = !!ann.is_read;
        const isStarred = !!ann.is_starred;
        const hasBookmark = !!ann.last_read_message_id;
        const taggedCount = getThreadEvidenceCount(th.thread_id);

        const readBadge = isRead
            ? `<button onclick="toggleThreadReadFromList('${th.thread_id}', event)" class="w-3 h-3 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900 hover:scale-125 transition flex-shrink-0 block shadow-2xs" title="Conversa LIDA • Clique para marcar como Pendente"></button>`
            : `<button onclick="toggleThreadReadFromList('${th.thread_id}', event)" class="w-3 h-3 rounded-full bg-slate-300 dark:bg-slate-600 border-2 border-white dark:border-slate-900 hover:bg-emerald-500 hover:scale-125 transition flex-shrink-0 block shadow-2xs" title="Conversa PENDENTE • Clique para marcar como Lida"></button>`;

        const starIcon = isStarred
            ? `<button onclick="toggleStarFromList('${th.thread_id}', event)" title="Marcada como Relevante" class="text-amber-500 hover:text-amber-600 transition p-0.5"><i data-lucide="star" class="w-3.5 h-3.5 fill-amber-500"></i></button>`
            : `<button onclick="toggleStarFromList('${th.thread_id}', event)" title="Marcar como Relevante" class="text-slate-300 dark:text-slate-600 hover:text-amber-500 transition p-0.5"><i data-lucide="star" class="w-3.5 h-3.5"></i></button>`;

        const bookmarkBadge = hasBookmark
            ? `<span class="text-amber-500 flex items-center" title="Marcador de leitura ativo"><i data-lucide="bookmark" class="w-3 h-3 fill-amber-500"></i></span>`
            : '';

        const tagBadge = taggedCount > 0
            ? `<span class="px-1.5 py-0.2 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-600 dark:text-amber-400 font-bold text-[9px] flex items-center space-x-0.5 flex-shrink-0" title="${taggedCount} mensagem(ns) com tags de prova"><i data-lucide="tag" class="w-2.5 h-2.5 fill-amber-500"></i><span>${taggedCount}</span></span>`
            : '';

        // Formatação do snippet da última mensagem
        let snippet = '';
        const msgType = th.last_message_type || 'text';
        const content = (th.last_message_content || '').trim();
        if (msgType === 'audio') {
            snippet = `<span class="flex items-center space-x-1 text-purple-600 dark:text-purple-400 font-medium"><i data-lucide="mic" class="w-3 h-3"></i><span>Áudio</span></span>`;
        } else if (msgType === 'image' || msgType === 'photo') {
            snippet = `<span class="flex items-center space-x-1 text-blue-600 dark:text-cyan-400 font-medium"><i data-lucide="image" class="w-3 h-3"></i><span>Foto</span></span>`;
        } else if (msgType === 'video') {
            snippet = `<span class="flex items-center space-x-1 text-pink-600 dark:text-pink-400 font-medium"><i data-lucide="video" class="w-3 h-3"></i><span>Vídeo</span></span>`;
        } else if (msgType === 'call') {
            snippet = `<span class="flex items-center space-x-1 text-amber-600 dark:text-amber-400 font-medium"><i data-lucide="phone-call" class="w-3 h-3"></i><span>Chamada</span></span>`;
        } else if (content) {
            const safe = escapeHtml(content);
            const highlighted = currentDmSearchQuery ? highlightSearchTerms(safe, currentDmSearchQuery) : safe;
            snippet = `<span class="text-slate-500 dark:text-slate-400 truncate">${highlighted}</span>`;
        } else {
            snippet = `<span class="text-slate-400 dark:text-slate-500 italic">Sem mensagens</span>`;
        }

        // Formatação da data
        let dateDisplay = '---';
        if (th.last_activity_brt) {
            const m = th.last_activity_brt.match(/^(\d{2}\/\d{2}(?:\/\d{2,4})?)\s+(\d{2}:\d{2})/);
            if (m) {
                dateDisplay = `${m[1]} ${m[2]}`;
            } else {
                dateDisplay = th.last_activity_brt.split(' ')[0] || th.last_activity_brt;
            }
        } else if (th.last_activity_utc) {
            dateDisplay = th.last_activity_utc.slice(0, 10);
        }

        html += `
            <div onclick="handleDmThreadClick('${th.thread_id}')" class="p-2.5 cursor-pointer transition ${selectedClass} flex items-center space-x-3">
                <div class="relative flex-shrink-0">
                    ${threadAvatarHtml}
                    <div class="absolute -bottom-0.5 -right-0.5">${readBadge}</div>
                </div>
                <div class="min-w-0 flex-1">
                    <div class="flex items-center justify-between">
                        <h5 class="text-xs font-bold text-slate-800 dark:text-slate-200 truncate flex items-center" title="${escapeHtml(displayParticipant)}">
                            ${th.is_group ? '<i data-lucide="users" class="w-3.5 h-3.5 text-indigo-500 flex-shrink-0 mr-1.5" title="Conversa em Grupo"></i>' : ''}
                            <span class="truncate">${escapeHtml(displayParticipant)}</span>
                        </h5>
                        <div class="flex items-center space-x-1.5 flex-shrink-0 ml-1.5">
                            ${bookmarkBadge}
                            ${starIcon}
                            <span class="font-mono text-[9px] text-slate-400 dark:text-slate-500">${dateDisplay}</span>
                        </div>
                    </div>

                    <div class="flex items-center justify-between mt-1 text-[11px] gap-2">
                        <div class="min-w-0 flex-1 truncate text-[11px]">
                            ${snippet}
                        </div>
                        <div class="flex items-center space-x-1 flex-shrink-0">
                            ${tagBadge}
                            <span class="px-1.5 py-0.2 rounded-full bg-slate-200/70 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-mono text-[9px] font-semibold">${th.message_count} msgs</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });

    listElem.innerHTML = html;
    lucide.createIcons();
}

function toggleGroupParticipantsPopover(e) {
    if (e) e.stopPropagation();
    toggleDmChatDetailsDrawer('members');
}

let isDmSidebarCollapsed = false;

function toggleDmSidebar() {
    const sidebar = document.getElementById('dm-sidebar-col');
    const chatCol = document.getElementById('dm-chat-col');
    const btn = document.getElementById('btn-toggle-dm-sidebar');
    if (!sidebar || !chatCol) return;

    isDmSidebarCollapsed = !isDmSidebarCollapsed;

    if (isDmSidebarCollapsed) {
        sidebar.classList.add('hidden');
        chatCol.classList.remove('md:col-span-2');
        chatCol.classList.add('md:col-span-3');
        if (btn) {
            btn.innerHTML = `<i data-lucide="panel-left-open" class="w-4 h-4"></i>`;
            btn.title = "Mostrar lista de conversas";
            btn.classList.add('bg-pink-500/10', 'text-pink-600', 'border', 'border-pink-500/20');
        }
    } else {
        sidebar.classList.remove('hidden');
        chatCol.classList.remove('md:col-span-3');
        chatCol.classList.add('md:col-span-2');
        if (btn) {
            btn.innerHTML = `<i data-lucide="panel-left-close" class="w-4 h-4"></i>`;
            btn.title = "Recolher lista de conversas (Modo Tela Ampla)";
            btn.classList.remove('bg-pink-500/10', 'text-pink-600', 'border', 'border-pink-500/20');
        }
    }
    lucide.createIcons();
}

async function selectDmThread(threadId, participantLabel, msgCount, autoMarkRead = true, targetMessageId = null) {
    currentSelectedThreadId = String(threadId);
    currentSelectedParticipant = participantLabel;

    renderFilteredDmThreads();

    const headerTitle = document.getElementById('dm-current-participant');
    const headerSubtitleText = document.getElementById('dm-header-subtitle-text');
    const btnDetails = document.getElementById('btn-toggle-chat-details');
    const badgeDetails = document.getElementById('dm-chat-details-badge');
    const igLink = document.getElementById('dm-header-ig-link');
    const headerAvatarImg = document.getElementById('dm-header-avatar-img');
    const headerAvatarFallback = document.getElementById('dm-header-avatar-fallback');
    const drawerMembersCount = document.getElementById('drawer-members-count');
    const tabBtnMembers = document.getElementById('tab-btn-members');
    const btnBookmark = document.getElementById('btn-jump-bookmark');
    const btnRead = document.getElementById('btn-toggle-read-status');
    const btnStar = document.getElementById('btn-toggle-star-status');
    const btnDateFilter = document.getElementById('btn-toggle-date-filter');
    const container = document.getElementById('dm-messages-container');

    activeDmMemberFilter = null;

    let participantsArr = [];
    let interlocutorUidFromThread = null;
    let sendersUidsMap = {};
    if (cachedDmThreads) {
        const found = cachedDmThreads.find(t => String(t.thread_id) === String(threadId));
        if (found) {
            const rawList = Array.isArray(found.participants) ? found.participants : [];
            participantsArr = Array.from(new Set(rawList.map(p => String(p).trim()).filter(Boolean)));
            participantLabel = formatDmParticipants(participantsArr);
            msgCount = found.message_count;
            interlocutorUidFromThread = found.interlocutor_uid || null;
            sendersUidsMap = found.senders_uids_map || {};
        }
    }
    window.currentDmSendersUidsMap = sendersUidsMap;

    // Filtrar o alvo dos participantes para focar exclusivamente no interlocutor
    const currentTarget = (window.currentTargetVanity || '').replace(/^@/, '').toLowerCase().trim();
    const interlocutors = participantsArr.filter(p => {
        const clean = String(p).replace(/^@/, '').toLowerCase().trim();
        if (currentTarget && clean === currentTarget) return false;
        if (window.operationTargetHandles && window.operationTargetHandles.has(clean)) return false;
        if (Array.isArray(window.currentTargetAccounts)) {
            if (window.currentTargetAccounts.some(a => a.vanity_name && a.vanity_name.replace(/^@/, '').toLowerCase().trim() === clean)) return false;
        }
        return true;
    });
    const mainInterlocutor = (interlocutors[0] || participantsArr[0] || '').replace(/^@/, '');
    window.currentSelectedInterlocutor = mainInterlocutor;

    if (!interlocutorUidFromThread && mainInterlocutor && sendersUidsMap[mainInterlocutor.toLowerCase()]) {
        interlocutorUidFromThread = sendersUidsMap[mainInterlocutor.toLowerCase()];
    }
    window.currentSelectedInterlocutorUid = interlocutorUidFromThread;

    const displayTitle = mainInterlocutor ? `@${mainInterlocutor}` : (participantLabel || `Thread ${threadId}`);

    if (headerTitle) {
        headerTitle.innerText = displayTitle;
        headerTitle.title = displayTitle;
    }

    // Configurar avatar do cabeçalho
    const cachedHeaderAvatar = getCachedAvatarSrc(mainInterlocutor);
    if (cachedHeaderAvatar && headerAvatarImg && headerAvatarFallback) {
        headerAvatarImg.src = cachedHeaderAvatar;
        headerAvatarImg.classList.remove('hidden');
        headerAvatarFallback.classList.add('hidden');
    } else if (headerAvatarFallback) {
        if (headerAvatarImg) headerAvatarImg.classList.add('hidden');
        const color = getAvatarColorPair(mainInterlocutor || 'IG');
        headerAvatarFallback.className = `w-full h-full ${color.bg} border ${color.border} flex items-center justify-center font-bold ${color.text} text-xs`;
        headerAvatarFallback.innerText = getAvatarInitials(mainInterlocutor || 'IG');
        headerAvatarFallback.classList.remove('hidden');
    }

    // Link do perfil no cabeçalho (direcionando prioritariamente para o ID numérico)
    if (igLink) {
        if (interlocutorUidFromThread) {
            igLink.href = getIgUidUrl(interlocutorUidFromThread);
            igLink.title = `Abrir perfil no Instagram por ID (${interlocutorUidFromThread})`;
            igLink.classList.remove('hidden');
        } else if (mainInterlocutor && mainInterlocutor !== 'Thread' && !mainInterlocutor.includes(' ')) {
            igLink.href = getIgProfileUrl(mainInterlocutor);
            igLink.title = `Abrir perfil @${mainInterlocutor} no Instagram`;
            igLink.classList.remove('hidden');
        } else {
            igLink.href = '#';
            igLink.classList.add('hidden');
        }
    }

    // Configurar grupo caso seja grupo (> 2 participantes no total)
    window.currentGroupParticipants = participantsArr;
    const isGroup = participantsArr.length > 2;

    if (drawerMembersCount) drawerMembersCount.innerText = `(${participantsArr.length})`;
    if (btnDetails) btnDetails.classList.remove('hidden');

    if (isGroup) {
        if (headerSubtitleText) {
            headerSubtitleText.innerHTML = `
                <span class="inline-flex items-center space-x-1 font-semibold text-indigo-600 dark:text-indigo-400">
                    <i data-lucide="users" class="w-3 h-3"></i>
                    <span>${participantsArr.length} participantes</span>
                </span>
                <span class="text-slate-300 dark:text-slate-700 mx-1">•</span>
                <span id="dm-header-subtitle-media-count">0 mídias</span>
                <span class="text-slate-300 dark:text-slate-700 mx-1">•</span>
                <span class="font-mono text-slate-400">ID: ${escapeHtml(threadId)}</span>
            `;
            if (window.lucide) lucide.createIcons();
        }
        if (badgeDetails) {
            badgeDetails.innerText = `(${participantsArr.length})`;
        }
        if (tabBtnMembers) tabBtnMembers.classList.remove('hidden');
    } else {
        if (headerSubtitleText) {
            headerSubtitleText.innerHTML = `
                <span id="dm-header-subtitle-media-count">0 mídias</span>
                <span class="text-slate-300 dark:text-slate-700 mx-1">•</span>
                <span class="font-mono text-slate-400">Thread ID: ${escapeHtml(threadId)}</span>
            `;
            if (window.lucide) lucide.createIcons();
        }
        if (badgeDetails) {
            badgeDetails.innerText = '';
        }
        if (tabBtnMembers) tabBtnMembers.classList.add('hidden');
        if (currentDmDetailsTab === 'members') {
            switchDmDetailsTab('media');
        }
    }

    // O status de leitura permanece manual (sob comando do analista)
    // Atualizar botões de ação do analista
    const ann = dmAnnotations[threadId] || {};
    if (btnDateFilter) btnDateFilter.classList.remove('hidden');
    if (btnRead) {
        btnRead.classList.remove('hidden');
        btnRead.innerHTML = ann.is_read
            ? `<i data-lucide="check-check" class="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400"></i><span class="text-emerald-600 dark:text-emerald-400 font-bold">Lida</span>`
            : `<i data-lucide="check" class="w-3.5 h-3.5 text-slate-500"></i><span class="text-slate-600 dark:text-slate-400">Pendente</span>`;
    }

    if (btnStar) {
        btnStar.classList.remove('hidden');
        btnStar.innerHTML = ann.is_starred
            ? `<i data-lucide="star" class="w-3.5 h-3.5 text-amber-500 fill-amber-500"></i>`
            : `<i data-lucide="star" class="w-3.5 h-3.5 text-slate-400"></i>`;
    }

    const bookmarkedMsgId = ann.last_read_message_id;
    if (btnBookmark) {
        if (bookmarkedMsgId) {
            btnBookmark.classList.remove('hidden');
        } else {
            btnBookmark.classList.add('hidden');
        }
    }

    if (container) container.innerHTML = `<div class="text-center py-12 text-slate-400 text-xs">Carregando mensagens...</div>`;

    try {
        let url = `/api/instagram/threads/${threadId}/messages?operation_id=${window.currentOpId}`;
        if (window.currentTargetId) url += `&target_id=${window.currentTargetId}`;
        if (currentDmStartDate) url += `&start_date=${encodeURIComponent(currentDmStartDate)}`;
        if (currentDmEndDate) url += `&end_date=${encodeURIComponent(currentDmEndDate)}`;

        const res = await fetch(url);
        const messages = await res.json();
        window.currentThreadMessages = messages;

        // Garantir preenchimento dos participantes caso a listagem lateral ainda não tenha carregado
        if (participantsArr.length === 0 && Array.isArray(messages) && messages.length > 0) {
            const rawP = messages[0].participants;
            if (Array.isArray(rawP)) {
                participantsArr = Array.from(new Set(rawP.map(p => String(p).trim()).filter(Boolean)));
            } else if (typeof rawP === 'string' && rawP.trim().startsWith('[')) {
                try {
                    participantsArr = Array.from(new Set(JSON.parse(rawP).map(p => String(p).trim()).filter(Boolean)));
                } catch(e) {}
            }
            window.currentGroupParticipants = participantsArr;
            if (drawerMembersCount) drawerMembersCount.innerText = `(${participantsArr.length})`;
        }
        const isGroupFinal = participantsArr.length > 2;

        // Identificar UID do interlocutor pelas mensagens carregadas ou pela thread
        let interlocutorUid = null;
        if (mainInterlocutor) {
            const interMsg = messages.find(m => m.sender_username && m.sender_username.replace(/^@/, '').toLowerCase() === mainInterlocutor.toLowerCase() && m.sender_id);
            if (interMsg && interMsg.sender_id) interlocutorUid = interMsg.sender_id;
        }
        if (!interlocutorUid) {
            const nonTargetMsg = messages.find(m => !m.is_target_sender && m.sender_id);
            if (nonTargetMsg && nonTargetMsg.sender_id) interlocutorUid = nonTargetMsg.sender_id;
        }
        if (!interlocutorUid) {
            interlocutorUid = interlocutorUidFromThread || window.currentSelectedInterlocutorUid || null;
        }
        window.currentSelectedInterlocutorUid = interlocutorUid;

        // Atualizar o link no cabeçalho (#dm-header-ig-link) direcionando para o ID permanente
        if (igLink) {
            if (interlocutorUid) {
                igLink.href = getIgUidUrl(interlocutorUid);
                igLink.title = `Abrir perfil no Instagram por ID (${interlocutorUid})`;
                igLink.classList.remove('hidden');
            } else if (mainInterlocutor && mainInterlocutor !== 'Thread' && !mainInterlocutor.includes(' ')) {
                igLink.href = getIgProfileUrl(mainInterlocutor);
                igLink.title = `Abrir perfil @${mainInterlocutor} no Instagram`;
                igLink.classList.remove('hidden');
            }
        }

        // Atualizar contadores de mídias da conversa no subtítulo e no botão de detalhes
        const threadMedia = messages.filter(m => m.media_path);
        
        if (headerSubtitleText) {
            if (isGroupFinal) {
                headerSubtitleText.innerHTML = `
                    <span class="inline-flex items-center space-x-1 font-semibold text-indigo-600 dark:text-indigo-400">
                        <i data-lucide="users" class="w-3 h-3"></i>
                        <span>${participantsArr.length} participantes</span>
                    </span>
                    <span class="text-slate-300 dark:text-slate-700 mx-1">•</span>
                    <span>${threadMedia.length} mídias</span>
                    <span class="text-slate-300 dark:text-slate-700 mx-1">•</span>
                    <span class="font-mono text-slate-400">ID: ${escapeHtml(threadId)}</span>
                `;
            } else {
                const uidSub = interlocutorUid ? `
                    <span class="font-mono text-purple-600 dark:text-purple-400 font-semibold cursor-pointer hover:underline" onclick="copyDmCurrentUid()" title="Clique para copiar o Instagram UID (${interlocutorUid})">ID: <span id="dm-header-uid-text">${escapeHtml(interlocutorUid)}</span></span>
                    <span class="text-slate-300 dark:text-slate-700 mx-1">•</span>
                ` : '';
                headerSubtitleText.innerHTML = `
                    ${uidSub}
                    <span>${threadMedia.length} mídias</span>
                    <span class="text-slate-300 dark:text-slate-700 mx-1">•</span>
                    <span class="font-mono text-slate-400">Thread ID: ${escapeHtml(threadId)}</span>
                `;
            }
            if (window.lucide) lucide.createIcons();
        }

        if (badgeDetails) {
            if (isGroupFinal) {
                badgeDetails.innerText = `(${participantsArr.length})`;
            } else {
                badgeDetails.innerText = threadMedia.length > 0 ? `(${threadMedia.length})` : '';
            }
        }
        const drawerMediaCount = document.getElementById('drawer-media-count');
        if (drawerMediaCount) {
            drawerMediaCount.innerText = `(${threadMedia.length})`;
        }
        if (tabBtnMembers) {
            if (isGroupFinal) tabBtnMembers.classList.remove('hidden');
            else tabBtnMembers.classList.add('hidden');
        }

        // Atualizar botão de transcrição em lote de áudios da conversa
        const threadAudios = messages.filter(m => m.message_type === 'audio');
        const pendingAudios = threadAudios.filter(m => !m.transcription || !m.transcription.trim());
        const btnTranscribeAll = document.getElementById('btn-transcribe-thread-audios');
        const badgePendingAudios = document.getElementById('dm-pending-audios-count');
        if (btnTranscribeAll && badgePendingAudios) {
            if (threadAudios.length > 0) {
                badgePendingAudios.innerText = `(${pendingAudios.length}/${threadAudios.length})`;
                btnTranscribeAll.classList.remove('hidden');
                if (pendingAudios.length === 0) {
                    btnTranscribeAll.title = "Todos os áudios desta conversa já foram transcritos";
                    btnTranscribeAll.classList.add('opacity-75');
                } else {
                    btnTranscribeAll.title = `Transcrever ${pendingAudios.length} áudios pendentes com Whisper`;
                    btnTranscribeAll.classList.remove('opacity-75');
                }
            } else {
                btnTranscribeAll.classList.add('hidden');
            }
        }

        // Atualizar contador de evidências marcadas desta conversa
        const taggedEvCount = messages.filter(m => !!evidenceTagsMap[String(m.id)]).length;
        const badgeEvidence = document.getElementById('evidence-count-badge');
        if (badgeEvidence) {
            badgeEvidence.innerText = `(${taggedEvCount})`;
        }

        const drawer = document.getElementById('dm-chat-details-drawer');
        if (drawer && !drawer.classList.contains('hidden')) {
            if (currentDmDetailsTab === 'members') {
                renderDmGroupMembersDrawer();
            } else {
                renderDmChatMediaDrawer();
            }
        }

        renderDmChatMessages(targetMessageId);
    } catch (err) {
        console.error("Erro ao carregar mensagens:", err);
    }
}

function renderDmChatMessages(targetMessageId = null, preserveScroll = false) {
    const container = document.getElementById('dm-messages-container');
    const messages = window.currentThreadMessages || [];
    if (!container) return;

    const savedScrollTop = preserveScroll ? container.scrollTop : 0;

    if (messages.length === 0) {
        const tagFilterBarEl = document.getElementById('dm-chat-tag-filter-bar');
        if (tagFilterBarEl) {
            tagFilterBarEl.classList.add('hidden');
            tagFilterBarEl.innerHTML = '';
        }
        container.innerHTML = `<p class="text-xs text-slate-500 text-center py-8">Nenhuma mensagem encontrada neste filtro.</p>`;
        lucide.createIcons();
        return;
    }

    // 1. Auto-reset automático do filtro de tags se a tag ativa não existir mais
    if (activeDmTagFilter && activeDmTagFilter !== 'all') {
        const hasMatchingTag = messages.some(m => {
            const ev = evidenceTagsMap[String(m.id)];
            if (!ev) return false;
            const tList = ev.tags || (ev.tag_label ? [ev.tag_label] : ['Prova Chave']);
            return tList.some(t => t.toLowerCase() === activeDmTagFilter.toLowerCase());
        });
        if (!hasMatchingTag) {
            activeDmTagFilter = 'all';
        }
    }

    // 2. Renderizar a barra de tags fora do container de mensagens com reatividade imediata
    renderDmChatTagFilterBar();

    // 3. Filtrar mensagens se houver filtro ativo (com fallback auto-reset)
    let displayedMessages = messages;
    if (activeDmTagFilter !== 'all') {
        displayedMessages = messages.filter(m => {
            const ev = evidenceTagsMap[String(m.id)];
            if (!ev) return false;
            const tList = ev.tags || (ev.tag_label ? [ev.tag_label] : ['Prova Chave']);
            return tList.some(t => t.toLowerCase() === activeDmTagFilter.toLowerCase());
        });
        if (displayedMessages.length === 0) {
            activeDmTagFilter = 'all';
            displayedMessages = messages;
        }
    }

    // 3.1 Filtrar mensagens por membro do grupo (se houver filtro ativo)
    if (activeDmMemberFilter) {
        const cleanFilter = activeDmMemberFilter.replace(/^@/, '').toLowerCase().trim();
        displayedMessages = displayedMessages.filter(m => {
            const senderUser = (m.sender_username || '').replace(/^@/, '').toLowerCase().trim();
            const senderId = (m.sender_id || '').toLowerCase().trim();
            return senderUser === cleanFilter || senderId === cleanFilter;
        });
    }

    // 3.2 Atualizar badges visuais do filtro de membro
    const memberBadge = document.getElementById('dm-chat-member-badge');
    const memberBadgeText = document.getElementById('dm-chat-member-badge-text');
    const drawerMemberFilterBar = document.getElementById('dm-member-active-filter-bar');
    const drawerMemberFilterName = document.getElementById('dm-member-active-filter-name');

    if (activeDmMemberFilter) {
        if (memberBadge && memberBadgeText) {
            memberBadgeText.innerHTML = `
                <i data-lucide="user-check" class="w-3.5 h-3.5 text-indigo-500 flex-shrink-0"></i>
                <span>Exibindo mensagens enviadas por <strong>@${escapeHtml(activeDmMemberFilter.replace(/^@/, ''))}</strong> (${displayedMessages.length} encontradas)</span>
            `;
            memberBadge.classList.remove('hidden');
        }
        if (drawerMemberFilterBar && drawerMemberFilterName) {
            drawerMemberFilterName.innerText = `@${activeDmMemberFilter.replace(/^@/, '')} (${displayedMessages.length} msgs)`;
            drawerMemberFilterBar.classList.remove('hidden');
        }
    } else {
        if (memberBadge) memberBadge.classList.add('hidden');
        if (drawerMemberFilterBar) drawerMemberFilterBar.classList.add('hidden');
    }

    let html = '';
    let foundBookmark = false;
    let lastRenderedDay = null;
    const ann = dmAnnotations[currentSelectedThreadId] || {};
    const bookmarkedMsgId = ann.last_read_message_id;

    if (displayedMessages.length === 0) {
        if (activeDmMemberFilter) {
            html += `<p class="text-xs text-slate-500 text-center py-12">Nenhuma mensagem enviada por <b>@${escapeHtml(activeDmMemberFilter.replace(/^@/, ''))}</b> encontrada nesta conversa.</p>`;
        } else {
            html += `<p class="text-xs text-slate-500 text-center py-12">Nenhuma mensagem com a tag <b>"${escapeHtml(activeDmTagFilter)}"</b> encontrada nesta conversa.</p>`;
        }
    }

    displayedMessages.forEach(m => {
        // Divisor temporal de data agrupado por dia (Instagram / WhatsApp Style)
        const dateRef = m.timestamp_brt || m.timestamp_utc || '';
        const rawDay = dateRef.split(' ')[0];
        if (rawDay && rawDay !== lastRenderedDay) {
            lastRenderedDay = rawDay;
            const dayLabel = formatChatDayHeader(dateRef);
            html += `
                <div class="flex items-center justify-center my-3 select-none">
                    <div class="h-px bg-slate-200/80 dark:bg-slate-800 flex-1"></div>
                    <span class="mx-3 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400 text-[10px] font-semibold border border-slate-200 dark:border-slate-800 shadow-2xs">
                        📅 ${escapeHtml(dayLabel)}
                    </span>
                    <div class="h-px bg-slate-200/80 dark:bg-slate-800 flex-1"></div>
                </div>
            `;
        }

        const currentTargetVanity = (window.currentTargetVanity || '').replace(/^@/, '').toLowerCase().trim();
        const currentTargetUid = String(window.currentTargetUid || '').trim();
        const senderClean = (m.sender_username || '').replace(/^@/, '').toLowerCase().trim();
        const senderIdStr = String(m.sender_id || '').trim();

        let isTarget = (m.is_target_sender === 1 || m.is_target_sender === true || m.is_target_sender === '1')
            || (currentTargetVanity && senderClean === currentTargetVanity)
            || (currentTargetUid && senderIdStr === currentTargetUid)
            || (window.operationTargetHandles && window.operationTargetHandles.has(senderClean))
            || (window.operationTargetUids && window.operationTargetUids.has(senderIdStr));

        if (!isTarget && Array.isArray(window.currentTargetAccounts)) {
            if (window.currentTargetAccounts.some(a => 
                (a.vanity_name && a.vanity_name.replace(/^@/, '').toLowerCase().trim() === senderClean) ||
                (a.target_uid && String(a.target_uid).trim() === senderIdStr)
            )) {
                isTarget = true;
            }
        }

        const alignClass = isTarget ? 'justify-end' : 'justify-start';
        const isBookmarked = bookmarkedMsgId && (m.id === bookmarkedMsgId);
        
        const evInfo = evidenceTagsMap[String(m.id)];
        const isEvidence = !!evInfo;
        const msgTags = evInfo ? (evInfo.tags || (evInfo.tag_label ? [evInfo.tag_label] : ['Prova Chave'])) : [];

        if (isBookmarked) {
            foundBookmark = true;
            const bookmarkTimestamp = formatAnalystDate(ann.updated_at);
            html += `
                <div id="dm-msg-bookmark-anchor" class="py-2.5 my-2 flex items-center justify-center space-x-2">
                    <div class="h-px bg-amber-500/40 flex-1"></div>
                    <div class="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-700 dark:text-amber-300 font-bold text-[10px] flex items-center space-x-2 shadow-xs">
                        <i data-lucide="bookmark" class="w-3 h-3 text-amber-500 fill-amber-500"></i>
                        <span>📍 VOCÊ PAROU AQUI • Marcado em ${bookmarkTimestamp}</span>
                        <button onclick="removeThreadBookmark(event)" title="Remover este marcador de leitura" class="ml-1 px-1.5 py-0.5 rounded text-[9px] font-semibold bg-red-500/15 hover:bg-red-500/25 text-red-600 dark:text-red-400 border border-red-500/20 transition flex items-center space-x-0.5">
                            <i data-lucide="x" class="w-2.5 h-2.5"></i>
                            <span>Desmarcar</span>
                        </button>
                    </div>
                    <div class="h-px bg-amber-500/40 flex-1"></div>
                </div>
            `;
        }

        let bubbleBorder = '';
        if (isEvidence) {
            bubbleBorder = 'ring-2 ring-amber-400 shadow-md';
        } else if (isBookmarked) {
            bubbleBorder = 'ring-2 ring-emerald-500/60 ring-offset-1';
        }

        const bubbleBg = isTarget
            ? `bg-pink-600 text-white rounded-br-none shadow-sm ${bubbleBorder}`
            : `bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-bl-none border border-slate-200 dark:border-slate-700 shadow-sm ${bubbleBorder}`;

        const senderHandle = m.sender_username ? `@${m.sender_username}` : (m.sender_id ? `ID: ${m.sender_id}` : 'Desconhecido');
        const authorColor = getAvatarColorPair(m.sender_username || m.sender_id || 'user');
        
        let authorTag = '';
        if (isTarget) {
            const accounts = window.currentTargetAccounts || [];
            if (accounts.length > 1) {
                authorTag = `<span class="text-[10px] text-pink-100 font-bold flex items-center space-x-1 max-w-[240px] truncate" title="${escapeHtml(senderHandle)}"><span>Investigado</span><span class="px-1.5 py-0.2 rounded-full bg-pink-900/60 text-pink-100 text-[9px] border border-pink-300/40">Via ${escapeHtml(senderHandle)}</span></span>`;
            } else {
                authorTag = `<span class="text-[10px] text-pink-100 font-bold flex items-center space-x-1 max-w-[140px] sm:max-w-[180px] truncate" title="${escapeHtml(senderHandle)}"><span>Investigado (${escapeHtml(senderHandle)})</span></span>`;
            }
        } else {
            const authorHref = m.sender_id ? getIgUidUrl(m.sender_id) : getIgProfileUrl(m.sender_username);
            const authorTitle = m.sender_id ? `Abrir perfil no Instagram por ID (${m.sender_id})` : `Abrir perfil @${escapeHtml(m.sender_username || '')}`;
            authorTag = `<a href="${authorHref}" target="_blank" rel="noopener noreferrer" class="text-[10px] ${authorColor.text} font-bold hover:underline flex items-center space-x-0.5 truncate max-w-[200px]" title="${authorTitle}"><span>${escapeHtml(senderHandle)}</span><i data-lucide="external-link" class="w-2.5 h-2.5 opacity-70 flex-shrink-0"></i></a>`;
        }

        const senderAvatarHtml = !isTarget ? renderAvatarHtml(m.sender_username, m.sender_id, 'w-6 h-6', 'text-[9px]') : '';

        let mediaHtml = '';
        if (m.media_path) {
            if (m.message_type === 'audio') {
                const isTranscribed = !!(m.transcription && m.transcription.trim());
                const isEdited = m.transcription_status === 'edited' || m.transcribed_by === 'analyst';
                const transBadge = isEdited ? '👤 Revisada pelo Analista' : '📝 Whisper small';
                
                let transcriptionHtml = '';
                if (isTranscribed) {
                    transcriptionHtml = `
                        <div id="transcription-box-${m.id}" class="mt-2 p-2.5 rounded-xl ${isTarget ? 'bg-black/20 text-white border border-white/20' : 'bg-slate-100 dark:bg-slate-950/70 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-800'} space-y-1.5 text-xs select-text">
                            <div class="flex items-center justify-between text-[10px] ${isTarget ? 'text-white/80' : 'text-slate-500 dark:text-slate-400'} select-none">
                                <span class="font-bold flex items-center space-x-1">
                                    <i data-lucide="file-text" class="w-3 h-3 text-indigo-400"></i>
                                    <span>${transBadge}</span>
                                </span>
                                <div class="flex items-center space-x-1.5">
                                    <button onclick="copyTranscriptionText('${m.id}')" class="hover:underline flex items-center space-x-0.5" title="Copiar texto da transcrição">
                                        <i data-lucide="copy" class="w-3 h-3"></i>
                                        <span>Copiar</span>
                                    </button>
                                    <span>•</span>
                                    <button onclick="openEditTranscriptionModal(${m.id})" class="hover:underline flex items-center space-x-0.5 text-amber-500 hover:text-amber-400 font-semibold" title="Editar transcrição pericial">
                                        <i data-lucide="edit-3" class="w-3 h-3"></i>
                                        <span>Editar</span>
                                    </button>
                                </div>
                            </div>
                            <p id="transcription-text-${m.id}" class="text-[11px] leading-relaxed italic font-medium font-sans">"${currentDmSearchQuery ? highlightSearchTerms(escapeHtml(m.transcription || ''), currentDmSearchQuery) : escapeHtml(m.transcription || '')}"</p>
                        </div>
                    `;
                }

                mediaHtml = `
                    <div class="mt-2 pt-2 border-t ${isTarget ? 'border-white/20' : 'border-slate-200 dark:border-slate-700/60'} flex flex-wrap items-center gap-2">
                        <audio id="audio-player-${m.id}" controls class="w-52 max-w-full h-8 outline-none rounded-lg">
                            <source src="${m.media_path}" type="audio/mpeg">
                            <source src="${m.media_path}" type="audio/aac">
                            <source src="${m.media_path}" type="audio/ogg">
                            Seu navegador não suporta áudio.
                        </audio>
                        <button onclick="toggleAudioSpeed('audio-player-${m.id}', this)" class="btn-audio-speed px-2 py-1 rounded-lg text-[11px] font-mono font-bold ${isTarget ? 'bg-white/20 hover:bg-white/30 text-white border border-white/30' : 'bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 border border-slate-300 dark:border-slate-600'} transition shadow-xs flex items-center space-x-0.5 select-none flex-shrink-0" title="Alternar velocidade global do áudio (1.0x, 1.25x, 1.5x, 2.0x)">
                            <span>${getGlobalAudioSpeedLabel()}</span>
                        </button>
                        ${!isTranscribed ? `
                            <button id="btn-transcribe-${m.id}" onclick="transcribeAudioMessage(${m.id}, this)" class="px-2.5 py-1 rounded-lg text-[11px] font-semibold ${isTarget ? 'bg-white/20 hover:bg-white/30 text-white border border-white/30' : 'bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800'} transition shadow-xs flex items-center space-x-1.5 flex-shrink-0" title="Transcrever este áudio com Whisper small">
                                <i data-lucide="mic" class="w-3.5 h-3.5"></i>
                                <span>Transcrever</span>
                            </button>
                        ` : ''}
                    </div>
                    ${transcriptionHtml}
                `;
            } else if (m.message_type === 'image') {
                mediaHtml = `
                    <div class="mt-1.5 cursor-pointer group/media relative overflow-hidden rounded-lg border border-slate-200 dark:border-white/20 w-56 h-44 bg-slate-200 dark:bg-slate-700/50" onclick="openMediaViewer('${m.media_path}', 'image', '${escapeHtml(m.sender_username || '')}')" title="Clique para ampliar">
                        <img src="${m.media_path}" class="w-full h-full object-cover group-hover/media:scale-[1.02] transition duration-200" loading="lazy">
                        <div class="absolute inset-0 bg-black/40 opacity-0 group-hover/media:opacity-100 flex items-center justify-center transition text-white text-xs space-x-1.5 font-bold backdrop-blur-[1px]">
                            <i data-lucide="zoom-in" class="w-4 h-4"></i>
                            <span>Ampliar</span>
                        </div>
                    </div>
                `;
            } else if (m.message_type === 'video') {
                mediaHtml = `
                    <div class="mt-1.5 overflow-hidden rounded-xl border border-slate-200 dark:border-white/20 w-64 max-w-full bg-slate-950 shadow-md">
                        <video controls preload="metadata" class="w-full max-h-56 rounded-t-xl outline-none bg-black">
                            <source src="${m.media_path}" type="video/mp4">
                            Seu navegador não suporta vídeos.
                        </video>
                    </div>
                `;
            }

            if (isBookmarked) foundBookmark = true;
        }

        const pinClasses = isBookmarked
            ? 'opacity-100 text-amber-400 hover:text-amber-500'
            : 'opacity-0 group-hover:opacity-100 text-slate-300 hover:text-amber-400';

        const pinTitle = isBookmarked
            ? 'Marcador de leitura ativo (Onde Parei) • Clique para remover'
            : 'Marcar como Onde Parei';

        const pinOnClick = isBookmarked
            ? `removeDmBookmark(${m.id})`
            : `setDmBookmark(${m.id})`;

        const tagClasses = isEvidence
            ? 'opacity-100 text-amber-500 hover:text-amber-400'
            : 'opacity-0 group-hover:opacity-100 text-slate-300 hover:text-amber-400';

        const tagTitle = isEvidence
            ? `Evidência (${escapeHtml(msgTags.join(', '))}) • Clique para editar tags`
            : 'Classificar como evidência';

        const evidenceBtn = `
            <button id="tag-btn-${m.id}" onclick="toggleEvidenceTagPopover(${m.id}, event)" title="${tagTitle}" class="${tagClasses} p-0.5 transition">
                <i data-lucide="tag" class="w-3.5 h-3.5 ${isEvidence ? 'text-amber-500 fill-amber-500' : ''}"></i>
            </button>
        `;

        const tagsBadgesHtml = isEvidence ? renderMessageTagBadges(m.id, msgTags, isTarget) : '';

        let contentBodyHtml = '';
        if (m.content) {
            contentBodyHtml = formatMessageContentWithLinks(m.content, isTarget);
        } else if (!m.media_path) {
            contentBodyHtml = `
                <div class="flex items-center space-x-1.5 py-1 px-2 rounded-lg ${isTarget ? 'bg-white/10 text-pink-100' : 'bg-slate-100 dark:bg-slate-900/60 text-slate-600 dark:text-slate-400'} text-[11px] italic font-medium my-0.5 border ${isTarget ? 'border-white/15' : 'border-slate-200 dark:border-slate-800'}">
                    <i data-lucide="info" class="w-3.5 h-3.5 opacity-70 flex-shrink-0"></i>
                    <span>Registro de Evento / Chamada em Grupo</span>
                </div>
            `;
        }

        html += `
            <div id="msg-${m.id}" class="flex ${alignClass} items-end space-x-1.5 group mb-2">
                ${!isTarget ? `<div class="mb-0.5 flex-shrink-0">${senderAvatarHtml}</div>` : ''}
                <div class="max-w-md ${bubbleBg} px-3.5 py-2 rounded-2xl space-y-1 relative">
                    <div class="flex items-center justify-between space-x-3 text-[10px] opacity-90">
                        ${authorTag}
                        <div class="flex items-center space-x-1.5 flex-shrink-0">
                            <span class="font-mono text-[9px] opacity-75">${m.timestamp_brt || m.timestamp_utc}</span>
                            <button onclick="${pinOnClick}" title="${pinTitle}" class="${pinClasses} p-0.5 transition">
                                <i data-lucide="bookmark" class="w-3.5 h-3.5 ${isBookmarked ? 'text-amber-400 fill-amber-400' : ''}"></i>
                            </button>
                            ${evidenceBtn}
                        </div>
                    </div>
                    ${contentBodyHtml}
                    ${mediaHtml}
                    ${tagsBadgesHtml}
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
    lucide.createIcons();
    attachChatContinuousAudio();

    // Mapear todas as ocorrências da busca nas mensagens da conversa ativa
    window.currentDmSearchMatches = [];
    window.currentDmSearchMatchIndex = -1;

    if (currentDmSearchQuery && currentDmSearchQuery.trim()) {
        const cleanQuery = currentDmSearchQuery.trim().toLowerCase();
        const terms = cleanQuery.replace(/[,;]/g, ' ').split(/\s+/).map(t => t.trim()).filter(t => t.length >= 1);
        if (terms.length > 0) {
            displayedMessages.forEach(m => {
                const c = (m.content || '').toLowerCase();
                const tr = (m.transcription || '').toLowerCase();
                const sender = (m.sender_username || '').toLowerCase();
                if (terms.some(t => c.includes(t) || tr.includes(t) || sender.includes(t))) {
                    window.currentDmSearchMatches.push(m.id);
                }
            });
        }
    }

    // Atualizar a barra flutuante de navegação de busca no cabeçalho do chat
    const searchNav = document.getElementById('dm-chat-search-navigator');
    const searchNavTerm = document.getElementById('dm-search-nav-term');
    const searchNavBadge = document.getElementById('dm-search-nav-badge');

    if (currentDmSearchQuery && currentDmSearchQuery.trim()) {
        if (searchNav && searchNavTerm && searchNavBadge) {
            searchNavTerm.innerText = `"${currentDmSearchQuery}"`;
            if (window.currentDmSearchMatches.length > 0) {
                window.currentDmSearchMatchIndex = 0;
                searchNavBadge.innerText = `1 de ${window.currentDmSearchMatches.length}`;
                searchNavBadge.className = "px-2 py-0.5 rounded-full bg-amber-200/80 dark:bg-amber-800/60 text-amber-900 dark:text-amber-100 font-mono font-bold text-[11px] flex-shrink-0";
            } else {
                searchNavBadge.innerText = "0 de 0 (Nenhuma ocorrência neste chat)";
                searchNavBadge.className = "px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-mono text-[10px] flex-shrink-0";
            }
            searchNav.classList.remove('hidden');
            if (window.lucide) lucide.createIcons();
        }
    } else if (searchNav) {
        searchNav.classList.add('hidden');
    }

    if (preserveScroll) {
        container.scrollTop = savedScrollTop;
        return;
    }

    // Rolar automaticamente para a mensagem alvo, para a primeira ocorrência da busca, para o marcador ou para o final
    if (targetMessageId) {
        setTimeout(() => scrollToDmMessage(targetMessageId), 80);
        setTimeout(() => scrollToDmMessage(targetMessageId), 280);
        setTimeout(() => scrollToDmMessage(targetMessageId), 650);
    } else if (window.currentDmSearchMatches && window.currentDmSearchMatches.length > 0) {
        const firstMatchId = window.currentDmSearchMatches[0];
        setTimeout(() => scrollToDmMessage(firstMatchId), 80);
        setTimeout(() => scrollToDmMessage(firstMatchId), 280);
        setTimeout(() => scrollToDmMessage(firstMatchId), 650);
    } else if (foundBookmark) {
        setTimeout(() => jumpToBookmark(), 80);
    } else {
        setTimeout(() => {
            if (container) container.scrollTop = container.scrollHeight;
        }, 80);
    }
}

function navigateDmSearchMatch(direction = 1) {
    if (!window.currentDmSearchMatches || window.currentDmSearchMatches.length === 0) return;

    window.currentDmSearchMatchIndex = (window.currentDmSearchMatchIndex + direction + window.currentDmSearchMatches.length) % window.currentDmSearchMatches.length;

    const badge = document.getElementById('dm-search-nav-badge');
    if (badge) {
        badge.innerText = `${window.currentDmSearchMatchIndex + 1} de ${window.currentDmSearchMatches.length}`;
    }

    const targetMsgId = window.currentDmSearchMatches[window.currentDmSearchMatchIndex];
    scrollToDmMessage(targetMsgId);
}

function closeDmChatSearch() {
    const searchNav = document.getElementById('dm-chat-search-navigator');
    if (searchNav) searchNav.classList.add('hidden');
}

function scrollToDmMessage(messageId) {
    const targetEl = document.getElementById(`msg-${messageId}`);
    const container = document.getElementById('dm-messages-container');
    if (targetEl && container) {
        const cRect = container.getBoundingClientRect();
        const tRect = targetEl.getBoundingClientRect();
        const currentScroll = container.scrollTop;
        const targetYInContainer = (tRect.top - cRect.top) + currentScroll;
        const desiredScroll = targetYInContainer - (container.clientHeight / 2) + (targetEl.clientHeight / 2);
        container.scrollTo({ top: Math.max(0, desiredScroll), behavior: 'smooth' });
        targetEl.classList.add('pulse-highlight');
        setTimeout(() => targetEl.classList.remove('pulse-highlight'), 4500);
        return true;
    }
    return false;
}

function jumpToBookmark() {
    const anchor = document.getElementById('dm-msg-bookmark-anchor');
    const container = document.getElementById('dm-messages-container');
    if (anchor && container) {
        const cRect = container.getBoundingClientRect();
        const aRect = anchor.getBoundingClientRect();
        const currentScroll = container.scrollTop;
        const targetYInContainer = (aRect.top - cRect.top) + currentScroll;
        const desiredScroll = targetYInContainer - (container.clientHeight / 2) + (anchor.clientHeight / 2);
        container.scrollTo({ top: Math.max(0, desiredScroll), behavior: 'smooth' });
    }
}

// ==================== PALETA E ESTILOS DE TAGS FORENSES ====================

const PREDEFINED_EVIDENCE_TAGS = [
    { name: "Armas / Munições", icon: "crosshair", colorClass: "rose" },
    { name: "Drogas / Entorpecentes", icon: "pill", colorClass: "emerald" },
    { name: "Financeiro / Pix / Valores", icon: "dollar-sign", colorClass: "amber" },
    { name: "Conteúdo Sexual / Abuso", icon: "shield-alert", colorClass: "purple" },
    { name: "Facção / Membros / Hierarquia", icon: "users", colorClass: "sky" },
    { name: "Logística / Localização", icon: "map-pin", colorClass: "orange" },
    { name: "Prova Chave", icon: "file-check", colorClass: "blue" }
];

let activeTagPickerMsgId = null;
let currentSelectedModalTags = [];
let activeDmTagFilter = 'all';
let activeReportSelectedTags = [];

function getTagBadgeStyle(tagName) {
    const lower = (tagName || '').toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (lower.includes('arma') || lower.includes('munic') || lower.includes('tiro') || lower.includes('fuzil') || lower.includes('pistola')) {
        return {
            bg: 'bg-rose-500/15 dark:bg-rose-950/60',
            text: 'text-rose-700 dark:text-rose-300',
            border: 'border-rose-500/30 dark:border-rose-800',
            dot: 'bg-rose-500',
            icon: 'crosshair'
        };
    }
    if (lower.includes('droga') || lower.includes('entorpe') || lower.includes('coca') || lower.includes('maconha') || lower.includes('crack')) {
        return {
            bg: 'bg-emerald-500/15 dark:bg-emerald-950/60',
            text: 'text-emerald-700 dark:text-emerald-300',
            border: 'border-emerald-500/30 dark:border-emerald-800',
            dot: 'bg-emerald-500',
            icon: 'pill'
        };
    }
    if (lower.includes('financ') || lower.includes('pix') || lower.includes('dinheiro') || lower.includes('valor') || lower.includes('conta') || lower.includes('banco') || lower.includes('ted')) {
        return {
            bg: 'bg-amber-500/15 dark:bg-amber-950/60',
            text: 'text-amber-700 dark:text-amber-300',
            border: 'border-amber-500/30 dark:border-amber-800',
            dot: 'bg-amber-500',
            icon: 'dollar-sign'
        };
    }
    if (lower.includes('sexual') || lower.includes('abuso') || lower.includes('nude') || lower.includes('menor') || lower.includes('estupro')) {
        return {
            bg: 'bg-purple-500/15 dark:bg-purple-950/60',
            text: 'text-purple-700 dark:text-purple-300',
            border: 'border-purple-500/30 dark:border-purple-800',
            dot: 'bg-purple-500',
            icon: 'shield-alert'
        };
    }
    if (lower.includes('facc') || lower.includes('membro') || lower.includes('hierarq') || lower.includes('comando') || lower.includes('pcc') || lower.includes('cv')) {
        return {
            bg: 'bg-sky-500/15 dark:bg-sky-950/60',
            text: 'text-sky-700 dark:text-sky-300',
            border: 'border-sky-500/30 dark:border-sky-800',
            dot: 'bg-sky-500',
            icon: 'users'
        };
    }
    if (lower.includes('logist') || lower.includes('localiz') || lower.includes('ponto') || lower.includes('endereco') || lower.includes('biqueira')) {
        return {
            bg: 'bg-orange-500/15 dark:bg-orange-950/60',
            text: 'text-orange-700 dark:text-orange-300',
            border: 'border-orange-500/30 dark:border-orange-800',
            dot: 'bg-orange-500',
            icon: 'map-pin'
        };
    }
    return {
        bg: 'bg-blue-500/15 dark:bg-blue-950/60',
        text: 'text-blue-700 dark:text-blue-300',
        border: 'border-blue-500/30 dark:border-blue-800',
        dot: 'bg-blue-500',
        icon: 'tag'
    };
}

function renderMessageTagBadges(messageId, tags, isTarget) {
    if (!tags || tags.length === 0) return '';
    const borderClass = isTarget ? 'border-white/20' : 'border-slate-200 dark:border-slate-700/60';
    
    let chipsHtml = tags.map(t => {
        const style = getTagBadgeStyle(t);
        const chipClass = isTarget
            ? 'bg-white/90 text-slate-900 border-white font-bold'
            : `${style.bg} ${style.text} ${style.border} font-bold`;

        return `
            <span onclick="toggleEvidenceTagPopover(${messageId}, event)" class="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] ${chipClass} shadow-xs select-none cursor-pointer hover:opacity-90 transition" title="Clique para editar tags">
                <span class="w-1.5 h-1.5 rounded-full ${style.dot}"></span>
                <span>${escapeHtml(t)}</span>
            </span>
        `;
    }).join('');

    return `
        <div class="tag-badges-container flex flex-wrap items-center gap-1.5 pt-1.5 mt-1 border-t ${borderClass}">
            ${chipsHtml}
        </div>
    `;
}

// ==================== RENDERIZAÇÃO DE MENSAGENS COM FILTRO DE TAGS ====================

function renderDmChatTagFilterBar() {
    const tagFilterBarEl = document.getElementById('dm-chat-tag-filter-bar');
    if (!tagFilterBarEl) return;

    const messages = window.currentThreadMessages || [];
    if (messages.length === 0) {
        tagFilterBarEl.classList.add('hidden');
        tagFilterBarEl.innerHTML = '';
        return;
    }

    // 1. Calcular tags presentes nesta conversa para o menu de filtro rápido
    const allThreadTags = {};
    messages.forEach(m => {
        const ev = evidenceTagsMap[String(m.id)];
        if (ev) {
            const tList = ev.tags || (ev.tag_label ? [ev.tag_label] : ['Prova Chave']);
            tList.forEach(t => { allThreadTags[t] = (allThreadTags[t] || 0) + 1; });
        }
    });
    const tagKeys = Object.keys(allThreadTags);

    // Auto-Reset inteligente: se a tag selecionada não existir mais nesta conversa, reseta para 'all'
    if (activeDmTagFilter !== 'all') {
        const hasMatchingTag = tagKeys.some(t => t.toLowerCase() === activeDmTagFilter.toLowerCase());
        if (!hasMatchingTag) {
            activeDmTagFilter = 'all';
        }
    }

    // Atualizar badge de evidências no cabeçalho
    const taggedEvCount = messages.filter(m => !!evidenceTagsMap[String(m.id)]).length;
    const badgeEvidence = document.getElementById('evidence-count-badge');
    if (badgeEvidence) {
        badgeEvidence.innerText = `(${taggedEvCount})`;
    }

    if (tagKeys.length > 0) {
        tagFilterBarEl.classList.remove('hidden');
        tagFilterBarEl.innerHTML = `
            <div class="flex items-center space-x-1 text-slate-400 dark:text-slate-500 text-[10px] font-semibold flex-shrink-0 mr-1 whitespace-nowrap">
                <i data-lucide="tag" class="w-2.5 h-2.5 text-amber-500 flex-shrink-0"></i>
                <span>Tags:</span>
            </div>
            <button onclick="setDmTagFilter('all')" class="px-1.5 py-0.5 rounded font-bold transition flex-shrink-0 whitespace-nowrap inline-flex items-center space-x-0.5 text-[10px] ${activeDmTagFilter === 'all' ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 shadow-2xs' : 'bg-slate-200/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-300'}">
                Todas (${messages.length})
            </button>
            ${tagKeys.map(t => {
                const style = getTagBadgeStyle(t);
                const isSel = activeDmTagFilter.toLowerCase() === t.toLowerCase();
                return `
                    <button onclick="setDmTagFilter('${escapeHtml(t)}')" class="px-1.5 py-0.5 rounded font-bold border transition inline-flex items-center space-x-1 flex-shrink-0 whitespace-nowrap text-[10px] ${isSel ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-2xs ring-1 ring-amber-500' : `${style.bg} ${style.text} ${style.border} hover:opacity-80`}">
                        <span class="w-1.5 h-1.5 rounded-full ${style.dot} flex-shrink-0"></span>
                        <span class="whitespace-nowrap">${escapeHtml(t)}</span>
                        <span class="opacity-80 font-mono text-[9px]">(${allThreadTags[t]})</span>
                    </button>
                `;
            }).join('')}
        `;
        lucide.createIcons();
    } else {
        tagFilterBarEl.classList.add('hidden');
        tagFilterBarEl.innerHTML = '';
    }
}

function setDmTagFilter(tag) {
    if (activeDmTagFilter && activeDmTagFilter.toLowerCase() === (tag || '').toLowerCase()) {
        activeDmTagFilter = 'all';
    } else {
        activeDmTagFilter = tag;
    }
    renderDmChatMessages();
}

// ==================== MARCADORES DE EVIDÊNCIA & POPOVER INLINE DE TAGS ====================

let activeInlineTagMsgId = null;

function getAllKnownTagsForCase() {
    const defaultTagNames = PREDEFINED_EVIDENCE_TAGS.map(t => t.name);
    const customSet = new Set();

    // Coletar todas as tags já atribuídas no caso
    Object.values(evidenceTagsMap).forEach(ev => {
        const tList = ev.tags || (ev.tag_label ? [ev.tag_label] : []);
        tList.forEach(t => {
            const clean = String(t).trim();
            if (clean && !defaultTagNames.includes(clean)) {
                customSet.add(clean);
            }
        });
    });

    return {
        predefined: PREDEFINED_EVIDENCE_TAGS,
        custom: Array.from(customSet)
    };
}

function toggleEvidenceTagPopover(messageId, event) {
    if (event) {
        event.stopPropagation();
        event.preventDefault();
    }
    const popover = document.getElementById('dm-inline-tag-popover');
    if (!popover) return;

    if (activeInlineTagMsgId === messageId && !popover.classList.contains('hidden')) {
        closeEvidenceTagPopover();
        return;
    }

    activeInlineTagMsgId = messageId;

    // Posicionar popover ancorado ao botão de tag clicado
    const btn = event?.currentTarget || document.getElementById(`gallery-tag-btn-${messageId}`) || document.getElementById(`tag-btn-${messageId}`);
    if (btn) {
        const rect = btn.getBoundingClientRect();
        let top = rect.bottom + 6;
        let left = rect.left - 230;

        if (left < 10) left = 10;
        if (left + 300 > window.innerWidth) left = window.innerWidth - 310;
        if (top + 280 > window.innerHeight) {
            top = Math.max(10, rect.top - 280);
        }

        popover.style.top = `${Math.round(top)}px`;
        popover.style.left = `${Math.round(left)}px`;
    }

    renderInlineTagPopoverContent();
    popover.classList.remove('hidden');
    lucide.createIcons();

    // Focar no campo de input após abrir
    setTimeout(() => {
        const input = document.getElementById('inline-tag-custom-input');
        if (input) input.focus();
    }, 50);
}

function closeEvidenceTagPopover() {
    const popover = document.getElementById('dm-inline-tag-popover');
    if (popover) popover.classList.add('hidden');
    activeInlineTagMsgId = null;
}

function renderInlineTagPopoverContent() {
    if (!activeInlineTagMsgId) return;
    const msgId = activeInlineTagMsgId;
    const existingEv = evidenceTagsMap[String(msgId)];
    const currentTags = existingEv ? (existingEv.tags || [existingEv.tag_label || 'Prova Chave']) : [];

    const listEl = document.getElementById('inline-tag-preset-list');
    const footerEl = document.getElementById('inline-tag-footer-actions');
    const countBadge = document.getElementById('inline-tag-count-badge');

    const known = getAllKnownTagsForCase();

    if (listEl) {
        let html = '';

        // 1. Tags Padrão Forenses
        html += known.predefined.map(t => {
            const isSelected = currentTags.includes(t.name);
            const style = getTagBadgeStyle(t.name);
            const activeBg = isSelected
                ? `bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500 font-bold shadow-xs ring-1 ring-amber-500/40`
                : `bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/80`;

            return `
                <button type="button" onclick="toggleInlineTag('${escapeHtml(t.name)}', event)" class="w-full px-2.5 py-1.5 rounded-lg border text-[11px] flex items-center justify-between transition ${activeBg}">
                    <div class="flex items-center space-x-2 truncate">
                        <span class="w-2 h-2 rounded-full ${style.dot}"></span>
                        <span class="truncate">${escapeHtml(t.name)}</span>
                    </div>
                    <i data-lucide="${isSelected ? 'check-circle-2' : 'plus'}" class="w-3.5 h-3.5 flex-shrink-0 ${isSelected ? 'text-amber-500' : 'opacity-30'}"></i>
                </button>
            `;
        }).join('');

        // 2. Tags Personalizadas Criadas no Caso (Memória do Caso)
        if (known.custom.length > 0) {
            html += `<div class="pt-1.5 mt-1 border-t border-slate-100 dark:border-slate-800 text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500">Personalizadas do Caso:</div>`;
            html += known.custom.map(customTagName => {
                const isSelected = currentTags.includes(customTagName);
                const style = getTagBadgeStyle(customTagName);
                const activeBg = isSelected
                    ? `bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500 font-bold shadow-xs ring-1 ring-amber-500/40`
                    : `bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/80`;

                return `
                    <button type="button" onclick="toggleInlineTag('${escapeHtml(customTagName)}', event)" class="w-full px-2.5 py-1.5 rounded-lg border text-[11px] flex items-center justify-between transition ${activeBg}">
                        <div class="flex items-center space-x-2 truncate">
                            <span class="w-2 h-2 rounded-full ${style.dot}"></span>
                            <span class="truncate">${escapeHtml(customTagName)}</span>
                        </div>
                        <i data-lucide="${isSelected ? 'check-circle-2' : 'plus'}" class="w-3.5 h-3.5 flex-shrink-0 ${isSelected ? 'text-amber-500' : 'opacity-30'}"></i>
                    </button>
                `;
            }).join('');
        }

        listEl.innerHTML = html;
    }

    if (footerEl) {
        if (currentTags.length > 0) {
            footerEl.classList.remove('hidden');
            if (countBadge) countBadge.innerText = `${currentTags.length} tag${currentTags.length > 1 ? 's' : ''}`;
        } else {
            footerEl.classList.add('hidden');
        }
    }

    lucide.createIcons();
}

async function toggleInlineTag(tagName, event) {
    if (event) {
        event.stopPropagation();
        event.preventDefault();
    }
    if (!activeInlineTagMsgId || !window.currentOpId) return;
    const msgId = activeInlineTagMsgId;
    const existingEv = evidenceTagsMap[String(msgId)];
    let currentTags = existingEv ? (existingEv.tags || [existingEv.tag_label || 'Prova Chave']) : [];

    let updatedTags = [];
    if (currentTags.includes(tagName)) {
        updatedTags = currentTags.filter(t => t !== tagName);
    } else {
        updatedTags = [...currentTags, tagName];
    }

    const isIncluded = updatedTags.length > 0;

    // Atualização otimista local imediata (zero lag na tela)
    if (isIncluded) {
        evidenceTagsMap[String(msgId)] = {
            operation_id: window.currentOpId,
            message_id: msgId,
            tags: updatedTags,
            tag_label: updatedTags[0],
            analyst_notes: existingEv?.analyst_notes || ''
        };
    } else {
        delete evidenceTagsMap[String(msgId)];
    }

    updateMessageBubbleEvidenceUI(msgId, isIncluded, updatedTags);
    renderInlineTagPopoverContent();
    afterEvidenceTagChanged();

    const count = Object.keys(evidenceTagsMap).length;
    const badge = document.getElementById('evidence-count-badge');
    if (badge) badge.innerText = count;

    try {
        await fetch('/api/evidence/toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                operation_id: window.currentOpId,
                message_id: msgId,
                is_included: isIncluded,
                tags: updatedTags,
                tag_label: updatedTags.join(', '),
                analyst_notes: existingEv?.analyst_notes || ''
            })
        });
    } catch (err) {
        console.error("Erro ao salvar tag:", err);
    }
}

function afterEvidenceTagChanged() {
    renderFilteredDmThreads();
    renderDmChatMessages();
}

async function addInlineCustomTag(event) {
    if (event) {
        event.stopPropagation();
        event.preventDefault();
    }
    const input = document.getElementById('inline-tag-custom-input');
    if (!input || !activeInlineTagMsgId) return;
    const tag = input.value.trim();
    if (!tag) return;

    input.value = '';
    await toggleInlineTag(tag, event);
}

async function removeInlineAllTags(event) {
    if (event) {
        event.stopPropagation();
        event.preventDefault();
    }
    if (!activeInlineTagMsgId || !window.currentOpId) return;
    const msgId = activeInlineTagMsgId;

    delete evidenceTagsMap[String(msgId)];
    updateMessageBubbleEvidenceUI(msgId, false, []);
    renderInlineTagPopoverContent();
    afterEvidenceTagChanged();

    const count = Object.keys(evidenceTagsMap).length;
    const badge = document.getElementById('evidence-count-badge');
    if (badge) badge.innerText = count;

    try {
        await fetch('/api/evidence/toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                operation_id: window.currentOpId,
                message_id: msgId,
                is_included: false
            })
        });
    } catch (err) {
        console.error("Erro ao desmarcar evidência:", err);
    }
}

// Fechar popover de tag ao clicar fora ou na tecla Escape
document.addEventListener('click', (e) => {
    const popover = document.getElementById('dm-inline-tag-popover');
    if (popover && !popover.classList.contains('hidden')) {
        if (!popover.contains(e.target) && !e.target.closest('#dm-inline-tag-popover') && !e.target.closest('[id^="tag-btn-"]')) {
            closeEvidenceTagPopover();
        }
    }
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeEvidenceTagPopover();
    }
});

function updateMessageBubbleEvidenceUI(messageId, isEvidence, tags) {
    // 1. Atualizar botão de tag na Galeria de Mídias (se existir no DOM)
    const galleryTagBtn = document.getElementById(`gallery-tag-btn-${messageId}`);
    if (galleryTagBtn) {
        if (isEvidence) {
            galleryTagBtn.className = 'px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 border border-amber-400 flex items-center space-x-1 transition shadow-xs select-none';
            galleryTagBtn.title = `Evidência (${(tags || []).join(', ')}) • Clique para editar tags`;
            galleryTagBtn.innerHTML = '<i data-lucide="tag" class="w-3 h-3 fill-slate-950"></i><span>Tag</span>';
        } else {
            galleryTagBtn.className = 'px-1.5 py-0.5 rounded text-[9px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-amber-500 hover:text-slate-950 flex items-center space-x-1 transition shadow-xs select-none';
            galleryTagBtn.title = 'Classificar evidência';
            galleryTagBtn.innerHTML = '<i data-lucide="tag" class="w-3 h-3"></i><span>Tag</span>';
        }
        if (window.lucide) lucide.createIcons();
    }

    // 2. Atualizar no Chat de DMs (se a mensagem estiver visível no DOM)
    const msgEl = document.getElementById(`msg-${messageId}`);
    if (!msgEl) return;

    const bubble = msgEl.querySelector('.max-w-md');
    const tagBtn = document.getElementById(`tag-btn-${messageId}`);
    const isTarget = msgEl.classList.contains('justify-end') || (bubble && bubble.classList.contains('bg-pink-600'));

    if (isEvidence) {
        if (bubble) bubble.classList.add('ring-2', 'ring-amber-400', 'shadow-md');
        if (tagBtn) {
            tagBtn.className = 'opacity-100 text-amber-500 hover:text-amber-400 p-0.5 transition';
            tagBtn.title = `Evidência (${tags.join(', ')}) • Clique para editar tags`;
            tagBtn.innerHTML = '<i data-lucide="tag" class="w-3.5 h-3.5 fill-amber-500 text-amber-500"></i>';
        }
    } else {
        if (bubble) bubble.classList.remove('ring-2', 'ring-amber-400', 'shadow-md');
        if (tagBtn) {
            tagBtn.className = 'opacity-0 group-hover:opacity-100 text-slate-300 hover:text-amber-400 p-0.5 transition';
            tagBtn.title = 'Classificar como evidência';
            tagBtn.innerHTML = '<i data-lucide="tag" class="w-3.5 h-3.5"></i>';
        }
    }

    // Atualizar container de badges de tags no rodapé do balão
    let badgesContainer = msgEl.querySelector('.tag-badges-container');
    if (isEvidence && tags.length > 0) {
        const borderClass = isTarget ? 'border-white/20' : 'border-slate-200 dark:border-slate-700/60';
        const chips = tags.map(t => {
            const style = getTagBadgeStyle(t);
            const chipClass = isTarget
                ? 'bg-white/90 text-slate-900 border-white font-bold'
                : `${style.bg} ${style.text} ${style.border} font-bold`;

            return `
                <span onclick="toggleEvidenceTagPopover(${messageId}, event)" class="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] ${chipClass} shadow-xs select-none cursor-pointer hover:opacity-90 transition" title="Clique para editar tags">
                    <span class="w-1.5 h-1.5 rounded-full ${style.dot}"></span>
                    <span>${escapeHtml(t)}</span>
                </span>
            `;
        }).join('');

        const newHtml = `
            <div class="tag-badges-container flex flex-wrap items-center gap-1.5 pt-1.5 mt-1 border-t ${borderClass}">
                ${chips}
            </div>
        `;
        if (badgesContainer) {
            badgesContainer.outerHTML = newHtml;
        } else if (bubble) {
            bubble.insertAdjacentHTML('beforeend', newHtml);
        }
    } else if (badgesContainer) {
        badgesContainer.remove();
    }

    lucide.createIcons();
    renderDmChatTagFilterBar();
}

// ==================== MODAL DE RELATÓRIO PERICIAL DE EVIDÊNCIAS ====================

async function openEvidenceReportModal() {
    if (!window.currentOpId) return;
    const modal = document.getElementById('modal-evidence-report');
    modal.classList.remove('hidden');

    // Carregar resumo de tags da operação
    try {
        let sumUrl = `/api/evidence/tags-summary?operation_id=${window.currentOpId}`;
        if (window.currentPhaseId) sumUrl += `&phase_id=${window.currentPhaseId}`;
        if (window.currentTargetId) sumUrl += `&target_id=${window.currentTargetId}`;

        const resSum = await fetch(sumUrl);
        const sumData = await resSum.json();
        const tagCounts = sumData.tag_counts || {};

        const chipsContainer = document.getElementById('report-tag-filter-chips');
        if (chipsContainer) {
            const allTags = Object.keys(tagCounts);
            if (activeReportSelectedTags.length === 0) {
                activeReportSelectedTags = [...allTags];
            }

            chipsContainer.innerHTML = allTags.map(t => {
                const isSelected = activeReportSelectedTags.includes(t);
                const style = getTagBadgeStyle(t);
                const count = tagCounts[t] || 0;
                const activeClass = isSelected
                    ? `bg-amber-500 text-slate-950 border-amber-600 font-bold shadow-xs`
                    : `bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-transparent opacity-70 hover:opacity-100`;

                return `
                    <button type="button" onclick="toggleReportFilterTag('${escapeHtml(t)}')" class="px-2 py-0.5 rounded-md text-[11px] border transition flex items-center space-x-1 ${activeClass}">
                        <span>${escapeHtml(t)}</span>
                        <span class="px-1 rounded bg-black/15 text-[10px] font-mono">${count}</span>
                    </button>
                `;
            }).join('');
        }
    } catch (e) {
        console.warn("Aviso ao carregar resumo de tags:", e);
    }

    await loadAndRenderReportContent();
}

function toggleReportFilterTag(tagName) {
    activeReportSelectedTags = activeReportSelectedTags.filter(t => t !== '__none__');
    if (activeReportSelectedTags.includes(tagName)) {
        activeReportSelectedTags = activeReportSelectedTags.filter(t => t !== tagName);
    } else {
        activeReportSelectedTags.push(tagName);
    }
    if (activeReportSelectedTags.length === 0) {
        activeReportSelectedTags = ['__none__'];
    }
    openEvidenceReportModal();
}

function toggleAllReportTags(selectAll) {
    if (selectAll) {
        activeReportSelectedTags = [];
    } else {
        activeReportSelectedTags = ['__none__'];
    }
    openEvidenceReportModal();
}

async function loadAndRenderReportContent() {
    const printArea = document.getElementById('evidence-report-print-area');
    if (!printArea) return;

    printArea.innerHTML = `<div class="text-center py-12 text-slate-400">Carregando relatório e estruturando evidências...</div>`;

    try {
        let url = `/api/evidence/report-data?operation_id=${window.currentOpId}`;
        if (window.currentPhaseId) url += `&phase_id=${window.currentPhaseId}`;
        if (window.currentTargetId) url += `&target_id=${window.currentTargetId}`;
        if (activeReportSelectedTags.length > 0 && !activeReportSelectedTags.includes('__none__')) {
            url += `&filter_tags=${encodeURIComponent(activeReportSelectedTags.join(','))}`;
        } else if (activeReportSelectedTags.includes('__none__')) {
            url += `&filter_tags=__NONE_SELECTED__`;
        }

        const res = await fetch(url);
        const data = await res.json();

        if (!data.threads || data.threads.length === 0) {
            printArea.innerHTML = `
                <div class="text-center py-16 space-y-3">
                    <i data-lucide="file-question" class="w-12 h-12 mx-auto text-amber-500"></i>
                    <h4 class="font-bold text-sm text-slate-800 dark:text-white">Nenhuma evidência selecionada para estes filtros</h4>
                    <p class="text-xs text-slate-500 max-w-md mx-auto">Navegue pelas conversas de DMs e clique no botão de evidência <b>[ 📌 / 🏷️ ]</b> nas mensagens incriminadoras para gerar este relatório temático consolidado.</p>
                </div>
            `;
            lucide.createIcons();
            return;
        }

        const op = data.operation || {};
        const ph = data.phase || {};
        const tgt = data.target || {};
        const custody = data.custody_files || [];

        let custodyHtml = '';
        if (custody.length > 0) {
            custodyHtml = `
                <div class="p-3 bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1.5">
                    <h5 class="text-[11px] font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 flex items-center space-x-1">
                        <i data-lucide="shield-check" class="w-3.5 h-3.5 text-emerald-500"></i>
                        <span>Cadeia de Custódia & Integridade Probatória (Hashes SHA-256)</span>
                    </h5>
                    <div class="divide-y divide-slate-200 dark:divide-slate-800 text-[10px] font-mono">
                        ${custody.map(c => `
                            <div class="py-1 flex flex-wrap justify-between gap-1">
                                <span class="font-bold text-slate-800 dark:text-slate-200">${escapeHtml(c.file_name)} (${(c.file_size / 1024).toFixed(1)} KB)</span>
                                <span class="text-blue-600 dark:text-cyan-400">SHA-256: ${c.sha256_hash}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }

        let threadsHtml = '';
        window.currentReportMessagesMap = {};

        data.threads.forEach((th, idx) => {
            const parts = th.participants.join(', ') || `Thread ${th.thread_id}`;
            let msgsHtml = '';
            th.messages.forEach(m => {
                window.currentReportMessagesMap[m.id] = m;
                const author = m.is_target_sender
                    ? `Investigado (@${m.sender_username || m.target_identifier || 'alvo'})`
                    : `Interlocutor (@${m.sender_username || m.sender_id || 'contato'})`;
                
                // Badges de Tags
                const tags = m.tags || ['Prova Chave'];
                const tagsBadges = tags.map(t => {
                    const style = getTagBadgeStyle(t);
                    return `<span class="px-1.5 py-0.2 rounded text-[9px] font-bold border ${style.bg} ${style.text} ${style.border}">${escapeHtml(t)}</span>`;
                }).join(' ');

                const notesHtml = m.analyst_notes ? `<div class="text-[11px] font-medium text-amber-700 dark:text-amber-300 bg-amber-500/10 p-1.5 rounded-md border border-amber-500/20 mt-1">📝 <b>Nota Pericial:</b> ${escapeHtml(m.analyst_notes)}</div>` : '';

                if (m.message_type === 'audio') {
                    // Card Pericial de Áudio idêntico ao modelo pericial aprovado
                    let whisperLabel = 'Whisper small';
                    if (m.transcribed_by === 'analyst') {
                        whisperLabel = 'Whisper (Revisado pelo Analista)';
                    } else if (m.transcribed_by) {
                        whisperLabel = m.transcribed_by.replace(/^whisper[-_]/i, 'Whisper ');
                    }

                    const hasTrans = m.transcription && m.transcription.trim().length > 0;
                    const transcriptionBody = hasTrans 
                        ? `"${escapeHtml(m.transcription.trim())}"` 
                        : `<span class="italic text-white/70 opacity-85">[Áudio sem transcrição cadastrada • Clique em Editar para transcrever ou inserir notas]</span>`;

                    const tagPills = tags.map(t => {
                        const style = getTagBadgeStyle(t);
                        const dotColor = style.dot || 'bg-rose-500';
                        return `
                            <div class="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-white text-slate-900 font-bold text-xs shadow-xs">
                                <span class="w-2.5 h-2.5 rounded-full ${dotColor} inline-block flex-shrink-0"></span>
                                <span>${escapeHtml(t)}</span>
                            </div>
                        `;
                    }).join('');

                    const voiceLabel = m.content && m.content.trim() 
                        ? escapeHtml(m.content.trim()) 
                        : (m.is_target_sender ? 'You sent a voice message.' : 'Áudio recebido');

                    msgsHtml += `
                        <div class="rounded-2xl p-4 sm:p-5 text-white shadow-md space-y-3 print-color-exact" style="background: linear-gradient(135deg, #d81b60 0%, #c2185b 50%, #ad1457 100%);">
                            <!-- Topo: Investigado/Interlocutor + Data/Hora + Ícone de Tag -->
                            <div class="flex items-center justify-between text-xs font-semibold text-white/95">
                                <div class="flex items-center space-x-1.5 truncate">
                                    <span class="font-bold text-sm tracking-tight">${escapeHtml(author)}</span>
                                </div>
                                <div class="flex items-center space-x-2 flex-shrink-0">
                                    <span class="text-[11px] text-white/80 font-mono">${escapeHtml(m.timestamp_brt || m.timestamp_utc)}</span>
                                    <i data-lucide="tag" class="w-3.5 h-3.5 text-amber-300 fill-amber-300"></i>
                                </div>
                            </div>

                            <!-- Label de Voz -->
                            <div class="text-xs text-white/90 flex items-center space-x-1.5 font-medium">
                                <span>🎤</span>
                                <span>${voiceLabel}</span>
                            </div>

                            <!-- Player de Áudio + Botão de Velocidade -->
                            <div class="flex items-center space-x-2 pt-0.5 audio-player-wrapper">
                                <div class="flex-1 bg-white rounded-full px-2 py-1 shadow-xs flex items-center">
                                    <audio id="report-audio-${m.id}" controls preload="metadata" class="w-full h-8 outline-none">
                                        <source src="${m.media_path}">
                                        Seu navegador não suporta a reprodução deste áudio.
                                    </audio>
                                </div>
                                <button type="button" onclick="toggleAudioSpeed('report-audio-${m.id}', this)" class="btn-audio-speed px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white font-mono text-xs font-bold transition flex-shrink-0 shadow-xs border border-white/20" title="Alternar velocidade global de reprodução">
                                    1.0x
                                </button>
                            </div>

                            <!-- Caixa da Transcrição Whisper -->
                            <div class="rounded-xl p-3.5 text-xs space-y-2 border border-white/10" style="background-color: rgba(0, 0, 0, 0.22);">
                                <div class="flex items-center justify-between text-[11px] text-white/80 font-medium">
                                    <div class="flex items-center space-x-1.5">
                                        <span>📄</span>
                                        <span>📝</span>
                                        <span class="font-bold">${escapeHtml(whisperLabel)}</span>
                                    </div>
                                    <div class="flex items-center space-x-2 text-[11px]">
                                        <button type="button" onclick="copyTranscriptionText(${m.id})" class="hover:underline flex items-center space-x-1 text-white/90 hover:text-white font-semibold cursor-pointer" title="Copiar transcrição">
                                            <i data-lucide="copy" class="w-3 h-3"></i>
                                            <span>Copiar</span>
                                        </button>
                                        <span class="text-white/40">•</span>
                                        <button type="button" onclick="openEditTranscriptionModal(${m.id})" class="hover:underline flex items-center space-x-1 text-amber-300 hover:text-amber-200 font-semibold cursor-pointer" title="Editar transcrição pericial">
                                            <i data-lucide="edit-3" class="w-3 h-3"></i>
                                            <span>Editar</span>
                                        </button>
                                    </div>
                                </div>
                                <div id="report-trans-text-${m.id}" class="text-xs leading-relaxed text-white font-medium italic select-text">
                                    ${transcriptionBody}
                                </div>
                            </div>

                            <!-- Rodapé: Pílulas de Tags Periciais -->
                            <div class="flex flex-wrap items-center gap-2 pt-1">
                                ${tagPills}
                            </div>

                            ${m.analyst_notes ? `
                                <div class="text-[11px] font-medium text-amber-100 bg-black/25 p-2 rounded-lg border border-amber-400/30">
                                    📝 <b>Nota Pericial:</b> ${escapeHtml(m.analyst_notes)}
                                </div>
                            ` : ''}
                        </div>
                    `;
                } else if (m.message_type === 'image' || m.message_type === 'photo') {
                    // Evidência de Imagem / Fotografia
                    msgsHtml += `
                        <div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
                            <div class="flex items-center justify-between text-[11px]">
                                <div class="flex items-center space-x-1.5">
                                    <span class="font-bold text-pink-600 dark:text-pink-400">${escapeHtml(author)}</span>
                                    ${tagsBadges}
                                </div>
                                <span class="font-mono text-slate-500 text-[10px]">${escapeHtml(m.timestamp_brt || m.timestamp_utc)}</span>
                            </div>
                            ${m.content ? `<p class="text-xs leading-relaxed text-slate-900 dark:text-slate-100 font-sans">${escapeHtml(m.content)}</p>` : ''}
                            ${m.media_path ? `
                                <div class="inline-block rounded-lg overflow-hidden border border-slate-300 dark:border-slate-700 bg-black max-w-sm shadow-xs">
                                    <img src="${m.media_path}" alt="Evidência Fotográfica" class="max-h-64 object-contain cursor-pointer hover:opacity-95 transition" onclick="openMediaViewer('${m.media_path}', 'image', '${escapeHtml(author)}')" />
                                </div>
                            ` : ''}
                            ${notesHtml}
                        </div>
                    `;
                } else if (m.message_type === 'video') {
                    // Evidência de Vídeo
                    msgsHtml += `
                        <div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
                            <div class="flex items-center justify-between text-[11px]">
                                <div class="flex items-center space-x-1.5">
                                    <span class="font-bold text-pink-600 dark:text-pink-400">${escapeHtml(author)}</span>
                                    ${tagsBadges}
                                </div>
                                <span class="font-mono text-slate-500 text-[10px]">${escapeHtml(m.timestamp_brt || m.timestamp_utc)}</span>
                            </div>
                            ${m.content ? `<p class="text-xs leading-relaxed text-slate-900 dark:text-slate-100 font-sans">${escapeHtml(m.content)}</p>` : ''}
                            ${m.media_path ? `
                                <div class="inline-block rounded-lg overflow-hidden border border-slate-300 dark:border-slate-700 bg-black max-w-sm shadow-xs">
                                    <video controls preload="metadata" class="max-h-64 outline-none">
                                        <source src="${m.media_path}">
                                        Seu navegador não suporta vídeos.
                                    </video>
                                </div>
                            ` : ''}
                            ${notesHtml}
                        </div>
                    `;
                } else {
                    // Mensagem de Texto padrão
                    msgsHtml += `
                        <div class="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-1">
                            <div class="flex items-center justify-between text-[10px]">
                                <div class="flex items-center space-x-1.5">
                                    <span class="font-bold text-pink-600 dark:text-pink-400">${escapeHtml(author)}</span>
                                    ${tagsBadges}
                                </div>
                                <span class="font-mono text-slate-500">${escapeHtml(m.timestamp_brt || m.timestamp_utc)}</span>
                            </div>
                            <p class="text-xs leading-relaxed text-slate-900 dark:text-slate-100 font-sans">${escapeHtml(m.content || '')}</p>
                            ${notesHtml}
                        </div>
                    `;
                }
            });

            threadsHtml += `
                <div class="space-y-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                    <div class="flex items-center justify-between">
                        <h4 class="font-bold text-xs text-slate-800 dark:text-white flex items-center space-x-1.5">
                            <span class="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-800 text-[10px] flex items-center justify-center font-mono font-bold">${idx + 1}</span>
                            <span>Diálogo com: <b>${escapeHtml(parts)}</b></span>
                        </h4>
                        <span class="text-[10px] font-mono text-slate-500">Thread ID: ${th.thread_id} (${th.messages.length} evidências)</span>
                    </div>
                    <div class="space-y-1.5 pl-6 border-l-2 border-slate-200 dark:border-slate-800">
                        ${msgsHtml}
                    </div>
                </div>
            `;
        });

        printArea.innerHTML = `
            <div class="space-y-5">
                <!-- Cabeçalho Oficial -->
                <div class="text-center pb-3 border-b-2 border-slate-900 dark:border-white space-y-1">
                    <h2 class="text-sm font-bold uppercase tracking-widest text-slate-900 dark:text-white">REPÚBLICA FEDERATIVA DO BRASIL</h2>
                    <h3 class="text-xs font-semibold text-slate-700 dark:text-slate-300">DEPARTAMENTO DE INTELIGÊNCIA POLICIAL • SEÇÃO DE ANÁLISE TELEMÁTICA</h3>
                    <p class="text-[10px] text-slate-500 uppercase tracking-wider font-mono">RELATÓRIO DE EXTRAÇÃO E CONSOLIDAÇÃO DE EVIDÊNCIAS DIGITAIS</p>
                </div>

                <!-- Quadro de Metadados -->
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-200 dark:border-slate-800">
                    <div>
                        <span class="text-slate-500 block text-[10px]">Operação Policial:</span>
                        <strong class="text-slate-900 dark:text-white font-bold">${escapeHtml(op.name || '---')}</strong>
                    </div>
                    <div>
                        <span class="text-slate-500 block text-[10px]">Mandado / Ofício:</span>
                        <strong class="text-slate-900 dark:text-white font-mono">${escapeHtml(ph.court_order_number || 'Conforme autos')}</strong>
                    </div>
                    <div>
                        <span class="text-slate-500 block text-[10px]">Alvo Investigado:</span>
                        <strong class="text-pink-600 dark:text-pink-400 font-bold">${escapeHtml(tgt.name_or_alias || '')} (${escapeHtml(tgt.main_identifier || '')})</strong>
                    </div>
                    <div>
                        <span class="text-slate-500 block text-[10px]">Total de Evidências:</span>
                        <strong class="text-emerald-600 font-bold">${data.total_evidence_count} mensagens</strong>
                    </div>
                </div>

                <!-- Custódia -->
                ${custodyHtml}

                <!-- Diálogos Periciais -->
                <div class="space-y-4">
                    <h4 class="text-xs font-bold uppercase text-slate-700 dark:text-slate-300 flex items-center space-x-1.5">
                        <i data-lucide="message-square" class="w-3.5 h-3.5 text-pink-500"></i>
                        <span>Diálogos e Mensagens Incriminadoras Selecionadas (Ordem Cronológica)</span>
                    </h4>
                    ${threadsHtml}
                </div>
            </div>
        `;
        lucide.createIcons();

    } catch (err) {
        console.error("Erro ao gerar relatório pericial:", err);
        printArea.innerHTML = `<p class="text-center text-red-500 text-xs py-8">Erro ao compilar relatório pericial.</p>`;
    }
}

function closeEvidenceReportModal() {
    const modal = document.getElementById('modal-evidence-report');
    if (modal) modal.classList.add('hidden');
}

function printEvidenceReport() {
    window.print();
}

// ==================== VISUALIZADOR DE MÍDIA FORENSE (LIGHTBOX COM ZOOM E NAVEGAÇÃO) ====================

// ==================== VISUALIZADOR DE MÍDIA FORENSE (LIGHTBOX COM ZOOM ATÉ 2500%, VÍDEOS E NAVEGAÇÃO) ====================

let mediaViewerItems = [];
let mediaViewerCurrentIndex = 0;
let mediaZoomLevel = 1.0;
let mediaPanX = 0;
let mediaPanY = 0;
let mediaRotation = 0;
let mediaActiveVisualFilter = 'none';
let isMediaPanning = false;
let mediaPanStartX = 0;
let mediaPanStartY = 0;

function openMediaViewer(url, type = 'image', sender = '', customItems = null) {
    mediaViewerItems = [];

    // 1. Prioridade: lista customizada se fornecida
    if (Array.isArray(customItems) && customItems.length > 0) {
        mediaViewerItems = customItems;
    }
    // 2. Mapear mídias da conversa aberta atual (currentThreadMessages)
    else if (Array.isArray(window.currentThreadMessages) && window.currentThreadMessages.length > 0) {
        mediaViewerItems = window.currentThreadMessages
            .filter(m => m.media_path && (m.message_type === 'image' || m.message_type === 'video'))
            .map(m => ({
                url: m.media_path,
                type: m.message_type,
                sender: m.sender_username || '',
                id: m.id
            }));
    }

    // 3. Se não achou na conversa, verificar galeria de mídias (currentGalleryMediaItems)
    if (mediaViewerItems.length === 0 && Array.isArray(window.currentGalleryMediaItems) && window.currentGalleryMediaItems.length > 0) {
        mediaViewerItems = window.currentGalleryMediaItems
            .filter(m => m.media_path && (m.message_type === 'image' || m.message_type === 'video'))
            .map(m => ({
                url: m.media_path,
                type: m.message_type,
                sender: m.sender_username || '',
                id: m.id
            }));
    }

    // 4. Fallback amplo: escanear elementos de mídia visíveis no DOM
    if (mediaViewerItems.length <= 1) {
        const domMedia = document.querySelectorAll('#dm-messages-container img[src*="/media/"], #dm-messages-container video source[src*="/media/"], #ig-media-grid img[src*="/media/"], #ig-media-grid video source[src*="/media/"], #dm-chat-media-drawer img[src*="/media/"], #dm-chat-media-drawer video source[src*="/media/"]');
        if (domMedia.length > 1) {
            const seen = new Set();
            const scanned = [];
            domMedia.forEach(el => {
                const s = el.getAttribute('src') || el.src;
                if (s && !seen.has(s)) {
                    seen.add(s);
                    const isVid = el.tagName.toLowerCase() === 'source' || s.endsWith('.mp4') || s.endsWith('.webm');
                    scanned.push({
                        url: s,
                        type: isVid ? 'video' : 'image',
                        sender: sender || ''
                    });
                }
            });
            if (scanned.length > 1) {
                mediaViewerItems = scanned;
            }
        }
    }

    // 5. Localizar o item clicado por matching tolerante de URL
    const cleanUrl = (url || '').trim().replace(/^https?:\/\/[^\/]+/, '').replace(/\\/g, '/');
    const baseName = cleanUrl.split('/').pop();

    mediaViewerCurrentIndex = mediaViewerItems.findIndex(x => {
        const xClean = (x.url || '').trim().replace(/^https?:\/\/[^\/]+/, '').replace(/\\/g, '/');
        return xClean === cleanUrl || xClean.endsWith(baseName) || cleanUrl.endsWith(xClean.split('/').pop());
    });

    if (mediaViewerCurrentIndex === -1) {
        mediaViewerItems.unshift({ url, type, sender });
        mediaViewerCurrentIndex = 0;
    }

    const modal = document.getElementById('modal-media-viewer');
    if (!modal) return;
    modal.classList.remove('hidden');
    modal.focus();

    resetMediaZoom();
    renderMediaViewerCurrentItem();
}

function applyMediaVisualFilter(filterKey) {
    mediaActiveVisualFilter = filterKey || 'none';
    const label = document.getElementById('media-current-filter-label');
    const labelMap = {
        'none': 'Filtros',
        'invert': 'Negativo',
        'contrast': 'Contraste',
        'grayscale': 'P&B',
        'bright': '+Luz'
    };
    if (label) label.innerText = labelMap[mediaActiveVisualFilter] || 'Filtros';
    
    // Fecha dropdown
    const dd = document.getElementById('dropdown-media-filters');
    if (dd) dd.classList.add('hidden');

    updateMediaTransform();
}
window.applyMediaVisualFilter = applyMediaVisualFilter;

function toggleMediaFiltersDropdown(event) {
    if (event) event.stopPropagation();
    const dd = document.getElementById('dropdown-media-filters');
    if (dd) dd.classList.toggle('hidden');
}
window.toggleMediaFiltersDropdown = toggleMediaFiltersDropdown;

function toggleMediaExifDrawer() {
    const drawer = document.getElementById('media-viewer-exif-drawer');
    if (drawer) drawer.classList.toggle('hidden');
}
window.toggleMediaExifDrawer = toggleMediaExifDrawer;

function renderMediaViewerCurrentItem() {
    const item = mediaViewerItems[mediaViewerCurrentIndex];
    if (!item) return;

    const container = document.getElementById('media-viewer-content');
    const btnOpenTab = document.getElementById('media-viewer-open-tab');
    const btnDownload = document.getElementById('media-viewer-download');
    const title = document.getElementById('media-viewer-title');
    const counter = document.getElementById('media-viewer-counter');
    const prevBtn = document.getElementById('media-viewer-prev-btn');
    const nextBtn = document.getElementById('media-viewer-next-btn');

    if (btnOpenTab) btnOpenTab.href = item.url;
    if (btnDownload) btnDownload.href = item.url;
    if (title) title.innerText = item.sender ? `Evidência Digital (${item.sender})` : 'Visualizador de Evidência';
    if (counter) counter.innerText = `${mediaViewerCurrentIndex + 1} / ${mediaViewerItems.length}`;

    // Mostrar ou ocultar setas laterais
    const hasMultiple = mediaViewerItems.length > 1;
    if (prevBtn) prevBtn.style.display = hasMultiple ? 'flex' : 'none';
    if (nextBtn) nextBtn.style.display = hasMultiple ? 'flex' : 'none';

    if (item.type === 'video') {
        container.innerHTML = `
            <div id="media-viewer-active-wrapper" class="relative max-h-[80vh] max-w-full flex items-center justify-center select-none" style="touch-action: none;">
                <video id="media-viewer-active-element" src="${item.url}" controls autoplay class="max-h-[78vh] max-w-full rounded-xl outline-none shadow-2xl transition-transform duration-75 select-none pointer-events-auto cursor-grab"></video>
            </div>
        `;
    } else {
        container.innerHTML = `
            <div id="media-viewer-active-wrapper" class="relative max-h-[80vh] max-w-full flex items-center justify-center select-none" style="touch-action: none;">
                <img id="media-viewer-active-element" src="${item.url}" class="max-h-[78vh] max-w-full object-contain rounded-xl shadow-2xl transition-transform duration-75 select-none pointer-events-auto cursor-grab" draggable="false">
            </div>
        `;
    }

    // Atualizar Drawer de Metadados Forenses
    const exifContent = document.getElementById('media-viewer-exif-content');
    const pData = item.photoData || null;
    const lat = pData ? pData.latitude : (item.latitude || null);
    const lng = pData ? pData.longitude : (item.longitude || null);

    if (exifContent) {
        if (pData) {
            exifContent.innerHTML = `
                <div class="space-y-2">
                    <div class="p-2 rounded-lg bg-white/5 border border-white/10 space-y-1">
                        <span class="text-[10px] text-slate-400 font-mono block uppercase">Arquivo Original</span>
                        <p class="font-bold text-slate-100 truncate" title="${escapeHtml(pData.file_name || '')}">${escapeHtml(pData.file_name || '')}</p>
                    </div>
                    <div class="grid grid-cols-2 gap-2">
                        <div class="p-2 rounded-lg bg-white/5 border border-white/10 space-y-0.5">
                            <span class="text-[10px] text-slate-400 font-mono block">Data (BRT)</span>
                            <p class="font-semibold text-slate-200">${escapeHtml(pData.capture_time_brt || 'n/d')}</p>
                        </div>
                        <div class="p-2 rounded-lg bg-white/5 border border-white/10 space-y-0.5">
                            <span class="text-[10px] text-slate-400 font-mono block">Tamanho</span>
                            <p class="font-semibold text-slate-200">${pData.file_size ? `${(pData.file_size / 1024).toFixed(1)} KB` : 'n/d'}</p>
                        </div>
                    </div>
                    <div class="p-2 rounded-lg bg-white/5 border border-white/10 space-y-0.5">
                        <span class="text-[10px] text-slate-400 font-mono block">Coordenadas GPS</span>
                        ${lat != null && lng != null ? `
                            <p class="font-mono text-emerald-400 font-bold">${lat.toFixed(6)}, ${lng.toFixed(6)}</p>
                            <div class="flex items-center space-x-2 mt-1">
                                <a href="https://www.google.com/maps?q=${lat},${lng}" target="_blank" rel="noopener noreferrer" class="text-[10px] text-cyan-400 hover:text-cyan-300 underline">Google Maps ↗</a>
                                <button onclick="viewGooglePhotoOnLeafletMap(${lat}, ${lng}, '${escapeHtml(pData.title || pData.file_name || 'Mídia')}')" class="px-2 py-0.5 rounded bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 text-[10px] font-semibold transition border border-emerald-500/30">
                                    Focar no Mapa 📍
                                </button>
                            </div>
                        ` : `
                            <p class="text-slate-400 italic">Sem coordenadas registradas</p>
                        `}
                    </div>
                    ${pData.exif_hash ? `
                        <div class="p-2 rounded-lg bg-white/5 border border-white/10 space-y-0.5">
                            <span class="text-[10px] text-slate-400 font-mono block">Hash EXIF / Integridade</span>
                            <code class="text-[9px] text-purple-300 font-mono break-all block">${escapeHtml(pData.exif_hash)}</code>
                        </div>
                    ` : ''}
                </div>
            `;
        } else {
            exifContent.innerHTML = `
                <div class="p-2 rounded-lg bg-white/5 border border-white/10 space-y-1">
                    <span class="text-[10px] text-slate-400 font-mono block uppercase">Origem da Evidência</span>
                    <p class="font-bold text-slate-100">${escapeHtml(item.sender || 'Mídia Digital')}</p>
                    <p class="text-[10px] text-slate-400 font-mono break-all">${escapeHtml(item.url || '')}</p>
                </div>
            `;
        }
    }

    setupMediaZoomAndPan();
    lucide.createIcons();
}

function navigateMediaViewer(direction) {
    if (mediaViewerItems.length <= 1) return;
    mediaViewerCurrentIndex += direction;
    if (mediaViewerCurrentIndex < 0) {
        mediaViewerCurrentIndex = mediaViewerItems.length - 1;
    } else if (mediaViewerCurrentIndex >= mediaViewerItems.length) {
        mediaViewerCurrentIndex = 0;
    }
    resetMediaZoom();
    renderMediaViewerCurrentItem();
}

function updateMediaTransform() {
    const elem = document.getElementById('media-viewer-active-element');
    const zoomText = document.getElementById('media-viewer-zoom-level');
    if (zoomText) {
        zoomText.innerText = `${Math.round(mediaZoomLevel * 100)}%`;
    }
    if (elem) {
        elem.style.transform = `translate(${mediaPanX}px, ${mediaPanY}px) scale(${mediaZoomLevel}) rotate(${mediaRotation}deg)`;
        elem.style.cursor = mediaZoomLevel > 1.0 ? (isMediaPanning ? 'grabbing' : 'grab') : 'default';
        if (mediaZoomLevel >= 4.0) {
            elem.style.imageRendering = 'pixelated';
        } else {
            elem.style.imageRendering = 'auto';
        }

        // Filtro pericial de imagem
        let cssFilter = 'none';
        if (mediaActiveVisualFilter === 'invert') {
            cssFilter = 'invert(1) hue-rotate(180deg)';
        } else if (mediaActiveVisualFilter === 'contrast') {
            cssFilter = 'contrast(190%) brightness(105%) saturate(120%)';
        } else if (mediaActiveVisualFilter === 'grayscale') {
            cssFilter = 'grayscale(100%) contrast(125%)';
        } else if (mediaActiveVisualFilter === 'bright') {
            cssFilter = 'brightness(145%) contrast(120%)';
        }
        elem.style.filter = cssFilter;
    }
}

function rotateMedia(deg = 90) {
    mediaRotation = (mediaRotation + deg) % 360;
    updateMediaTransform();
}

function zoomMediaIn() {
    if (mediaZoomLevel < 2.0) {
        mediaZoomLevel = Math.round((mediaZoomLevel + 0.25) * 100) / 100;
    } else if (mediaZoomLevel < 5.0) {
        mediaZoomLevel = Math.round((mediaZoomLevel + 0.50) * 100) / 100;
    } else if (mediaZoomLevel < 10.0) {
        mediaZoomLevel = Math.round((mediaZoomLevel + 1.0) * 100) / 100;
    } else {
        mediaZoomLevel = Math.round((mediaZoomLevel + 2.5) * 100) / 100;
    }
    mediaZoomLevel = Math.min(25.0, mediaZoomLevel); // Até 2500% de zoom forense!
    updateMediaTransform();
}

function zoomMediaOut() {
    if (mediaZoomLevel > 10.0) {
        mediaZoomLevel = Math.round((mediaZoomLevel - 2.5) * 100) / 100;
    } else if (mediaZoomLevel > 5.0) {
        mediaZoomLevel = Math.round((mediaZoomLevel - 1.0) * 100) / 100;
    } else if (mediaZoomLevel > 2.0) {
        mediaZoomLevel = Math.round((mediaZoomLevel - 0.50) * 100) / 100;
    } else {
        mediaZoomLevel = Math.round((mediaZoomLevel - 0.25) * 100) / 100;
    }
    mediaZoomLevel = Math.max(0.25, mediaZoomLevel); // Mínimo 25%
    if (mediaZoomLevel <= 1.0) {
        mediaPanX = 0;
        mediaPanY = 0;
    }
    updateMediaTransform();
}

function setMediaZoomExact(level) {
    mediaZoomLevel = level;
    if (mediaZoomLevel <= 1.0) {
        mediaPanX = 0;
        mediaPanY = 0;
    }
    updateMediaTransform();
}

function resetMediaZoom() {
    mediaZoomLevel = 1.0;
    mediaPanX = 0;
    mediaPanY = 0;
    mediaRotation = 0;
    isMediaPanning = false;
    updateMediaTransform();
}

function setupMediaZoomAndPan() {
    const container = document.getElementById('media-viewer-content');
    const elem = document.getElementById('media-viewer-active-element');
    if (!container || !elem) return;

    // Zoom com a rodinha do mouse (wheel)
    container.onwheel = (e) => {
        e.preventDefault();
        if (e.deltaY < 0) {
            zoomMediaIn();
        } else {
            zoomMediaOut();
        }
    };

    // Duplo clique para alternar entre 1.0x e 2.5x
    elem.ondblclick = (e) => {
        e.preventDefault();
        if (mediaZoomLevel > 1.0) {
            resetMediaZoom();
        } else {
            setMediaZoomExact(2.5);
        }
    };

    // Arrastar (Pan) com o botão do mouse
    elem.onmousedown = (e) => {
        if (e.button !== 0 || mediaZoomLevel <= 1.0) return;
        e.preventDefault();
        isMediaPanning = true;
        mediaPanStartX = e.clientX - mediaPanX;
        mediaPanStartY = e.clientY - mediaPanY;
        updateMediaTransform();
    };

    window.addEventListener('mousemove', handleMediaMouseMove);
    window.addEventListener('mouseup', handleMediaMouseUp);
}

function handleMediaMouseMove(e) {
    if (!isMediaPanning) return;
    mediaPanX = e.clientX - mediaPanStartX;
    mediaPanY = e.clientY - mediaPanStartY;
    updateMediaTransform();
}

function handleMediaMouseUp() {
    if (isMediaPanning) {
        isMediaPanning = false;
        updateMediaTransform();
    }
}

function closeMediaViewer() {
    const modal = document.getElementById('modal-media-viewer');
    const container = document.getElementById('media-viewer-content');
    if (modal) modal.classList.add('hidden');
    if (container) {
        container.innerHTML = '';
        container.onwheel = null;
    }
    const drawer = document.getElementById('media-viewer-exif-drawer');
    if (drawer) drawer.classList.add('hidden');
    const filterMenu = document.getElementById('dropdown-media-filters');
    if (filterMenu) filterMenu.classList.add('hidden');
    mediaActiveVisualFilter = 'none';
    const filterLabel = document.getElementById('media-current-filter-label');
    if (filterLabel) filterLabel.innerText = 'Filtros';

    resetMediaZoom();
    mediaViewerItems = [];
    window.removeEventListener('mousemove', handleMediaMouseMove);
    window.removeEventListener('mouseup', handleMediaMouseUp);
}

function viewGooglePhotoOnLeafletMap(lat, lon, title) {
    if (typeof window.focusGooglePhotoOnMap === 'function') {
        window.focusGooglePhotoOnMap(lat, lon, title);
    } else {
        closeMediaViewer();
        if (typeof switchGoogleSubTab === 'function') {
            switchGoogleSubTab('locations');
        }
    }
}
window.viewGooglePhotoOnLeafletMap = viewGooglePhotoOnLeafletMap;

window.zoomMediaIn = zoomMediaIn;
window.zoomMediaOut = zoomMediaOut;
window.setMediaZoomExact = setMediaZoomExact;
window.resetMediaZoom = resetMediaZoom;
window.rotateMedia = rotateMedia;
window.navigateMediaViewer = navigateMediaViewer;
window.closeMediaViewer = closeMediaViewer;
window.openMediaViewer = openMediaViewer;

document.addEventListener('keydown', (e) => {
    const mediaModal = document.getElementById('modal-media-viewer');
    const isMediaOpen = mediaModal && !mediaModal.classList.contains('hidden');

    if (isMediaOpen) {
        if (e.key === 'ArrowLeft') {
            e.preventDefault();
            e.stopPropagation();
            navigateMediaViewer(-1);
            return;
        } else if (e.key === 'ArrowRight') {
            e.preventDefault();
            e.stopPropagation();
            navigateMediaViewer(1);
            return;
        } else if (e.key === '+' || e.key === '=') {
            e.preventDefault();
            zoomMediaIn();
            return;
        } else if (e.key === '-' || e.key === '_') {
            e.preventDefault();
            zoomMediaOut();
            return;
        } else if (e.key === '0') {
            e.preventDefault();
            resetMediaZoom();
            return;
        } else if (e.key === 'r' || e.key === 'R') {
            e.preventDefault();
            rotateMedia(90);
            return;
        } else if (e.key === 'Escape') {
            e.preventDefault();
            closeMediaViewer();
            return;
        }
    }

    if (e.key === 'Escape') {
        closeEvidenceReportModal();
        document.getElementById('dm-threads-calendar-popover')?.classList.add('hidden');
        document.getElementById('dm-chat-calendar-popover')?.classList.add('hidden');
        document.getElementById('dm-group-participants-popover')?.classList.add('hidden');
    }
});

document.addEventListener('click', (e) => {
    const tp = document.getElementById('dm-threads-calendar-popover');
    const tb = document.getElementById('btn-toggle-threads-calendar');
    if (tp && !tp.classList.contains('hidden') && !tp.contains(e.target) && !tb?.contains(e.target)) {
        tp.classList.add('hidden');
    }

    const cp = document.getElementById('dm-chat-calendar-popover');
    const cb = document.getElementById('btn-toggle-date-filter');
    if (cp && !cp.classList.contains('hidden') && !cp.contains(e.target) && !cb?.contains(e.target)) {
        cp.classList.add('hidden');
    }
});

// ==================== PAINEL LATERAL RETRÁTIL DE DETALHES DA CONVERSA / GRUPO ====================
let currentDmDetailsTab = 'members';

function toggleDmChatDetailsDrawer(defaultTab = null) {
    const drawer = document.getElementById('dm-chat-details-drawer');
    if (!drawer) return;

    const isHidden = drawer.classList.contains('hidden');

    if (defaultTab) {
        if (isHidden) {
            drawer.classList.remove('hidden');
            switchDmDetailsTab(defaultTab);
        } else if (currentDmDetailsTab === defaultTab) {
            drawer.classList.add('hidden');
        } else {
            switchDmDetailsTab(defaultTab);
        }
    } else {
        drawer.classList.toggle('hidden');
        if (!drawer.classList.contains('hidden')) {
            const hasMembers = Array.isArray(window.currentGroupParticipants) && window.currentGroupParticipants.length > 2;
            switchDmDetailsTab(hasMembers ? currentDmDetailsTab : 'media');
        }
    }
}

// Compatibilidade retroativa com chamadas legadas
function toggleDmChatMediaDrawer() {
    toggleDmChatDetailsDrawer('media');
}

function switchDmDetailsTab(tab) {
    currentDmDetailsTab = tab;
    const tabMembers = document.getElementById('tab-btn-members');
    const tabMedia = document.getElementById('tab-btn-media');
    const contentMembers = document.getElementById('drawer-tab-members');
    const contentMedia = document.getElementById('drawer-tab-media');
    const drawerTitle = document.getElementById('dm-drawer-title');

    if (tab === 'members') {
        if (tabMembers) {
            tabMembers.className = 'flex-1 py-1 px-2 rounded-lg text-center transition flex items-center justify-center space-x-1 bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs';
        }
        if (tabMedia) {
            tabMedia.className = 'flex-1 py-1 px-2 rounded-lg text-center transition flex items-center justify-center space-x-1 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200';
        }
        if (contentMembers) contentMembers.classList.remove('hidden');
        if (contentMedia) contentMedia.classList.add('hidden');
        if (drawerTitle) drawerTitle.innerText = 'Participantes do Grupo';
        renderDmGroupMembersDrawer();
    } else {
        if (tabMedia) {
            tabMedia.className = 'flex-1 py-1 px-2 rounded-lg text-center transition flex items-center justify-center space-x-1 bg-white dark:bg-slate-900 text-purple-600 dark:text-purple-400 shadow-xs';
        }
        if (tabMembers) {
            tabMembers.className = 'flex-1 py-1 px-2 rounded-lg text-center transition flex items-center justify-center space-x-1 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200';
        }
        if (contentMedia) contentMedia.classList.remove('hidden');
        if (contentMembers) contentMembers.classList.add('hidden');
        if (drawerTitle) drawerTitle.innerText = 'Mídias desta Conversa';
        renderDmChatMediaDrawer();
    }
    lucide.createIcons();
}

function renderDmGroupMembersDrawer() {
    const listElem = document.getElementById('dm-group-members-list');
    const countBadge = document.getElementById('drawer-members-count');
    const searchInput = document.getElementById('dm-member-search-input');
    if (!listElem) return;

    const participants = window.currentGroupParticipants || [];
    if (countBadge) countBadge.innerText = `(${participants.length})`;

    if (participants.length === 0) {
        listElem.innerHTML = `<p class="text-[11px] text-slate-400 text-center py-8">Esta conversa não possui múltiplos participantes.</p>`;
        return;
    }

    // Contar mensagens por participante
    const msgs = window.currentThreadMessages || [];
    const countBySender = {};
    msgs.forEach(m => {
        const u = (m.sender_username || m.sender_id || '').replace(/^@/, '').toLowerCase().trim();
        if (u) countBySender[u] = (countBySender[u] || 0) + 1;
    });

    const targetClean = (window.currentTargetVanity || '').replace(/^@/, '').toLowerCase().trim();
    const searchTerm = (searchInput ? searchInput.value : '').toLowerCase().trim();

    let filtered = participants;
    if (searchTerm) {
        filtered = participants.filter(p => String(p).toLowerCase().includes(searchTerm));
    }

    if (filtered.length === 0) {
        listElem.innerHTML = `<p class="text-[11px] text-slate-400 text-center py-8">Nenhum participante encontrado para "${escapeHtml(searchTerm)}".</p>`;
        return;
    }

    let html = '';
    filtered.forEach(p => {
        const cleanP = String(p).replace(/^@/, '').trim();
        const memberUid = (window.currentDmSendersUidsMap && window.currentDmSendersUidsMap[cleanP.toLowerCase()]) || null;
        const url = memberUid ? getIgUidUrl(memberUid) : getIgProfileUrl(cleanP);
        const linkTitle = memberUid ? `Abrir perfil no Instagram por ID (${memberUid})` : `Abrir perfil @${escapeHtml(cleanP)} no Instagram`;
        const msgCount = countBySender[cleanP.toLowerCase()] || 0;
        const isTarget = targetClean && cleanP.toLowerCase() === targetClean;
        const isFiltered = activeDmMemberFilter && activeDmMemberFilter.replace(/^@/, '').toLowerCase() === cleanP.toLowerCase();

        const color = getAvatarColorPair(cleanP || 'IG');
        const cachedAvatar = getCachedAvatarSrc(cleanP);

        const avatarHtml = cachedAvatar
            ? `<img src="${cachedAvatar}" class="w-7 h-7 rounded-full object-cover flex-shrink-0 border border-slate-300 dark:border-slate-700" alt="${escapeHtml(cleanP)}">`
            : `<div class="w-7 h-7 rounded-full ${color.bg} border ${color.border} flex items-center justify-center font-bold ${color.text} text-[10px] flex-shrink-0">${getAvatarInitials(cleanP)}</div>`;

        const activeClass = isFiltered
            ? 'border-indigo-500 bg-indigo-50/70 dark:bg-indigo-950/40 shadow-xs ring-1 ring-indigo-500'
            : 'border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800/60 shadow-2xs';

        html += `
            <div onclick="toggleMemberFilter('${escapeHtml(cleanP)}')" class="p-2 rounded-xl border ${activeClass} transition cursor-pointer flex items-center justify-between gap-2 group" title="Clique para ${isFiltered ? 'remover filtro' : 'filtrar mensagens deste membro'}">
                <div class="flex items-center space-x-2 overflow-hidden flex-1 min-w-0">
                    ${avatarHtml}
                    <div class="min-w-0 flex-1">
                        <div class="flex items-center space-x-1">
                            <span class="font-bold text-xs text-slate-900 dark:text-white truncate">@${escapeHtml(cleanP)}</span>
                            ${isTarget ? `<span class="px-1.5 py-0.2 rounded bg-amber-500/15 text-amber-700 dark:text-amber-400 font-bold text-[9px] border border-amber-500/30 flex-shrink-0">Alvo</span>` : ''}
                        </div>
                        <div class="flex items-center space-x-1.5 text-[10px] text-slate-400 mt-0.5">
                            <span class="font-mono text-slate-600 dark:text-slate-400">${msgCount} msg${msgCount !== 1 ? 's' : ''}</span>
                            ${memberUid ? `<span class="font-mono text-[9px] text-purple-600 dark:text-purple-400">UID: ${escapeHtml(memberUid)}</span>` : ''}
                            ${isFiltered ? `<span class="text-indigo-600 dark:text-indigo-400 font-semibold">• Ativo</span>` : ''}
                        </div>
                    </div>
                </div>
                <div class="flex items-center space-x-1 flex-shrink-0">
                    <button type="button" onclick="event.stopPropagation(); toggleMemberFilter('${escapeHtml(cleanP)}')" class="p-1 rounded-lg ${isFiltered ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800'}" title="${isFiltered ? 'Limpar filtro' : 'Filtrar falas no chat'}">
                        <i data-lucide="${isFiltered ? 'check' : 'filter'}" class="w-3.5 h-3.5"></i>
                    </button>
                    <a href="${url}" target="_blank" rel="noopener noreferrer" onclick="event.stopPropagation()" class="text-slate-400 hover:text-pink-600 p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition" title="${linkTitle}">
                        <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                    </a>
                </div>
            </div>
        `;
    });

    listElem.innerHTML = html;
    lucide.createIcons();
}

function filterDmMembersList() {
    renderDmGroupMembersDrawer();
}

function toggleMemberFilter(username) {
    const clean = (username || '').replace(/^@/, '').trim();
    if (!clean) return;

    if (activeDmMemberFilter && activeDmMemberFilter.replace(/^@/, '').toLowerCase() === clean.toLowerCase()) {
        activeDmMemberFilter = null;
    } else {
        activeDmMemberFilter = clean;
    }

    renderDmChatMessages(null, false);
    renderDmGroupMembersDrawer();
}

function clearChatMemberFilter() {
    activeDmMemberFilter = null;
    renderDmChatMessages(null, false);
    renderDmGroupMembersDrawer();
}

function renderDmChatMediaDrawer() {
    const listElem = document.getElementById('dm-chat-media-list');
    const drawerMediaCount = document.getElementById('drawer-media-count');
    if (!listElem) return;

    if (!window.currentThreadMessages || window.currentThreadMessages.length === 0) {
        if (drawerMediaCount) drawerMediaCount.innerText = "(0)";
        listElem.innerHTML = `<p class="text-[11px] text-slate-400 text-center py-8">Nenhuma mensagem nesta conversa.</p>`;
        return;
    }

    const mediaMsgs = window.currentThreadMessages.filter(m => m.media_path);
    if (drawerMediaCount) drawerMediaCount.innerText = `(${mediaMsgs.length})`;

    if (mediaMsgs.length === 0) {
        listElem.innerHTML = `<p class="text-[11px] text-slate-400 text-center py-8">Nenhuma mídia encontrada neste chat.</p>`;
        return;
    }

    let html = `
        <div class="space-y-2">
            <div class="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-1">
                ${mediaMsgs.length} Mídias Trocadas
            </div>
            <div class="grid grid-cols-2 gap-1.5">
    `;

    mediaMsgs.forEach(m => {
        const sender = m.sender_username || m.sender_id || 'Alvo';
        if (m.message_type === 'image') {
            html += `
                <div class="group/cmedia relative rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 aspect-square cursor-pointer" onclick="jumpToMessageInDm('${m.thread_id}', ${m.id})" title="Enviado por @${escapeHtml(sender)} em ${m.timestamp_brt || m.timestamp_utc}">
                    <img src="${m.media_path}" class="w-full h-full object-cover group-hover/cmedia:scale-105 transition duration-200">
                    <div class="absolute inset-0 bg-black/40 opacity-0 group-hover/cmedia:opacity-100 flex flex-col items-center justify-center text-white text-[10px] transition p-1 text-center">
                        <span class="font-bold truncate max-w-full">@${escapeHtml(sender)}</span>
                        <span class="text-[8px] opacity-80">${m.timestamp_brt ? m.timestamp_brt.split(' ')[0] : ''}</span>
                        <span class="mt-1 px-1.5 py-0.5 rounded bg-blue-600 text-[8px] font-bold">Ver no Chat</span>
                    </div>
                </div>
            `;
        } else if (m.message_type === 'video') {
            html += `
                <div class="group/cmedia relative rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900 aspect-square cursor-pointer flex items-center justify-center" onclick="jumpToMessageInDm('${m.thread_id}', ${m.id})" title="Vídeo de @${escapeHtml(sender)}">
                    <video class="w-full h-full object-cover opacity-60">
                        <source src="${m.media_path}" type="video/mp4">
                    </video>
                    <div class="absolute inset-0 flex flex-col items-center justify-center text-white text-[10px] p-1 text-center">
                        <div class="w-6 h-6 rounded-full bg-purple-600 flex items-center justify-center mb-1 shadow">
                            <i data-lucide="play" class="w-3 h-3 ml-0.5 fill-white"></i>
                        </div>
                        <span class="font-bold truncate max-w-full">@${escapeHtml(sender)}</span>
                    </div>
                </div>
            `;
        } else if (m.message_type === 'audio') {
            html += `
                <div class="col-span-2 p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-amber-500/5 hover:bg-amber-500/10 transition cursor-pointer flex items-center space-x-2" onclick="jumpToMessageInDm('${m.thread_id}', ${m.id})" title="Clique para ir para a mensagem">
                    <div class="w-7 h-7 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center flex-shrink-0 font-bold">
                        <i data-lucide="mic" class="w-3.5 h-3.5"></i>
                    </div>
                    <div class="flex-1 min-w-0 text-[10px]">
                        <span class="font-bold text-slate-800 dark:text-slate-200 block truncate">@${escapeHtml(sender)}</span>
                        <span class="text-[9px] text-slate-500 block">${m.timestamp_brt || m.timestamp_utc}</span>
                    </div>
                    <span class="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300 font-bold">Áudio</span>
                </div>
            `;
        }
    });

    html += `</div></div>`;
    listElem.innerHTML = html;
    lucide.createIcons();
}

// ==================== SALTO DIRETO PARA MENSAGEM NO CHAT ====================
async function jumpToMessageInDm(threadId, messageId) {
    if (!threadId) return;

    window.isJumpingToMessage = true;

    // 1. Alternar visualmente para a sub-aba de DMs
    switchIgSubTab('dms');

    // 2. Garantir que as threads estejam carregadas
    if (!cachedDmThreads || cachedDmThreads.length === 0) {
        await loadDmThreads(window.currentOpId, window.currentPhaseId, window.currentTargetId);
    }

    // 3. Localizar a conversa na lista de threads
    const found = cachedDmThreads ? cachedDmThreads.find(t => String(t.thread_id) === String(threadId)) : null;
    const label = found ? formatDmParticipants(found.participants) : `Thread ${threadId}`;
    const count = found ? found.message_count : 0;

    // 4. Abrir e rolar direto até a mensagem com highlight pulsante
    await selectDmThread(threadId, label, count, true, messageId);

    setTimeout(() => {
        window.isJumpingToMessage = false;
    }, 2500);
}

// ==================== ABA GLOBAL: GALERIA DE MÍDIAS FORENSE ====================
let currentMediaFilterType = 'all';
let currentMediaSearch = '';
let currentMediaPage = 1;
let currentMediaLimit = 40;
let currentMediaTotal = 0;

function setMediaFilterType(type) {
    currentMediaFilterType = type;
    currentMediaPage = 1;

    const types = ['all', 'image', 'video', 'audio'];
    types.forEach(t => {
        const btn = document.getElementById(`btn-media-filter-${t}`);
        if (!btn) return;
        if (t === type) {
            btn.className = "px-2.5 py-1 rounded-lg bg-pink-600 text-white font-bold transition shadow-xs flex items-center space-x-1.5 text-xs shrink-0 whitespace-nowrap";
        } else {
            btn.className = "px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition shadow-xs flex items-center space-x-1.5 font-medium text-xs shrink-0 whitespace-nowrap";
        }
    });

    const btnTranscribeAll = document.getElementById('btn-gallery-transcribe-all');
    if (btnTranscribeAll) {
        if (type === 'audio') {
            btnTranscribeAll.classList.remove('hidden');
        } else {
            btnTranscribeAll.classList.add('hidden');
        }
    }

    if (window.currentOpId) {
        loadIgMediaGallery(window.currentOpId, window.currentPhaseId, window.currentTargetId);
    }
}

let mediaSearchTimeout = null;
function handleMediaSearch(event) {
    clearTimeout(mediaSearchTimeout);
    mediaSearchTimeout = setTimeout(() => {
        currentMediaSearch = document.getElementById('media-search-input')?.value.trim() || '';
        currentMediaPage = 1;
        if (window.currentOpId) {
            loadIgMediaGallery(window.currentOpId, window.currentPhaseId, window.currentTargetId);
        }
    }, 300);
}

function changeMediaPage(delta) {
    const newPage = currentMediaPage + delta;
    if (newPage >= 1 && newPage <= Math.ceil(currentMediaTotal / currentMediaLimit)) {
        currentMediaPage = newPage;
        if (window.currentOpId) {
            loadIgMediaGallery(window.currentOpId, window.currentPhaseId, window.currentTargetId);
        }
    }
}

window.currentMediaSortOrder = window.currentMediaSortOrder || 'desc';

function changeMediaSortOrder(order) {
    window.currentMediaSortOrder = order || 'desc';
    currentMediaPage = 1;
    if (window.currentOpId) {
        loadIgMediaGallery(window.currentOpId, window.currentPhaseId, window.currentTargetId);
    }
}
window.changeMediaSortOrder = changeMediaSortOrder;

async function loadIgMediaGallery(operationId, phaseId = null, targetId = null, accountUid = null) {
    operationId = operationId || window.currentOpId;
    phaseId = phaseId || window.currentPhaseId;
    targetId = targetId || window.currentTargetId;
    if (!operationId) return;

    const grid = document.getElementById('ig-media-grid');
    if (!grid) return;

    grid.innerHTML = `<div class="col-span-full text-center py-16 text-slate-400 text-xs flex flex-col items-center justify-center space-y-2"><i data-lucide="loader-2" class="w-6 h-6 animate-spin text-pink-500"></i><span>Carregando galeria pericial de mídias...</span></div>`;
    lucide.createIcons();

    const effectiveAccountUid = accountUid || currentSelectedAccountUid;

    try {
        let url = `/api/instagram/media?operation_id=${operationId}&page=${currentMediaPage}&limit=${currentMediaLimit}`;
        if (phaseId) url += `&phase_id=${phaseId}`;
        if (targetId) url += `&target_id=${targetId}`;
        if (effectiveAccountUid) url += `&account_uid=${encodeURIComponent(effectiveAccountUid)}`;
        if (currentMediaFilterType !== 'all') url += `&media_type=${currentMediaFilterType}`;
        if (currentMediaSearch) url += `&search=${encodeURIComponent(currentMediaSearch)}`;
        if (window.currentMediaSortOrder) url += `&order=${window.currentMediaSortOrder}`;

        const res = await fetch(url);
        const data = await res.json();
        window.currentGalleryMediaItems = data.media || [];

        currentMediaTotal = data.total || 0;

        // Atualizar contadores
        const st = data.stats || {};
        const statAll = document.getElementById('stat-media-all');
        const statPhotos = document.getElementById('stat-media-photos');
        const statVideos = document.getElementById('stat-media-videos');
        const statAudios = document.getElementById('stat-media-audios');

        if (statAll) statAll.innerText = (st.total || 0).toLocaleString();
        if (statPhotos) statPhotos.innerText = (st.image || 0).toLocaleString();
        if (statVideos) statVideos.innerText = (st.video || 0).toLocaleString();
        if (statAudios) statAudios.innerText = (st.audio || 0).toLocaleString();

        // Sincronizar controles visuais de ordenação e velocidade
        const sortSelect = document.getElementById('media-sort-order');
        if (sortSelect && window.currentMediaSortOrder) {
            sortSelect.value = window.currentMediaSortOrder;
        }
        const globalSpeedGallery = document.getElementById('btn-global-speed-gallery');
        if (globalSpeedGallery) {
            const span = globalSpeedGallery.querySelector('span');
            if (span) span.innerText = getGlobalAudioSpeedLabel();
        }

        // Paginação
        const pagInfo = document.getElementById('media-pagination-info');
        const btnPrev = document.getElementById('media-prev-page');
        const btnNext = document.getElementById('media-next-page');

        const totalPages = Math.ceil(currentMediaTotal / currentMediaLimit) || 1;
        if (pagInfo) pagInfo.innerText = `Mostrando ${data.media.length} de ${currentMediaTotal} mídias • Página ${currentMediaPage} de ${totalPages}`;
        if (btnPrev) btnPrev.disabled = (currentMediaPage <= 1);
        if (btnNext) btnNext.disabled = (currentMediaPage >= totalPages);

        renderIgMediaGrid(data.media || []);
        updateGalleryPendingAudiosCount(data.media || []);

    } catch (err) {
        console.error("Erro ao carregar galeria de mídias:", err);
        grid.innerHTML = `<p class="col-span-full text-center text-red-500 text-xs py-8">Erro ao carregar mídias.</p>`;
    }
}

function renderIgMediaGrid(items) {
    const grid = document.getElementById('ig-media-grid');
    if (!grid) return;

    if (items.length === 0) {
        grid.innerHTML = `
            <div class="col-span-full text-center py-16 bg-white dark:bg-slate-900/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 p-6 space-y-2">
                <i data-lucide="image-off" class="w-10 h-10 mx-auto text-slate-400"></i>
                <h4 class="text-xs font-bold text-slate-700 dark:text-slate-300">Nenhuma mídia encontrada com os filtros selecionados</h4>
                <p class="text-[11px] text-slate-500">Tente buscar por outro termo ou alterar o tipo de arquivo.</p>
            </div>
        `;
        lucide.createIcons();
        return;
    }

    let html = '';
    items.forEach(m => {
        const sender = m.sender_username || m.sender_id || 'Investigado';
        const senderClean = (m.sender_username || '').replace(/^@/, '').toLowerCase().trim();
        const senderIdStr = String(m.sender_id || '').trim();
        const currentTargetVanity = (window.currentTargetVanity || '').replace(/^@/, '').toLowerCase().trim();
        const currentTargetUid = String(window.currentTargetUid || '').trim();

        // Verificar dinamicamente se o remetente é o investigado ou qualquer uma das contas vinculadas
        let isTarget = false;
        if (currentTargetVanity && senderClean === currentTargetVanity) isTarget = true;
        if (currentTargetUid && senderIdStr === currentTargetUid) isTarget = true;
        if (window.operationTargetHandles && window.operationTargetHandles.has(senderClean)) isTarget = true;
        if (Array.isArray(window.currentTargetAccounts) && window.currentTargetAccounts.length > 0) {
            if (window.currentTargetAccounts.some(a => 
                (a.vanity_name && a.vanity_name.replace(/^@/, '').toLowerCase().trim() === senderClean) ||
                (a.target_uid && String(a.target_uid).trim() === senderIdStr)
            )) {
                isTarget = true;
            }
        }

        const senderBadge = isTarget
            ? `<span class="px-1.5 py-0.5 rounded-full bg-pink-500/20 text-pink-700 dark:text-pink-300 font-bold text-[9px] border border-pink-500/30">Alvo (@${escapeHtml(sender.replace(/^@/, ''))})</span>`
            : `<span class="px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-[9px] border border-slate-200 dark:border-slate-700">@${escapeHtml(sender.replace(/^@/, ''))}</span>`;

        const evInfo = evidenceTagsMap[String(m.id)];
        const isEvidence = !!evInfo;
        const msgTags = evInfo ? (evInfo.tags || (evInfo.tag_label ? [evInfo.tag_label] : ['Prova Chave'])) : [];

        const evidenceBtn = `
            <button id="gallery-tag-btn-${m.id}" onclick="toggleEvidenceTagPopover(${m.id}, event)" title="${isEvidence ? `Evidência (${escapeHtml(msgTags.join(', '))}) • Clique para editar tags` : 'Classificar evidência'}" class="px-1.5 py-0.5 rounded text-[9px] font-bold ${isEvidence ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 border border-amber-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-amber-500 hover:text-slate-950'} flex items-center space-x-1 transition shadow-xs select-none">
                <i data-lucide="tag" class="w-3 h-3 ${isEvidence ? 'fill-slate-950' : ''}"></i>
                <span>Tag</span>
            </button>
        `;

        if (m.message_type === 'image') {
            html += `
                <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs hover:shadow-md transition duration-200 flex flex-col justify-between group/mcard">
                    <!-- Thumbnail com Lightbox ao Clicar -->
                    <div class="relative aspect-square bg-slate-100 dark:bg-slate-950 overflow-hidden cursor-pointer" onclick="openMediaViewer('${m.media_path}', 'image', '${escapeHtml(sender)}')">
                        <img src="${m.media_path}" class="w-full h-full object-cover group-hover/mcard:scale-105 transition duration-300" loading="lazy">
                        <div class="absolute inset-0 bg-black/40 opacity-0 group-hover/mcard:opacity-100 flex items-center justify-center transition text-white text-xs font-bold space-x-1 backdrop-blur-[1px]">
                            <i data-lucide="zoom-in" class="w-4 h-4"></i>
                            <span>Ampliar</span>
                        </div>
                        <span class="absolute top-2 left-2 px-1.5 py-0.2 rounded bg-black/60 text-white font-bold text-[9px] backdrop-blur-xs flex items-center space-x-0.5">
                            <i data-lucide="image" class="w-2.5 h-2.5"></i>
                            <span>Foto</span>
                        </span>
                    </div>

                    <!-- Rodapé do Card -->
                    <div class="p-2.5 space-y-1.5 text-[10px]">
                        <div class="flex items-center justify-between">
                            ${senderBadge}
                            <span class="font-mono text-slate-400 text-[9px]">${m.timestamp_brt ? m.timestamp_brt.split(' ')[0] : ''}</span>
                        </div>
                        ${m.content && m.content !== 'You sent a voice message.' ? `<p class="text-[11px] text-slate-700 dark:text-slate-300 truncate font-medium" title="${escapeHtml(m.content)}">${escapeHtml(m.content)}</p>` : ''}
                        <div class="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800/80">
                            <button onclick="jumpToMessageInDm('${m.thread_id}', ${m.id})" title="Abrir esta conversa no chat" class="px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-cyan-400 hover:bg-blue-100 dark:hover:bg-blue-900/60 font-bold flex items-center space-x-1 transition text-[9px]">
                                <i data-lucide="message-square" class="w-2.5 h-2.5"></i>
                                <span>Ver no Chat ↗</span>
                            </button>
                            ${evidenceBtn}
                        </div>
                    </div>
                </div>
            `;
        } else if (m.message_type === 'video') {
            html += `
                <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs hover:shadow-md transition duration-200 flex flex-col justify-between group/mcard">
                    <!-- Thumbnail de Vídeo -->
                    <div class="relative aspect-square bg-slate-950 overflow-hidden cursor-pointer flex items-center justify-center" onclick="openMediaViewer('${m.media_path}', 'video', '${escapeHtml(sender)}')">
                        <video class="w-full h-full object-cover opacity-70">
                            <source src="${m.media_path}" type="video/mp4">
                        </video>
                        <div class="absolute inset-0 bg-black/30 flex items-center justify-center group-hover/mcard:bg-black/50 transition">
                            <div class="w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center shadow-lg group-hover/mcard:scale-110 transition">
                                <i data-lucide="play" class="w-5 h-5 ml-0.5 fill-white"></i>
                            </div>
                        </div>
                        <span class="absolute top-2 left-2 px-1.5 py-0.2 rounded bg-purple-600 text-white font-bold text-[9px] flex items-center space-x-0.5 shadow">
                            <i data-lucide="video" class="w-2.5 h-2.5"></i>
                            <span>Vídeo</span>
                        </span>
                    </div>

                    <!-- Rodapé do Card -->
                    <div class="p-2.5 space-y-1.5 text-[10px]">
                        <div class="flex items-center justify-between">
                            ${senderBadge}
                            <span class="font-mono text-slate-400 text-[9px]">${m.timestamp_brt ? m.timestamp_brt.split(' ')[0] : ''}</span>
                        </div>
                        ${m.content ? `<p class="text-[11px] text-slate-700 dark:text-slate-300 truncate font-medium" title="${escapeHtml(m.content)}">${escapeHtml(m.content)}</p>` : ''}
                        <div class="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800/80">
                            <button onclick="jumpToMessageInDm('${m.thread_id}', ${m.id})" title="Abrir esta conversa no chat" class="px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-cyan-400 hover:bg-blue-100 dark:hover:bg-blue-900/60 font-bold flex items-center space-x-1 transition text-[9px]">
                                <i data-lucide="message-square" class="w-2.5 h-2.5"></i>
                                <span>Ver no Chat ↗</span>
                            </button>
                            ${evidenceBtn}
                        </div>
                    </div>
                </div>
            `;
        } else if (m.message_type === 'audio') {
            const isTranscribed = !!(m.transcription && m.transcription.trim());
            const transBoxHtml = isTranscribed
                ? renderGalleryAudioTranscriptionBox(m, currentMediaSearch)
                : `
                    <div id="gallery-trans-container-${m.id}" class="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between">
                        <span class="text-[10px] text-slate-400 italic">Áudio não transcrito</span>
                        <button id="btn-gallery-transcribe-${m.id}" onclick="transcribeGallerySingleAudio(${m.id}, this)" class="px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 text-[10px] font-semibold flex items-center space-x-1 transition shadow-2xs" title="Transcrever com Whisper small">
                            <i data-lucide="sparkles" class="w-3 h-3 text-indigo-500"></i>
                            <span>Transcrever</span>
                        </button>
                    </div>
                `;

            html += `
                <div id="gallery-card-${m.id}" class="bg-white dark:bg-slate-900 border ${isTranscribed ? 'border-indigo-200/80 dark:border-indigo-900/50' : 'border-slate-200 dark:border-slate-800'} rounded-xl p-3 shadow-xs hover:shadow-md transition duration-200 flex flex-col justify-between group/mcard">
                    <!-- Topo e Player de Áudio agrupados com espaçamento fixo -->
                    <div class="space-y-2">
                        <div class="flex items-start justify-between">
                            <div class="flex items-center space-x-2 min-w-0">
                                <div class="w-7 h-7 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center flex-shrink-0 font-bold">
                                    <i data-lucide="mic" class="w-3.5 h-3.5"></i>
                                </div>
                                <div class="min-w-0">
                                    ${senderBadge}
                                    <span class="text-[9px] text-slate-400 font-mono block mt-0.5">${m.timestamp_brt || m.timestamp_utc}</span>
                                </div>
                            </div>
                            <span class="px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-700 dark:text-amber-300 font-bold text-[9px] flex-shrink-0">Áudio</span>
                        </div>

                        <!-- Player de Áudio Embutido com Velocidade Global -->
                        <div class="bg-slate-50 dark:bg-slate-950 p-2 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                            <div class="flex items-center gap-1.5">
                                <audio id="gallery-audio-${m.id}" controls class="w-full h-8 outline-none rounded-lg flex-1">
                                    <source src="${m.media_path}" type="audio/mpeg">
                                    <source src="${m.media_path}" type="audio/aac">
                                    <source src="${m.media_path}" type="audio/ogg">
                                </audio>
                                <button onclick="toggleAudioSpeed('gallery-audio-${m.id}', this)" class="btn-audio-speed px-2 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 border border-slate-300 dark:border-slate-700 text-[10px] font-mono font-bold flex-shrink-0 transition shadow-xs" title="Velocidade global do áudio (1.0x, 1.25x, 1.5x, 2.0x)">
                                    <span>${getGlobalAudioSpeedLabel()}</span>
                                </button>
                            </div>
                        </div>

                        <!-- Área de Transcrição Pericial -->
                        ${transBoxHtml}
                    </div>

                    <!-- Rodapé no Fim do Card -->
                    <div class="flex items-center justify-between pt-2 mt-3 border-t border-slate-100 dark:border-slate-800/80">
                        <button onclick="jumpToMessageInDm('${m.thread_id}', ${m.id})" title="Abrir esta conversa no chat" class="px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-cyan-400 hover:bg-blue-100 dark:hover:bg-blue-900/60 font-bold flex items-center space-x-1 transition text-[9px]">
                            <i data-lucide="message-square" class="w-2.5 h-2.5"></i>
                            <span>Ver no Chat ↗</span>
                        </button>
                        ${evidenceBtn}
                    </div>
                </div>
            `;
        }
    });

    grid.innerHTML = html;
    lucide.createIcons();
    attachGalleryContinuousAudio();
}

function renderGalleryAudioTranscriptionBox(m, searchTerm = '') {
    const isEdited = m.transcription_status === 'edited' || m.transcribed_by === 'analyst';
    const transBadge = isEdited ? '👤 Revisada' : '📝 Whisper';
    let textHtml = escapeHtml(m.transcription || '');
    if (searchTerm && searchTerm.trim()) {
        try {
            const cleanSearch = searchTerm.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regex = new RegExp(`(${cleanSearch})`, 'gi');
            textHtml = textHtml.replace(regex, '<mark class="bg-amber-300 dark:bg-amber-500/40 text-slate-950 dark:text-amber-200 px-0.5 rounded font-bold">$1</mark>');
        } catch (e) {}
    }

    return `
        <div id="gallery-trans-container-${m.id}" class="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/60 space-y-1.5 select-text">
            <div class="flex items-center justify-between text-[9px] text-slate-500 dark:text-slate-400 select-none">
                <span class="font-bold flex items-center space-x-1 text-indigo-600 dark:text-indigo-400">
                    <i data-lucide="file-text" class="w-2.5 h-2.5"></i>
                    <span>${transBadge}</span>
                </span>
                <div class="flex items-center space-x-1.5">
                    <button onclick="copyTranscriptionDirect('${m.id}')" class="hover:underline flex items-center space-x-0.5 text-slate-600 dark:text-slate-300 hover:text-indigo-600" title="Copiar texto da transcrição">
                        <i data-lucide="copy" class="w-2.5 h-2.5"></i>
                        <span>Copiar</span>
                    </button>
                    <span>•</span>
                    <button onclick="openEditTranscriptionModal(${m.id})" class="hover:underline flex items-center space-x-0.5 text-amber-500 hover:text-amber-400 font-semibold" title="Editar transcrição pericial">
                        <i data-lucide="edit-3" class="w-2.5 h-2.5"></i>
                        <span>Editar</span>
                    </button>
                </div>
            </div>
            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800/80">
                <p id="gallery-trans-text-${m.id}" class="text-[10px] leading-relaxed italic font-medium font-sans text-slate-700 dark:text-slate-300">"${textHtml}"</p>
            </div>
        </div>
    `;
}

function updateGalleryPendingAudiosCount(mediaList) {
    const audios = (mediaList || []).filter(m => m.message_type === 'audio');
    const pending = audios.filter(m => !m.transcription || !m.transcription.trim());
    const countEl = document.getElementById('gallery-pending-audios-count');
    const btnAll = document.getElementById('btn-gallery-transcribe-all');
    const labelEl = document.getElementById('btn-gallery-transcribe-label');
    if (countEl) countEl.innerText = pending.length;
    if (btnAll) {
        if (currentMediaFilterType === 'audio') {
            btnAll.classList.remove('hidden');
            if (pending.length === 0) {
                btnAll.disabled = true;
                btnAll.classList.add('opacity-60', 'cursor-not-allowed');
                btnAll.title = "Todos os áudios exibidos já foram transcritos";
                if (labelEl) labelEl.innerText = "Áudios Transcritos";
            } else {
                btnAll.disabled = false;
                btnAll.classList.remove('opacity-60', 'cursor-not-allowed');
                btnAll.title = `Transcrever ${pending.length} áudio(s) pendente(s) com Whisper`;
                if (labelEl) labelEl.innerText = "Transcrever Áudios";
            }
        } else {
            btnAll.classList.add('hidden');
        }
    }
}

async function transcribeAllGalleryAudios() {
    await ensureWhisperReady(async () => {
        await _doTranscribeAllGalleryAudios();
    });
}

async function _doTranscribeAllGalleryAudios() {
    if (!window.currentGalleryMediaItems || window.currentGalleryMediaItems.length === 0) return;
    const pending = window.currentGalleryMediaItems.filter(m => m.message_type === 'audio' && (!m.transcription || !m.transcription.trim()));
    if (pending.length === 0) {
        alert("Todos os áudios exibidos nesta página já estão transcritos!");
        return;
    }

    const btnAll = document.getElementById('btn-gallery-transcribe-all');
    const labelEl = document.getElementById('btn-gallery-transcribe-label');
    const countEl = document.getElementById('gallery-pending-audios-count');
    const origBtnHtml = btnAll ? btnAll.innerHTML : '';

    if (btnAll) {
        btnAll.disabled = true;
        btnAll.classList.add('cursor-wait');
    }

    let completed = 0;
    const total = pending.length;

    for (let i = 0; i < total; i++) {
        const item = pending[i];
        if (labelEl) labelEl.innerText = `Transcrevendo ${i + 1}/${total}...`;

        // Indicar loading no card específico
        const cardContainer = document.getElementById(`gallery-trans-container-${item.id}`);
        if (cardContainer) {
            cardContainer.innerHTML = `
                <div class="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/60 flex items-center space-x-1.5 text-indigo-500 text-[10px] font-semibold animate-pulse">
                    <i data-lucide="loader-2" class="w-3 h-3 animate-spin"></i>
                    <span>Processando áudio com Whisper small (${i + 1}/${total})...</span>
                </div>
            `;
            if (window.lucide) lucide.createIcons();
        }

        try {
            const res = await fetch(`/api/messages/${item.id}/transcribe`, { method: 'POST' });
            const data = await res.json();
            if (res.ok && data.success && data.data) {
                completed++;
                // Atualizar no array da galeria
                item.transcription = data.data.transcription;
                item.transcription_status = data.data.transcription_status;
                item.transcribed_by = data.data.transcribed_by;
                item.transcribed_at = data.data.transcribed_at;

                // Atualizar card individual no DOM IMEDIATAMENTE com efeito de destaque
                const updatedContainer = document.getElementById(`gallery-trans-container-${item.id}`);
                if (updatedContainer) {
                    const boxHtml = renderGalleryAudioTranscriptionBox(item, currentMediaSearch);
                    updatedContainer.outerHTML = boxHtml;
                    const newBox = document.getElementById(`gallery-trans-container-${item.id}`);
                    if (newBox) {
                        newBox.classList.add('ring-2', 'ring-emerald-400', 'transition', 'duration-500');
                        setTimeout(() => newBox.classList.remove('ring-2', 'ring-emerald-400'), 2500);
                    }
                    if (window.lucide) lucide.createIcons();
                }
            }
        } catch (err) {
            console.error(`Erro ao transcrever áudio ${item.id}:`, err);
            if (cardContainer) {
                cardContainer.innerHTML = `
                    <div class="mt-2 pt-2 border-t border-red-200 dark:border-red-900/60 flex items-center justify-between text-red-500 text-[10px]">
                        <span>Erro ao transcrever</span>
                        <button onclick="transcribeGallerySingleAudio(${item.id}, this)" class="underline font-semibold">Tentar novamente</button>
                    </div>
                `;
            }
        }

        if (countEl) countEl.innerText = Math.max(0, total - completed);
    }

    if (btnAll) {
        btnAll.disabled = false;
        btnAll.classList.remove('cursor-wait');
        btnAll.innerHTML = origBtnHtml;
        if (window.lucide) lucide.createIcons();
    }

    updateGalleryPendingAudiosCount(window.currentGalleryMediaItems);
}

async function transcribeGallerySingleAudio(msgId, btn) {
    await ensureWhisperReady(async () => {
        await _doTranscribeGallerySingleAudio(msgId, btn);
    });
}

async function _doTranscribeGallerySingleAudio(msgId, btn) {
    if (!btn) btn = document.getElementById(`btn-gallery-transcribe-${msgId}`);
    const origHtml = btn ? btn.innerHTML : '';
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<i data-lucide="loader-2" class="w-3 h-3 animate-spin"></i><span>Transcrevendo...</span>`;
        if (window.lucide) lucide.createIcons();
    }

    try {
        const res = await fetch(`/api/messages/${msgId}/transcribe`, { method: 'POST' });
        const data = await res.json();
        if (!res.ok || !data.success) {
            throw new Error(data.detail || 'Falha na transcrição');
        }

        const transData = data.data;

        if (Array.isArray(window.currentGalleryMediaItems)) {
            const item = window.currentGalleryMediaItems.find(x => x.id === msgId);
            if (item) {
                item.transcription = transData.transcription;
                item.transcription_status = transData.transcription_status;
                item.transcribed_by = transData.transcribed_by;
                item.transcribed_at = transData.transcribed_at;
            }
        }

        const container = document.getElementById(`gallery-trans-container-${msgId}`);
        if (container) {
            const dummyItem = (window.currentGalleryMediaItems || []).find(x => x.id === msgId) || {
                id: msgId,
                transcription: transData.transcription,
                transcription_status: transData.transcription_status,
                transcribed_by: transData.transcribed_by
            };
            container.outerHTML = renderGalleryAudioTranscriptionBox(dummyItem, currentMediaSearch);
            const newBox = document.getElementById(`gallery-trans-container-${msgId}`);
            if (newBox) {
                newBox.classList.add('ring-2', 'ring-emerald-400', 'transition', 'duration-500');
                setTimeout(() => newBox.classList.remove('ring-2', 'ring-emerald-400'), 2500);
            }
            if (window.lucide) lucide.createIcons();
        }

        updateGalleryPendingAudiosCount(window.currentGalleryMediaItems);

    } catch (err) {
        console.error("Erro na transcrição de galeria:", err);
        alert("Erro ao transcrever áudio: " + err.message);
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = origHtml;
            if (window.lucide) lucide.createIcons();
        }
    }
}

function copyTranscriptionDirect(msgId) {
    let text = '';
    const el = document.getElementById(`gallery-trans-text-${msgId}`) || document.getElementById(`transcription-text-${msgId}`);
    if (el) {
        text = el.innerText.replace(/^"|"$/g, '').trim();
    } else if (Array.isArray(window.currentGalleryMediaItems)) {
        const item = window.currentGalleryMediaItems.find(x => x.id === Number(msgId));
        if (item) text = item.transcription || '';
    }
    if (text) {
        navigator.clipboard.writeText(text).then(() => {
            alert("Transcrição copiada para a área de transferência!");
        }).catch(() => {
            const ta = document.createElement('textarea');
            ta.value = text;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            alert("Transcrição copiada!");
        });
    }
}

function formatAnalystDate(dateStr) {
    if (!dateStr) {
        const now = new Date();
        const pad = (n) => String(n).padStart(2, '0');
        return `${pad(now.getDate())}/${pad(now.getMonth() + 1)}/${now.getFullYear()} às ${pad(now.getHours())}:${pad(now.getMinutes())}`;
    }
    try {
        let d = new Date(dateStr.replace(' ', 'T'));
        if (isNaN(d.getTime())) {
            d = new Date();
        }
        const pad = (n) => String(n).padStart(2, '0');
        return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} às ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    } catch (e) {
        return dateStr;
    }
}

async function removeThreadBookmark(event) {
    if (event) event.stopPropagation();
    if (!window.currentOpId || !currentSelectedThreadId) return;

    try {
        await fetch('/api/dms/annotations/set-bookmark', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                operation_id: window.currentOpId,
                platform: 'instagram',
                thread_id: currentSelectedThreadId,
                message_id: null
            })
        });

        if (dmAnnotations[currentSelectedThreadId]) {
            dmAnnotations[currentSelectedThreadId].last_read_message_id = null;
        }

        const existingAnchor = document.getElementById('dm-msg-bookmark-anchor');
        if (existingAnchor) existingAnchor.remove();

        document.querySelectorAll('[id^="bookmark-btn-"]').forEach(btn => {
            btn.className = 'opacity-0 group-hover:opacity-100 text-slate-300 hover:text-amber-400 p-0.5 transition';
            btn.title = 'Marcar onde parei nesta mensagem';
            btn.onclick = (e) => {
                const mId = parseInt(btn.id.replace('bookmark-btn-', ''));
                setThreadBookmark(mId, e);
            };
        });

        const btnBookmark = document.getElementById('btn-jump-bookmark');
        if (btnBookmark) btnBookmark.classList.add('hidden');

        updateDmProgress();
        renderFilteredDmThreads();
        lucide.createIcons();
    } catch (err) {
        console.error("Erro ao remover marcador:", err);
    }
}

async function setThreadBookmark(messageId, event) {
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }
    if (!window.currentOpId || !currentSelectedThreadId) return;

    const container = document.getElementById('dm-messages-container');
    const prevScrollTop = container ? container.scrollTop : 0;

    try {
        const res = await fetch('/api/dms/annotations/set-bookmark', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                operation_id: window.currentOpId,
                platform: 'instagram',
                thread_id: currentSelectedThreadId,
                message_id: messageId
            })
        });
        const data = await res.json();

        if (!dmAnnotations[currentSelectedThreadId]) dmAnnotations[currentSelectedThreadId] = {};
        dmAnnotations[currentSelectedThreadId].last_read_message_id = messageId;
        dmAnnotations[currentSelectedThreadId].updated_at = data.updated_at || new Date().toISOString();

        // 1. Remover âncora anterior se houver
        const existingAnchor = document.getElementById('dm-msg-bookmark-anchor');
        if (existingAnchor) existingAnchor.remove();

        // 2. Resetar todos os botões de bookmark
        document.querySelectorAll('[id^="bookmark-btn-"]').forEach(btn => {
            btn.className = 'opacity-0 group-hover:opacity-100 text-slate-300 hover:text-amber-400 p-0.5 transition';
            btn.title = 'Marcar onde parei nesta mensagem';
            btn.onclick = (e) => {
                const mId = parseInt(btn.id.replace('bookmark-btn-', ''));
                setThreadBookmark(mId, e);
            };
        });

        // 3. Ativar botão na mensagem marcada
        const targetBtn = document.getElementById(`bookmark-btn-${messageId}`);
        if (targetBtn) {
            targetBtn.className = 'opacity-100 text-amber-500 hover:text-red-500 p-0.5 transition';
            targetBtn.title = 'Clique para desmarcar leitura';
            targetBtn.onclick = (e) => removeThreadBookmark(e);
        }

        // 4. Inserir divisor "VOCÊ PAROU AQUI" suavemente acima da mensagem mantendo o scroll estável
        const msgEl = document.getElementById(`msg-${messageId}`);
        if (msgEl) {
            const bookmarkTimestamp = formatAnalystDate(dmAnnotations[currentSelectedThreadId].updated_at);
            const dividerHtml = `
                <div id="dm-msg-bookmark-anchor" class="py-2.5 my-2 flex items-center justify-center space-x-2">
                    <div class="h-px bg-amber-500/40 flex-1"></div>
                    <div class="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-700 dark:text-amber-300 font-bold text-[10px] flex items-center space-x-2 shadow-xs">
                        <i data-lucide="bookmark" class="w-3 h-3 text-amber-500 fill-amber-500"></i>
                        <span>📍 VOCÊ PAROU AQUI • Marcado em ${bookmarkTimestamp}</span>
                        <button onclick="removeThreadBookmark(event)" title="Remover este marcador de leitura" class="ml-1 px-1.5 py-0.5 rounded text-[9px] font-semibold bg-red-500/15 hover:bg-red-500/25 text-red-600 dark:text-red-400 border border-red-500/20 transition flex items-center space-x-0.5">
                            <i data-lucide="x" class="w-2.5 h-2.5"></i>
                            <span>Desmarcar</span>
                        </button>
                    </div>
                    <div class="h-px bg-amber-500/40 flex-1"></div>
                </div>
            `;
            msgEl.insertAdjacentHTML('beforebegin', dividerHtml);
            if (container) {
                container.scrollTop = prevScrollTop;
            }
        }

        // 5. Exibir botão "Ir p/ Marcador" (apenas ícone) no topo
        const btnBookmark = document.getElementById('btn-jump-bookmark');
        if (btnBookmark) btnBookmark.classList.remove('hidden');

        updateDmProgress();
        renderFilteredDmThreads();
        lucide.createIcons();
    } catch (err) {
        console.error("Erro ao fixar marcador:", err);
    }
}

// ==================== AÇÕES DE ANOTAÇÃO DO ANALISTA ====================

async function setDmReadStatus(threadId, isRead) {
    if (!window.currentOpId || !threadId) return;
    try {
        await fetch('/api/dms/annotations/toggle-read', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ operation_id: window.currentOpId, platform: 'instagram', thread_id: threadId, is_read: isRead })
        });
        if (!dmAnnotations[threadId]) dmAnnotations[threadId] = {};
        dmAnnotations[threadId].is_read = isRead;
        updateDmProgress();
        renderFilteredDmThreads();
        
        // Se for a thread aberta no momento, atualizar o botão do cabeçalho
        if (threadId === currentSelectedThreadId) {
            const btnRead = document.getElementById('btn-toggle-read-status');
            if (btnRead) {
                btnRead.innerHTML = isRead
                    ? `<i data-lucide="check-check" class="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400"></i><span class="text-emerald-600 dark:text-emerald-400 font-bold">Lida</span>`
                    : `<i data-lucide="check" class="w-3.5 h-3.5 text-slate-500"></i><span class="text-slate-600 dark:text-slate-400">Pendente</span>`;
                lucide.createIcons();
            }
        }
    } catch (err) {
        console.error("Erro ao alternar status de leitura:", err);
    }
}

async function toggleCurrentThreadRead() {
    if (!currentSelectedThreadId) return;
    const currentStatus = !!(dmAnnotations[currentSelectedThreadId]?.is_read);
    const newStatus = !currentStatus;
    await setDmReadStatus(currentSelectedThreadId, newStatus);
}

async function toggleThreadReadFromList(threadId, event) {
    if (event) event.stopPropagation();
    const currentStatus = !!(dmAnnotations[threadId]?.is_read);
    await setDmReadStatus(threadId, !currentStatus);
}

async function toggleCurrentThreadStar() {
    if (!currentSelectedThreadId) return;
    const currentStatus = !!(dmAnnotations[currentSelectedThreadId]?.is_starred);
    const newStatus = !currentStatus;
    await setDmStarStatus(currentSelectedThreadId, newStatus);

    const btnStar = document.getElementById('btn-toggle-star-status');
    btnStar.innerHTML = newStatus
        ? `<i data-lucide="star" class="w-3.5 h-3.5 text-amber-500 fill-amber-500"></i>`
        : `<i data-lucide="star" class="w-3.5 h-3.5 text-slate-400"></i>`;
    lucide.createIcons();
}

async function toggleStarFromList(threadId, event) {
    if (event) event.stopPropagation();
    const currentStatus = !!(dmAnnotations[threadId]?.is_starred);
    await setDmStarStatus(threadId, !currentStatus);
}

async function setDmStarStatus(threadId, isStarred) {
    if (!window.currentOpId || !threadId) return;
    try {
        await fetch('/api/dms/annotations/toggle-star', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ operation_id: window.currentOpId, platform: 'instagram', thread_id: threadId, is_starred: isStarred })
        });
        if (!dmAnnotations[threadId]) dmAnnotations[threadId] = {};
        dmAnnotations[threadId].is_starred = isStarred;
        renderFilteredDmThreads();
    } catch (err) {
        console.error("Erro ao alternar estrela:", err);
    }
}

let dmSearchTimeout = null;
function handleDmSearch(e) {
    if (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (window.currentDmSearchMatches && window.currentDmSearchMatches.length > 0) {
                navigateDmSearchMatch(e.shiftKey ? -1 : 1);
                return;
            }
        }
        if (e.key === 'Escape') {
            clearDmSearch();
            return;
        }
    }

    clearTimeout(dmSearchTimeout);
    dmSearchTimeout = setTimeout(() => {
        const input = document.getElementById('dm-search-input');
        const clearBtn = document.getElementById('btn-clear-dm-search');
        const query = input ? input.value.trim() : '';
        currentDmSearchQuery = query;
        if (clearBtn) {
            if (query) clearBtn.classList.remove('hidden');
            else clearBtn.classList.add('hidden');
        }
        if (window.currentOpId) {
            loadDmThreads(window.currentOpId, window.currentPhaseId, window.currentTargetId, query);
        }
        if (currentSelectedThreadId && window.currentThreadMessages && window.currentThreadMessages.length > 0) {
            renderDmChatMessages(null, false);
        }
    }, 300);
}

function clearDmSearch() {
    const input = document.getElementById('dm-search-input');
    const clearBtn = document.getElementById('btn-clear-dm-search');
    if (input) input.value = '';
    if (clearBtn) clearBtn.classList.add('hidden');
    currentDmSearchQuery = '';
    closeDmChatSearch();
    if (window.currentOpId) {
        loadDmThreads(window.currentOpId, window.currentPhaseId, window.currentTargetId, '');
    }
    if (currentSelectedThreadId && window.currentThreadMessages && window.currentThreadMessages.length > 0) {
        renderDmChatMessages(null, true);
    }
}

// ==================== PAINEL DE INTELIGÊNCIA & GEOLOCALIZAÇÃO DE IPs ====================

let cachedIpIntelligenceData = null;
let currentIpTableViewMode = 'ranking';
let currentIpFilterCategory = 'all';
let currentIpFilterText = '';
let igLeafletMap = null;
let igLeafletMarkersGroup = null;

function setIpFilterCategory(category) {
    currentIpFilterCategory = category;

    const btnAll = document.getElementById('btn-ip-filter-all');
    const btnMobile = document.getElementById('btn-ip-filter-mobile');
    const btnProxy = document.getElementById('btn-ip-filter-proxy');
    const btnHosting = document.getElementById('btn-ip-filter-hosting');
    const btnIpv4 = document.getElementById('btn-ip-filter-ipv4');
    const btnIpv6 = document.getElementById('btn-ip-filter-ipv6');

    const activeClass = "px-2 py-1 rounded-md font-bold bg-blue-600 text-white shadow-xs transition";
    const inactiveClass = "px-2 py-1 rounded-md font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition";

    if (btnAll) btnAll.className = (category === 'all') ? activeClass : inactiveClass;
    if (btnMobile) btnMobile.className = (category === 'mobile') ? activeClass : inactiveClass;
    if (btnProxy) btnProxy.className = (category === 'proxy') ? activeClass : inactiveClass;
    if (btnHosting) btnHosting.className = (category === 'hosting') ? activeClass : inactiveClass;
    if (btnIpv4) btnIpv4.className = (category === 'ipv4') ? activeClass : inactiveClass;
    if (btnIpv6) btnIpv6.className = (category === 'ipv6') ? activeClass : inactiveClass;

    renderIpRankingTable();
    renderIpTimelineTable();
}

function setIpVersionFilter(version) {
    setIpFilterCategory(version);
}

async function loadIgConnections(opId, phaseId = null, targetId = null, accountUid = null) {
    const rankingBody = document.getElementById('ig-ip-ranking-body');
    const timelineBody = document.getElementById('ig-connections-body');
    const effectiveAccountUid = accountUid || currentSelectedAccountUid;

    try {
        let url = `/api/instagram/connections?operation_id=${opId}`;
        if (phaseId) url += `&phase_id=${phaseId}`;
        if (targetId) url += `&target_id=${targetId}`;
        if (effectiveAccountUid) url += `&account_uid=${encodeURIComponent(effectiveAccountUid)}`;

        const res = await fetch(url);
        const data = await res.json();
        cachedIpIntelligenceData = data;

        renderIpIntelligenceUI(data);
    } catch (err) {
        console.error("Erro ao carregar inteligência de IPs:", err);
        if (rankingBody) rankingBody.innerHTML = `<tr><td colspan="6" class="text-center py-6 text-red-400 font-medium">Erro ao carregar conexões de IP.</td></tr>`;
        if (timelineBody) timelineBody.innerHTML = `<tr><td colspan="5" class="text-center py-6 text-red-400 font-medium">Erro ao carregar conexões de IP.</td></tr>`;
    }
}

function renderIpIntelligenceUI(data) {
    if (!data) return;

    const stats = data.stats || {};
    const ranked = data.ranked_ips || [];
    const geoPoints = data.geo_points || [];

    // 1. Atualizar 4 KPI Cards
    const elTotal = document.getElementById('ip-kpi-total-conns');
    const elPeriod = document.getElementById('ip-kpi-activity-period');
    const elUnique = document.getElementById('ip-kpi-unique-ips');
    const elTopIp = document.getElementById('ip-kpi-top-ip');
    const elTopUsage = document.getElementById('ip-kpi-top-usage');
    const elRegIp = document.getElementById('ip-kpi-reg-ip');
    const elRegDate = document.getElementById('ip-kpi-reg-date');

    if (elTotal) elTotal.innerText = (stats.total_connections || 0).toLocaleString();
    if (elPeriod) elPeriod.innerText = `Primeiro: ${stats.first_activity_brt ? stats.first_activity_brt.split(' ')[0] : '---'} • Último: ${stats.last_activity_brt ? stats.last_activity_brt.split(' ')[0] : '---'}`;
    
    if (elUnique) {
        elUnique.innerText = (stats.unique_ips_count || 0).toLocaleString();
    }

    if (elTopIp) {
        elTopIp.innerText = stats.top_ip_clean || stats.top_ip || '---';
    }
    if (elTopUsage) {
        const ispLabel = stats.top_ip_isp && stats.top_ip_isp !== 'Pendente de consulta' ? ` • ${stats.top_ip_isp}` : '';
        elTopUsage.innerText = `${stats.top_ip_count || 0} conexões (${stats.top_ip_percent || 0}%)${ispLabel}`;
    }

    if (elRegIp) {
        const regClean = stats.registration_ip_clean || stats.registration_ip || 'Não informado';
        elRegIp.innerHTML = stats.registration_whois_url && regClean !== 'Não informado'
            ? `<a href="${stats.registration_whois_url}" target="_blank" rel="noopener noreferrer" class="hover:underline flex items-center space-x-1" title="Consultar Whois do IP de Criação"><span>${escapeHtml(regClean)}</span><i data-lucide="external-link" class="w-3 h-3 opacity-60"></i></a>`
            : escapeHtml(regClean);
    }
    if (elRegDate) elRegDate.innerText = `Data de Criação: ${stats.registration_date_brt || '---'}`;

    // Atualizar Contadores de Filtro
    const totalAll = ranked.length;
    const totalMobile = ranked.filter(r => r.is_mobile).length;
    const totalProxy = ranked.filter(r => r.is_proxy).length;
    const totalHosting = ranked.filter(r => r.is_hosting).length;
    const totalIpv4 = ranked.filter(r => r.ip_version === 'IPv4' || !r.ip_address.includes(':')).length;
    const totalIpv6 = ranked.filter(r => r.ip_version === 'IPv6' || r.ip_address.includes(':')).length;

    const cAll = document.getElementById('count-ip-filter-all');
    const cMobile = document.getElementById('count-ip-filter-mobile');
    const cProxy = document.getElementById('count-ip-filter-proxy');
    const cHosting = document.getElementById('count-ip-filter-hosting');
    const cIpv4 = document.getElementById('count-ip-filter-ipv4');
    const cIpv6 = document.getElementById('count-ip-filter-ipv6');

    if (cAll) cAll.innerText = totalAll;
    if (cMobile) cMobile.innerText = totalMobile;
    if (cProxy) cProxy.innerText = totalProxy;
    if (cHosting) cHosting.innerText = totalHosting;
    if (cIpv4) cIpv4.innerText = totalIpv4;
    if (cIpv6) cIpv6.innerText = totalIpv6;

    // 2. Atualizar Contador do Mapa
    const elMapCount = document.getElementById('ip-map-cities-count');
    if (elMapCount) elMapCount.innerText = `${geoPoints.length} localizações estimadas`;

    // 3. Renderizar Mapa Leaflet
    renderIpMap(geoPoints);

    // 4. Renderizar Tabelas
    renderIpRankingTable();
    renderIpTimelineTable();

    lucide.createIcons();
}

function renderIpMap(geoPoints) {
    const mapContainer = document.getElementById('ig-ip-map');
    if (!mapContainer || typeof L === 'undefined') return;

    if (!igLeafletMap) {
        igLeafletMap = L.map('ig-ip-map', {
            zoomControl: true,
            attributionControl: false
        }).setView([-14.235, -51.925], 4);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 18,
            attribution: '© OpenStreetMap contributors'
        }).addTo(igLeafletMap);

        igLeafletMarkersGroup = L.featureGroup().addTo(igLeafletMap);
    }

    if (igLeafletMarkersGroup) {
        igLeafletMarkersGroup.clearLayers();
    }

    if (!geoPoints || geoPoints.length === 0) {
        return;
    }

    const markers = [];
    const maxCount = Math.max(...geoPoints.map(p => p.total_count || 1), 1);

    geoPoints.forEach(p => {
        if (!p.lat || !p.lon) return;

        const ratio = (p.total_count || 1) / maxCount;
        const radius = Math.round(8 + ratio * 14);

        const isMain = ratio >= 0.5;
        const fillColor = isMain ? '#e11d48' : '#2563eb';
        const color = isMain ? '#fda4af' : '#93c5fd';

        const marker = L.circleMarker([p.lat, p.lon], {
            radius: radius,
            fillColor: fillColor,
            color: color,
            weight: 2,
            opacity: 0.9,
            fillOpacity: 0.75
        });

        const popupContent = `
            <div class="p-1 space-y-1 text-slate-900 dark:text-slate-100 font-sans" style="min-width: 170px;">
                <div class="font-bold text-xs flex items-center space-x-1">
                    <span>📍 ${escapeHtml(p.city)}</span>
                    <span class="text-[10px] text-slate-500 font-normal">(${escapeHtml(p.region || p.country || '')})</span>
                </div>
                <div class="text-[11px] text-blue-600 dark:text-cyan-400 font-semibold font-mono">
                    ${p.total_count} conexão(ões)
                </div>
                <div class="text-[10px] text-slate-600 dark:text-slate-300">
                    Provedor: <b>${escapeHtml(p.top_isp || 'Não informado')}</b>
                </div>
                <div class="pt-1 border-t border-slate-200 mt-1">
                    <button onclick="filterIpTableByCity('${escapeHtml(p.city)}')" class="w-full py-0.5 px-1.5 rounded bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold text-center transition">
                        Filtrar Esta Cidade
                    </button>
                </div>
            </div>
        `;

        marker.bindPopup(popupContent);
        marker.addTo(igLeafletMarkersGroup);
        markers.push(marker);
    });

    if (markers.length > 0) {
        try {
            igLeafletMap.fitBounds(igLeafletMarkersGroup.getBounds(), { padding: [30, 30], maxZoom: 10 });
        } catch (e) {
            console.warn("Erro ao ajustar limites do mapa:", e);
        }
    }

    setTimeout(() => {
        if (igLeafletMap) igLeafletMap.invalidateSize();
    }, 200);
}

function renderIpRankingTable() {
    const tbody = document.getElementById('ig-ip-ranking-body');
    if (!tbody) return;

    if (!cachedIpIntelligenceData || !cachedIpIntelligenceData.ranked_ips || cachedIpIntelligenceData.ranked_ips.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-slate-400">Nenhum registro de IP disponível.</td></tr>`;
        return;
    }

    let items = cachedIpIntelligenceData.ranked_ips;

    // Filtros por Categoria Forense
    if (currentIpFilterCategory === 'mobile') {
        items = items.filter(r => r.is_mobile);
    } else if (currentIpFilterCategory === 'proxy') {
        items = items.filter(r => r.is_proxy);
    } else if (currentIpFilterCategory === 'hosting') {
        items = items.filter(r => r.is_hosting);
    } else if (currentIpFilterCategory === 'ipv4') {
        items = items.filter(r => r.ip_version === 'IPv4' || !r.ip_address.includes(':'));
    } else if (currentIpFilterCategory === 'ipv6') {
        items = items.filter(r => r.ip_version === 'IPv6' || r.ip_address.includes(':'));
    }

    if (currentIpFilterText) {
        const q = currentIpFilterText.toLowerCase();
        items = items.filter(r =>
            (r.clean_ip && r.clean_ip.toLowerCase().includes(q)) ||
            (r.ip_address && r.ip_address.toLowerCase().includes(q)) ||
            (r.ports_str && r.ports_str.toLowerCase().includes(q)) ||
            (r.isp && r.isp.toLowerCase().includes(q)) ||
            (r.asname && r.asname.toLowerCase().includes(q)) ||
            (r.city && r.city.toLowerCase().includes(q)) ||
            (r.asn && r.asn.toLowerCase().includes(q))
        );
    }

    if (items.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-slate-400">Nenhum IP corresponde aos filtros selecionados.</td></tr>`;
        return;
    }

    let html = '';
    items.forEach((r, idx) => {
        const isIpv6 = r.ip_version === 'IPv6';
        const badgeVersion = isIpv6
            ? `<span class="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 ml-1.5">IPv6</span>`
            : `<span class="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 ml-1.5">IPv4</span>`;

        const rankBadge = `<span class="inline-block text-[11px] font-mono font-bold text-slate-400 dark:text-slate-500 mr-2 w-6 text-left">#${idx + 1}</span>`;

        // Badges Periciais de Inteligência de Rede (Mobile, Proxy, Hosting, Banda Larga)
        let networkTypeBadge = '';
        if (r.is_proxy) {
            networkTypeBadge = `<span class="px-1.5 py-0.5 rounded text-[9px] font-bold bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-300 dark:border-red-800 inline-flex items-center space-x-1 shadow-2xs" title="Endereço de VPN, Proxy Anônimo ou nó Tor"><i data-lucide="shield-alert" class="w-2.5 h-2.5"></i><span>VPN / Proxy</span></span>`;
        } else if (r.is_mobile) {
            networkTypeBadge = `<span class="px-1.5 py-0.5 rounded text-[9px] font-bold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800 inline-flex items-center space-x-1 shadow-2xs" title="Rede Móvel Celular (3G/4G/5G)"><i data-lucide="smartphone" class="w-2.5 h-2.5"></i><span>Móvel 4G/5G</span></span>`;
        } else if (r.is_hosting) {
            networkTypeBadge = `<span class="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-800 inline-flex items-center space-x-1 shadow-2xs" title="Servidor, VPS ou Data Center"><i data-lucide="server" class="w-2.5 h-2.5"></i><span>Data Center</span></span>`;
        } else if (r.isp && r.isp !== 'Pendente de consulta') {
            networkTypeBadge = `<span class="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 inline-flex items-center space-x-1 shadow-2xs" title="Banda Larga Residencial / Fixo"><i data-lucide="home" class="w-2.5 h-2.5"></i><span>Banda Larga</span></span>`;
        }

        // Portas Lógicas Registradas
        let portsBadge = '';
        if (r.ports_str) {
            portsBadge = `
                <div class="mt-1 flex items-center space-x-1">
                    <span class="text-[9px] font-semibold text-slate-400">Portas:</span>
                    <span class="px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono text-[9px] border border-slate-200 dark:border-slate-700/80" title="Portas lógicas registradas no registro da Meta">${escapeHtml(r.ports_str)}</span>
                </div>
            `;
        }

        // Provedor / ASN / Localização
        const hasIsp = r.isp && r.isp !== 'Pendente de consulta' && r.isp !== 'Consulta Pendente / Não Identificado';
        let ispDisplay = '';
        if (hasIsp) {
            const locText = r.city && r.city !== 'Não identificada' ? `${r.city}${r.region ? ` - ${r.region}` : ''}` : (r.country || 'Brasil');
            const flag = r.is_brazil ? '🇧🇷' : '🌐';
            const asDisplay = r.asname && r.asname !== '---' ? r.asname : (r.asn || '');
            ispDisplay = `
                <div class="space-y-0.5">
                    <div class="font-bold text-slate-900 dark:text-slate-100 text-xs flex items-center space-x-1">
                        <span>🏢 ${escapeHtml(r.isp)}</span>
                        ${asDisplay ? `<span class="text-[9px] font-mono px-1 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700">${escapeHtml(asDisplay)}</span>` : ''}
                    </div>
                    <div class="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                        📍 ${flag} ${escapeHtml(locText)} ${r.timezone ? `<span class="opacity-75">(${r.timezone})</span>` : ''}
                    </div>
                </div>
            `;
        } else {
            ispDisplay = `
                <span class="text-slate-400 dark:text-slate-500 italic text-[11px]">
                    Identificação pendente (clique em Identificar no topo)
                </span>
            `;
        }

        // Whois link oficial (sempre IP puro)
        const whoisBtn = r.is_brazil
            ? `<a href="${r.whois_url}" target="_blank" rel="noopener noreferrer" class="px-2 py-1 rounded text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 inline-flex items-center space-x-1 transition" title="Consultar no Registro.br Oficial">
                <span>Registro.br</span>
                <i data-lucide="external-link" class="w-2.5 h-2.5 opacity-60"></i>
               </a>`
            : `<a href="${r.whois_url}" target="_blank" rel="noopener noreferrer" class="px-2 py-1 rounded text-[11px] font-semibold text-blue-700 dark:text-cyan-400 hover:bg-blue-50 dark:hover:bg-blue-950/40 inline-flex items-center space-x-1 transition" title="Consultar Whois Internacional">
                <span>Whois</span>
                <i data-lucide="external-link" class="w-2.5 h-2.5 opacity-60"></i>
               </a>`;

        html += `
            <tr class="table-row-hover transition">
                <!-- IP, Versão, Tipo e Portas -->
                <td class="py-2.5 px-4 font-mono font-bold text-slate-900 dark:text-slate-100">
                    <div>
                        <div class="flex items-center flex-wrap gap-1">
                            ${rankBadge}
                            <span class="text-blue-600 dark:text-cyan-400 select-all">${escapeHtml(r.clean_ip || r.ip_address)}</span>
                            ${badgeVersion}
                            ${networkTypeBadge}
                        </div>
                        ${portsBadge}
                    </div>
                </td>

                <!-- Volume & % -->
                <td class="py-2.5 px-4">
                    <div class="space-y-1 max-w-[120px]">
                        <div class="flex items-center justify-between text-xs font-mono font-bold">
                            <span class="text-slate-800 dark:text-slate-200">${r.count}</span>
                            <span class="text-slate-500 dark:text-slate-400 text-[10px]">${r.percent}%</span>
                        </div>
                        <div class="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                            <div class="bg-blue-600 dark:bg-cyan-500 h-1.5 rounded-full" style="width: ${Math.min(r.percent, 100)}%"></div>
                        </div>
                    </div>
                </td>

                <!-- Primeiro Acesso BRT -->
                <td class="py-2.5 px-4 font-mono text-[11px] text-slate-700 dark:text-slate-300 whitespace-nowrap">
                    ${r.first_seen_brt || '---'}
                </td>

                <!-- Último Acesso BRT -->
                <td class="py-2.5 px-4 font-mono text-[11px] text-slate-700 dark:text-slate-300 whitespace-nowrap">
                    ${r.last_seen_brt || '---'}
                </td>

                <!-- Provedor / ASN & Localização -->
                <td class="py-2.5 px-4">
                    ${ispDisplay}
                </td>

                <!-- Ações Rápidas -->
                <td class="py-2.5 px-4 text-right">
                    <div class="flex items-center justify-end space-x-1">
                        <button onclick="copyIpToClipboard('${escapeHtml(r.clean_ip || r.ip_address)}', this)" class="px-2 py-1 rounded text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] font-semibold flex items-center space-x-1 transition" title="Copiar endereço IP puro">
                            <i data-lucide="copy" class="w-3 h-3 opacity-70"></i>
                            <span>Copiar</span>
                        </button>
                        ${whoisBtn}
                    </div>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
    lucide.createIcons();
}

function renderIpTimelineTable() {
    const tbody = document.getElementById('ig-connections-body');
    if (!tbody) return;

    if (!cachedIpIntelligenceData || !cachedIpIntelligenceData.raw_connections || cachedIpIntelligenceData.raw_connections.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center py-8 text-slate-400">Nenhuma conexão registrada.</td></tr>`;
        return;
    }

    let conns = cachedIpIntelligenceData.raw_connections;
    const ipMap = {};
    if (cachedIpIntelligenceData.ranked_ips) {
        cachedIpIntelligenceData.ranked_ips.forEach(r => {
            ipMap[r.clean_ip || r.ip_address] = r;
        });
    }

    // Filtros por Categoria Forense
    if (currentIpFilterCategory === 'mobile') {
        conns = conns.filter(c => ipMap[c.clean_ip || c.ip_address]?.is_mobile);
    } else if (currentIpFilterCategory === 'proxy') {
        conns = conns.filter(c => ipMap[c.clean_ip || c.ip_address]?.is_proxy);
    } else if (currentIpFilterCategory === 'hosting') {
        conns = conns.filter(c => ipMap[c.clean_ip || c.ip_address]?.is_hosting);
    } else if (currentIpFilterCategory === 'ipv4') {
        conns = conns.filter(c => !(c.clean_ip || c.ip_address).includes(':'));
    } else if (currentIpFilterCategory === 'ipv6') {
        conns = conns.filter(c => (c.clean_ip || c.ip_address).includes(':'));
    }

    if (currentIpFilterText) {
        const q = currentIpFilterText.toLowerCase();
        conns = conns.filter(c => {
            const clean = (c.clean_ip || c.ip_address || '').toLowerCase();
            const disp = (c.display_ip || '').toLowerCase();
            const port = String(c.port || '');
            const info = ipMap[c.clean_ip || c.ip_address] || {};
            const isp = (info.isp || '').toLowerCase();
            const city = (info.city || '').toLowerCase();
            return clean.includes(q) || disp.includes(q) || port.includes(q) || isp.includes(q) || city.includes(q);
        });
    }

    let html = '';
    conns.forEach(c => {
        const cleanIp = c.clean_ip || c.ip_address;
        const info = ipMap[cleanIp] || {};
        const hasIsp = info.isp && info.isp !== 'Pendente de consulta' && info.isp !== 'Consulta Pendente / Não Identificado';
        
        let typeBadge = '';
        if (info.is_proxy) {
            typeBadge = `<span class="ml-1 px-1 py-0.2 rounded text-[8px] font-bold bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-300 dark:border-red-800">VPN</span>`;
        } else if (info.is_mobile) {
            typeBadge = `<span class="ml-1 px-1 py-0.2 rounded text-[8px] font-bold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800">4G/5G</span>`;
        } else if (info.is_hosting) {
            typeBadge = `<span class="ml-1 px-1 py-0.2 rounded text-[8px] font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-800">HOST</span>`;
        }

        const ispLabel = hasIsp ? `${escapeHtml(info.isp)} (${escapeHtml(info.city || 'BR')}) ${typeBadge}` : '<span class="text-slate-400 italic">Pendente</span>';

        const portFormatted = (c.port !== null && c.port !== undefined)
            ? `<span class="text-slate-400 dark:text-slate-500 font-mono text-[11px] font-normal">:${c.port}</span>`
            : '';

        html += `
            <tr class="table-row-hover transition">
                <td class="py-2.5 px-4 text-slate-800 dark:text-slate-200 font-sans font-medium text-xs whitespace-nowrap">
                    ${c.timestamp_brt || '---'}
                </td>
                <td class="py-2.5 px-4 font-mono font-bold text-blue-600 dark:text-cyan-400 select-all">
                    <span>${escapeHtml(cleanIp)}</span>${portFormatted}
                </td>
                <td class="py-2.5 px-4 font-sans text-xs text-slate-700 dark:text-slate-300">
                    ${ispLabel}
                </td>
                <td class="py-2.5 px-4 text-slate-500 dark:text-slate-400 font-mono text-[11px] whitespace-nowrap">
                    ${c.timestamp_utc || '---'}
                </td>
                <td class="py-2.5 px-4 text-right">
                    <button onclick="copyIpToClipboard('${escapeHtml(c.display_ip || cleanIp)}', this)" class="px-2 py-1 rounded text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] font-semibold inline-flex items-center space-x-1 transition" title="Copiar IP e porta">
                        <i data-lucide="copy" class="w-3 h-3 opacity-70"></i>
                        <span>Copiar</span>
                    </button>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
    lucide.createIcons();
}

function switchIpTableView(viewName) {
    currentIpTableViewMode = viewName;

    const btnRanking = document.getElementById('tab-btn-ip-ranking');
    const btnTimeline = document.getElementById('tab-btn-ip-timeline');
    const boxRanking = document.getElementById('ip-view-ranking-container');
    const boxTimeline = document.getElementById('ip-view-timeline-container');

    if (viewName === 'ranking') {
        if (btnRanking) btnRanking.className = "px-3 py-1 rounded-md font-bold bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs transition flex items-center space-x-1";
        if (btnTimeline) btnTimeline.className = "px-3 py-1 rounded-md font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition flex items-center space-x-1";
        if (boxRanking) boxRanking.classList.remove('hidden');
        if (boxTimeline) boxTimeline.classList.add('hidden');
    } else {
        if (btnTimeline) btnTimeline.className = "px-3 py-1 rounded-md font-bold bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs transition flex items-center space-x-1";
        if (btnRanking) btnRanking.className = "px-3 py-1 rounded-md font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition flex items-center space-x-1";
        if (boxTimeline) boxTimeline.classList.remove('hidden');
        if (boxRanking) boxRanking.classList.add('hidden');
    }
}

let ipSearchTimer = null;
function handleIpTableSearch(e) {
    clearTimeout(ipSearchTimer);
    ipSearchTimer = setTimeout(() => {
        currentIpFilterText = document.getElementById('ip-table-search-input')?.value.trim() || '';
        renderIpRankingTable();
        renderIpTimelineTable();
    }, 250);
}

function filterIpTableByCity(cityName) {
    const input = document.getElementById('ip-table-search-input');
    if (input) {
        input.value = cityName;
        currentIpFilterText = cityName;
        renderIpRankingTable();
        renderIpTimelineTable();
        input.focus();
    }
}

async function identifyAllTargetIps() {
    if (!window.currentOpId) return;

    const btn = document.getElementById('btn-identify-all-ips');
    const originalHtml = btn ? btn.innerHTML : '';

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<i data-lucide="loader" class="w-3.5 h-3.5 animate-spin"></i><span>Consultando Operadoras em Lote...</span>`;
        lucide.createIcons();
    }

    try {
        let url = `/api/instagram/ips/identify-all?operation_id=${window.currentOpId}`;
        if (window.currentPhaseId) url += `&phase_id=${window.currentPhaseId}`;
        if (window.currentTargetId) url += `&target_id=${window.currentTargetId}`;

        const res = await fetch(url, { method: 'POST' });
        const updatedData = await res.json();
        cachedIpIntelligenceData = updatedData;

        renderIpIntelligenceUI(updatedData);

        if (btn) {
            btn.innerHTML = `<i data-lucide="check" class="w-3.5 h-3.5 text-emerald-300"></i><span>Provedores Identificados!</span>`;
            lucide.createIcons();
            setTimeout(() => {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
                lucide.createIcons();
            }, 2500);
        }
    } catch (err) {
        console.error("Erro ao identificar provedores em lote:", err);
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalHtml;
            lucide.createIcons();
        }
    }
}

function copyIpToClipboard(ip, btnElem) {
    if (!ip) return;
    navigator.clipboard.writeText(ip).then(() => {
        if (btnElem) {
            const orig = btnElem.innerHTML;
            btnElem.innerHTML = `<span class="text-emerald-500 font-bold">✓ Copiado!</span>`;
            setTimeout(() => {
                btnElem.innerHTML = orig;
                lucide.createIcons();
            }, 1800);
        }
    }).catch(err => {
        console.error("Erro ao copiar IP:", err);
    });
}

function exportIpsToCsv() {
    if (!cachedIpIntelligenceData || !cachedIpIntelligenceData.ranked_ips || cachedIpIntelligenceData.ranked_ips.length === 0) {
        alert("Nenhum dado de IP para exportar.");
        return;
    }

    const items = cachedIpIntelligenceData.ranked_ips;
    const headers = [
        "Endereço IP",
        "Portas Lógicas",
        "Versão",
        "Tipo de Rede (Móvel/Proxy/Hosting)",
        "Total de Conexões",
        "Porcentagem de Uso (%)",
        "Primeiro Acesso (BRT)",
        "Último Acesso (BRT)",
        "Provedor / ISP",
        "ASN",
        "Nome ASN (asname)",
        "Cidade",
        "Estado / Região",
        "País",
        "Fuso Horário",
        "Link Whois Oficial"
    ];

    const rows = items.map(r => {
        let typeStr = "Banda Larga / Fixo";
        if (r.is_proxy) typeStr = "VPN / Proxy";
        else if (r.is_mobile) typeStr = "Móvel (3G/4G/5G)";
        else if (r.is_hosting) typeStr = "Data Center / Hosting";

        return [
            `"${r.clean_ip || r.ip_address}"`,
            `"${r.ports_str || ''}"`,
            `"${r.ip_version}"`,
            `"${typeStr}"`,
            r.count,
            r.percent,
            `"${r.first_seen_brt || ''}"`,
            `"${r.last_seen_brt || ''}"`,
            `"${(r.isp || '').replace(/"/g, '""')}"`,
            `"${r.asn || ''}"`,
            `"${r.asname || ''}"`,
            `"${(r.city || '').replace(/"/g, '""')}"`,
            `"${(r.region || '').replace(/"/g, '""')}"`,
            `"${(r.country || '').replace(/"/g, '""')}"`,
            `"${r.timezone || ''}"`,
            `"${r.whois_url || ''}"`
        ];
    });

    const csvContent = "\uFEFF" + [headers.join(","), ...rows.map(e => e.join(","))].join("\r\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `MetaAnalise_Historico_IPs_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// ==================== TABELA DE RELACIONAMENTOS (COM LINKS EXTERNOS) ====================

function renderIgTable(data) {
    const tbody = document.getElementById('ig-table-body');
    const items = data.relationships || [];
    const total = data.total || 0;

    if (items.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center py-6 text-slate-400 font-medium">Nenhum registro encontrado para este filtro ou busca.</td></tr>`;
        document.getElementById('ig-pagination-info').innerText = '0 registros';
        document.getElementById('ig-prev-page').disabled = true;
        document.getElementById('ig-next-page').disabled = true;
        return;
    }

    let rowsHtml = '';
    items.forEach(r => {
        let badgeType = '';
        if (r.rel_type === 'follower') {
            badgeType = `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-pink-100 text-pink-800 border border-pink-300 dark:bg-pink-500/20 dark:text-pink-400 dark:border-pink-500/30">SEGUIDOR</span>`;
        } else if (r.rel_type === 'following') {
            badgeType = `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 dark:bg-amber-500/20 dark:text-amber-400 dark:border-amber-500/30">SEGUIDO</span>`;
        } else if (r.rel_type === 'threads_follower') {
            badgeType = `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-900 border border-purple-300 dark:bg-purple-500/20 dark:text-purple-400 dark:border-purple-500/30">THREADS SEGUIDOR</span>`;
        } else {
            badgeType = `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-900 border border-indigo-300 dark:bg-indigo-500/20 dark:text-indigo-400 dark:border-indigo-500/30">THREADS SEGUIDO</span>`;
        }

        const dateStr = r.timestamp_brt || (r.timestamp_utc ? `${r.timestamp_utc} (UTC)` : '<span class="text-slate-400 dark:text-slate-600">Não disponível</span>');
        const cleanUser = (r.username || '').replace(/^@/, '').trim();
        const igUrl = getIgProfileUrl(cleanUser);

        let targetBadge = '';
        if (data.is_consolidated && (r.target_identifier || r.target_name)) {
            const tgtLabel = r.target_identifier || r.target_name;
            targetBadge = `<span class="inline-block text-[9px] font-bold px-1.5 py-0.2 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-300 dark:border-slate-700 ml-1.5" title="Investigado vinculado">🎯 ${escapeHtml(tgtLabel)}</span>`;
        }

        const uidVal = (r.uid || '').trim();
        const uidUrl = getIgUidUrl(uidVal);
        const uidCellHtml = (uidVal && uidVal !== '---' && uidVal !== 'N/A')
            ? `<a href="${uidUrl}" target="_blank" rel="noopener noreferrer" class="text-purple-600 dark:text-purple-400 font-mono font-semibold hover:underline flex items-center space-x-1" title="Abrir perfil permanente via UID no Instagram">
                 <span>${escapeHtml(uidVal)}</span>
                 <i data-lucide="external-link" class="w-2.5 h-2.5 opacity-60"></i>
               </a>`
            : `<span class="text-slate-400 font-mono">---</span>`;

        rowsHtml += `
            <tr class="table-row-hover transition">
                <td class="py-2.5 px-4 font-semibold text-slate-900 dark:text-slate-100">
                    <div class="flex items-center space-x-1">
                        <a href="${igUrl}" target="_blank" rel="noopener noreferrer" class="text-pink-600 dark:text-pink-400 font-bold hover:underline flex items-center space-x-1" title="Abrir @${escapeHtml(cleanUser)} no Instagram">
                            <span>@${escapeHtml(cleanUser)}</span>
                            <i data-lucide="external-link" class="w-3 h-3 opacity-60"></i>
                        </a>
                        ${targetBadge}
                    </div>
                </td>
                <td class="py-2.5 px-4">${uidCellHtml}</td>
                <td class="py-2.5 px-4 text-slate-800 dark:text-slate-300 font-sans font-medium">${escapeHtml(r.display_name) || '<span class="text-slate-400 dark:text-slate-600 italic">Sem nome</span>'}</td>
                <td class="py-2.5 px-4">${badgeType}</td>
                <td class="py-2.5 px-4 text-slate-700 dark:text-slate-300 font-mono font-medium">${dateStr}</td>
            </tr>
        `;
    });

    tbody.innerHTML = rowsHtml;

    const start = (data.page - 1) * data.limit + 1;
    const end = Math.min(data.page * data.limit, total);
    document.getElementById('ig-pagination-info').innerText = `Mostrando ${start}-${end} de ${total.toLocaleString()} registros`;

    document.getElementById('ig-prev-page').disabled = data.page <= 1;
    document.getElementById('ig-next-page').disabled = end >= total;
    if (window.lucide) lucide.createIcons({ root: tbody });
}

function setIgRelFilter(filterType) {
    currentIgRelFilter = filterType;
    currentIgPage = 1;

    const btnIds = {
        'follower': 'btn-ig-followers',
        'following': 'btn-ig-following',
        'threads_follower': 'btn-ig-threads-followers',
        'threads_following': 'btn-ig-threads-following'
    };

    Object.keys(btnIds).forEach(k => {
        const btn = document.getElementById(btnIds[k]);
        if (!btn) return;
        if (k === filterType) {
            btn.className = "px-3 py-1.5 rounded-lg bg-pink-600 text-white font-bold transition text-xs shadow-sm";
        } else {
            btn.className = "px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700/80 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white font-semibold transition text-xs shadow-xs";
        }
    });

    if (window.currentOpId) {
        loadInstagramView(window.currentOpId, window.currentPhaseId, window.currentTargetId);
    }
}

let igSearchTimeout = null;
function handleIgSearch(e) {
    clearTimeout(igSearchTimeout);
    igSearchTimeout = setTimeout(() => {
        currentIgSearch = document.getElementById('ig-search-input').value.trim();
        currentIgPage = 1;
        if (window.currentOpId) {
            loadInstagramView(window.currentOpId, window.currentPhaseId, window.currentTargetId);
        }
    }, 300);
}

function changeIgPage(delta) {
    currentIgPage += delta;
    if (currentIgPage < 1) currentIgPage = 1;
    if (window.currentOpId) {
        loadInstagramView(window.currentOpId, window.currentPhaseId, window.currentTargetId);
    }
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.innerText = text;
    return div.innerHTML;
}

function formatEmailDisplay(rawEmail) {
    if (!rawEmail) return '<span class="text-slate-400 dark:text-slate-500 italic text-[11px]">Não informado no registro</span>';
    let text = rawEmail.trim();
    if (text.toLowerCase().includes('no responsive') || text.toLowerCase().includes('definition')) {
        return '<span class="text-slate-400 dark:text-slate-500 italic text-[11px]">Não informado no registro</span>';
    }

    // Dividir por quebra de linha ou extrair emails individuais
    let lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    if (lines.length === 1 && lines[0].indexOf('@') !== lines[0].lastIndexOf('@')) {
        const matches = lines[0].match(/([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)(?:\s*\(([^)]+)\))?/g);
        if (matches) lines = matches;
    }

    const pad = (n) => String(n).padStart(2, '0');
    const emailHtmls = lines.map(line => {
        const emMatch = line.match(/^([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)(?:\s*\((.*?)\))?/);
        let address = line;
        let statusStr = '';
        if (emMatch) {
            address = emMatch[1].trim();
            statusStr = emMatch[2] ? emMatch[2].trim() : '';
        } else {
            address = line.replace(/\s*\([^)]*\)/g, '').trim();
        }

        let badgeHtml = '';
        if (statusStr) {
            const dateMatch = statusStr.match(/(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})/);
            if (dateMatch) {
                try {
                    const d = new Date(dateMatch[1].replace(' ', 'T') + 'Z');
                    if (!isNaN(d.getTime())) {
                        const brt = new Date(d.getTime() - 3 * 3600 * 1000);
                        const verText = `✓ Verificado em ${pad(brt.getUTCDate())}/${pad(brt.getUTCMonth() + 1)}/${brt.getUTCFullYear()} ${pad(brt.getUTCHours())}:${pad(brt.getUTCMinutes())} BRT`;
                        badgeHtml = `<span class="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 mt-0.5">${escapeHtml(verText)}</span>`;
                    }
                } catch (e) {}
            }
            if (!badgeHtml) {
                if (statusStr.toLowerCase().includes('verified') && !statusStr.toLowerCase().includes('unverified')) {
                    badgeHtml = `<span class="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 mt-0.5">✓ Verificado</span>`;
                } else if (statusStr.toLowerCase().includes('unverified')) {
                    badgeHtml = `<span class="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 mt-0.5">⚠️ Não Verificado</span>`;
                } else if (statusStr.toLowerCase().includes('primary')) {
                    badgeHtml = `<span class="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 mt-0.5">⭐ Primário</span>`;
                }
            }
        }

        return `
            <div class="mb-1.5 last:mb-0">
                <span class="font-mono text-slate-800 dark:text-slate-200 text-[11px] font-medium block truncate" title="${escapeHtml(address)}">${escapeHtml(address)}</span>
                ${badgeHtml}
            </div>
        `;
    });

    return `<div class="space-y-1">${emailHtmls.join('')}</div>`;
}

function formatPhoneDisplay(rawPhone) {
    if (!rawPhone) return '<span class="text-slate-400 dark:text-slate-500 italic text-[11px]">Não informado no registro</span>';
    let phone = rawPhone.trim();

    // Se for texto explicativo do glossário Meta ou ausência de registro
    if (
        phone.toLowerCase().includes('list of "unverified"') ||
        phone.toLowerCase().includes('no responsive') ||
        phone.toLowerCase().includes('provided by the account') ||
        phone.toLowerCase() === 'unverified'
    ) {
        return '<span class="text-slate-400 dark:text-slate-500 italic text-[11px]">Não informado no registro</span>';
    }

    const m = phone.match(/(\+?\d{10,15})(?:\s*(?:Verified\s*on|Verificado\s*em)?\s*(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}))?/i);
    if (m) {
        let num = m[1];
        let dateUtc = m[2];

        let formattedNum = num;
        if (num.startsWith('+55') && num.length === 14) {
            formattedNum = `+55 (${num.slice(3, 5)}) ${num.slice(5, 10)}-${num.slice(10)}`;
        } else if (num.startsWith('+55') && num.length === 13) {
            formattedNum = `+55 (${num.slice(3, 5)}) ${num.slice(5, 9)}-${num.slice(9)}`;
        }

        let verBadge = '';
        if (dateUtc) {
            try {
                const d = new Date(dateUtc.replace(' ', 'T') + 'Z');
                if (!isNaN(d.getTime())) {
                    const pad = (n) => String(n).padStart(2, '0');
                    const brt = new Date(d.getTime() - 3 * 3600 * 1000);
                    const verText = `✓ Verificado em ${pad(brt.getUTCDate())}/${pad(brt.getUTCMonth() + 1)}/${brt.getUTCFullYear()} ${pad(brt.getUTCHours())}:${pad(brt.getUTCMinutes())} BRT`;
                    verBadge = `<span class="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 mt-0.5">${escapeHtml(verText)}</span>`;
                }
            } catch (e) {
                verBadge = `<span class="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 mt-0.5">✓ Verificado</span>`;
            }
        } else if (phone.toLowerCase().includes('verified') && !phone.toLowerCase().includes('unverified')) {
            verBadge = `<span class="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 mt-0.5">✓ Verificado</span>`;
        } else if (phone.toLowerCase().includes('unverified')) {
            verBadge = `<span class="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 mt-0.5">⚠️ Não Verificado pelo Alvo</span>`;
        }

        return `
            <span class="font-mono text-slate-800 dark:text-slate-200 text-[11px] font-bold block">${escapeHtml(formattedNum)}</span>
            ${verBadge}
        `;
    }

    if (!/\d{6,}/.test(phone)) {
        return '<span class="text-slate-400 dark:text-slate-500 italic text-[11px]">Não informado no registro</span>';
    }

    return `<span class="font-mono text-slate-800 dark:text-slate-200 text-[11px] font-medium">${escapeHtml(phone)}</span>`;
}

// ==================== DISPOSITIVOS & APARELHOS FÍSICOS (DEVICES) ====================

let currentIgDevicesSearch = '';
let currentIgDevFilter = 'all'; // 'all', 'android', 'apple', 'active'
let cachedIgDevices = [];
let cachedIgDevicesIsConsolidated = false;
let igDevicesTimeout = null;

function handleIgDevicesSearch(e) {
    clearTimeout(igDevicesTimeout);
    igDevicesTimeout = setTimeout(() => {
        currentIgDevicesSearch = document.getElementById('ig-devices-search-input').value.trim();
        renderFilteredIgDevices();
    }, 300);
}

function setIgDevFilter(filterType) {
    currentIgDevFilter = filterType;
    
    const btnIds = {
        'all': 'btn-dev-filter-all',
        'android': 'btn-dev-filter-android',
        'apple': 'btn-dev-filter-apple'
    };

    Object.keys(btnIds).forEach(k => {
        const btn = document.getElementById(btnIds[k]);
        if (!btn) return;
        if (k === filterType) {
            btn.className = "px-3 py-1.5 rounded-lg bg-amber-600 text-white font-bold transition text-xs shadow-sm";
        } else {
            btn.className = "px-3 py-1.5 rounded-lg bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700/80 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold transition text-xs shadow-xs";
        }
    });

    renderFilteredIgDevices();
}

async function copyDeviceId(devId, btnElem) {
    if (!devId) return;
    try {
        await navigator.clipboard.writeText(devId);
        if (btnElem) {
            const originalHtml = btnElem.innerHTML;
            btnElem.innerHTML = `<i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i><span class="text-emerald-600 dark:text-emerald-400 font-bold">Copiado!</span>`;
            lucide.createIcons();
            setTimeout(() => {
                btnElem.innerHTML = originalHtml;
                lucide.createIcons();
            }, 1800);
        }
    } catch (e) {
        console.error("Falha ao copiar:", e);
    }
}

async function loadIgDevices(opId, phaseId = null, targetId = null, search = '', accountUid = null) {
    const tbody = document.getElementById('ig-devices-table-body');
    if (!tbody) return;

    const effectiveAccountUid = accountUid || currentSelectedAccountUid;

    try {
        let url = `/api/instagram/devices?operation_id=${opId}`;
        if (phaseId) url += `&phase_id=${phaseId}`;
        if (targetId) url += `&target_id=${targetId}`;
        if (effectiveAccountUid) url += `&account_uid=${encodeURIComponent(effectiveAccountUid)}`;
        if (search) url += `&search=${encodeURIComponent(search)}`;

        const res = await fetch(url);
        const data = await res.json();
        cachedIgDevices = data.devices || [];
        cachedIgDevicesIsConsolidated = (data.is_consolidated === true) || (!targetId);

        // Calcular Métricas / KPIs
        const total = cachedIgDevices.length;
        let androidCount = 0;
        let appleCount = 0;
        let activeCount = 0;

        cachedIgDevices.forEach(d => {
            const devId = (d.device_id || '').toLowerCase();
            if (devId.startsWith('android-')) {
                androidCount++;
            } else if (devId.includes('-')) {
                appleCount++;
            }
            if (d.is_active) activeCount++;
        });

        const androidPct = total > 0 ? Math.round((androidCount / total) * 100) : 0;
        const applePct = total > 0 ? Math.round((appleCount / total) * 100) : 0;

        const kpiTotal = document.getElementById('dev-kpi-total');
        const kpiAndroid = document.getElementById('dev-kpi-android');
        const kpiAndroidPct = document.getElementById('dev-kpi-android-pct');
        const kpiApple = document.getElementById('dev-kpi-apple');
        const kpiApplePct = document.getElementById('dev-kpi-apple-pct');
        const kpiActive = document.getElementById('dev-kpi-active');

        if (kpiTotal) kpiTotal.innerText = total.toLocaleString();
        if (kpiAndroid) kpiAndroid.innerText = androidCount.toLocaleString();
        if (kpiAndroidPct) kpiAndroidPct.innerText = `${androidPct}% dos aparelhos`;
        if (kpiApple) kpiApple.innerText = appleCount.toLocaleString();
        if (kpiApplePct) kpiApplePct.innerText = `${applePct}% dos aparelhos`;
        if (kpiActive) kpiActive.innerText = activeCount.toLocaleString();

        const btnAllCount = document.getElementById('dev-btn-all-count');
        const btnAndroidCount = document.getElementById('dev-btn-android-count');
        const btnAppleCount = document.getElementById('dev-btn-apple-count');
        if (btnAllCount) btnAllCount.innerText = total;
        if (btnAndroidCount) btnAndroidCount.innerText = androidCount;
        if (btnAppleCount) btnAppleCount.innerText = appleCount;

        const badgeElem = document.getElementById('badge-ig-devices-count');
        if (badgeElem) badgeElem.innerText = total.toLocaleString();

        renderFilteredIgDevices();

    } catch (err) {
        console.error("Erro ao carregar dispositivos:", err);
        tbody.innerHTML = `<tr><td colspan="6" class="text-center py-6 text-red-500 text-xs">Erro ao carregar dispositivos.</td></tr>`;
    }
}

function renderFilteredIgDevices() {
    const tbody = document.getElementById('ig-devices-table-body');
    if (!tbody) return;

    // Alternar visibilidade da coluna "Investigado" no cabeçalho
    const thTarget = document.getElementById('th-dev-target');
    if (thTarget) {
        if (cachedIgDevicesIsConsolidated) {
            thTarget.classList.remove('hidden');
        } else {
            thTarget.classList.add('hidden');
        }
    }

    let filtered = cachedIgDevices.filter(d => {
        const devId = (d.device_id || '').toLowerCase();
        const devType = (d.device_type || '').toLowerCase();
        const users = (d.associated_users || '').toLowerCase();

        // Filtro de Ecossistema
        if (currentIgDevFilter === 'android' && !devId.startsWith('android-')) return false;
        if (currentIgDevFilter === 'apple' && (devId.startsWith('android-') || !devId.includes('-'))) return false;
        if (currentIgDevFilter === 'active' && !d.is_active) return false;

        // Filtro de Busca
        if (currentIgDevicesSearch) {
            const s = currentIgDevicesSearch.toLowerCase();
            return devId.includes(s) || devType.includes(s) || users.includes(s);
        }
        return true;
    });

    const colSpan = cachedIgDevicesIsConsolidated ? 6 : 5;

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="${colSpan}" class="text-center py-12 text-slate-400">
                    <i data-lucide="smartphone-nfc" class="w-8 h-8 mx-auto text-slate-400 dark:text-slate-600 mb-2"></i>
                    <p class="text-xs font-semibold">Nenhum dispositivo encontrado neste filtro</p>
                    <p class="text-[11px] text-slate-500 mt-0.5">Tente alterar os termos da busca ou selecionar outro ecossistema.</p>
                </td>
            </tr>
        `;
        lucide.createIcons();
        return;
    }

    let rowsHtml = '';
    filtered.forEach(d => {
        const devId = d.device_id || '';
        const isAndroid = devId.toLowerCase().startsWith('android-');
        const isAppleUUID = !isAndroid && devId.includes('-');
        
        let typeBadge = '';
        if (isAndroid) {
            typeBadge = `<span class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 dark:bg-emerald-500/20 dark:text-emerald-400 dark:border-emerald-500/30"><i data-lucide="smartphone" class="w-3.5 h-3.5 text-emerald-500"></i><span>Android (SSAID Hardware)</span></span>`;
        } else if (isAppleUUID) {
            typeBadge = `<span class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold bg-blue-100 text-blue-900 border border-blue-300 dark:bg-blue-500/20 dark:text-cyan-400 dark:border-blue-500/30"><i data-lucide="apple" class="w-3.5 h-3.5 text-blue-500"></i><span>Apple (IDFV / UUID)</span></span>`;
        } else {
            typeBadge = `<span class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold bg-slate-100 text-slate-800 border border-slate-300 dark:bg-slate-800 dark:text-slate-300"><i data-lucide="cpu" class="w-3.5 h-3.5 text-amber-500"></i><span>${escapeHtml(d.device_type || 'Dispositivo')}</span></span>`;
        }

        const activeBadge = d.is_active ?
            `<span class="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md text-[10px] font-medium bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 cursor-help" title="Indica se o Instagram foi acessado pelo dispositivo.">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                <span>Ativo</span>
            </span>` :
            `<span class="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-md text-[10px] font-medium bg-slate-100 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700/60 cursor-help" title="Sem registro de acesso pelo dispositivo.">
                <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                <span>Inativo</span>
            </span>`;

        const associatedUsers = d.associated_users ?
            `<div class="flex items-center space-x-1"><i data-lucide="users" class="w-3 h-3 text-indigo-500"></i><span class="font-sans font-semibold text-slate-900 dark:text-slate-100 text-xs">${escapeHtml(d.associated_users)}</span></div>` :
            `<span class="text-slate-400 dark:text-slate-600 italic text-[11px]">Nenhum outro perfil</span>`;

        let targetCell = '';
        if (cachedIgDevicesIsConsolidated) {
            const targetBadge = (d.target_identifier || d.target_name) ?
                `<span class="inline-block text-[10px] font-bold px-2 py-0.5 rounded bg-pink-50 dark:bg-pink-950/30 text-pink-700 dark:text-pink-300 border border-pink-200 dark:border-pink-800/40">🎯 ${escapeHtml(d.target_identifier || d.target_name)}</span>` :
                '---';
            targetCell = `<td class="py-3 px-4">${targetBadge}</td>`;
        }

        rowsHtml += `
            <tr class="table-row-hover transition">
                <td class="py-3 px-4">${typeBadge}</td>
                <td class="py-3 px-4 font-mono font-bold text-slate-900 dark:text-slate-100 select-all text-xs tracking-tight">${escapeHtml(devId)}</td>
                <td class="py-3 px-4">${activeBadge}</td>
                <td class="py-3 px-4">${associatedUsers}</td>
                ${targetCell}
                <td class="py-3 px-4 text-right">
                    <button onclick="copyDeviceId('${escapeHtml(devId)}', this)" class="px-2.5 py-1 text-[11px] font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-amber-500/20 hover:text-amber-700 dark:hover:text-amber-300 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 transition inline-flex items-center space-x-1 shadow-2xs" title="Copiar ID para usar em ofícios ou perícias">
                        <i data-lucide="copy" class="w-3 h-3"></i>
                        <span>Copiar ID</span>
                    </button>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = rowsHtml;
    lucide.createIcons();
}

// ==================== AÇÕES DE AVATARES & COPIAR UID ====================

async function fetchTargetAvatarOnline(silent = false) {
    const handle = window.currentTargetVanity;
    const uid = window.currentTargetUid;
    if (!uid || !String(uid).trim() || String(uid).trim() === 'N/A' || String(uid).trim() === '---') {
        if (!silent) alert("Este perfil não possui ID numérico registrado no caso para buscar a foto.");
        return;
    }

    const btn = document.getElementById('btn-fetch-target-avatar');
    const icon = document.getElementById('icon-fetch-target-avatar');
    if (icon && !silent) icon.classList.add('animate-spin');

    try {
        const res = await fetch('/api/instagram/avatars/fetch-single', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: handle || '',
                user_id: uid ? String(uid) : null,
                target_id: window.currentTargetId || null
            })
        });
        const data = await res.json();

        if (data.success && data.avatar_url) {
            await loadCachedAvatarsMap();
            const img = document.getElementById('ig-target-avatar-img');
            const fallback = document.getElementById('ig-target-avatar-fallback');
            if (img && fallback) {
                img.src = `${data.avatar_url}?t=${Date.now()}`;
                img.classList.remove('hidden');
                fallback.classList.add('hidden');
            }
            updateVisibleAvatarsInDom();
        } else if (!silent) {
            alert(data.message || "Não foi possível extrair a foto deste perfil no momento.");
        }
    } catch (err) {
        if (!silent) {
            console.error("Erro ao buscar foto do alvo:", err);
            alert("Erro de conexão ao tentar buscar a foto do perfil.");
        }
    } finally {
        if (icon && !silent) icon.classList.remove('animate-spin');
    }
}

async function syncInstagramAvatars() {
    const btn = document.getElementById('btn-sync-avatars');
    const icon = document.getElementById('icon-sync-avatars');
    const label = document.getElementById('text-sync-avatars');
    const barContainer = document.getElementById('dm-avatar-sync-bar-container');

    if (btn) btn.disabled = true;
    if (icon) icon.classList.add('animate-spin');
    if (label) label.innerText = 'Iniciando sincronização...';
    if (barContainer) barContainer.classList.remove('hidden');

    try {
        const res = await fetch('/api/instagram/avatars/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                operation_id: window.currentOpId,
                target_id: window.currentTargetId,
                limit: null
            })
        });
        const data = await res.json();
        
        // Iniciar monitoramento do progresso com atualização contínua
        startAvatarSyncPolling();
    } catch (err) {
        console.error("Erro ao disparar sincronização de fotos:", err);
        if (btn) btn.disabled = false;
        if (icon) icon.classList.remove('animate-spin');
        if (label) label.innerText = 'Sincronizar Fotos dos Perfis';
        if (barContainer) barContainer.classList.add('hidden');
    }
}

let _lastAvatarDownloaded = -1;

function startAvatarSyncPolling() {
    if (avatarSyncInterval) clearInterval(avatarSyncInterval);
    _lastAvatarDownloaded = -1;

    avatarSyncInterval = setInterval(async () => {
        try {
            const res = await fetch('/api/instagram/avatars/status');
            const status = await res.json();

            const bar = document.getElementById('dm-avatar-sync-bar');
            const text = document.getElementById('dm-avatar-sync-text');
            const label = document.getElementById('text-sync-avatars');
            const icon = document.getElementById('icon-sync-avatars');
            const btn = document.getElementById('btn-sync-avatars');
            const barContainer = document.getElementById('dm-avatar-sync-bar-container');

            if (status.in_progress) {
                const cur = status.current || 0;
                const tot = status.total || 1;
                const dl = status.downloaded || 0;
                const pct = Math.round((cur / tot) * 100);
                if (bar) bar.style.width = `${pct}%`;
                const userTag = status.current_user ? ` • Perfil: @${status.current_user}` : '';
                if (text) text.innerText = `${cur} / ${tot} (${pct}%) • Baixados: ${dl}${userTag}`;
                if (label) label.innerText = `Baixando... (${cur}/${tot})`;

                // ATUALIZAÇÃO INSTANTÂNEA EM TEMPO REAL:
                // Conforme novas fotos chegam, atualiza imediatamente as fotos na tela
                if (dl > _lastAvatarDownloaded) {
                    _lastAvatarDownloaded = dl;
                    await loadCachedAvatarsMap();
                    renderFilteredDmThreads();
                    updateVisibleAvatarsInDom();
                }
            } else {
                clearInterval(avatarSyncInterval);
                avatarSyncInterval = null;

                if (bar) bar.style.width = '100%';
                if (text) text.innerText = status.total === 0 ? 'Todas as fotos já estão sincronizadas!' : `Concluído! ${status.downloaded || 0} fotos salvas.`;
                if (label) label.innerText = status.total === 0 ? '✓ Fotos Atualizadas' : `✓ Fotos Atualizadas (+${status.downloaded || 0})`;
                if (icon) icon.classList.remove('animate-spin');
                if (btn) btn.disabled = false;

                // ATUALIZAÇÃO INSTANTÂNEA FINAL:
                // Atualiza todo o painel imediatamente sem necessidade de F5
                await loadCachedAvatarsMap();
                renderFilteredDmThreads();
                updateVisibleAvatarsInDom();

                setTimeout(() => {
                    if (barContainer) barContainer.classList.add('hidden');
                    if (label) label.innerText = 'Sincronizar Fotos dos Perfis';
                }, 4000);
            }
        } catch (err) {
            console.error("Erro no polling de sincronização:", err);
            clearInterval(avatarSyncInterval);
            avatarSyncInterval = null;
        }
    }, 800);
}

function copyTargetUid() {
    const uid = window.currentTargetUid || (document.getElementById('ig-uid')?.innerText || '').replace('UID:', '').trim();
    if (!uid || uid === '---' || uid === 'N/A') return;

    navigator.clipboard.writeText(uid).then(() => {
        const btn = document.getElementById('ig-uid-btn');
        if (btn) {
            const originalHtml = btn.innerHTML;
            btn.innerHTML = `<span class="text-emerald-500 font-bold">✓ Copiado!</span>`;
            setTimeout(() => { btn.innerHTML = originalHtml; lucide.createIcons(); }, 1500);
        }
    });
}

function copyDmCurrentUid() {
    const textElem = document.getElementById('dm-header-uid-text');
    const text = textElem ? textElem.innerText.replace(/^@/, '').trim() : '';
    if (!text) return;

    navigator.clipboard.writeText(text).then(() => {
        const original = textElem.innerText;
        textElem.innerText = "✓ Copiado!";
        setTimeout(() => { textElem.innerText = original; }, 1500);
    });
}

window.syncAllAvatars = syncInstagramAvatars;
window.copyInterlocutorUid = copyDmCurrentUid;
window.toggleThreadReadStatus = toggleCurrentThreadRead;
window.toggleThreadStarStatus = toggleCurrentThreadStar;
window.handleDmThreadClick = handleDmThreadClick;
window.openDmThread = selectDmThread;
window.selectDmThread = selectDmThread;
window.handleDmSearch = handleDmSearch;
window.clearDmSearch = clearDmSearch;

// ==================== CONTROLE DE TRANSCRIÇÃO DE ÁUDIOS (WHISPER SMALL) ====================

// ==================== GERENCIADOR DE INSTALAÇÃO / DOWNLOAD WHISPER AI ====================
let whisperPollingTimer = null;
let isWhisperDownloading = false;
let pendingWhisperAction = null;

if (typeof window.showToastSuccess !== 'function') {
    window.showToastSuccess = function(msg) {
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-5 right-5 z-50 bg-slate-900 text-white dark:bg-white dark:text-slate-900 px-4 py-2.5 rounded-xl shadow-2xl border border-slate-700 flex items-center space-x-2 text-xs font-semibold animate-bounce';
        toast.innerHTML = `<i data-lucide="check-circle" class="w-4 h-4 text-emerald-400"></i><span>${msg}</span>`;
        document.body.appendChild(toast);
        if (window.lucide) lucide.createIcons();
        setTimeout(() => { toast.remove(); }, 3500);
    };
}

async function checkWhisperStatus() {
    try {
        const res = await fetch('/api/whisper/status');
        const json = await res.json();
        return json.success ? json.data : null;
    } catch (e) {
        console.warn("Erro ao consultar status do Whisper:", e);
        return null;
    }
}

async function ensureWhisperReady(onReadyCallback) {
    const status = await checkWhisperStatus();
    if (status && status.installed) {
        if (typeof onReadyCallback === 'function') onReadyCallback();
        return;
    }

    pendingWhisperAction = onReadyCallback;
    openWhisperModal(status);
}

function openWhisperModal(initialStatus) {
    const modal = document.getElementById('modal-whisper-download');
    if (modal) modal.classList.remove('hidden');

    if (initialStatus) {
        updateWhisperUI(initialStatus);
        if (initialStatus.status === 'downloading') startWhisperPolling();
    } else {
        checkWhisperStatus().then(st => {
            if (st) {
                updateWhisperUI(st);
                if (st.status === 'downloading') startWhisperPolling();
            }
        });
    }

    if (window.lucide) lucide.createIcons();
}

function minimizeWhisperDownload() {
    const modal = document.getElementById('modal-whisper-download');
    if (modal) modal.classList.add('hidden');
    window.showToastSuccess("Download do Whisper continuando em segundo plano.");
}

function closeWhisperModal() {
    const modal = document.getElementById('modal-whisper-download');
    if (modal) modal.classList.add('hidden');
}

async function startWhisperDownload() {
    const btnStart = document.getElementById('btn-whisper-start');
    const errBox = document.getElementById('whisper-error-box');
    if (errBox) errBox.classList.add('hidden');

    if (btnStart) {
        btnStart.disabled = true;
        btnStart.innerHTML = `<i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i><span>Iniciando...</span>`;
        if (window.lucide) lucide.createIcons();
    }

    try {
        const res = await fetch('/api/whisper/download', { method: 'POST' });
        const data = await res.json();
        if (!res.ok || !data.success) {
            throw new Error(data.detail || 'Não foi possível iniciar o download.');
        }

        isWhisperDownloading = true;
        updateWhisperUI(data.data);
        startWhisperPolling();

    } catch (err) {
        console.error("Erro ao iniciar download do Whisper:", err);
        const errMsg = document.getElementById('whisper-error-msg');
        if (errBox && errMsg) {
            errMsg.innerText = err.message;
            errBox.classList.remove('hidden');
        }
        if (btnStart) {
            btnStart.disabled = false;
            btnStart.innerHTML = `<i data-lucide="download-cloud" class="w-4 h-4"></i><span>Tentar Novamente</span>`;
            if (window.lucide) lucide.createIcons();
        }
    }
}

function startWhisperPolling() {
    if (whisperPollingTimer) return;
    isWhisperDownloading = true;

    whisperPollingTimer = setInterval(async () => {
        const status = await checkWhisperStatus();
        if (!status) return;

        updateWhisperUI(status);

        if (status.status === 'completed' || status.installed) {
            stopWhisperPolling();
            isWhisperDownloading = false;
            handleWhisperDownloadComplete();
        } else if (status.status === 'error') {
            stopWhisperPolling();
            isWhisperDownloading = false;
            handleWhisperDownloadError(status.error_message);
        }
    }, 600);
}

function stopWhisperPolling() {
    if (whisperPollingTimer) {
        clearInterval(whisperPollingTimer);
        whisperPollingTimer = null;
    }
}

function updateWhisperUI(data) {
    if (!data) return;

    const pct = data.progress || 0;
    const downloadedMb = data.downloaded_mb || 0;
    const totalMb = data.total_mb || 486.2;
    const speed = data.speed_mb_s || 0;
    const eta = data.eta_seconds || 0;
    const currentFile = data.current_file || '';

    // Elementos do Modal
    const pBar = document.getElementById('whisper-progress-bar');
    const pPct = document.getElementById('whisper-status-pct');
    const pText = document.getElementById('whisper-status-text');
    const pDot = document.getElementById('whisper-pulse-dot');
    const mDown = document.getElementById('whisper-metric-downloaded');
    const mSpeed = document.getElementById('whisper-metric-speed');
    const mEta = document.getElementById('whisper-metric-eta');
    const btnStart = document.getElementById('btn-whisper-start');

    if (pBar) pBar.style.width = `${pct}%`;
    if (pPct) pPct.innerText = `${pct}%`;
    if (mDown) mDown.innerText = `${downloadedMb} / ${totalMb} MB`;
    if (mSpeed) mSpeed.innerText = `${speed} MB/s`;

    let etaFormatted = '--';
    if (eta > 0) {
        if (eta < 60) etaFormatted = `~${eta}s`;
        else etaFormatted = `~${Math.floor(eta / 60)}m ${eta % 60}s`;
    }
    if (mEta) mEta.innerText = etaFormatted;

    if (pText) {
        if (data.status === 'downloading') {
            pText.innerText = currentFile ? `${currentFile} (${pct}%)` : `Baixando modelo... (${pct}%)`;
            if (pDot) pDot.className = "w-2 h-2 rounded-full bg-indigo-500 animate-ping inline-block";
            if (btnStart) {
                btnStart.disabled = true;
                btnStart.innerHTML = `<i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i><span>Baixando (${pct}%)...</span>`;
            }
        } else if (data.status === 'completed' || data.installed) {
            pText.innerText = "Modelo instalado e pronto para uso!";
            if (pDot) pDot.className = "w-2 h-2 rounded-full bg-emerald-500 inline-block";
            if (btnStart) {
                btnStart.disabled = true;
                btnStart.className = "px-5 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow-md flex items-center space-x-2 cursor-default";
                btnStart.innerHTML = `<i data-lucide="check" class="w-4 h-4"></i><span>Instalado ✅</span>`;
            }
        }
    }

    if (window.lucide) lucide.createIcons();
}

function handleWhisperDownloadComplete() {
    const modal = document.getElementById('modal-whisper-download');

    window.showToastSuccess("✅ Whisper AI instalado com sucesso! Modelo pronto para transcrição.");

    if (modal && !modal.classList.contains('hidden')) {
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 1200);
    }

    if (typeof pendingWhisperAction === 'function') {
        const action = pendingWhisperAction;
        pendingWhisperAction = null;
        console.log("Executando transcrição pendente após instalação do Whisper...");
        action();
    }
}

function handleWhisperDownloadError(errMsg) {
    const modal = document.getElementById('modal-whisper-download');
    if (modal) modal.classList.remove('hidden');

    const errBox = document.getElementById('whisper-error-box');
    const errText = document.getElementById('whisper-error-msg');
    const btnStart = document.getElementById('btn-whisper-start');

    if (errBox && errText) {
        errText.innerText = errMsg || "Erro desconhecido durante o download.";
        errBox.classList.remove('hidden');
    }

    if (btnStart) {
        btnStart.disabled = false;
        btnStart.className = "px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md flex items-center space-x-2";
        btnStart.innerHTML = `<i data-lucide="refresh-cw" class="w-4 h-4"></i><span>Tentar Novamente</span>`;
    }

    if (window.lucide) lucide.createIcons();
}

let currentEditingTranscriptionMsgId = null;

async function transcribeAudioMessage(msgId, btn) {
    await ensureWhisperReady(async () => {
        await _doTranscribeAudioMessage(msgId, btn);
    });
}

async function _doTranscribeAudioMessage(msgId, btn) {
    if (!btn) btn = document.getElementById(`btn-transcribe-${msgId}`);
    const origHtml = btn ? btn.innerHTML : '';
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>Transcrevendo...</span>`;
        if (window.lucide) lucide.createIcons();
    }

    try {
        const res = await fetch(`/api/messages/${msgId}/transcribe`, { method: 'POST' });
        const data = await res.json();
        if (!res.ok || !data.success) {
            throw new Error(data.detail || 'Falha na transcrição');
        }

        const transData = data.data;

        // Atualizar no array local window.currentThreadMessages
        if (Array.isArray(window.currentThreadMessages)) {
            const idx = window.currentThreadMessages.findIndex(x => x.id === msgId);
            if (idx !== -1) {
                window.currentThreadMessages[idx].transcription = transData.transcription;
                window.currentThreadMessages[idx].transcription_status = transData.transcription_status;
                window.currentThreadMessages[idx].transcribed_by = transData.transcribed_by;
                window.currentThreadMessages[idx].transcribed_at = transData.transcribed_at;
            }
        }

        // Atualizar contador do cabeçalho
        const threadAudios = (window.currentThreadMessages || []).filter(m => m.message_type === 'audio');
        const pendingAudios = threadAudios.filter(m => !m.transcription || !m.transcription.trim());
        const badgePendingAudios = document.getElementById('dm-pending-audios-count');
        if (badgePendingAudios) {
            badgePendingAudios.innerText = `(${pendingAudios.length}/${threadAudios.length})`;
        }

        // Re-renderizar mensagens mantendo a posição exata de scroll
        renderDmChatMessages(null, true);

    } catch (err) {
        console.error("Erro na transcrição:", err);
        alert("Erro ao transcrever áudio: " + err.message);
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = origHtml;
            if (window.lucide) lucide.createIcons();
        }
    }
}

function copyTranscriptionText(msgId) {
    let textEl = document.getElementById(`transcription-text-${msgId}`);
    if (!textEl) {
        textEl = document.getElementById(`report-trans-text-${msgId}`);
    }
    if (!textEl) return;
    const raw = textEl.innerText.replace(/^"|"$/g, '').trim();
    navigator.clipboard.writeText(raw).then(() => {
        alert("Transcrição copiada para a área de transferência!");
    });
}

function openEditTranscriptionModal(msgId) {
    currentEditingTranscriptionMsgId = msgId;
    let msg = (window.currentThreadMessages || []).find(x => x.id === msgId);
    if (!msg && Array.isArray(window.currentGalleryMediaItems)) {
        msg = window.currentGalleryMediaItems.find(x => x.id === msgId);
    }
    if (!msg && window.currentReportMessagesMap && window.currentReportMessagesMap[msgId]) {
        msg = window.currentReportMessagesMap[msgId];
    }
    const textarea = document.getElementById('edit-transcription-textarea');
    if (textarea) {
        textarea.value = msg ? (msg.transcription || '') : '';
    }
    const modal = document.getElementById('modal-edit-transcription');
    if (modal) {
        modal.classList.remove('hidden');
        if (textarea) textarea.focus();
    }
    if (window.lucide) lucide.createIcons();
}

function closeEditTranscriptionModal() {
    const modal = document.getElementById('modal-edit-transcription');
    if (modal) modal.classList.add('hidden');
    currentEditingTranscriptionMsgId = null;
}

async function saveEditedTranscription() {
    if (!currentEditingTranscriptionMsgId) return;
    const textarea = document.getElementById('edit-transcription-textarea');
    const newText = textarea ? textarea.value.trim() : '';
    if (!newText) {
        alert("O texto da transcrição não pode ser vazio.");
        return;
    }

    const btn = document.getElementById('btn-save-edit-transcription');
    const origHtml = btn ? btn.innerHTML : '';
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span>Salvando...</span>`;
    }

    try {
        const res = await fetch(`/api/messages/${currentEditingTranscriptionMsgId}/transcription`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ transcription: newText })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
            throw new Error(data.detail || 'Falha ao salvar');
        }

        // Atualizar no array local da conversa
        if (Array.isArray(window.currentThreadMessages)) {
            const idx = window.currentThreadMessages.findIndex(x => x.id === currentEditingTranscriptionMsgId);
            if (idx !== -1) {
                window.currentThreadMessages[idx].transcription = newText;
                window.currentThreadMessages[idx].transcription_status = 'edited';
                window.currentThreadMessages[idx].transcribed_by = 'analyst';
            }
        }

        // Atualizar no array da galeria se presente
        if (Array.isArray(window.currentGalleryMediaItems)) {
            const gIdx = window.currentGalleryMediaItems.findIndex(x => x.id === currentEditingTranscriptionMsgId);
            if (gIdx !== -1) {
                window.currentGalleryMediaItems[gIdx].transcription = newText;
                window.currentGalleryMediaItems[gIdx].transcription_status = 'edited';
                window.currentGalleryMediaItems[gIdx].transcribed_by = 'analyst';
                const galleryBox = document.getElementById(`gallery-trans-container-${currentEditingTranscriptionMsgId}`);
                if (galleryBox) {
                    galleryBox.outerHTML = renderGalleryAudioTranscriptionBox(window.currentGalleryMediaItems[gIdx], currentMediaSearch);
                    if (window.lucide) lucide.createIcons();
                }
            }
        }

        // Atualizar no card do relatório pericial se estiver aberto
        const reportTransEl = document.getElementById(`report-trans-text-${currentEditingTranscriptionMsgId}`);
        if (reportTransEl) {
            reportTransEl.innerHTML = `"${escapeHtml(newText)}"`;
        }
        if (window.currentReportMessagesMap && window.currentReportMessagesMap[currentEditingTranscriptionMsgId]) {
            window.currentReportMessagesMap[currentEditingTranscriptionMsgId].transcription = newText;
            window.currentReportMessagesMap[currentEditingTranscriptionMsgId].transcription_status = 'edited';
            window.currentReportMessagesMap[currentEditingTranscriptionMsgId].transcribed_by = 'analyst';
        }

        closeEditTranscriptionModal();

        // Re-renderizar mensagens do chat mantendo a posição exata de scroll
        renderDmChatMessages(null, true);

    } catch (err) {
        console.error("Erro ao salvar revisão:", err);
        alert("Erro ao salvar revisão: " + err.message);
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = origHtml;
            if (window.lucide) lucide.createIcons();
        }
    }
}

async function transcribeCurrentThreadAudios() {
    await ensureWhisperReady(async () => {
        await _doTranscribeCurrentThreadAudios();
    });
}

async function _doTranscribeCurrentThreadAudios() {
    if (!currentSelectedThreadId || !currentOpId) {
        alert("Nenhuma conversa selecionada.");
        return;
    }

    const threadAudios = (window.currentThreadMessages || []).filter(m => m.message_type === 'audio');
    const pending = threadAudios.filter(m => !m.transcription || !m.transcription.trim());
    if (pending.length === 0) {
        alert("Todos os áudios desta conversa já foram transcritos!");
        return;
    }

    const confirmRun = confirm(`Deseja transcrever ${pending.length} áudios pendentes desta conversa com Whisper?`);
    if (!confirmRun) return;

    const btn = document.getElementById('btn-transcribe-thread-audios');
    const origHtml = btn ? btn.innerHTML : '';
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<i data-lucide="loader-2" class="w-3.5 h-3.5 animate-spin"></i><span>Transcrevendo ${pending.length}...</span>`;
        if (window.lucide) lucide.createIcons();
    }

    try {
        const res = await fetch(`/api/threads/${currentSelectedThreadId}/transcribe-all?operation_id=${currentOpId}`, {
            method: 'POST'
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
            throw new Error(data.detail || 'Falha no processamento em lote');
        }

        alert(`Transcrição concluída! ${data.data.transcribed_count} áudios transcritos com sucesso.`);
        await selectDmThread(currentSelectedThreadId, currentSelectedParticipant, null, false);

    } catch (err) {
        console.error("Erro no lote de transcrição:", err);
        alert("Erro no lote: " + err.message);
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = origHtml;
            if (window.lucide) lucide.createIcons();
        }
    }
}

window.transcribeAudioMessage = transcribeAudioMessage;
window.copyTranscriptionText = copyTranscriptionText;
window.openEditTranscriptionModal = openEditTranscriptionModal;
window.closeEditTranscriptionModal = closeEditTranscriptionModal;
window.saveEditedTranscription = saveEditedTranscription;
window.transcribeCurrentThreadAudios = transcribeCurrentThreadAudios;
window.transcribeAllGalleryAudios = transcribeAllGalleryAudios;
window.transcribeGallerySingleAudio = transcribeGallerySingleAudio;
window.copyTranscriptionDirect = copyTranscriptionDirect;
window.updateGalleryPendingAudiosCount = updateGalleryPendingAudiosCount;
window.setGlobalAudioSpeed = setGlobalAudioSpeed;
window.cycleGlobalAudioSpeed = cycleGlobalAudioSpeed;
window.toggleAudioSpeed = toggleAudioSpeed;
window.changeMediaSortOrder = changeMediaSortOrder;
window.attachChatContinuousAudio = attachChatContinuousAudio;
window.attachGalleryContinuousAudio = attachGalleryContinuousAudio;
window.playAutoplayTransitionSound = playAutoplayTransitionSound;
window.navigateDmSearchMatch = navigateDmSearchMatch;
window.closeDmChatSearch = closeDmChatSearch;

// Controles do Gerenciador de Download do Whisper
window.openWhisperModal = openWhisperModal;
window.minimizeWhisperDownload = minimizeWhisperDownload;
window.closeWhisperModal = closeWhisperModal;
window.startWhisperDownload = startWhisperDownload;
window.ensureWhisperReady = ensureWhisperReady;
window.updateWhisperUI = updateWhisperUI;
window.checkWhisperStatus = checkWhisperStatus;



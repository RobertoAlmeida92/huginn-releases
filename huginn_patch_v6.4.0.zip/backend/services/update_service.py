﻿import os
import sys
import json
import hmac
import hashlib
import zipfile
import shutil
import urllib.request
import logging
from datetime import datetime
from typing import Dict, Any, Optional, Tuple

from backend.config import APP_DIR, BUNDLE_DIR, STATIC_DIR

logger = logging.getLogger(__name__)

# Versão atual do Huginn
CURRENT_VERSION = "6.3.0"

# Segredo criptográfico mestre para validação de autenticidade dos patches
_RELEASE_SECRET = b"MetaAnalise_Forensic_Cryptographic_License_Secret_2026_Key"

# URL do manifesto de atualizações no GitHub
DEFAULT_UPDATE_MANIFEST_URL = os.environ.get(
    "HUGINN_UPDATE_URL",
    "https://raw.githubusercontent.com/huginn-forensics/huginn/main/version.json"
)

class UpdateService:
    @classmethod
    def get_current_version(cls) -> str:
        return CURRENT_VERSION

    @classmethod
    def generate_patch_signature(cls, zip_bytes: bytes) -> Dict[str, str]:
        """Gera o hash SHA-256 e a assinatura criptográfica para publicação de release."""
        actual_sha = hashlib.sha256(zip_bytes).hexdigest().lower()
        sig = hmac.new(_RELEASE_SECRET, actual_sha.encode("utf-8"), hashlib.sha256).hexdigest().upper()
        return {
            "sha256": actual_sha,
            "signature": sig
        }

    @classmethod
    def verify_patch_signature(cls, zip_bytes: bytes, expected_sig: str, expected_sha: str) -> Tuple[bool, str]:
        """Valida se o ZIP não foi adulterado e se foi assinado legitimamente com a chave mestra."""
        actual_sha = hashlib.sha256(zip_bytes).hexdigest().lower()
        if actual_sha != expected_sha.strip().lower():
            return False, f"Hash SHA-256 divergente! Esperado: {expected_sha}, Obtido: {actual_sha}"

        calculated_sig = hmac.new(_RELEASE_SECRET, actual_sha.encode("utf-8"), hashlib.sha256).hexdigest().upper()
        if not hmac.compare_digest(calculated_sig, expected_sig.strip().upper()):
            return False, "Assinatura criptográfica do patch inválida! Pacote rejeitado por segurança."

        return True, "Assinatura e integridade validadas com sucesso."

    @classmethod
    def check_for_updates(cls, manifest_url: Optional[str] = None) -> Dict[str, Any]:
        """Consulta o servidor GitHub para verificar se há uma nova versão disponível."""
        url = manifest_url or DEFAULT_UPDATE_MANIFEST_URL
        try:
            req = urllib.request.Request(url)
            req.add_header("User-Agent", f"Huginn-Forensics-Client/{CURRENT_VERSION}")
            req.add_header("Cache-Control", "no-cache")

            with urllib.request.urlopen(req, timeout=6) as res:
                if res.getcode() == 200:
                    data = json.loads(res.read().decode("utf-8"))
                    remote_ver = data.get("version", "").strip()
                    
                    has_update = cls._is_newer_version(remote_ver, CURRENT_VERSION)
                    return {
                        "success": True,
                        "current_version": CURRENT_VERSION,
                        "latest_version": remote_ver,
                        "has_update": has_update,
                        "release_date": data.get("release_date", ""),
                        "download_url": data.get("download_url", ""),
                        "sha256": data.get("sha256", ""),
                        "signature": data.get("signature", ""),
                        "changelog": data.get("changelog", []),
                        "mandatory": data.get("mandatory", False)
                    }
        except Exception as e:
            logger.info(f"Checagem de atualização offline ou indisponível: {e}")
            return {
                "success": False,
                "current_version": CURRENT_VERSION,
                "has_update": False,
                "message": f"Servidor de atualizações inacessível: {str(e)}"
            }

    @staticmethod
    def _is_newer_version(remote: str, local: str) -> bool:
        """Compara versões semânticas (ex: 6.4.0 > 6.3.0)."""
        try:
            r_parts = [int(p) for p in remote.split(".")]
            l_parts = [int(p) for p in local.split(".")]
            return r_parts > l_parts
        except Exception:
            return remote > local

    @classmethod
    def apply_update_from_url(cls, download_url: str, expected_sha: str, expected_sig: str) -> Dict[str, Any]:
        """
        Baixa o patch leve, valida hash e assinatura, realiza backup e aplica os arquivos.
        Protegido contra Zip-Slip e com blindagem dos bancos de dados locais.
        """
        if not download_url.startswith("https://"):
            return {"success": False, "message": "O download deve utilizar conexão criptografada HTTPS segura."}

        temp_dir = os.path.join(APP_DIR, ".update_tmp")
        try:
            req = urllib.request.Request(download_url)
            req.add_header("User-Agent", f"Huginn-Forensics-Client/{CURRENT_VERSION}")
            with urllib.request.urlopen(req, timeout=40) as res:
                if res.getcode() != 200:
                    return {"success": False, "message": f"Falha ao baixar o pacote de atualização (HTTP {res.getcode()})."}
                zip_bytes = res.read()

            # 1. Validação Criptográfica Rigorosa
            valid, msg = cls.verify_patch_signature(zip_bytes, expected_sig, expected_sha)
            if not valid:
                logger.error(f"[SECURITY AUDIT] Atualização bloqueada: {msg}")
                return {"success": False, "message": f"Falha de segurança no pacote: {msg}"}

            # 2. Salvar pacote temporário
            os.makedirs(temp_dir, exist_ok=True)
            temp_zip = os.path.join(temp_dir, "patch.zip")
            with open(temp_zip, "wb") as f:
                f.write(zip_bytes)

            # 3. Auditoria de Segurança Anti Zip-Slip e Proteção de Bancos
            with zipfile.ZipFile(temp_zip, "r") as zf:
                for member in zf.namelist():
                    norm = os.path.normpath(member)
                    if norm.startswith("..") or os.path.isabs(norm):
                        return {"success": False, "message": f"Arquivo rejeitado por segurança (Path Traversal): {member}"}
                    # Protege expressamente bancos de dados e chaves de licença
                    if norm.endswith(".db") or norm.endswith(".sqlite") or norm.endswith(".dat"):
                        return {"success": False, "message": f"Tentativa de alteração de arquivo crítico bloqueada: {member}"}

                # 4. Criar Backup Preventivo da pasta atual
                backup_dir = os.path.join(APP_DIR, ".backups", f"rollback_pre_update_{int(datetime.now().timestamp())}")
                os.makedirs(backup_dir, exist_ok=True)

                target_backend = os.path.join(APP_DIR, "backend")
                if os.path.exists(target_backend):
                    shutil.copytree(target_backend, os.path.join(backup_dir, "backend"), dirs_exist_ok=True)

                # 5. Extrair arquivos de atualização
                target_dirs = [APP_DIR]
                if BUNDLE_DIR and BUNDLE_DIR != APP_DIR and os.path.exists(BUNDLE_DIR):
                    target_dirs.append(BUNDLE_DIR)

                for t_dir in target_dirs:
                    zf.extractall(t_dir)

            return {
                "success": True,
                "message": "Huginn atualizado com sucesso! Reinicie a aplicação para usufruir de todas as melhorias.",
                "backup_path": backup_dir
            }
        except Exception as e:
            logger.exception("Erro crítico durante a aplicação do patch:")
            return {"success": False, "message": f"Erro ao aplicar atualização: {str(e)}"}
        finally:
            if os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir, ignore_errors=True)
                except Exception:
                    pass

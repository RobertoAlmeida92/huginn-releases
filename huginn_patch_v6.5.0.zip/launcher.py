import os
import sys
import time
import socket
import threading
import subprocess
import webbrowser
import uvicorn

# Proteção robusta contra falhas de escrita caso executado sem console (console=False)
if sys.stdout is None:
    try:
        sys.stdout = open(os.devnull, 'w', encoding='utf-8')
    except Exception:
        class _FullNullStream:
            def write(self, s): pass
            def flush(self): pass
            def isatty(self): return False
            encoding = 'utf-8'
        sys.stdout = _FullNullStream()

if sys.stderr is None:
    try:
        sys.stderr = open(os.devnull, 'w', encoding='utf-8')
    except Exception:
        class _FullNullStream:
            def write(self, s): pass
            def flush(self): pass
            def isatty(self): return False
            encoding = 'utf-8'
        sys.stderr = _FullNullStream()

# Adiciona o diretorio base ao sys.path para importacoes
if getattr(sys, 'frozen', False):
    app_base = os.path.dirname(sys.executable)
    if hasattr(sys, '_MEIPASS'):
        sys.path.insert(0, sys._MEIPASS)
else:
    app_base = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, app_base)

def is_port_available(port: int) -> bool:
    # 1. Tentar conectar: se responder, significa que outro programa esta escutando na porta
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.2)
            if s.connect_ex(('127.0.0.1', port)) == 0:
                return False
    except Exception:
        pass

    # 2. Tentar bind em todas as interfaces
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('0.0.0.0', port))
            return True
    except OSError:
        return False

def find_available_port(start_port: int = 8000, max_attempts: int = 20) -> int:
    for p in range(start_port, start_port + max_attempts):
        if is_port_available(p):
            return p
    return start_port

def wait_for_server(port: int, timeout: float = 25.0) -> bool:
    """Aguarda ativamente até que o servidor FastAPI/Uvicorn esteja escutando na porta especificada."""
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.2)
                if s.connect_ex(('127.0.0.1', port)) == 0:
                    return True
        except Exception:
            pass
        time.sleep(0.2)
    return False

def open_desktop_window_fallback(port: int):
    """
    Fallback de contingência caso o componente WebView2 nativo não esteja disponível
    em máquinas legadas, abrindo em modo janela de aplicativo (--app).
    """
    url = f'http://127.0.0.1:{port}'
    app_profile = os.path.join(os.environ.get('TEMP', os.path.expanduser('~')), 'huginn_app_profile')

    edge_paths = [
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%LocalAppData%\Microsoft\Edge\Application\msedge.exe"),
    ]
    chrome_paths = [
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
    ]

    for browser_exe in edge_paths + chrome_paths:
        if os.path.exists(browser_exe):
            try:
                subprocess.Popen([
                    browser_exe,
                    f"--app={url}",
                    f"--user-data-dir={app_profile}",
                    "--no-first-run",
                    "--no-default-browser-check",
                    "--window-size=1440,900",
                    "--start-maximized"
                ])
                return
            except Exception:
                pass

    try:
        webbrowser.open(url)
    except Exception:
        pass

def check_existing_instance(port: int = 8000) -> bool:
    """Verifica se já existe uma instância do Huginn respondendo com saúde."""
    import urllib.request
    try:
        req = urllib.request.Request(f'http://127.0.0.1:{port}/api/system/check-update', headers={'User-Agent': 'HuginnLauncher'})
        with urllib.request.urlopen(req, timeout=0.8) as resp:
            if resp.status == 200:
                return True
    except Exception:
        pass
    return False

if __name__ == '__main__':
    from backend.config import UPLOAD_DIR, MEDIA_BASE_DIR, DB_PATH
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs(MEDIA_BASE_DIR, exist_ok=True)

    port = 8000
    is_running = check_existing_instance(port)

    server = None
    server_thread = None

    if not is_running:
        port = find_available_port(start_port=8000)
        import uvicorn
        from backend.main import app

        def run_uvicorn():
            global server
            config = uvicorn.Config(app, host='127.0.0.1', port=port, log_config=None, log_level='warning')
            server = uvicorn.Server(config)
            server.run()

        server_thread = threading.Thread(target=run_uvicorn, daemon=True)
        server_thread.start()

        if not wait_for_server(port, timeout=25.0):
            print(f"[ERRO] Falha ao iniciar o servidor local na porta {port}.")
            sys.exit(1)

    url = f'http://127.0.0.1:{port}'

    # Iniciar Janela Nativa Embutida via pywebview (Edge WebView2)
    use_native_window = True
    try:
        import webview

        window = webview.create_window(
            title='Huginn — Plataforma de Inteligência & Análise Telemática',
            url=url,
            width=1440,
            height=900,
            min_size=(1024, 650),
            confirm_close=False,
            text_select=True
        )

        def on_window_closed():
            if server:
                server.should_exit = True

        window.events.closed += on_window_closed

        # webview.start bloqueia a thread principal até o fechamento da janela no "X"
        webview.start(gui='edgechromium', debug=False)

    except Exception as e:
        use_native_window = False
        # Em caso de falha de inicialização do WebView2, aciona o fallback
        open_desktop_window_fallback(port)
        if server_thread:
            server_thread.join()

    # Encerra o servidor FastAPI/Uvicorn e libera recursos do SO
    if server:
        server.should_exit = True
    sys.exit(0)
